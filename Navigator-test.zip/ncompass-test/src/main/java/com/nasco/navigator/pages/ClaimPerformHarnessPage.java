package com.nasco.navigator.pages;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.nasco.navigator.Setup.BasePage;

@SuppressWarnings({"rawtypes"})
public class ClaimPerformHarnessPage extends BasePage{

	@FindBy(xpath = "//div[text()='Navigator ID:']")
	WebElement navigatorID;
	
	public ArrayList<String> getClaimDetails()
	{
		driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
		ArrayList<String> claimDetails = new ArrayList<String>();
		for(int i=1;i<=20;i++)
		{
			claimDetails.add(driver.findElement(By.xpath("(//span[contains(@class,'field-caption dataLabelForRead')])["+i+"]")).getText());
		}
		return claimDetails;
	}
	
	public void claimDetails(Hashtable<String, String> data,ArrayList<String> claimDetails)
	{
		String messageString="";
		for(int i=0;i<claimDetails.size();i++)
		{
			messageString=messageString+","+claimDetails.get(i);
			
		}
		assertEquals(data.get("ClaimHeaderDetails"),messageString,"Claim Header Details");
	}
	
	public ArrayList<String> claimProcessiongActions(Hashtable<String, String> data)
	{
		driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
		driver.findElement(By.xpath("(//button[contains(@name,'WorkObjectHeader_pyWorkPage')])[2]")).click();
		wait(3500);
		ArrayList<String> claimActions = new ArrayList<String>();
		List<WebElement> claimactions =driver.findElements(By.xpath("//ul[contains(@class,'menu menu-format-header-menu menu-regular')]/li/a"));
		for(int i=1;i<=claimactions.size();i++)
		{
			claimActions.add(driver.findElement(By.xpath("(//ul[contains(@class,'menu menu-format-header-menu menu-regular')]/li/a)["+i+"]")).getText());
		}
		String messageString="";
		for(int i=0;i<claimActions.size();i++)
		{
			messageString=messageString+","+claimActions.get(i);
		}
		assertEquals(data.get("ClaimProcessingActions"),messageString,"Claim Processing Actions");
		return claimActions;
	}
	
	public void claimProcessing(Hashtable<String, String> data)
	{
		driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
		String processingAction=driver.findElement(By.xpath("//span[contains(text(),'Alpha Prefix')]//following::label[1]")).getText();
		driver.findElement(By.xpath("(//button[contains(@name,'WorkObjectHeader_pyWorkPage')])[2]")).click();
		wait(3500);
		ArrayList<String> claimDetails = new ArrayList<String>();
		List<WebElement> claimdetails =driver.findElements(By.xpath("//ul[contains(@class,'menu menu-format-header-menu menu-regular')]/li/a"));
		for(int i=1;i<=claimdetails.size();i++)
		{
			claimDetails.add(driver.findElement(By.xpath("(//ul[contains(@class,'menu menu-format-header-menu menu-regular')]/li/a)["+i+"]")).getText());
		}
		for(int i=1;i<claimdetails.size();i++)
		{
			String ICN="";
			if(i>1)
			{
				ICN=driver.findElement(By.xpath("//div[contains(text(),'ICN:')]//following::label[1]")).getText();
				driver.findElement(By.xpath("(//button[contains(@name,'WorkObjectHeader_pyWorkPage')])[2]")).click();
				wait(1500);
			}
			WebElement text=driver.findElement(By.xpath("(//ul[contains(@class,'menu menu-format-header-menu menu-regular')]/li/a)["+(i+1)+"]"));
			if(text.getText().equals(claimDetails.get(i)))
			{
				text.click();
				wait(2500);
				processingAction=driver.findElement(By.xpath("//span[contains(text(),'Alpha Prefix')]//following::label[1]")).getText();
				String message="";
				if(processingAction.equals("Put on Hold"))
				{
					Select holdReasons= new Select(driver.findElement(By.xpath("//select[contains(@name,'$PpyWorkPage$pReasonID')]")));
					List<WebElement> options= holdReasons.getOptions();
					for(WebElement item:options) 
			        { 
						claimDetails.add(item.getText());
						message=message+","+item.getText();
			         }
					assertEquals(data.get("HoldReasons"),message,"Hold Reasons");
				
				if(data.get("ROUTINGACTIONS").equals("Y"))
				{
					wait(2500);
					holdReasons.selectByIndex(1);
					claimProcessingActions( processingAction, ICN);
				}
				
				
				}
				
				if(processingAction.equals("Route to External Team"))
				{
					try{
						Select holdReasons= new Select(driver.findElement(By.xpath("//select[contains(@name,'$PpyWorkPage$pRouteExternalTeam')]")));
						message="";
						List<WebElement> options= holdReasons.getOptions();
						for(WebElement item:options) 
				        { 
							claimDetails.add(item.getText());
							message=message+","+item.getText();          
				         }
						assertEquals(data.get("ExternalTeam"),message,"Route to External Team options");
						if(data.get("ROUTINGACTIONS").equals("Y"))
						{
							wait(2500);
							holdReasons.selectByIndex(1);
							claimProcessingActions( processingAction, ICN);
						}
					}
					catch(Exception e)
					{
						
					}
				}
				
				if(processingAction.equals("Route to Team Lead"))
				{
					try{
						Select holdReasons= new Select(driver.findElement(By.xpath("//select[contains(@name,'$PpyWorkPage$pReassignOperator')]")));
						message="";
						List<WebElement> options= holdReasons.getOptions();
						for(WebElement item:options) 
				        { 
							claimDetails.add(item.getText());
							message=message+","+item.getText();           
				        }
						assertEquals(data.get("TeamLead"),message,"Route to Team Lead options");
						if(data.get("ROUTINGACTIONS").equals("Y"))
						{
							wait(2500);
							holdReasons.selectByIndex(1);
							claimProcessingActions( processingAction, ICN);
						}
					}
					catch(Exception e)
					{
						
					}
				}
				
				if(processingAction.equals("Route to Business Analyst"))
				{
					try{
						Select holdReasons= new Select(driver.findElement(By.xpath("//select[contains(@name,'$PpyWorkPage$pReassignOperator')]")));
						message="";
						List<WebElement> options= holdReasons.getOptions();
						for(WebElement item:options) 
				        { 
							claimDetails.add(item.getText());
							message=message+","+item.getText();           
				        }
						assertEquals(data.get("BAOptions"),message,"Route to BA options");
						if(data.get("ROUTINGACTIONS").equals("Y"))
						{
							wait(2500);
							holdReasons.selectByIndex(1);
							claimProcessingActions( processingAction, ICN);
						}
					}
					catch(Exception e)
					{
						
					}
				}
			}
		}
	}
	
	public void claimProcessingActions(String processingAction,String ICN)
	{
		wait(2500);
		driver.findElement(By.name("$PpyWorkPage$ppyNote")).sendKeys("Testing "+processingAction);
		driver.findElement(By.xpath("//textarea[contains(@name,'$PpyWorkPage$ppyNote')]//following::button")).click();
		wait(2500);
		
	}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		try{
			switchToFrame("PegaGadget1Ifr");
			return ExpectedConditions.visibilityOf(navigatorID);
		}catch(Exception e)
		{
			throw e;
		}
	}

}
