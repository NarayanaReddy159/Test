package com.nasco.navigator.Base;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.nasco.navigator.Run.RunTestNG_Navigator;
import com.nasco.navigator.utilities.DriverFactory;
import com.nasco.navigator.utilities.DriverManager;

import io.github.bonigarcia.wdm.WebDriverManager;
public class BaseTest {
	
	private WebDriver driver;
	public static Logger log = LogManager.getLogger(BaseTest.class.getName());
	private String defaultUserName;
	private String defaultPassword;	
    public static JavascriptExecutor js;
    protected ExtentTest test;
	public String getDefaultUserName() {
		return defaultUserName;
	}

	public void setDefaultUserName(String defaultUserName) {
		this.defaultUserName = defaultUserName;
	}


	public String getDefaultPassword() {
		return defaultPassword;
	}

	public void setDefaultPassword(String defaultPassword) {
		this.defaultPassword = defaultPassword;
	}

	@BeforeSuite
	public void beforeSuite(){
		PropertyConfigurator.configure("log4j.properties");
	}
	
	public void setUpFramework() {
		DriverFactory.setChromeDriverExePath(System.getProperty("user.dir") + RunTestNG_Navigator.Config.getProperty("ChromeDriver"));
		DriverFactory.setIeDriverExePath(System.getProperty("user.dir") + RunTestNG_Navigator.Config.getProperty("IEDriver"));
	}
	
	
	public void extentLogWarning(String message) {
		
		test.log(Status.WARNING, message);
	}

	public void configureLog4jLogging() {
		System.setProperty("log4j.configurationFile", System.getProperty("user.dir")+RunTestNG_Navigator.Config.getProperty("log4jPropertiesFilepath"));
	}

	//@SuppressWarnings("deprecation")
	public void openBrowser(String browser) {
		

		if (browser.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("profile.default_content_setting_values.notifications", 2);
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("prefs", prefs);
			options.addArguments("--disable-extensions");
			options.addArguments("--disable-infobars");
			options.addArguments("user-data-dir=C:\\Users\\N3AA86\\AppData\\Local\\Google\\Chrome\\User Data");
			log.info("Launching Chrome");	
			driver = new ChromeDriver(options);
			((JavascriptExecutor)driver).executeScript("document.body.style.zoom='80%';");
		} else if (browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			log.info("Launching firefox");
		} else if (browser.equalsIgnoreCase("ie")){
			WebDriverManager.iedriver().setup();
			InternetExplorerOptions options = new InternetExplorerOptions();
			options.ignoreZoomSettings();
			options.setCapability("nativeEvents",false);
			options.introduceFlakinessByIgnoringSecurityDomains();
			options.setCapability("disable-popup-blocking", true);
			driver = new InternetExplorerDriver(options);
			((JavascriptExecutor)driver).executeScript("document.body.style.zoom='80%';");
		}else if (browser.equalsIgnoreCase("edge")){
			WebDriverManager.edgedriver().setup();
			EdgeOptions options = new EdgeOptions();
			options.setCapability("inprivate", true);
			driver = new EdgeDriver(options);
			
		}else if (browser.equalsIgnoreCase("chromium")){
			WebDriverManager.chromiumdriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.setBinary(RunTestNG_Navigator.Config.getProperty("Chromium_Path"));
			driver = new ChromeDriver(options);
			
		}

		DriverManager.setWebDriver(driver);
		log.info("Driver Initialized !!!");
		DriverManager.getDriver().manage().window().maximize();
		DriverManager.getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		setDefaultUserName(RunTestNG_Navigator.Config.getProperty("opsAdmUser"));
		setDefaultPassword(RunTestNG_Navigator.Config.getProperty("opsAdmPassword"));
	}

	public void quit() throws Exception {
		try {
			Thread.sleep(2000);
			DriverManager.getDriver().quit();
			log.info("Test Execution Completed !!!");
		} 
		catch (Exception e) {
            e.printStackTrace();
            String excepionMessage = Arrays.toString(e.getStackTrace());
            BaseTest.log.error("Not able to quit the browser " + excepionMessage);
            test.log(Status.FAIL, "Not able to quit the browser " + e);
            throw e;
		}

	}
	
	

}
