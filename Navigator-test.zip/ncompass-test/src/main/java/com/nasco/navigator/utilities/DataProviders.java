package com.nasco.navigator.utilities;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;

import com.nasco.navigator.Run.RunTestNG_Navigator;

public class DataProviders {

	@DataProvider(name = "Navaigator_DP", parallel = false)
	public static Object[][] getDataG1(Method m) {

		if(RunTestNG_Navigator.runCount>0)
		{
			int rowsSize=RunTestNG_Navigator.failedData.get(m.getName()).size();
			Object[][] datautil= new Object[rowsSize][1];
			for(int i=0;i<rowsSize;i++)
			{
				datautil[i][0]=RunTestNG_Navigator.failedData.get(m.getName()).get(i);
			}
			return datautil;
		}else{
			ExcelReader excel = new ExcelReader(
					System.getProperty("user.dir") + RunTestNG_Navigator.Config.getProperty("TestData_HZ_XL_PATH"));
			String testcase = m.getName();
			 return DataUtil.getData(testcase, excel);
		}
	}

}
