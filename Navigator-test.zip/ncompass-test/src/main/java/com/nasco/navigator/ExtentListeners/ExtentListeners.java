package com.nasco.navigator.ExtentListeners;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.nasco.navigator.Run.RunFailed_Navigator;
import com.nasco.navigator.Run.RunTestNG_Navigator;
import com.nasco.navigator.utilities.DriverManager;
import com.nasco.navigator.utilities.EmailHTMLBuilder;
import com.nasco.navigator.utilities.EmailHTMLBuilder_Body;
//import com.nasco.navigator.utilities.EmailUtil;
import com.nasco.navigator.utilities.FileUtil;

public class ExtentListeners implements ITestListener {

	static Date d = new Date();
	static String fileName = "Extent_" + d.toString().replace(":", "_").replace(" ", "_") + ".html";
	Set<String> failedTc = new LinkedHashSet<String>();
	Map<String, List<String>> results = new HashMap<String, List<String>>();
	String status = "";
	String extentFilepath = System.getProperty("user.dir")
			+ RunTestNG_Navigator.Config.getProperty("EXTREPORT_LOC");
	public String timeStamp = new SimpleDateFormat("MM-dd-yyyy").format(Calendar.getInstance().getTime());
	public String timeStamp_email = timeStamp;
	EmailHTMLBuilder htmlbuilder_Summary = new EmailHTMLBuilder();
	EmailHTMLBuilder_Body htmlbuilder = new EmailHTMLBuilder_Body();
	DecimalFormat df = new DecimalFormat("###.##");
	String defectsListFile = System.getProperty("user.dir")
			+ RunTestNG_Navigator.Config.getProperty("DEFECTSLISTFILE_LOC");

	public static ExtentReports extent = ExtentManager.getInstance();
	public static ExtentReports extent1 = ExtentManager.getFailureInstance();
	public static ThreadLocal<ExtentTest> testReport = new ThreadLocal<ExtentTest>();
	public static ThreadLocal<ExtentTest> testReport1 = new ThreadLocal<ExtentTest>();

	long diff = 0;
	long diffMinutes = 0;
	long diffSeconds = 0;
	long diffHours = 0;

	String starttime = "";
	String endTime = "";
	List<ExtentTest> testList = new ArrayList<>();

	public void onTestStart(ITestResult result) {
		ExtentTest test;
		if (RunTestNG_Navigator.runCount > 0) {
			test = extent1.createTest("TestCase : " + result.getMethod().getMethodName());
			DriverManager.setExtentReport(test);
			testReport1.set(DriverManager.getExtentReport());
		} else {
			try {
				File f = new File(defectsListFile);
				f.delete();

			} catch (Exception e) {

			}
			test = extent.createTest("TestCase : " + result.getMethod().getMethodName());
			DriverManager.setExtentReport(test);
			testReport.set(DriverManager.getExtentReport());
			testList.add(test);
		}
	}

	public void onTestSuccess(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		if (RunTestNG_Navigator.runCount > 0) {
			testReport1.get().log(Status.PASS, methodName + " Test Case Passed");
			resultStatus(result, methodName, "Pass");

		} else {
			testReport.get().log(Status.PASS, methodName + " Test Case Passed");
			resultStatus(result, methodName, "Pass");
		}

		RunTestNG_Navigator.pass++;
		System.out.println("Pass: " + RunTestNG_Navigator.pass + " Fail: " + RunTestNG_Navigator.fail);
	}

	public void onTestFailure(ITestResult result) {
		RunTestNG_Navigator.fail++;
		System.out.println("Pass: "+RunTestNG_Navigator.pass+" Fail: "+RunTestNG_Navigator.fail);
		String excepionMessage = Arrays.toString(result.getThrowable().getStackTrace());
		String methodName = result.getMethod().getMethodName();
		System.out.println(methodName);
		if(RunTestNG_Navigator.runCount>0)
		{
			if (!excepionMessage.isEmpty())
				testReport1.get().log(Status.FAIL, excepionMessage);
			
			try {
				ExtentManager.captureScreenshot(methodName);
				testReport1.get().addScreenCaptureFromPath(ExtentManager.screenshotName).fail("<b><font color=red> Screen shot of failure</font></b>",MediaEntityBuilder.createScreenCaptureFromPath(ExtentManager.screenshotName).build());
				} catch (Exception e) {
				e.printStackTrace();
			}
			testReport1.get().log(Status.FAIL, methodName + " Test Case Failed");
			resultStatus(result, methodName, "Fail");
			RunTestNG_Navigator.failedMethods.add(methodName);
		}
		else{
			if (!excepionMessage.isEmpty())
				testReport.get().log(Status.FAIL, excepionMessage);
			if(!ExceptionUtils.getStackTrace(result.getThrowable()).contains("AssertionError")
					&&RunTestNG_Navigator.Config.getProperty("Rerun").toString().equalsIgnoreCase("Y"))
				{
				System.out.println(ExceptionUtils.getStackTrace(result.getThrowable()));
				for(int i=0;i<testList.size();i++)
				{
					if(testList.get(i).getModel().getName().contains(methodName) &&testList.get(i).getStatus().toString().equalsIgnoreCase("Fail"))
					{
						extent.removeTest(testList.get(i));
						failedTc.add(result.getTestClass().getName());
					}
				}
			}
			else{
				try {
					ExtentManager.captureScreenshot(methodName);
					testReport.get().addScreenCaptureFromPath(
							ExtentManager.screenshotName).fail("<b><font color=red> Screen shot of failure</font></b>",
							MediaEntityBuilder.createScreenCaptureFromPath(ExtentManager.screenshotName).build());
					} catch (Exception e) {
					e.printStackTrace();
				}
				
				testReport.get().log(Status.FAIL, methodName + " Test Case Failed");
				resultStatus(result, methodName, "Fail");
				RunTestNG_Navigator.failedMethods.add(methodName);
			}
			
			
			
	}
		
		
		
	}

	public void onTestSkipped(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		if (RunTestNG_Navigator.runCount > 0) {
			testReport1.get().log(Status.SKIP, methodName + " Test Case Skipped");

		} else {
			testReport.get().log(Status.SKIP, methodName + " Test Case Skipped");

		}

	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	public void onStart(ITestContext context) {
		if (RunTestNG_Navigator.runCount > 0) {
			// extent1.setSystemInfo("Environment",
			// RunTestNG_NCompass_HMHS.Config.getProperty("Environment"));

		} else {
			extent.setSystemInfo("User Name", System.getProperty("user.name").toUpperCase());
			extent.setSystemInfo("OS", System.getProperty("java.version"));
			extent.setSystemInfo("Java Version", System.getProperty("os.name"));
			try {
				extent.setSystemInfo("Host Name", InetAddress.getLocalHost().getHostName());
			} catch (UnknownHostException e) {
			}
			extent.setSystemInfo("Environment", RunTestNG_Navigator.Config.getProperty("Environment"));
			extent.setSystemInfo("Browser", RunTestNG_Navigator.Config.getProperty("Browser").toUpperCase());
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date date = new Date();
			starttime = formatter.format(date);
		}
	}

	@SuppressWarnings("unused")
	public void onFinish(ITestContext context) {

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("MMM");
		SimpleDateFormat dateFormat2 = new SimpleDateFormat("YYYY");
		SimpleDateFormat dateFormat3 = new SimpleDateFormat("MM");
		Date date = new Date();
		String reportsPath = RunTestNG_Navigator.Config.getProperty("Reports_Loc") + dateFormat2.format(date) + "/"
				+ dateFormat3.format(date) + "-" + dateFormat1.format(date).toUpperCase() + "/"
				+ dateFormat.format(date);
		endTime = formatter.format(date);
		Date startDate = null;
		Date endDate = null;
		try {
			startDate = formatter.parse(starttime);
			endDate = formatter.parse(endTime);

		} catch (ParseException e) {

		}
		try {
			diff = endDate.getTime() - startDate.getTime();
			diffSeconds = diff / 1000 % 60;
			diffMinutes = diff / (60 * 1000) % 60;
			diffHours = diff / (60 * 60 * 1000);
		} catch (Exception e) {

		}

		if (RunTestNG_Navigator.runCount > 0) {

			Object[][] arrayCounts = RunFailed_Navigator.getCountsObj();
			if (extent1 != null) {
				RunTestNG_Navigator.passedCount = RunTestNG_Navigator.passedCount
						+ context.getPassedTests().size();
				RunTestNG_Navigator.failedCount = RunTestNG_Navigator.failedCount
						- context.getPassedTests().size();
				System.out.println(" Pass Count: " + RunTestNG_Navigator.passedCount + " Fail Count: "
						+ RunTestNG_Navigator.failedCount);
				extent1.flush();
			}
		} else {
			Object[][] arrayCounts = RunTestNG_Navigator.getCountsObj();
			if (extent != null) {

				RunTestNG_Navigator.passedCount = context.getPassedTests().size();
				RunTestNG_Navigator.failedCount = context.getFailedTests().size();
				RunTestNG_Navigator.excTcCount = RunTestNG_Navigator.passedCount
						+ RunTestNG_Navigator.failedCount;
				System.out.println(" Pass Count: " + RunTestNG_Navigator.passedCount + " Fail Count: "
						+ RunTestNG_Navigator.failedCount);

				extent.flush();
				if (failedTc.size() > 0 && RunTestNG_Navigator.runCount == 0
						&& RunTestNG_Navigator.Config.getProperty("Rerun").toString().equalsIgnoreCase("Y")) {
					RunTestNG_Navigator.runCount++;
					formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
					date = new Date();
					starttime = formatter.format(date);
					for (int i = 0; i < failedTc.size(); i++) {
						RunTestNG_Navigator.fail--;
					}
					RunFailed_Navigator.reRun(failedTc);
					generatereport(reportsPath);
				} else {
					generatereport(reportsPath);
				}
			}

		}
	}

	public void generatereport(String reportsPath) {
		FileUtil.createandwriteFile(defectsListFile, RunTestNG_Navigator.failedMethods);
		String path = System.getProperty("user.dir") + RunTestNG_Navigator.Config.getProperty("ReportFile");
		String filename_Attachment = ExtentManager.fileName;
		String suiteStatus_Subject;
		String Env_Subject = null;
		Env_Subject = RunTestNG_Navigator.Config.getProperty("Environment");

		if (status.equalsIgnoreCase("")) {
			suiteStatus_Subject = "PASS";
		} else
			suiteStatus_Subject = "FAIL";
		RunTestNG_Navigator.excTcCount = RunTestNG_Navigator.passedCount + RunTestNG_Navigator.failedCount;
		double passpercentage = (double) (RunTestNG_Navigator.passedCount * 100)
				/ RunTestNG_Navigator.excTcCount;
		String passPercent = df.format(passpercentage);
		double failpercentage = (double) (RunTestNG_Navigator.failedCount * 100)
				/ RunTestNG_Navigator.excTcCount;
		String failPercent = df.format(failpercentage);
		String header_content = RunTestNG_Navigator.Config.getProperty("Body_Text") + timeStamp_email;
		htmlbuilder_Summary.appendSummary_Header(header_content,
				"Total time taken:" + diffHours + "h " + diffMinutes + "m " + diffSeconds + "s");
		htmlbuilder_Summary.appendSummary("Navigator ", RunTestNG_Navigator.excTcCount,
				RunTestNG_Navigator.passedCount, RunTestNG_Navigator.failedCount, passPercent, failPercent);
		htmlbuilder_Summary.append_closeTable();
		htmlbuilder_Summary.append_closebody();

		
		String htmlcontent = htmlbuilder_Summary.sb.toString();
		//System.out.println(htmlcontent);
		createApplicationLog();
		//EmailUtil.sendEmailWithAttachment(path, Env_Subject, suiteStatus_Subject,timeStamp_email, "", htmlcontent, extentFilepath, filename_Attachment);
	}

	
	public void resultStatus(ITestResult result, String tcname, String tcstatus) {
		List<String> values = new ArrayList<String>();
		values.add(0, result.getTestClass().getName());
		values.add(1, tcname);
		values.add(2, tcstatus);
		results.put(tcname, values);
	}

	
	


	public void createApplicationLog() {
		FileInputStream instream = null;
		FileOutputStream outstream = null;
		try {
			Date d = new Date();
			File infile = new File(System.getProperty("user.dir") + "/src/test/resources/logs/Application.log");
			File outfile = new File(System.getProperty("user.dir") + "/src/test/resources/logs/Application-"
					+ d.toString().replace(":", "_").replace(" ", "_") + ".log");
			instream = new FileInputStream(infile);
			outstream = new FileOutputStream(outfile);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = instream.read(buffer)) > 0) {
				outstream.write(buffer, 0, length);
			}
			instream.close();
			outstream.close();
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
	}
}
