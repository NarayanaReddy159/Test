package com.nasco.navigator.pages;

import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;
import com.nasco.navigator.Base.BaseTest;
import com.nasco.navigator.Setup.BasePage;

@SuppressWarnings({"rawtypes"})
public class BulkActionsPage extends BasePage{

	@FindBy(id = "PegaGadget1Ifr")
	WebElement frame;
	
	@FindBy(xpath = "//div[text()='Bulk Actions']")
	WebElement bulkActionsHeader;
	
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Filter Property')]/following::input")
	public WebElement FilterProperty;
	
	@FindBy(how = How.XPATH, using = "//select[contains(@name,'$PpyBulkProcessingPage$ppyConditionList$l')]")
	public WebElement FilterCondition;
	
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Filter Value')]/following::input[4]")
	public WebElement FilterValue;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Filter Value')]/following::button[1]")
	public WebElement searchBtn;
	
	String filterValueOptions ="//*[@id='acresults-list']/div";
	
	@FindBy(how = How.XPATH, using = "//a[text()='+ Add Filter']")
	public WebElement addFilter;
	
	@FindBy(how = How.XPATH, using = "//button[contains(@name,'NEWSBulkProcessingActionSection_pyBulkProcessingPage')]")
	public WebElement selectAction;

	@FindBy(how = How.XPATH, using = "//button[contains(@name,'NEWSBulkProcessingActionSection_pyBulkProcessingPage')]//following::ul/li/a")
	public WebElement reAssign;

	@FindBy(how = How.NAME, using = "$PTempWorkPage$pReassignOperator")
	public WebElement transferToOp;
	
	@FindBy(how = How.NAME, using = "$PTempWorkPage$ppyNote")
	public WebElement transferNotes;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Notes')]//following::button[1]")
	public WebElement transferOk;
	
	public void bulkTransfer(Hashtable<String, String> data)
	{
		try {
			
			String filterProperties=data.get("FILTERPROPERTY");
			String conditions=data.get("CONDITION");
			String values=data.get("FILTERVALUE");
			
			String [] filters =filterProperties.split(",");
			String condition [] =conditions.split(",");
			String value [] =values.split(",");
			
			if(filters.length>0)
			{
				for(int i=0;i<filters.length;i++)
				{
					
					driver.findElement(By.xpath(String.format("//input[@name='$PpyBulkProcessingPage$ppyConditionList$l%d$ppyFilterName']",i+1))).sendKeys(filters[i]);
					driver.switchTo().defaultContent();
					List<WebElement> optionsToSelect=driver.findElements(By.xpath(filterValueOptions));
					for(WebElement option : optionsToSelect){
					    if(option.getText().equals(filters[i])) {
					        option.click();
					        break;
					    }
					}
					wait(5000);
					driver.switchTo().frame("PegaGadget1Ifr");
					driver.findElement(By.xpath("//div[text()='Filter Property']")).click();
					Select filterConditiondropdown= new Select(driver.findElement(By.xpath(String.format("//select[contains(@name,'$PpyBulkProcessingPage$ppyConditionList$l%d')]",i+1))));
					filterConditiondropdown.selectByVisibleText(condition[i]);
					if(!condition[i].equals("Is Null")&&!condition[i].equals("Is Not Null"))
					{
						wait(3000);
						driver.findElement(By.xpath(String.format("//select[contains(@name,'$PpyBulkProcessingPage$ppyConditionList$l%d$ppyTempOperator')]//following::input[1]",i+1))).sendKeys(value[i]);
						wait(3000);
					}
					wait(3000);
					if(i<filters.length-1)
					{
						addFilter.click();	
					}
					
				}
			}
			else {
				FilterProperty.clear();
				FilterProperty.sendKeys(data.get("FILTERPROPERTY"));
				driver.switchTo().defaultContent();
				List<WebElement> optionsToSelect=driver.findElements(By.xpath(filterValueOptions));
				for(WebElement option : optionsToSelect){
				    if(option.getText().equals(data.get("FILTERPROPERTY"))) {
				        option.click();
				        break;
				    }
				}
				wait(5000);
				driver.switchTo().frame("PegaGadget1Ifr");
				driver.findElement(By.xpath("//div[text()='Filter Property']")).click();
				Select filterConditiondropdown= new Select(FilterCondition);
				filterConditiondropdown.selectByVisibleText(data.get("CONDITION"));
				if(!data.get("CONDITION").equals("Is Null")&&!data.get("CONDITION").equals("Is Not Null"))
				{
					wait(3000);
					FilterValue.sendKeys(data.get("FILTERVALUE"));
					wait(3000);
				}	
			}
			
			wait(3000);
			searchBtn.click();
			wait(3000);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on bulkTransfer method " + e);
			test.log(Status.FAIL, "Error on bulkTransfer method " + e);
			throw e;
		}
		
	}
	
	
	public void transferRecords(Hashtable<String, String> data)
	{
		try {
			wait(3000);
			//selectSearchResult.click();
			int cc=Integer.valueOf(data.get("RecordsToTransfer"));
			
			for(int i=0;i<cc;i++)
			{
				driver.findElement(By.xpath("//input[contains(@type,'checkbox') and contains(@name,'$PpyBulkProcessReport$ppxResults$l1"+i+"$ppySelected')]")).click();
			}
			selectAction.click();
			wait(5000);
			reAssign.click();
			wait(5000);
			Select transferOp= new Select(transferToOp);
			transferOp.selectByVisibleText(data.get("OperatorName"));
			transferNotes.clear();
			transferNotes.sendKeys("Reassigning claim to Operator "+data.get("OperatorName"));
			wait(3000);
			transferOk.click();
			wait(5000);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on transferRecords method " + e);
			test.log(Status.FAIL, "Error on transferRecords method " + e);
			throw e;
		}
		
	}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		try{
			return ExpectedConditions.visibilityOf(bulkActionsHeader);
		}catch(Exception e)
		{
			throw e;
		}
	}

}
