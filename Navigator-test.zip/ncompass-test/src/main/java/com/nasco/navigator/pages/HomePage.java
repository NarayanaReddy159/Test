package com.nasco.navigator.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.navigator.Base.BaseTest;
import com.nasco.navigator.Run.RunTestNG_Navigator;
import com.nasco.navigator.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked"})
public class HomePage extends BasePage{

	@FindBy(xpath = "//a[contains(@name,'CWSMgrTopPanel_pyDisplayHarness')]")
	WebElement headerHomePage;
	
	@FindBy(xpath = "//span[text()='Manage Operator']")
	WebElement manageOperatorMenu;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'field-item dataValueWrite')]/following::a[2]")
	public WebElement usernamediv;

	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Bulk Actions')]")
	public WebElement bulkactionsLink;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Log Out')]")
	public WebElement logOutLink;
	
	public ManageOperatorPage manageOperatorClick()
	{
		try {

			webElementClick(manageOperatorMenu,"Manage Operator Menu Item");
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on manageOperatorClick method " + e);
			test.log(Status.FAIL, "Error on manageOperatorClick method " + e);
			throw e;
		}

		return (ManageOperatorPage) openPage(ManageOperatorPage.class);
	}
	
	public BulkActionsPage moveToBulkactions()
	{
		try {
			switchToDefault();
			usernamediv.click();
			wait(5000);
			bulkactionsLink.click();
			wait(5000);
			switchToFrame("PegaGadget1Ifr");
			wait(2500);
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on moveToBulkactions method " + e);
			test.log(Status.FAIL, "Error on moveToBulkactions method " + e);
			throw e;
		}
		return (BulkActionsPage) openPage(BulkActionsPage.class);
	}
	
	public ClaimPerformHarnessPage clickNextAssignment()
	{
		try {
			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//a[contains(text(),'Next Assignment')]")).click();
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on clickNextAssignment method " + e);
			test.log(Status.FAIL, "Error on clickNextAssignment method " + e);
			throw e;
		}
		return (ClaimPerformHarnessPage) openPage(ClaimPerformHarnessPage.class);
	}
	
	public void logOut()
	{
		try {
			driver.switchTo().defaultContent();	
			usernamediv.click();
			wait(1500);
			logOutLink.click();
			wait(2500);
			driver.navigate().to( RunTestNG_Navigator.Config.getProperty("URL"));
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on logOut method " + e);
			test.log(Status.FAIL, "Error on logOut method " + e);
			throw e;
		}
		
	}
	
	public ReportsPage openReportsPage()
	{
		 return (ReportsPage) openPage(ReportsPage.class);
	}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		try{
			return ExpectedConditions.visibilityOf(headerHomePage);
		}catch(Exception e)
		{
			throw e;
		}
	}

}
