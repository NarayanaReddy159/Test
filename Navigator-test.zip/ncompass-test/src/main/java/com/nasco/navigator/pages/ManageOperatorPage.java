package com.nasco.navigator.pages;



import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.navigator.Base.BaseTest;
import com.nasco.navigator.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked"})
public class ManageOperatorPage extends BasePage{

	
	@FindBy(id = "PegaGadget0Ifr")
	WebElement frame0;
	
	
	@FindBy(xpath = "//div[text()='Manage Operator']")
	WebElement manageOperatorHeader;
	
	@FindBy(xpath = "//div[contains(text(),'Manage Operator')]/following::a")
	WebElement manageOpsProfilesLink;
	
	//User name sorting btn
	@FindBy(how=How.XPATH, using="//*[@id='th_UserID']/div/span[1]/a//following::button[1]")
	WebElement operatorSortBtn;
			
	//input text box
	@FindBy(how=How.XPATH, using="//*[@id='lv_filter_input']")
	WebElement filterInput;
			
	// apply button
	
	@FindBy(how=How.XPATH, using="//*[@id='lv_filter_btn']")
	WebElement applyFilter;
			
	// click on operator
			
	@FindBy(how=How.XPATH, using="//*[@id='1_1']")
	WebElement clickOperator;
	
	//Save button
	@FindBy(how=How.XPATH, using="//button[contains(@name,'ManagerRuleFormToolbarSave')]")
	WebElement saveBtn;
			
	//close button
	@FindBy(how=How.XPATH, using="//i[contains(@name,'RuleFormToolbarManager_RH')]")
	WebElement closeBtn;

	public void manageOpsProfileClick(String operator)
	{
		try {
			String parentHandle=driver.getWindowHandle(); 
			wait(5000);
			switchToFrame("PegaGadget0Ifr");
			driver.findElement(By.xpath("//div[contains(text(),'Manage Operator')]")).getText();
			webElementClick(manageOpsProfilesLink,"Manage Operator Menu Item");
			for (String windowHandle : driver.getWindowHandles())
			{
				if(!parentHandle.equals(windowHandle)){
					 driver.switchTo().window(windowHandle);
				}
			}			
			switchToDefault();
			wait(3000);
			driver.manage().window().maximize();
			operatorSortBtn.click();
			wait(2500);
			webElementSendText(filterInput,operator,"Operator");
			webElementClick(applyFilter,"Apply");
			wait(2500);
			String childHandle=driver.getWindowHandle();
			clickOperator.click();
			wait(2500);
			driver.switchTo().window(childHandle);
			wait(2500);
			driver.close();
			wait(2500);
			driver.switchTo().window(parentHandle);
			driver.switchTo().defaultContent().switchTo().frame("PegaGadget1Ifr");
			wait(2500);
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on manageOpsProfileClick method " + e);
			test.log(Status.FAIL, "Error on manageOpsProfileClick method " + e);
			throw e;
		}
	}
	
	public void removeProfileData()
	{
		try {
		List<WebElement> workGroup=driver.findElements(By.xpath("//div[contains(text(),'Work Group')]//following::a[contains(@name,'RoutingSettings_RH')]"));
			if(workGroup.size()>0)
			{
				for(int i=1;i<workGroup.size();i++)
				{
					driver.findElement(By.xpath("//div[contains(text(),'Work Group')]//following::a[contains(@name,'RoutingSettings_RH')]")).click();
					wait(1500);
				}
			}
			wait(2500);
			List<WebElement> skills=driver.findElements(By.xpath("//div[contains(text(),'Skill')]//following::a[contains(@name,'SkillsManager_RH') and contains(@title,'Delete')]"));
			if(skills.size()>0)
			{
				for(int i=1;i<=skills.size();i++)
				{
					driver.findElement(By.xpath("//div[contains(text(),'Skill')]//following::a[contains(@name,'SkillsManager_RH') and contains(@title,'Delete')]")).click();
					wait(1500);
				}
			}
			
			wait(2500);
			
			List<WebElement> workbasket=driver.findElements(By.xpath("//div[contains(text(),'Workbasket')]//following::a[contains(@name,'WorkBasketsManager') and contains(@title,'Delete')]"));
			if(workbasket.size()>0)
				{
					for(int i=1;i<=workbasket.size();i++)
					{
						driver.findElement(By.xpath("//div[contains(text(),'Workbasket')]//following::a[contains(@name,'WorkBasketsManager') and contains(@title,'Delete')]")).click();
						wait(1500);
					}
				}
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on removeProfileData method " + e);
			test.log(Status.FAIL, "Error on removeProfileData method " + e);
			throw e;
		}
	}
	
	public void editOpProfile(Hashtable<String, String> data)
	{
		try {
			
			  String wg=data.get("Workgroups"); 
			  String [] wgArray= wg.split(",");
			  if(wgArray.length>1) 
			  { 
				  for(int i=0;i<wgArray.length;i++) {
					  driver.findElement(By.xpath("(//div[contains(text(),'Work Group')]//following::a[contains(@name,'RoutingSettings_RH')])["+(i+1)+"]")).click(); 
					  wait(2500); 
					  if(i==0) 
					  { 
						  driver.findElement(By.xpath("//div[contains(text(),'Work Group')]//following::input[@type='radio']")).click();
						  }
					  driver.findElement(By.xpath("(//div[contains(text(),'Work Group')]//following::input[@type='text' and contains(@name,'$ppyWorkGroupName')])["+(i+1)+"]")).sendKeys(wgArray[i]); 
					  wait(2500);
					 }
				} 
			  else {
			  driver.findElement(By.xpath("//div[contains(text(),'Work Group')]//following::a[contains(@name,'RoutingSettings_RH')]")).click();
			  wait(2500); 
			  driver.findElement(By.xpath("//div[contains(text(),'Work Group')]//following::input[@type='radio']")).click();
			  driver.findElement(By.xpath("//div[contains(text(),'Work Group')]//following::input[@type='text' and contains(@name,'$ppyWorkGroupName')]")).sendKeys("3 Tier National@HZ"); 
			  wait(2500);
			  }
			  
			  //Adding Skills 
			  String skill=data.get("Skills"); 
			  String [] skillArray=skill.split(","); 
			  if(skillArray.length>1) 
			  { 
				  for(int i=0;i<skillArray.length;i++) 
				  { 
					  driver.findElement(By.xpath("//div[contains(text(),'Skill')]//following::a[contains(@name,'SkillsManager') and contains(@title,'Add')]")).click();
					  wait(2500); 
					  driver.findElement(By.xpath("(//div[contains(text(),'Skill')]//following::input[@type='text' and contains(@name,'$ppySkillName')])["+(i+1)+"]")).sendKeys(skillArray[i]); 
					  wait(2500);
					  driver.findElement(By.xpath("//div[contains(text(),'Work Group')]")).click();
					 } 
			  } 
			  else {
					  driver.findElement(By.xpath("//div[contains(text(),'Skill')]//following::a[contains(@name,'SkillsManager') and contains(@title,'Add')]")).click();
					  wait(2500); 
					  driver.findElement(By.xpath("//div[contains(text(),'Skill')]//following::input[@type='text' and contains(@name,'$ppySkillName')]")).sendKeys(skill); 
					  wait(2500);
					  driver.findElement(By.xpath("//div[contains(text(),'Skill')]")).click();
					 }
			  
			  
			  // Adding Work baskets 
			  String wb=data.get("Workbaskets"); 
			  if(null!=wb ){
				  String [] wbArray= wb.split(",");
				  if(wbArray.length>1) 
				  { 
					  for(int i=0;i<wbArray.length;i++) 
					  {
						  driver.findElement(By.xpath("//div[contains(text(),'Workbasket')]//following::a[contains(@name,'WorkBasketsManager_RH') and contains(@title,'Add')]")).click(); 
						  driver.findElement(By.xpath("(//div[contains(text(),'Workbasket')]//following::input[@type='text' and contains(@name,'$ppyWorkBasketName')])["+(i+1)+"]")).sendKeys(wbArray[i]); 
						  wait(2500);
						  driver.findElement(By.xpath("//div[contains(text(),'Skill')]")).click();
					  }
				  } 
				 else {
						 driver.findElement(By.xpath("//div[contains(text(),'Workbasket')]//following::a[contains(@name,'WorkBasketsManager_RH') and contains(@title,'Add')]")).click(); 
						 driver.findElement(By.xpath("//div[contains(text(),'Workbasket')]//following::input[@type='text' and contains(@name,'$ppyWorkBasketName')]")).sendKeys(wb); 
						 wait(2500);
						 driver.findElement(By.xpath("//div[contains(text(),'Skill')]")).click();
					 }
			  
			  }else{
				  }
			  
			  wait(2500); 
			  saveBtn.click(); 
			  wait(2500);
			  closeBtn.click();
			  wait(2500);
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on editOpProfile method " + e);
			test.log(Status.FAIL, "Error on editOpProfile method " + e);
			throw e;
		}
	}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		try{
			return ExpectedConditions.visibilityOf(frame0);
		}catch(Exception e)
		{
			throw e;
		}
	}
}