package com.nasco.navigator.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.navigator.Base.BaseTest;
import com.nasco.navigator.Setup.BasePage;
import com.nasco.navigator.utilities.DriverManager;

@SuppressWarnings({"rawtypes","unchecked"})
public class LoginPage extends BasePage {

	// Log in page Fields
	// user Name text box
	//User Name field
	@FindBy(id = "txtUserID")
	WebElement txtUserName;
			
	//Pass Word Field
	@FindBy(how = How.ID, using = "txtPassword")
	WebElement txtPassword;
	
	//Log in button
	@FindBy(how = How.ID, using = "sub")
	WebElement btnLogin;

	// open login page
	public LoginPage open(String url) {

		BaseTest.log.info("Driver Initialized !!!");
		DriverManager.getDriver().navigate().to(url);
		BaseTest.log.info("Navigated to URL:" + url);
		test.log(Status.INFO, "Navigated to URL:" + url);
		return (LoginPage) openPage(LoginPage.class);
	}

	
	
	
	// Login to application as valid user

	public HomePage doLoginAsValidUser(String username,String password) {

		try {

			txtUserName.sendKeys(username);
			txtPassword.sendKeys(password);
			webElementClick(btnLogin, "Login");
			waitSleep(3000);
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on doLoginAsValidUser method " + e);
			test.log(Status.FAIL, "Error on doLoginAsValidUser method " + e);
			throw e;
		}

		return (HomePage) openPage(HomePage.class);
	}

	
	public void doLoginAsUser(String username,String password) {

		try {

			txtUserName.sendKeys(username);
			txtPassword.sendKeys(password);
			webElementClick(btnLogin, "Login");
			waitSleep(3000);
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on doLoginAsValidUser method " + e);
			test.log(Status.FAIL, "Error on doLoginAsValidUser method " + e);
			throw e;
		}

	}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		try{
			return ExpectedConditions.visibilityOf(txtPassword);
		}catch(Exception e)
		{
			throw e;
		}
		
	}

}
