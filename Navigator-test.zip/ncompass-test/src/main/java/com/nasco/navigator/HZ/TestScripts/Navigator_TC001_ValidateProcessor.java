package com.nasco.navigator.HZ.TestScripts;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.nasco.navigator.Base.BaseTest;
import com.nasco.navigator.Run.RunTestNG_Navigator;
import com.nasco.navigator.pages.*;
import com.nasco.navigator.utilities.*;

public class Navigator_TC001_ValidateProcessor extends BaseTest {
	String message ="Navigator_TC001_ValidateProcessor";
	@Test(dataProviderClass = DataProviders.class, dataProvider = "Navaigator_DP")
	public void Navigator_AUTC001_ValidateProcessor(Hashtable<String, String> data) throws Exception {
		try{
			setUpFramework();
			test = DriverManager.getExtentReport();
			log.info("Inside "+message);
			openBrowser(RunTestNG_Navigator.Config.getProperty("Browser").toString());
			log.debug(message+" - Launched Browser : "
					+ RunTestNG_Navigator.Config.getProperty("Browser"));
			test.log(Status.INFO, "Launched Browser : " + RunTestNG_Navigator.Config.getProperty("Browser"));
			LoginPage login = new LoginPage().open(RunTestNG_Navigator.Config.getProperty("URL").toString());
			HomePage homePage=login.doLoginAsValidUser( getDefaultUserName(),
					getDefaultPassword());
			log.debug(message+" -Username entered as "
					+ RunTestNG_Navigator.Config.getProperty("opsAdmUser") + " and Password entered as "
					+ RunTestNG_Navigator.Config.getProperty("opsAdmPassword"));
			test.log(Status.INFO, "Username entered as " + RunTestNG_Navigator.Config.getProperty("opsAdmUser")
					);

			if(data.get("EditProfile").equals("Y"))
			{
				ManageOperatorPage manageOperator=homePage.manageOperatorClick();
				manageOperator.manageOpsProfileClick(data.get("Operator"));
				manageOperator.removeProfileData();
				manageOperator.editOpProfile(data);	
			}
			if(data.get("BulkTransfer").equals("Y"))
			{
				BulkActionsPage bulkactions= homePage.moveToBulkactions();
				bulkactions.bulkTransfer(data);
				bulkactions.transferRecords(data);
			}
			
			homePage.logOut();
			login.doLoginAsUser(data.get("Operator"),data.get("OperatorPwd"));
			ClaimPerformHarnessPage claim=homePage.clickNextAssignment();
			ArrayList<String> claimDetails =claim.getClaimDetails();
			claim.claimDetails(data,claimDetails);
			claim.claimProcessiongActions(data);
			claim.claimProcessing(data);
			homePage.logOut();
			
		}
		catch(Exception e)
		{
			if(RunTestNG_Navigator.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_Navigator.failedData.get(method).equals(null))
					{
						RunTestNG_Navigator.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_Navigator.failedData.get(method).add(data);
					}
					else{
						RunTestNG_Navigator.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_Navigator.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_Navigator.failedData.get(method).add(data);
				}
			}
			throw e;
		}
		
		
	
	}

	@AfterMethod
	public void tearDown() throws Exception  {
		test.log(Status.INFO, message);
		log.debug(message);
		quit();
	}
}
