package com.nasco.navigator.pages;

import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.navigator.Base.BaseTest;
import com.nasco.navigator.Setup.BasePage;

@SuppressWarnings({"rawtypes"})
public class ReportsPage extends BasePage{

	@FindBy(xpath = "//div[text()='Reports']")
	WebElement headerReportsPage;
	
	
	public void validateReports(Hashtable<String, String> data)
	{
		try {
			List<WebElement> reports= driver.findElements(By.xpath("//a[contains(@name,'NavigatorReportBrowserInner')]"));
			String reportLinks="";
			
			for(int i=0;i<reports.size();i++)
			{
				reportLinks=reportLinks+","+reports.get(i).getText();
			}
		assertEquals(reportLinks,data.get("ReportLinks"),"Reports Links");
		
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on validateReports method " + e);
			test.log(Status.FAIL, "Error on validateReports method " + e);
			throw e;
		}
	}
	
	public void reportsValidate(Hashtable<String, String> data)
	{
		try {
			String parentHandle=driver.getWindowHandle(); 
			wait(2500);
			switchToFrame("PegaGadget0Ifr");
			driver.findElement(By.xpath(String.format("//a[contains(text(),'%s')]",data.get("Report")))).click();
			wait(7500);
			for (String windowHandle : driver.getWindowHandles())
			{
				wait(5000);
				if(!parentHandle.equals(windowHandle)){
					 driver.switchTo().window(windowHandle);
				}
			}			
			driver.manage().window().maximize();
			wait(3000);
			driver.switchTo().activeElement();
			wait(5000);
			String reportTitle=driver.findElement(By.xpath("//span[@class='report_title']")).getText();
			//System.out.println("Title:"+reportTitle);
			assertEquals(reportTitle,data.get("Tiltle"),"Report tiltle");
			try {
				driver.findElement(By.xpath("//a[contains(text(),'Hide Chart')]")).click();
				wait(3000);
			}catch(Exception e)
			{
				
			}
			List<WebElement> tableHeader= driver.findElements(By.xpath("//span[contains(text(),'Total')]/parent::th/parent::tr/child::th"));
			String tableHeaders="";
			
			for(int i=0;i<tableHeader.size();i++)
			{
				tableHeaders=tableHeaders+","+tableHeader.get(i).getText();
			}
			//System.out.println("tableHeaders:"+tableHeaders);
			
			assertEquals(tableHeaders,data.get("TableHeader"),"Reports table headers");
			
			driver.findElement(By.xpath("//*[@id='GrandTotal_row1']/td[4]")).click();
			wait(3500);
				
			List<WebElement> drilldownHeader= driver.findElements(By.xpath("//div[contains(text(),'Urgency')]//ancestor::th/parent::tr/child::th"));
			String drilldowneHeaders="";
				
			for(int i=0;i<drilldownHeader.size();i++)
			{
				drilldowneHeaders=drilldowneHeaders+","+drilldownHeader.get(i).getText();
			}
			//System.out.println("drilldowneHeaders:"+drilldowneHeaders);
				
			assertEquals(drilldowneHeaders,data.get("DrillDownTableHeader"),"Reports drilldown table headers");
			
			driver.close();
			wait(2500);
			driver.switchTo().window(parentHandle);
			
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on reportsValidate method " + e);
			test.log(Status.FAIL, "Error on reportsValidate method " + e);
			throw e;
		}
	}
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget0Ifr");
		try{
			return ExpectedConditions.visibilityOf(headerReportsPage);
		}catch(Exception e)
		{
			throw e;
		}
	}

}
