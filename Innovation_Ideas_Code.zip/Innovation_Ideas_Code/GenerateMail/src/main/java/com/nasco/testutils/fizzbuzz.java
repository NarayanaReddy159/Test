package com.nasco.testutils;

public class fizzbuzz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num=15;
		if(num%5==0 && num%3!=0)
		{
			System.out.println("Fizz");
		}else if(num%5!=0 && num%3==0)
		{
			System.out.println("Buzz");
		} else if(num%5==0 && num%3==0)
		{
			System.out.println("FizzBuzz");
		}

	}

}
