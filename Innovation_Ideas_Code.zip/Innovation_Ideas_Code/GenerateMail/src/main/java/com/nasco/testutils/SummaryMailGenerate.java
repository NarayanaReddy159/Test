package com.nasco.testutils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class SummaryMailGenerate {

	public static void main(String[] args) throws Exception {
		List<String> mailData= GenerateMailData.getData();
		String emailTo=mailData.get(0);
		String emailCC=mailData.get(1);
		String subject=mailData.get(2)+new SimpleDateFormat("MM/dd/yyyy").format(Calendar.getInstance().getTime());
		String filepath=mailData.get(4);
		String htmlContent=mailData.get(3);
		System.out.println(htmlContent);
		SendEmail.execute(emailTo,emailCC,subject,htmlContent,filepath);
}

}
