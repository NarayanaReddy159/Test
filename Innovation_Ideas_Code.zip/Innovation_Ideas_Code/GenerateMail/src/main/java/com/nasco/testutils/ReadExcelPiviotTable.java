package com.nasco.testutils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFPivotTable;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelPiviotTable {

	@SuppressWarnings({ "serial" })
	public static String readExcelPiviotTable(String filepath,String tableName) throws Exception {
		StringBuilder tableContent = new StringBuilder();
		 Map<String, Integer> map = new HashMap<String, Integer>() {
	            {
	                int index =1;
	                for (char ch = 'A'; ch <= 'Z'; ++ch) {
	                    put(String.valueOf(ch), index); 
	                    index++;
	                }
	            }
	    };
		XSSFWorkbook workbook = new XSSFWorkbook(new File(filepath));
		XSSFSheet sheet = workbook.getSheetAt(0);
		List<XSSFPivotTable> tables=sheet.getPivotTables();
		List<String> dataValues= new ArrayList<String>();
		String cellValue="";
		for(int i=0;i<tables.size();i++)
		{
			if(tables.get(i).getCTPivotTableDefinition().getName().equals(tableName))
			{
				String range = tables.get(i).getCTPivotTableDefinition().getLocation().getRef();
				String [] values=range.split(":");
				int firstcol = map.get(values[0].replaceAll("[0-9]",""));
				int firstrow = Integer.parseInt(values[0].replaceAll("[\\D]", ""));
		        firstrow=firstrow+1;
		        int lastcol = map.get(values[1].replaceAll("[0-9]",""));
		        int lastrow = Integer.parseInt(values[1].replaceAll("[\\D]", ""));
		        Iterator<Row> rowIterator = sheet.iterator();
				while (rowIterator.hasNext()) 
				{
				    Row row = rowIterator.next();
				    if(checkrightrowcol(row.getRowNum()+1, firstrow, lastrow))
				    {
				    	Iterator<Cell> cellIterator = row.cellIterator();
					    while (cellIterator.hasNext()) 
					    {
					        Cell cell = cellIterator.next();
					       if(checkrightrowcol(cell.getColumnIndex()+1,firstcol,lastcol))
					        {    
					        	if (cell.getCellType() == null) {
					        		cellValue=cellValue+"__"+"!";
					        	}
					        	if (cell.getCellType()== CellType.BLANK) {
					        		cellValue=cellValue+"__"+"!";
					        	}
					        	if (cell.getCellType() == CellType.STRING) {
					        		cellValue=cellValue+cell.getStringCellValue()+"!";
					        }
					        	if (cell.getCellType() == CellType.NUMERIC || cell.getCellType() == CellType.FORMULA) {
					        		cellValue=cellValue+Integer.valueOf((int) cell.getNumericCellValue())+"!";
					        	}
					        	 	
					        }
					       
					     }
					    dataValues.add(cellValue);
					    cellValue="";
				 }
				}
			}
		}
		tableContent.append("<table style='border: 1px solid black;border-collapse: collapse;'>");
		for(int i=0;i<dataValues.size();i++)
		{
			tableContent.append("<tr style='border: 1px solid black; border-collapse: collapse; font-family:arial;font-size:13px;'>");
			String [] tablevalues=dataValues.get(i).toString().split("\\!");
			for(int j=0;j<tablevalues.length;j++)
			{
				if(i==0 ||i==dataValues.size()-1)
				{
					try{
						Integer.valueOf(tablevalues[j]);
						tableContent.append("<td style='border: 1px solid black; border-collapse: collapse;color:darkblue;background-color:#85C1E9;text-align:center;'>");
					}catch(Exception e1)
					{
						tableContent.append("<td style='border: 1px solid black; border-collapse: collapse;color:darkblue;background-color:#85C1E9;'>");
					}
						
				}else{
					
					try{
						Integer.valueOf(tablevalues[j]);
						tableContent.append("<td style='border: 1px solid black; border-collapse: collapse;color:darkblue;text-align:center;'>");
					}catch(Exception e1)
					{
						tableContent.append("<td style='border: 1px solid black; border-collapse: collapse;color:darkblue;'>");
					}
				}
				
				if(tablevalues[j].equals("__"))
				{
					tableContent.append(" ");
				}else{
					
					tableContent.append(tablevalues[j]);	
				}
				
				tableContent.append("</td>");
			}
			tableContent.append("</tr>");
		}
		tableContent.append("</table>");
		workbook.close();
		//System.out.println(tableContent.toString());
		return tableContent.toString();
}
	public static boolean checkrightrowcol(int n , int start, int end){

        while (start!=end){
            if(n == start || n == end)
                return true;
            start++;
        }
        return false;
    }
}