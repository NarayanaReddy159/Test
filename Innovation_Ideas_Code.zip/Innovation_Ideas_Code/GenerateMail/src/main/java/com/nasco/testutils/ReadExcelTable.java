package com.nasco.testutils;

import java.io.File;
import java.util.List;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFTable;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelTable {

	@SuppressWarnings({ "unused" })
	public static String readExcelTable(String fileloc,String tableName) throws Exception {
		StringBuilder tableContent = new StringBuilder();
		
		XSSFWorkbook workbook = new XSSFWorkbook(
				new File(fileloc));
		XSSFSheet sheet = workbook.getSheetAt(0);
		List<XSSFTable> tables = sheet.getTables();
		for (XSSFTable t : tables) {
			if(t.getName().equals(tableName))
			{
				tableContent.append("<table style='border: 1px solid black;border-collapse: collapse;'>");
				int startRow = t.getStartCellReference().getRow();
				int endRow = t.getEndCellReference().getRow();
				int startColumn = t.getStartCellReference().getCol();
				int endColumn = t.getEndCellReference().getCol();
				for (int i = startRow; i <= endRow; i++) {
					tableContent.append("<tr style='border: 1px solid black; border-collapse: collapse; font-family:arial;font-size:13px;'>");
					for (int j = startColumn; j <= endColumn; j++) {
						XSSFCell cell = sheet.getRow(i).getCell(j);
						XSSFColor cellColor = (XSSFColor) cell.getCellStyle().getFillBackgroundColorColor();
						try {
							cell.getCellStyle().getFillForegroundColorColor().getARGBHex();
							tableContent.append("<td style='border: 1px solid black; border-collapse: collapse;background-color:#99A3A4;color:darkblue;");
						} catch (Exception e) {
							tableContent.append("<td style='border: 1px solid black; border-collapse: collapse;color:darkblue;");
						}
						if (cell == null) {
							tableContent.append("'>");
							tableContent.append("");
						}
						if (cell.getCellType() == CellType.STRING) {
							tableContent.append("'>");
							tableContent.append(cell.getStringCellValue());
						}
						if (cell.getCellType() == CellType.NUMERIC || cell.getCellType() == CellType.FORMULA) {
							if(cell.getCellStyle().getDataFormatString().contains("%"))
							{
								tableContent.append("text-align:right;'>");
								double test=cell.getNumericCellValue()*100;
								int value = (int)test;
								tableContent.append(value);
								tableContent.append("%");
							}else{
								tableContent.append("text-align:right;'>");
								tableContent.append(Integer.valueOf((int) cell.getNumericCellValue()));
							}
						}
						if (cell.getCellType() == CellType.BLANK) {
							tableContent.append("'>");
							tableContent.append("");
						}
						if (cell.getCellType() == CellType.BOOLEAN) {
							tableContent.append("'>");
							tableContent.append(cell.getBooleanCellValue());
						}
						tableContent.append("</td>");
					}
					tableContent.append("</tr>");
				}
				tableContent.append("</table>");
				break;
			}
			
		}
		workbook.close();
		return tableContent.toString();
	}
	
}
