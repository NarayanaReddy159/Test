package com.nasco.testutils;

import java.io.File;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.swt.SWT;
import org.eclipse.swt.ole.win32.OLE;
import org.eclipse.swt.ole.win32.OleAutomation;
import org.eclipse.swt.ole.win32.OleClientSite;
import org.eclipse.swt.ole.win32.OleFrame;
import org.eclipse.swt.ole.win32.Variant;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class SendEmail {

    public static Object execute(String emailTolist, String emailCCList,String subject, String htmlContent,String attachfilepath) throws ExecutionException {
        Display display = Display.getCurrent();
        Shell shell = new Shell(display);
        OleFrame frame = new OleFrame(shell, SWT.NONE);
        // This should start outlook if it is not running yet
        OleClientSite site = new OleClientSite(frame, SWT.NONE, "OVCtl.OVCtl");
        site.doVerb(OLE.OLEIVERB_INPLACEACTIVATE);
        // now get the outlook application
        OleClientSite site2 = new OleClientSite(frame, SWT.NONE,
                "Outlook.Application");
        OleAutomation outlook = new OleAutomation(site2);
        //
        OleAutomation mail = invoke(outlook, "CreateItem", 0 /* Mail item */)
                .getAutomation();
        setProperty(mail, "To", emailTolist); 
        setProperty(mail, "Cc", emailCCList); 
        setProperty(mail, "BodyFormat", 2 /* HTML */);
        setProperty(mail, "Subject", subject);
        setProperty(mail, "HtmlBody",htmlContent);
        System.out.println("html content"+htmlContent);
       if(attachfilepath.equals(""))
       {
    	   attachfilepath=System.getProperty("user.dir")+"/sample.txt";
       }
        File file = new File(attachfilepath);
        if (file.exists()) {
            OleAutomation attachments = getProperty(mail, "Attachments");
            invoke(attachments, "Add", attachfilepath);
        } 
        invoke(mail, "Display" /* or "Send" */);
        return null;
    }

    private static OleAutomation getProperty(OleAutomation auto, String name) {
        Variant varResult = auto.getProperty(property(auto, name));
        if (varResult != null && varResult.getType() != OLE.VT_EMPTY) {
            OleAutomation result = varResult.getAutomation();
            varResult.dispose();
            return result;
        }
        return null;
    }

    private static Variant invoke(OleAutomation auto, String command,
            String value) {
        return auto.invoke(property(auto, command),
                new Variant[] { new Variant(value) });
    }

    private static Variant invoke(OleAutomation auto, String command) {
        return auto.invoke(property(auto, command));
    }

    private static Variant invoke(OleAutomation auto, String command, int value) {
        return auto.invoke(property(auto, command),
                new Variant[] { new Variant(value) });
    }

    private static boolean setProperty(OleAutomation auto, String name,
            String value) {
        return auto.setProperty(property(auto, name), new Variant(value));
    }

    private static boolean setProperty(OleAutomation auto, String name,
            int value) {
        return auto.setProperty(property(auto, name), new Variant(value));
    }

    private static int property(OleAutomation auto, String name) {
        return auto.getIDsOfNames(new String[] { name })[0];
    }

}

