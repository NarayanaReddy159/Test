package com.nasco.testutils;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GenerateMailData {
	
	public static List<String> getData() throws Exception
	{
		 List<String> mailData= new ArrayList<String>();
		 String excelFilePath = System.getProperty("user.dir")+"/DSRMailData.xlsx";
	     FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
	     Workbook workbook = new XSSFWorkbook(inputStream);
	     Sheet firstSheet = workbook.getSheetAt(0);
	     mailData.add(firstSheet.getRow(1).getCell(0).getStringCellValue());
	     mailData.add(firstSheet.getRow(1).getCell(1).getStringCellValue());
	     mailData.add(firstSheet.getRow(1).getCell(2).getStringCellValue());
	     String bodyheader=firstSheet.getRow(1).getCell(3).getStringCellValue();
	     String [] bodyheaderData=bodyheader.split("\\|");
	     StringBuilder bodyheaderValue= new StringBuilder();
	     bodyheaderValue.append("<html><div style='color:darkblue;font-family:calibri;font-size:14;'>");
	     for(int i=0;i<bodyheaderData.length;i++)
	     {
	    	 bodyheaderValue.append(bodyheaderData[i]+"<br/>");	 
	     }
	     bodyheaderValue.append("</div>");
	     bodyheaderValue.append("<br/><div style='color:blue;font-family:calibri;font-size:16;'><u>Status:</u><br/></div>");
	     
	     String status=firstSheet.getRow(1).getCell(4).getStringCellValue();
	     String [] statusValues=status.split("\\|");
	     for(int i=0;i<statusValues.length;i++)
	     {
	    	 	 bodyheaderValue.append("<div style='color:darkblue;font-family:calibri;font-size:14;'><u>");
	    		 String s[] = statusValues[i].split(":");
	    		 for(int j=0;j<s.length;j++)
	    		 {
	    			 if(j==0)
	    			 {
	    				 bodyheaderValue.append(s[j]+":"+"</u></div>");
	    			 }else{
	    				 /*String [] sj=s[j].split("\\,");
	    				 if(sj.length>2)
	    				 {
	    					 for(int k=0;k<sj.length;k++)
	    					 {
	    						 if(k/2!=0)
	    						 {
	    							 bodyheaderValue.append("<div style='color:green;font-family:calibri;font-size:13;'>o "+sj[k]+" "+sj[k+1]);
		    						 bodyheaderValue.append("</div>");	 
	    						 }
	    					 }
	    				 }else{*/
	    					 bodyheaderValue.append("<div style='color:green;font-family:calibri;font-size:13;'>"+s[j]);
	    					 bodyheaderValue.append("</div>");
	    				 //}
	    				
	    			 }
	    			 
	    		 }
	    }
	     bodyheaderValue.append("<br/>");
	     String tableData=firstSheet.getRow(1).getCell(5).getStringCellValue();
	     String [] tables=tableData.split("\\|");
	     for(int i=0;i<tables.length;i++)
	     {
	    	 String [] values=tables[i].split("\\:");
	    	 bodyheaderValue.append("<div style='color:darkblue;font-family:calibri;font-size:14;'><u>"+values[0]+":");
	    	 bodyheaderValue.append("</u></div><br/>");
	    	 if(values[1].contains("Pivot"))
	    	 {
	    		 bodyheaderValue.append(ReadExcelPiviotTable.readExcelPiviotTable(firstSheet.getRow(1).getCell(7).getStringCellValue(), values[1]));	 
	    	 }else{
	    		 bodyheaderValue.append(ReadExcelTable.readExcelTable(firstSheet.getRow(1).getCell(7).getStringCellValue(), values[1]));
	    	 }
	    	 bodyheaderValue.append("<br/>");
	     }
	     //String tableData=firstSheet.getRow(1).getCell(3).getStringCellValue();
	     String footer=firstSheet.getRow(1).getCell(6).getStringCellValue();
	     String [] footerVlaues=footer.split("\\|");
	     for(int i=0;i<footerVlaues.length;i++)
	     {
	    	 if(i==0){
	    		 bodyheaderValue.append("<p style='color:darkblue;font-family:calibri;font-size:14;'>"+footerVlaues[i]+"</p><p style='color:black;font-family:Century Gothic;font-size:13;'>");
	    	 }else{
	    		 bodyheaderValue.append(footerVlaues[i]+"<br/>");	 
	    	 }
	    	 
	     }
	     bodyheaderValue.append("</p><br/>");
	    
	     bodyheaderValue.append("</html>");
	     
	     
	     //System.out.println(bodyheaderValue.toString());
	     mailData.add(bodyheaderValue.toString());
	     String filepath="";
	     try{
	    	 filepath=firstSheet.getRow(1).getCell(8).getStringCellValue();
	     }catch(Exception e)
	     {
	     }
	     mailData.add(filepath);
	     workbook.close();
	     inputStream.close();
	     return mailData;
	}

}
