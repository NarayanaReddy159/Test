package DocumentExtractRead.DemoMavenDocumentExtractRead;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

public class App 
{
	public static void main( String[] args )
    {
    	final JFrame frame = new JFrame("Document Reader");
		frame.setSize(400, 400);
		frame.setLocation(750, 350);
		frame.setVisible(true);
		
		frame.addWindowListener(new WindowListener() {
			
			public void windowOpened(WindowEvent arg0) {
				JFileChooser fileChooser = new JFileChooser();
				int selected = fileChooser.showOpenDialog(frame);
				
				if(selected == JFileChooser.APPROVE_OPTION) {
					String path = fileChooser.getSelectedFile().getAbsolutePath();
					String[] splittedData = path.split("\\.");
					
					if(splittedData.length > 0) {
						if(splittedData[1].equalsIgnoreCase("docx")) {
							String Text1 = "";
							try {
								FileInputStream fps = new FileInputStream(path);
								@SuppressWarnings("resource")
								XWPFDocument docu = new XWPFDocument(fps);
								
								List<XWPFParagraph> data = docu.getParagraphs();
								
								for(XWPFParagraph p : data) {
									System.out.print(p.getText());
									Text1 = p.getText();
									System.out.print(Text1);
								}
								
							}
							catch(FileNotFoundException ex) {
								System.out.print(ex.getMessage());
				
							}
							catch(IOException ex1) {
								System.out.print(ex1.getMessage());
							
							}
						}
					}
				}
				/*File file = new File("G:\\Kiran\\NewTestMatrixByTool.xlsx");
				XSSFWorkbook wb = new XSSFWorkbook();
				
				XSSFSheet sh = wb.createSheet();
				sh.createRow(0).createCell(0).setCellValue("TS#");
				sh.createRow(1).createCell(0).setCellValue("TS_01");
				sh.createRow(2).createCell(0).setCellValue("TS_02");
				sh.createRow(3).createCell(0).setCellValue("TS_03");
				sh.createRow(4).createCell(0).setCellValue("TS_04");
				sh.createRow(5).createCell(0).setCellValue("TS_05");
				sh.getRow(0).createCell(1).setCellValue("Test Scenario Description");
				sh.createRow(1).createCell(1).setCellValue("Validate");
				sh.getRow(0).createCell(2).setCellValue("Test Type");
				sh.getRow(1).createCell(2).setCellValue("Positive");
				sh.getRow(0).createCell(3).setCellValue("Test case#");
				sh.getRow(1).createCell(3).setCellValue("TC_01");
				sh.getRow(2).createCell(3).setCellValue("TC_02");
				sh.getRow(3).createCell(3).setCellValue("TC_03");
				sh.getRow(4).createCell(3).setCellValue("TC_04");
				sh.getRow(5).createCell(3).setCellValue("TC_05");
				sh.getRow(0).createCell(4).setCellValue("Use Case Id");
				sh.getRow(1).createCell(4).setCellValue("1.1.M");
				sh.getRow(0).createCell(5).setCellValue("Priority");
				sh.getRow(1).createCell(5).setCellValue("High");
				sh.getRow(0).createCell(6).setCellValue("Requirement Rule");
				sh.getRow(1).createCell(6).setCellValue("NA");
				sh.getRow(0).createCell(7).setCellValue("Description - Test Objective");
				sh.getRow(1).createCell(7).setCellValue("Validate");
				sh.getRow(0).createCell(8).setCellValue("Test Data Mapping");
				sh.getRow(1).createCell(8).setCellValue("1.Active Contract UMI");
				sh.getRow(0).createCell(9).setCellValue("Instructions - Test Steps");
				sh.getRow(1).createCell(9).setCellValue("1. Login to GoldBase NCompass Portal."
						        +"\n"+ "2. Click '+New' button on the Home  screen and select 'Live Interaction-Member' and click on it."
								+"\n"+ "3. Select Member ID"
								+"\n"+ "4. Enter Member ID in corresponding text box"
								+"\n"+ "5. Click on Search Button"
								+"\n"+ "6. Select a member and Submit"
								+"\n"+ "7. Authenticate the member using Member's DOB and Address on Verify member screen"
								+"\n"+ "8. Click Submit "
								+"\n"+ "7. Click Add Task button on Interaction Manager screen.");
				sh.getRow(0).createCell(10).setCellValue("Expected Results");
				sh.getRow(0).createCell(11).setCellValue("Actual Results");
				sh.getRow(0).createCell(12).setCellValue("Group Info");
				sh.getRow(0).createCell(13).setCellValue("Status");
				sh.getRow(0).createCell(14).setCellValue("Date");
				sh.getRow(0).createCell(15).setCellValue("Defect ID");
				sh.getRow(0).createCell(16).setCellValue("Retesting Date");
				sh.getRow(0).createCell(17).setCellValue("Group Info");
				sh.getRow(0).createCell(18).setCellValue("BA Comments");
				sh.getRow(0).createCell(19).setCellValue("SIT Comments");
				
				try{
					FileOutputStream fos = new FileOutputStream(file);
					wb.write(fos);
					System.exit(0);
				}catch(Exception e){
					e.printStackTrace();
					System.exit(0);
				}*/
			}
			public void windowIconified(WindowEvent arg0) {
				
			}
			public void windowDeiconified(WindowEvent arg0) {
				
			}
			
			public void windowDeactivated(WindowEvent arg0) {
				
			}
			
			public void windowClosing(WindowEvent arg0) {
				
			}
			
			public void windowClosed(WindowEvent arg0) {
				
			}
			
			public void windowActivated(WindowEvent arg0) {
				
			}
		});
    }
}
