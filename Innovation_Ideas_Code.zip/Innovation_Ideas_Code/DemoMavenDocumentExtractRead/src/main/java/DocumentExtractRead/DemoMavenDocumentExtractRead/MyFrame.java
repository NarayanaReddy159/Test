package DocumentExtractRead.DemoMavenDocumentExtractRead;

import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;


@SuppressWarnings({ "rawtypes", "unchecked" })
public class MyFrame implements ActionListener{
	public JFrame jframe;
	JButton button,GenerateReportBtn;
	public JTextField relaseText,cycleText,interationTF,intentTF,planNameTF,testingPhaseTF;
	String filepath="";
	String fileName="";
	String sheetName="";
	String testCase="";
    String testScenario="";
    String testObjective="";
    String expectedResults="";
    String actualResults="";
    String status="";
    String testSteps="";
    String dataForTest="";
    String testingPhase="";
    String release="";
    String cycle="";
    String interaction="";
    String intent="";
    String planName="";
    String usecase="";
    

    public void getFrame()
    {
    	jframe= new JFrame();
    	jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setLayout(new FlowLayout());
    	jframe.setPreferredSize(new Dimension(880,550));
    	jframe.setTitle("Test Evidence Generation Tool");
		JLabel fileSelectLable= new JLabel("Select Test matrix: ");
		button = new JButton("Select File");
		button.addActionListener(this);
		jframe.add(fileSelectLable);
		jframe.setBounds(300, 50, 50, 20);
		fileSelectLable.setBounds(10, 15, 250, 25);
		button.setBounds(200,15,150,30);
		jframe.add(button);
		relaseText= new JTextField(50);
		cycleText= new JTextField(50);
		interationTF= new JTextField(50);
		jframe.add(interationTF);
		intentTF= new JTextField(50);
		jframe.add(intentTF);
		testingPhaseTF= new JTextField(50);
		planNameTF= new JTextField(50);
		GenerateReportBtn= new JButton("Generate Test Evidences");
		jframe.add(GenerateReportBtn);
		jframe.add(relaseText);
		jframe.add(cycleText);
		jframe.setLayout(null);
		jframe.pack();
		jframe.setVisible(true);
    }
    
	MyFrame(){		
		
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==button) {
			
			JFileChooser fileSelectr = new JFileChooser();
			
			fileSelectr.setCurrentDirectory(new File(".")); 
			
			int response = fileSelectr.showOpenDialog(null); 
			
			if(response == JFileChooser.APPROVE_OPTION) {
				File file = new File(fileSelectr.getSelectedFile().getAbsolutePath());
				filepath=file.getAbsolutePath();
				fileName=Paths.get(filepath).getFileName().toString();
				try {
					List<String>sheets= getSheetNames(filepath);
					JLabel sheetsLabel= new JLabel("Select Sheet Name:");
					jframe.add(sheetsLabel);
					sheetsLabel.setBounds(450, 15, 250, 25);
					final JComboBox excelSheets= new JComboBox(sheets.toArray()); 
					excelSheets.setBounds(650,15,200,30);
					jframe.add(excelSheets);
					SwingUtilities.updateComponentTreeUI(jframe);
					excelSheets.addActionListener( new ActionListener() {
						 public void actionPerformed(ActionEvent e) {
							sheetName= String.valueOf(excelSheets.getSelectedItem());
							String [] spaceSheet=sheetName.split(" ");
							if(spaceSheet.length==1)
							{
								try {
									JLabel usecaseLabel= new JLabel("Enter Usecase:");
									jframe.add(usecaseLabel);
									usecaseLabel.setBounds(10, 50, 250, 25);
									final JTextField usecaseFT= new JTextField(50);
									jframe.add(usecaseFT);
									usecaseFT.setBounds(200, 50, 200, 30);
									JLabel releaseLabel= new JLabel("Enter Release:");
									jframe.add(releaseLabel);
									releaseLabel.setBounds(450, 50, 250, 25);
									final JTextField releaseFT= new JTextField(50);
									jframe.add(releaseFT);
									releaseFT.setBounds(650, 50, 200, 30);
									List<String> headers=getHeaders(filepath);
									JLabel testCaseIdLabel= new JLabel("Select Test case id:");
									jframe.add(testCaseIdLabel);
									testCaseIdLabel.setBounds(10, 90, 250, 25);
									final JComboBox testCaseIdCB= new JComboBox(headers.toArray()); 
									jframe.add(testCaseIdCB);
									for(int i=0;i<headers.size();i++)
									{
										String testCaseValue=headers.get(i).toString();
										testCaseValue.toLowerCase();
										if(testCaseValue.toLowerCase().contains("test case"))
										{
											testCaseIdCB.setSelectedItem(headers.get(i).toString());
										}
									}
									testCaseIdCB.setSelectedItem("");
									testCaseIdCB.setBounds(200, 90, 200, 30);
									JLabel testScenarioIdLabel= new JLabel("Select Test Scenario id:");
									jframe.add(testScenarioIdLabel);
									testScenarioIdLabel.setBounds(450, 90, 250, 25);
									final JComboBox testScenarioIdCB= new JComboBox(headers.toArray()); 
									jframe.add(testScenarioIdCB);
									testScenarioIdCB.setBounds(650, 90, 200, 30);
									for(int i=0;i<headers.size();i++)
									{
										if(headers.get(i).toString().toLowerCase().contains("test scenario id"))
										{
											testScenarioIdCB.setSelectedItem(headers.get(i).toString());
										}
									}
									JLabel testObjectiveLabel= new JLabel("Select Test Objective:");
									jframe.add(testObjectiveLabel);
									testObjectiveLabel.setBounds(10, 130, 250, 25);
									final JComboBox testObjectiveCB= new JComboBox(headers.toArray()); 
									jframe.add(testObjectiveCB);
									testObjectiveCB.setBounds(200, 130, 200, 30);
									for(int i=0;i<headers.size();i++)
									{
										if(headers.get(i).toString().toLowerCase().contains("objective"))
										{
											testObjectiveCB.setSelectedItem(headers.get(i).toString());
										}
									}
									JLabel testDataLabel= new JLabel("Select Test Data:");
									jframe.add(testDataLabel);
									testDataLabel.setBounds(450, 130, 250, 25);
									final JComboBox testDataCB= new JComboBox(headers.toArray()); 
									jframe.add(testDataCB);
									for(int i=0;i<headers.size();i++)
									{
										if(headers.get(i).toString().toLowerCase().contains("test data"))
										{
											testDataCB.setSelectedItem(headers.get(i).toString());
										}
									}
									testDataCB.setBounds(650, 130, 200, 30);
									JLabel testStepsLabel= new JLabel("Select Test Steps:");
									jframe.add(testStepsLabel);
									testStepsLabel.setBounds(10, 170, 250, 25);
									final JComboBox testStepsCB= new JComboBox(headers.toArray()); 
									jframe.add(testStepsCB);
									testStepsCB.setBounds(200, 170, 200, 30);
									for(int i=0;i<headers.size();i++)
									{
										if(headers.get(i).toString().toLowerCase().contains("test steps"))
										{
											testStepsCB.setSelectedItem(headers.get(i).toString());
										}
									}
									JLabel expectedResultsLabel= new JLabel("Select Expected Results:");
									jframe.add(expectedResultsLabel);
									expectedResultsLabel.setBounds(450, 170, 250, 25);
									final JComboBox expectedResultsCB= new JComboBox(headers.toArray()); 
									jframe.add(expectedResultsCB);
									for(int i=0;i<headers.size();i++)
									{
										if(headers.get(i).toString().toLowerCase().contains("expected results"))
										{
											expectedResultsCB.setSelectedItem(headers.get(i).toString());
										}
									}
									expectedResultsCB.setBounds(650, 170, 200, 30);
									JLabel actualResultsLabel= new JLabel("Select Actual Results:");
									jframe.add(actualResultsLabel);
									actualResultsLabel.setBounds(10, 210, 250, 25);
									final JComboBox actualResultsCB= new JComboBox(headers.toArray()); 
									jframe.add(actualResultsCB);
									actualResultsCB.setBounds(200, 210, 200, 30);
									for(int i=0;i<headers.size();i++)
									{
										if(headers.get(i).toString().toLowerCase().contains("actual results"))
										{
											actualResultsCB.setSelectedItem(headers.get(i).toString());
										}
									}
									JLabel statusLabel= new JLabel("Select Status:");
									jframe.add(statusLabel);
									statusLabel.setBounds(450, 210, 250, 25);
									final JComboBox statusCB= new JComboBox(headers.toArray()); 
									jframe.add(statusCB);
									statusCB.setBounds(650, 210, 200, 30);
									for(int i=0;i<headers.size();i++)
									{
										if(headers.get(i).toString().toLowerCase().contains("status"))
										{
											statusCB.setSelectedItem(headers.get(i).toString());
										}
									}
									JLabel cycleLabel= new JLabel("Select Cycle:");
									jframe.add(cycleLabel);
									cycleLabel.setBounds(10, 250, 250, 25);
									final JComboBox cycleCB= new JComboBox(headers.toArray()); 
									jframe.add(cycleCB);
									cycleCB.setBounds(200, 250, 200, 30);
									final JLabel cycleTBLabel= new JLabel("Enter Cycle:");
									jframe.add(cycleTBLabel);
									
									
									for(int i=0;i<headers.size();i++)
									{
										if(headers.get(i).toString().toLowerCase().contains("cycle"))
										{
											cycleCB.setSelectedItem(headers.get(i).toString());
										}else{
											cycleCB.setSelectedItem("Other");
											cycleText.setBounds(650, 250, 200, 30);
											cycleTBLabel.setBounds(450, 250, 250, 25);
										}
									}
									
									/*JLabel intentLabel= new JLabel("Enter Intent:");
									jframe.add(intentLabel);
									intentLabel.setBounds(10, 290, 250, 25);
									jframe.add(intentTF);
									intentTF.setBounds(200, 290, 200, 30);*/
									
									
									//New 
									JLabel intetLabel= new JLabel("Select Intent:");
									jframe.add(intetLabel);
									intetLabel.setBounds(10, 290, 200, 25);
									jframe.add(intentTF);
									String [] intentValues={"Select","Other",
											"Create Follow Up","Create GSI","Find a Provider","Manage Checks",
											"Manage Claims","Manage Other Coverage","Manage PCP","Respond To Customer",
											"Request ID Card","Schedule Appointment","View Totals","View Benefits","View Authorizations",
											"Website Support"};
									final JComboBox intentCB= new JComboBox(intentValues);
									jframe.add(intentCB);
									intentCB.setBounds(200, 290, 200, 30);
									final JLabel intnetTFLbl= new JLabel("Enter Intent:");
									jframe.add(intnetTFLbl);
									intentCB.setSelectedItem(intentValues[0]);
									
									intentCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											intent=String.valueOf(intentCB.getSelectedItem());
											if(intent.equals("Other"))
											{
												intnetTFLbl.setVisible(true);
												intentTF.setVisible(true);
												intnetTFLbl.setBounds(450, 290, 250, 25);
												intentTF.setBounds(650, 290, 200, 30);
												SwingUtilities.updateComponentTreeUI(jframe);
											}else{
												intnetTFLbl.setVisible(false);
												intentTF.setVisible(false);
												SwingUtilities.updateComponentTreeUI(jframe);
											}
										}
									});
									
									//New
									
									JLabel interactionLabel= new JLabel("Select Interaction:");
									jframe.add(interactionLabel);
									interactionLabel.setBounds(10, 330, 200, 25);
									jframe.add(interationTF);
									String [] interactionValues={"Select","Other",
											"Live Interaction","Research Interaction","Non Live Interaction"};
									final JComboBox interactionCB= new JComboBox(interactionValues);
									jframe.add(interactionCB);
									interactionCB.setBounds(200, 330, 200, 30);
									final JLabel interactionTFLbl= new JLabel("Enter Interaction:");
									jframe.add(interactionTFLbl);
									for(int i=0;i<interactionValues.length;i++)
									{
										if(interactionValues[i].toLowerCase().equals("live interaction"))
										{
											interactionCB.setSelectedItem(interactionValues[i]);
										}
									}
									interactionCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											interaction=String.valueOf(interactionCB.getSelectedItem());
											if(interaction.equals("Other"))
											{
												interactionTFLbl.setVisible(true);
												interationTF.setVisible(true);
												interactionTFLbl.setBounds(450, 330, 250, 25);
												interationTF.setBounds(650, 330, 200, 30);
												SwingUtilities.updateComponentTreeUI(jframe);
											}else{
												interactionTFLbl.setVisible(false);
												interationTF.setVisible(false);
												SwingUtilities.updateComponentTreeUI(jframe);
											}
										}
									});
									
									
									JLabel testingPhaseLabel= new JLabel("Select Phase:");
									jframe.add(testingPhaseLabel);
									testingPhaseLabel.setBounds(10, 370, 250, 25);
									String [] testingPhaseValues= {"Select","Other","ST","SIT","SIT Workflow",
																	"Regression","UAT"};
									final JComboBox testingPhaseCB = new JComboBox(testingPhaseValues);
									jframe.add(testingPhaseCB);
									testingPhaseCB.setBounds(200, 370, 200, 30);
									final JLabel testingPhaseTFLabel= new JLabel("Enter Phase:");
									jframe.add(testingPhaseTFLabel);
									testingPhaseCB.setSelectedItem("SIT");
									testingPhaseCB.addActionListener(new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											testingPhase=testingPhaseCB.getSelectedItem().toString();
											if(testingPhase.equals("Other"))
											{
												testingPhaseTFLabel.setVisible(true);
												testingPhaseTF.setVisible(true);
												testingPhaseTFLabel.setBounds(450, 370, 250, 25);
												jframe.add(testingPhaseTF);
												testingPhaseTF.setBounds(650, 370, 200, 30);
												SwingUtilities.updateComponentTreeUI(jframe);
											}
											else{
												testingPhaseTFLabel.setVisible(false);
												testingPhaseTF.setVisible(false);
												SwingUtilities.updateComponentTreeUI(jframe);
											}
										}
									});
									
									
									JLabel planNameLabel= new JLabel("Select Plan Name:");
									jframe.add(planNameLabel);
									planNameLabel.setBounds(10, 410, 250, 25);
									String [] planNames={"Select","Other",
											"High Mark", "Gold Base", "Horozion", "MA", "MI"};
									final JComboBox planNameCB= new JComboBox(planNames);
									jframe.add(planNameCB);
									planNameCB.setBounds(200, 410, 200, 30);
									planNameCB.setSelectedItem("High Mark");
									final JLabel planNameTFLbl= new JLabel("Enter Plan Name:");
									planNameCB.addActionListener(new ActionListener() {
										public void actionPerformed(ActionEvent e) {
										planName=planNameCB.getSelectedItem().toString();
										if(planName.equals("Other"))
										{
											jframe.add(planNameTFLbl);
											planNameTF.setVisible(true);
											planNameTFLbl.setVisible(true);
											jframe.add(planNameTF);
											planNameTF.setBounds(650, 410, 200, 30);
											planNameTFLbl.setBounds(450,410,250,25);
											SwingUtilities.updateComponentTreeUI(jframe);
										}else
										{
											planNameTF.setVisible(false);
											planNameTFLbl.setVisible(false);
											SwingUtilities.updateComponentTreeUI(jframe);
										}
											
										}
									});
									
									
									GenerateReportBtn.setBounds(350,470,200,35);
									SwingUtilities.updateComponentTreeUI(jframe);
									GenerateReportBtn.addActionListener(new ActionListener() {
										
										public void actionPerformed(ActionEvent e) {
											testCase=String.valueOf(testCaseIdCB.getSelectedItem());
											testScenario=String.valueOf(testScenarioIdCB.getSelectedItem());
											testObjective=String.valueOf(testObjectiveCB.getSelectedItem());
											expectedResults=String.valueOf(expectedResultsCB.getSelectedItem());
											actualResults=String.valueOf(actualResultsCB.getSelectedItem());
											status=String.valueOf(statusCB.getSelectedItem());
											testSteps=String.valueOf(testStepsCB.getSelectedItem());
											dataForTest=String.valueOf(testDataCB.getSelectedItem());
											release=releaseFT.getText();
											usecase=usecaseFT.getText();
											if(cycle.equals("Other"))
											{
												cycle=cycleText.getText();
												
											}else{
												cycle=cycleCB.getSelectedItem().toString();
											}
											if(interaction.equals("Other"))
											{
												interaction=interationTF.getText();
											}else{
												interaction=interactionCB.getSelectedItem().toString();
											}
											if(planName.equals("Other"))
											{
												planName=planNameTF.getText().toString();
											}else{
												planName=planNameCB.getSelectedItem().toString();
											}
											if(intent.equals("Other"))
											{
												intent=intentTF.getText().toString();
											}else{
												intent=intentCB.getSelectedItem().toString();
											}
											
											if(testingPhase.equals("Other"))
											{
												testingPhase=testingPhaseTF.getText();
											}else{
												testingPhase= testingPhaseCB.getSelectedItem().toString();
											}
											
											generateReport(filepath, interaction, intent,usecase, planName,sheetName, testCase, testScenario, testObjective, 
													expectedResults, actualResults, status, testSteps, dataForTest,testingPhase,
													release, cycle);
											jframe.dispose();
											try {
												File fileloc= new File(System.getProperty("user.dir")+"/GeneratedDocs");
												Desktop.getDesktop().browse(fileloc.toURI());
											} catch (IOException e3) {
												
												e3.printStackTrace();
											}
											CreateOptionPane.optionPane("Test Evidence docs are generated, please check @ GeneratedDocs folder");
										}
									});
									
									cycleCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											cycle=String.valueOf(cycleCB.getSelectedItem());
											if(cycle.equals("Other"))
											{
												cycleText.setVisible(true);
												cycleTBLabel.setVisible(true);
												cycleText.setBounds(650, 250, 200, 30);
												cycleTBLabel.setBounds(450, 250, 250, 25);
												SwingUtilities.updateComponentTreeUI(jframe);
											}else{
												cycleText.setVisible(false);
												cycleTBLabel.setVisible(false);
												SwingUtilities.updateComponentTreeUI(jframe);
											}
										}
									});
									
									
								} catch (Exception e1) {
								e1.printStackTrace();
								
									jframe.dispose();
									CreateOptionPane.optionPane("No Header values present in the selected sheet '"+sheetName+"',  please select sheet having testcases");
								}
							}
							else{
								
								jframe.dispose();
								CreateOptionPane.optionPane("Sheet Name '"+sheetName+"' is having space, please update sheet name without spaces and re run");
							}
						}
					 }	);
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
				
				
			}
		}
		
		
		
	}
	
	public List<String> getSheetNames(String Filepath) throws Exception
	{
		List<String> sheetNames= new ArrayList<String>();
		FileInputStream fis=new FileInputStream(Filepath);
		Workbook workbook = new XSSFWorkbook(fis);
		sheetNames.add("Select Sheet");
		for(int i=0;i<workbook.getNumberOfSheets();i++)
		{
			sheetNames.add(workbook.getSheetName(i));
		}
		workbook.close();
		return sheetNames;
	}
	
	public void generateReport(String filepath,String interaction,String intent,String usecase,
			String planName,String sheetName,String testCase,String testScenario,String testObjective,
			String expectedResults,String actualResults, String status,String testSteps, String 			dataForTest,String testingPhase,String release,String cycle
			)
	{
		String fileName=Paths.get(filepath).getFileName().toString();
		String releaseValue="";
		String cycleValue="";
		try{
			 FileInputStream fis=new FileInputStream(filepath);
			 Workbook workbook = new XSSFWorkbook(fis);
			Sheet sheet = workbook.getSheet(sheetName);
			int testRows=sheet.getLastRowNum();
			int dataStartRowNum = 1;
			int testCols = 0;
			testCols = sheet.getRow(0).getLastCellNum();
			for (int rNum = dataStartRowNum; rNum <= testRows; rNum++) {
				Hashtable<String, String> table = new Hashtable<String, String>();
				for (int cNum = 0; cNum < testCols; cNum++) {
					String colName = "";
					String testData = "";
					try {
						colName = sheet.getRow(0).getCell(cNum).toString();
						testData = sheet.getRow(rNum).getCell(cNum).toString();
					} catch (Exception e1) {
					}
					table.put(colName, testData);
				}
				
				
				if (!Paths.get("./GeneratedDocs").toFile().exists())
					Files.createDirectories(Paths.get("./GeneratedDocs"));
				
				if(!table.get(testCase).equals("")){
					XWPFDocument document = new XWPFDocument();
					FileOutputStream out = new FileOutputStream(
							"GeneratedDocs/" + testingPhase+"_"+table.get(testCase)+"_" +usecase+".docx");
					addParagraphSetText(document, "Test Matrix File name < " + fileName + " >");
					XWPFTable pfttable = document.createTable();
					pfttable.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
					XWPFTableRow tableRowOne = pfttable.getRow(0);
					tableRowOne.getCell(0).setText(" Test Scenario# : " + table.get(testScenario));
					tableRowOne.addNewTableCell().setText(" Intent: " + interaction + "-" + intent);
					addTableRow(pfttable, " Test case ID: " + table.get(testCase), " Sprint#:");
					addTableRow(pfttable, " Defect ID:", " Plan: " + planName);
					releaseValue=release;
					try{
						if(!cycle.equals(""))
						{
							cycleValue=table.get(cycle);
							if(table.get(cycle).equals(null))
							{
								cycleValue=cycle;
							}
						}
					}
					catch(Exception e1)
					{
						cycleValue=cycle;
					}
					addTableRow(pfttable, " Release: "+releaseValue, " Cycle: "+ cycleValue);
					addTableRow(pfttable, " Quality Reviewer: ", " ");
					addParagraphBreakTest(document);
					addParagraphBold(document, "Type of Interaction: ",interaction);
					addParagraphBold(document, "Test Data: ",table.get(dataForTest));
					addParagraphSetText(document, "• Member id:");
					addParagraphSetText(document, "• Claim Number:");
					addParagraphBold(document, "Test case: ",table.get(testCase));
					addParagraphBold(document, "Test Objective:  ",table.get(testObjective));
					addParagraphBold(document, "Expected Result: ", table.get(expectedResults));
					addParagraphBold(document, "Actual Result: ",table.get(actualResults));
					addParagraphBold(document, "Status:  " + table.get(status));
					addParagraphBold(document, "Screen shots:  ", "See screen shots below for reference");
					addParagraphBold(document, "Letter Template Evidence:   ","NA");
					addParagraphBold(document, "Screen shots provided:  ");
					String s = table.get(testSteps);
					String[] s1 = s.split("\n");
					if(s1.length>0)
					{
						for (int i = 0; i < s1.length; i++) {
							addParagraphSetText(document, s1[i]);
						}
						
					}
					else{
						addParagraphSetText(document, s);
					}
					document.write(out);
		            out.close();
				}
				workbook.close();
	            fis.close();
	       }
		}catch(Exception e)
		{
			
		}
	}
	public List<String> getHeaders(String Filepath) throws Exception
	{
		List<String> headers= new ArrayList<String>();
		FileInputStream fis=new FileInputStream(Filepath);
		Workbook workbook = new XSSFWorkbook(fis);
		Sheet sheet = workbook.getSheet(sheetName);
		int testCols = 0;
		testCols = sheet.getRow(0).getLastCellNum();
		headers.add("Select");
		headers.add("Other");
		for (int cNum = 0; cNum < testCols; cNum++) {
			String headerValue=sheet.getRow(0).getCell(cNum).toString();
			if(!headerValue.equals(""))
			{
				headers.add(sheet.getRow(0).getCell(cNum).toString());
			}
		}
		
		workbook.close();
		return headers;
	}
	
	public static void addParagraphBreakTest(XWPFDocument document) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.addBreak();
	}

	public static void addParagraphBold(XWPFDocument document, String textToSet) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.setBold(true);
		run.setText(textToSet);
	}
	
	public static void addParagraphBold(XWPFDocument document, String boldText, String plainText) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.setBold(true);
		run.setText(boldText);
		XWPFRun run1 = paragraph.createRun();
		run1.setText(plainText);
	}

	public static void addParagraphSetText(XWPFDocument document, String textToSet) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.setText(textToSet);
	}

	public static void addTableRow(XWPFTable table, String cellOValue, String cell1Value) {
		XWPFTableRow tableRow = table.createRow();
		tableRow.getCell(0).setText(cellOValue);
		tableRow.getCell(1).setText(cell1Value);
	}
}