package DocumentExtractRead.DemoMavenDocumentExtractRead;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;


public class ReadDocBulletPoints {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws Exception {
	
		String filename = System.getProperty("user.dir")+"/Specification - View Totals.docx";
      
		FileInputStream fis = new FileInputStream(filename);
		XWPFDocument docx= new XWPFDocument(fis);
		List<XWPFParagraph> paragraphList = docx.getParagraphs();
		System.out.println(paragraphList.size());
		List<String> MainpathData= new ArrayList<String>();
		for(XWPFParagraph paragraph:paragraphList)
		{
			MainpathData.add(paragraph.getText());
			System.out.println(paragraph.getText());
		}
		
		/*int j=0;
		int k=0;
		for(int i=0;i<MainpathData.size();i++)
		{
			if(MainpathData.get(i).trim().equals("MAIN PATH:"))
			{
				j=i;
			}
			if(MainpathData.get(i).trim().equals("Use case ends."))
			{
				k=i;
			}
			
		}
		List<String> convertedData= new ArrayList<String>();
		for(int i=j+3;i<k;i++)
		{
			if(!MainpathData.get(i).trim().equals(""))
			{
				convertedData.add(MainpathData.get(i).trim());
			}
		}
		System.out.println(convertedData.size());
		for(int i=0;i<convertedData.size();i++)
		{
			System.out.println(convertedData.get(i));
		}*/
	}
	

}
