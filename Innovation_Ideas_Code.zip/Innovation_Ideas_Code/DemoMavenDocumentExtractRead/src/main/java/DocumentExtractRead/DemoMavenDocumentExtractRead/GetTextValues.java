package DocumentExtractRead.DemoMavenDocumentExtractRead;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class GetTextValues implements ActionListener{

	JButton addRelease;
	JTextField releaseText;
	public void getRelease(JFrame jframe)
	{
		addRelease = new JButton("Add Button");
		releaseText= new JTextField(50);
		jframe.add(addRelease);
		jframe.add(releaseText);
		releaseText.setBounds(520, 445, 150, 35);
		addRelease.setBounds(675, 445, 120, 35);
		System.out.println("release text added");
		System.out.println("release button added");
	}

	public void actionPerformed(ActionEvent e) {
		System.out.println(e.getSource());
		if(e.getSource()==addRelease)
		{
			//MyFrame.releaseTF=releaseText.getText();
			//System.out.println("In GetText: "+MyFrame.releaseTF);
		}
		
	}
}
