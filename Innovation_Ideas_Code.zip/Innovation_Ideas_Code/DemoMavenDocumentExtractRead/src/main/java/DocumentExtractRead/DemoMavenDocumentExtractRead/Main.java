package DocumentExtractRead.DemoMavenDocumentExtractRead;

public class Main {
	public static void main(String[] args) {
		
		// JFileChooser = A GUI mechanism that let's a user choose a file (helpful for opening or saving files)
		
		MyFrame createFrame= new MyFrame();
		createFrame.getFrame();
	}
}
