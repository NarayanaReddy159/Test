package com.nasco.CQ.utilities;

public class EmailHTMLBuilder {

	public StringBuilder sb = new StringBuilder();

	public void appendSummary_Header(String header_Content,String defectsData) {
		sb.append("<html>");
		sb.append("<head></head>");
		sb.append("<body>");
		sb.append("<h5>Hi All,</h5>");
		sb.append("<h4>" + header_Content + "</h4>");
		sb.append("<h4>" + defectsData + "</h4>");
		sb.append("" + "<Br/>"  + "<h5>Thanks," + "<Br/>" + "Testing Team." + "</h5>"
				+ "</body>" + "</html>");
	}

	
}
