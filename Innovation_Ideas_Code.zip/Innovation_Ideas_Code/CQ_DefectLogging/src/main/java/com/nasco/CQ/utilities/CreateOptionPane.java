package com.nasco.CQ.utilities;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class CreateOptionPane {

	
	public static void optionPane(String message)
	{
		 Thread t1 = new Thread(new Runnable() {
	            public void run() {
	                try {
	                    Thread.sleep(30000);
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }               
	                JOptionPane.getRootFrame().dispose();
	            }
	        });
	        t1.start();
	        JOptionPane.showMessageDialog(null, message);
	        System.exit(0);
	}
	
	public static int dialoguePane()
	{
		JFrame f= new JFrame();
		int input =JOptionPane.showConfirmDialog(f,"Do you want to submit?","Log Defect",JOptionPane.YES_NO_CANCEL_OPTION );
		f.dispose();
		return input;
	}
	
	
	/*public static void optionPane(String[] args) {
		// TODO Auto-generated method stub
new CreateOptionPane("");
	}*/

}
