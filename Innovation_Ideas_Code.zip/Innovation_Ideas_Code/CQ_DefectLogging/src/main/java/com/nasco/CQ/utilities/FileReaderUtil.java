package com.nasco.CQ.utilities;

import java.io.BufferedReader;
import java.io.FileReader;

public class FileReaderUtil {

	public static String FileRead(String fileName)  {
		String fileData="";
		try {
			BufferedReader reader = new BufferedReader(new FileReader(System.getProperty("user.dir")+"/"+fileName));
			 reader.readLine(); // this will read the first line
			 String line1=null;
			 
			 while ((line1 = reader.readLine()) != null){ //loop will run from 2nd line
			     fileData= fileData+line1+", ";
			 }
			 if(!fileData.equals(""))
			 {
				 fileData=fileData.substring(0,fileData.length()-2);
			 }
			 reader.close();
		    } catch (Exception e) {
		     
		    }
		return fileData;
	}

}
