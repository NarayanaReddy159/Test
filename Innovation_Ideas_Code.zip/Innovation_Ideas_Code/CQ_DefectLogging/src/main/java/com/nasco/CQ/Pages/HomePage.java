package com.nasco.CQ.Pages;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.CQ.Run.RunTestNG_CQ;
import com.nasco.CQ.Setup.BasePage;
import com.nasco.CQ.utilities.CreateOptionPane;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class HomePage extends BasePage {

	String excepionMessage = "";

	// web elements
	@FindBy(xpath = "//div[text()='New Defect']")
	public WebElement newDefect;

	@FindBy(id = "cqFindRecordString")
	public WebElement searchDefectInput;
	
	@FindBy(id = "cqFindRecordButton")
	public WebElement searchDefectBtn;
	
	@FindBy(xpath = "//span[text()='Save']")
	public WebElement saveDefectBtn;
	
	
	String defectID="(//td[contains(@title,'Defect:')])[%d]";
	String headLine="(//label[contains(text(),'State')]//following::textarea[1])[%d]";
	String project="(//label[contains(text(),'Headline')]//following::input[contains(@id,'cq_widget_CqEditableCombo')][1])[%d]";
	String importance="(//label[contains(text(),'Project')]//following::input[contains(@id,'cq_widget_CqFilteringSelect')][1])[%d]";
	String csr="(//label[contains(text(),'Importance')]//following::input[contains(@id,'cq_widget_CqEditableCombo')][1])[%d]";
	String seviority="(//label[contains(text(),'CSR')]//following::input[contains(@id,'cq_widget_CqEditableCombo')][1])[%d]";
	String priority="(//label[contains(text(),'PIV')]//following::input[contains(@id,'cq_widget_CqFilteringSelect')][1])[%d]";
	String priorityLabel="(//label[contains(text(),'Priority')])[%d]";
	String piv="(//label[contains(text(),'Severity')]//following::input[contains(@id,'cq_widget_CqEditableCombo')][1])[%d]";
	String release="(//label[contains(text(),'PIV')]//following::input[contains(@id,'cq_widget_CqFilteringSelect')][3])[%d]";
	String type="(//label[contains(text(),'PIV')]//following::input[contains(@id,'cq_widget_CqEditableCombo')][1])[%d]";
	String functionalArea="(//label[contains(text(),'Type')]//following::input[contains(@id,'cq_widget_CqEditableCombo')][1])[%d]";
	String environment="(//label[contains(text(),'Type')]//following::input[contains(@id,'cq_widget_CqFilteringSelect')][1])[%d]";
	String platForm="(//label[contains(text(),'Functional Area')]//following::input[contains(@id,'cq_widget_CqEditableCombo')][1])[%d]";
	String testingPhase="(//label[contains(text(),'Functional Area')]//following::input[contains(@id,'cq_widget_CqEditableCombo')][2])[%d]";
	String description="(//label[contains(text(),'Type')]//following::textarea[1])[%d]";
	String referncesTab="(//span[contains(text(),'References')])[%d]";
	String notesTab="(//span[contains(text(),'Notes')])[%d]";
	String notesLog="(//label[contains(text(),'Origin of Defect')]//following::textarea[1])[%d]";
	String organization="(//label[contains(text(),'Contact Nbr')]//following::input[contains(@id,'cq_widget_CqFilteringSelect')][1])[%d]";
	String refCQ="(//label[contains(text(),'Symptoms')]//following::input[1])[%d]";
	String attachmentsTab="(//span[text()='Attachments'])[%d]";
	String addattach="(//span[text()='Add...'])[%d]";
	String addAttachUpload="(//span[text()='Add' and contains(@id,'dijit_form_Button')])[%d]";
	String fileUpload="(//input[@id='attachment_file'])[%d]";
	String fileDesc="(//input[@id='attachment_description'])[%d]";
	String changeState="//span[text()='Change State']";
	String statusChange="(//td[text()='%s'])[%d]";
	String role="(//label[contains(text(),'Delivery Team')]//following::input[contains(@id,'cq_widget_CqEditableCombo')][1])[%d]";
	String owner="(//label[contains(text(),'Role')]//following::input[contains(@id,'cq_widget_CqFilteringSelect')][1])[%d]";
	String deliveryTeam="(//label[contains(text(),'Functional Area')]//following::input[contains(@id,'cq_widget_CqEditableCombo')][1])[%d]";
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(newDefect);
	}

	public HomePage openHomePage() {
		return (HomePage) openPage(HomePage.class);
	}

	public String createNewDefect(Hashtable<String, String> data, int row) {
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		String defectid = "";
		try{
			webElementClick(newDefect, "New Defect");
			defectid =webElementReadText(driver.findElement(By.xpath(String.format(defectID, row))), "New Defect id");
			defectid = defectid.substring(7, defectid.length());
			waitSleep(1500);
			driver.findElement(By.xpath(String.format(environment, row))).sendKeys(data.get("Environment"));
			waitSleep(2000);
			driver.findElement(By.xpath(String.format(headLine, row))).sendKeys(data.get("Headline"),Keys.DOWN);
			waitSleep(700);
			driver.findElement(By.xpath(String.format(project, row))).sendKeys(data.get("Project"));
			driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			waitSleep(700);
			driver.findElement(By.xpath(String.format(csr, row))).sendKeys(data.get("CSR"));
			driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			waitSleep(1000);
			if(null != data.get("Type") && !data.get("Type").isEmpty())
			{
				waitSleep(1000);
				driver.findElement(By.xpath(String.format(type, row))).sendKeys(data.get("Type"));
				driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			}
			if(null != data.get("FunctionalArea") && !data.get("FunctionalArea").isEmpty())
			{
				waitSleep(1000);
				driver.findElement(By.xpath(String.format(functionalArea, row))).sendKeys(data.get("FunctionalArea"));
				driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			}
			if(null != data.get("Platform") && !data.get("Platform").isEmpty())
			{
				waitSleep(1000);
				driver.findElement(By.xpath(String.format(platForm, row))).sendKeys(data.get("Platform"));
				driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			}
			if(null != data.get("PIV") && !data.get("PIV").isEmpty())
			{
				waitSleep(1000);
				driver.findElement(By.xpath(String.format(piv, row))).sendKeys(data.get("PIV"));
				driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			}
			if(null != data.get("TestingPhase") && !data.get("TestingPhase").isEmpty())
			{
				waitSleep(1000);
				driver.findElement(By.xpath(String.format(testingPhase, row))).sendKeys(data.get("TestingPhase"));
				driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			}
			waitSleep(1500);
			webElementSendText(driver.findElement(By.xpath(String.format(importance, row))), data.get("Importance"), "Importance");
			waitSleep(1500);	
			webElementSendText(driver.findElement(By.xpath(String.format(seviority, row))), data.get("Seviority"), "Seviority");
			waitSleep(1500);
			if(null != data.get("Release") && !data.get("Release").isEmpty())
			{
				webElementSendText(driver.findElement(By.xpath(String.format(release, row))), data.get("Release"), "Release");
				waitSleep(3000);
				webElementSendText(driver.findElement(By.xpath(String.format(description, row))), data.get("Description"), "Description");
				waitSleep(1500);	
			}
			webElementSendText(driver.findElement(By.xpath(String.format(priority, row))), data.get("Priority"), "Priority");
			waitSleep(2000);
			webElementClick(driver.findElement(By.xpath(String.format(referncesTab, row))), "References Tab");
			waitSleep(1000);
			webElementSendText(driver.findElement(By.xpath(String.format(organization, row))), data.get("Org"), "Organization");
			waitSleep(1000);
			if(null != data.get("RefCQ") && !data.get("RefCQ").isEmpty())
			{
				webElementSendText(driver.findElement(By.xpath(String.format(refCQ, row))), data.get("RefCQ"), "Reference CQ#");
					
			}
			if(null != data.get("AttachmentsPath") && !data.get("AttachmentsPath").isEmpty())
			{
				attchFile(row,data.get("AttachmentsPath"),data.get("AttachDesc"));
			}
			driver.findElement(By.xpath(String.format(notesTab, row))).click();
			if(null != data.get("Notes") && !data.get("Notes").isEmpty())
			{
				notesLog(data,row);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return defectid;
	}

	public void attchFile(int row, String AttachmentsPath,String AttachDesc)
	{
		String attachFilepath=AttachmentsPath;
		webElementClick(driver.findElement(By.xpath(String.format(attachmentsTab, row))), "Attachments Tab");
		webElementClick(driver.findElement(By.xpath(String.format(addattach, row))), "Add Attachement");
		driver.switchTo().activeElement();
		
		File oldFilePath = new File(AttachmentsPath);
		String filepath=oldFilePath.getName();
		String file=oldFilePath.getAbsolutePath();
		file=file.substring(0,file.length()-filepath.length());
		String fileName=FilenameUtils.removeExtension(filepath);
		String extension =FilenameUtils.getExtension(filepath);
		String updatedFileName="";
		if(fileName.length()>45)
		{
			Random rand = new Random();
			int upperbound = 10000;
			int int_random = rand.nextInt(upperbound); 
			updatedFileName=fileName.substring(0,35)+"_"+int_random+"."+extension;
			File newFile= new File(file+"\\"+updatedFileName);
			try {
				FileUtils.copyFile(oldFilePath, newFile);
			} catch (IOException e) {
				e.printStackTrace();
			}
			attachFilepath=file+"\\"+updatedFileName;
		}
		try {
			waitSleep(1500);
			driver.findElement(By.xpath(String.format(fileUpload, row))).sendKeys(attachFilepath);
			driver.findElement(By.xpath(String.format(fileDesc, row))).sendKeys(AttachDesc);
			driver.findElement(By.xpath(String.format(addAttachUpload, row))).click();
			waitSleep(2500);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		driver.switchTo().defaultContent();
		
		if(!attachFilepath.equals(AttachmentsPath))
		{
			try{
				File newFile= new File(attachFilepath);
				newFile.delete();
			}
			catch(Exception e1)
			{
				e1.printStackTrace();
			}
		}
	}
	
	public void notesLog(Hashtable<String, String> data,int row)
	{
		driver.findElement(By.xpath(String.format(notesTab, row))).click();
		driver.findElement(By.xpath(String.format(notesLog, row))).sendKeys(data.get("Notes"));
	}
	
	public void assignNotesLog(Hashtable<String, String> data,int row)
	{
		driver.findElement(By.xpath(String.format(notesTab, row))).click();
		driver.findElement(By.xpath(String.format(notesLog, row))).sendKeys(data.get("AssignNotes"));
	}
	
	public String assignDefect(Hashtable<String, String> data,int row)
	{
		String defectid = "";
		try{
			webElementSendText(searchDefectInput, data.get("DefectID"), "Search DefectID");
			webElementClick(searchDefectBtn, "Search Button");
			waitSleep(2000);
			defectid =webElementReadText(driver.findElement(By.xpath(String.format(defectID, row))), "Defect id");
			defectid = defectid.substring(7, defectid.length());
			waitSleep(1000);
			webElementClick(driver.findElement(By.xpath(String.format(changeState, row))), "Change State");
			webElementClick(driver.findElement(By.xpath(String.format(statusChange,data.get("Status"), row))), "Status");
			waitSleep(1500);
			webElementSendText(driver.findElement(By.xpath(String.format(role, row))), data.get("Role"), "Role");
			waitSleep(1000);
			driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			webElementSendText(driver.findElement(By.xpath(String.format(owner, row))), data.get("Owner"), "Owner");
			waitSleep(1000);
			driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			webElementSendText(driver.findElement(By.xpath(String.format(deliveryTeam, row))), "NASCO", "Delivery Team");
			waitSleep(1000);
			driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			
			if(null != data.get("AttachmentsPath") && !data.get("AttachmentsPath").isEmpty())
			{
				attchFile(row,data.get("AttachmentsPath"),data.get("AttachDesc"));
			}
			driver.findElement(By.xpath(String.format(notesTab, row))).click();
			if(null != data.get("Notes") && !data.get("Notes").isEmpty())
			{
				waitSleep(1500);
				notesLog(data,row);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();	
		}
		return defectid;
	}
	
	public String assignSaveDefect(Hashtable<String, String> data,String defectId,int row)
	{
		String defectid = "";
		try{
			webElementSendText(searchDefectInput, defectId, "Search DefectID");
			webElementClick(searchDefectBtn, "Search Button");
			waitSleep(2000);
			defectid =webElementReadText(driver.findElement(By.xpath(String.format(defectID, row))), "Defect id");
			defectid = defectid.substring(7, defectid.length());
			waitSleep(1000);
			webElementClick(driver.findElement(By.xpath(String.format(changeState, row))), "Change State");
			webElementClick(driver.findElement(By.xpath(String.format(statusChange,data.get("AssignStatus"), row))), "Status");
			waitSleep(1500);
			webElementSendText(driver.findElement(By.xpath(String.format(role, row))), data.get("Role"), "Role");
			waitSleep(1000);
			driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			webElementSendText(driver.findElement(By.xpath(String.format(owner, row))), data.get("Owner"), "Owner");
			waitSleep(1000);
			driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			webElementSendText(driver.findElement(By.xpath(String.format(deliveryTeam, row))), "NASCO", "Delivery Team");
			waitSleep(1000);
			driver.findElement(By.xpath(String.format(priorityLabel, row))).click();
			
			if(null != data.get("AssignAttachmentsPath") && !data.get("AssignAttachmentsPath").isEmpty())
			{
				attchFile(row,data.get("AssignAttachmentsPath"),data.get("AssignAttachmentsDesc"));
			}
			driver.findElement(By.xpath(String.format(notesTab, row))).click();
			if(null != data.get("AssignNotes") && !data.get("AssignNotes").isEmpty())
			{
				waitSleep(1500);
				assignNotesLog(data,row);
			}
			createdefect(data);
		}
		catch(Exception e)
		{
			e.printStackTrace();	
		}
		return defectid;
	}
	
	
	
	public void createdefect(Hashtable<String, String> data)
	{
		if(RunTestNG_CQ.Config.getProperty("Manual_intervention").equals("true"))
		{
			if(CreateOptionPane.dialoguePane()!=0)
			{
				System.out.println("Stop execution");	
				System.exit(0);	
			}else{
				System.out.println("Continue execution");
				saveDefectBtn.click();
				wait(5000);
			}
			
		}else{
			System.out.println("this is manual intervention");
			saveDefectBtn.click();
			wait(5000);
		}
	}
}
