package com.nasco.CQ.utilities;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.nasco.CQ.Run.RunTestNG_CQ;

public class EmailUtil {

	public static void sendEmailWithAttachment( String Env_Subject, String timestamp, String htmlContent) {
		// this will set host of server- you can change based on your
		// requirement
		RunTestNG_CQ.Config.put("mail.smtp.host", RunTestNG_CQ.Config.getProperty("SMTP"));

		RunTestNG_CQ.Config.put("mail.smtp.user", "lakshmi.karri@nasco.com");

		RunTestNG_CQ.Config.put("mail.smtp.starttls.enable", "true");

		// set the port of socket factory
		RunTestNG_CQ.Config.put("mail.smtp.socketFactory.port", "25");

		// set socket factory
		RunTestNG_CQ.Config.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

		RunTestNG_CQ.Config.put("mail.smtp.socketFactory.fallback", "true");

		// set the authentication to true
		RunTestNG_CQ.Config.put("mail.smtp.auth", "true");

		// set the port of SMTP server
		RunTestNG_CQ.Config.put("mail.smtp.port", "25");
		// This will handle the complete authentication
		Session session = Session.getDefaultInstance(RunTestNG_CQ.Config,
				new javax.mail.Authenticator() {

					protected javax.mail.PasswordAuthentication getPasswordAuthentication() {

						return new PasswordAuthentication(RunTestNG_CQ.Config.getProperty("Email_Username"),
								RunTestNG_CQ.Config.getProperty("Email_Password"));

					}

				});

		try {

			// Create object of MimeMessage class
			Message message = new MimeMessage(session);

			// Set the from address
			message.setFrom(new InternetAddress(RunTestNG_CQ.Config.getProperty("Email_From")));
			// Set the recipient address
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(RunTestNG_CQ.Config.getProperty("Email_list")));
			message.setRecipients(Message.RecipientType.CC,
					InternetAddress.parse(RunTestNG_CQ.Config.getProperty("Email_CC_list")));

			// Add the subject link

			message.setSubject(
					RunTestNG_CQ.Config.getProperty("Email_Subject") +" - "+timestamp);

			// Create object to add multimedia type content
			BodyPart messageBodyPart1 = new MimeBodyPart();

			// Set the body of email

			
			// set the body html table content

			messageBodyPart1.setContent(htmlContent, "text/html");

	
			// Create object of MimeMultipart class
			Multipart multipart = new MimeMultipart();

			// add body part 1
			multipart.addBodyPart(messageBodyPart1);

		
			// set the content
			message.setContent(multipart);

			// finally send the email
			Transport.send(message);

		
		} catch (MessagingException e) {

			throw new RuntimeException(e);

		}

	}

}