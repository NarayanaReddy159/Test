package com.nasco.CQ.TestScripts;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Hashtable;

import org.testng.annotations.Test;

import com.nasco.CQ.Base.BaseTest;
import com.nasco.CQ.Pages.DefectsListPage;
import com.nasco.CQ.Pages.LoginPage;
import com.nasco.CQ.Run.RunTestNG_CQ;
import com.nasco.CQ.utilities.DataProviders;
import com.nasco.CQ.utilities.DriverManager;
import com.nasco.CQ.utilities.EmailUtil;


public class CQAssignedDefects extends BaseTest {
	
	
	@Test(dataProviderClass = DataProviders.class, dataProvider = "CQLoggingDP")
	public void GetAssignedDefects(Hashtable<String, String> data) throws Exception {
		try {
			setUpFramework();
			test = DriverManager.getExtentReport();
			openBrowser(RunTestNG_CQ.Config.getProperty("Browser").toString());
			LoginPage login = new LoginPage().open(RunTestNG_CQ.Config.getProperty("QueryURL").toString());
			login.loginTogetQuery(RunTestNG_CQ.Config.getProperty("username"),
					RunTestNG_CQ.Config.getProperty("password"));
			DefectsListPage defectList= new DefectsListPage().openDefectsListPage();
			int defectCount=defectList.getDefectsList();
			//System.out.println("Defect Count: "+defectCount);
			String htmlcontent="";
			String tableHeader="";
			String tableValues="";
			if(defectCount>0)
			{
				tableHeader=defectList.getHeader();
				tableValues=defectList.getDefectsListValues(defectCount);
			}
			
			DriverManager.getDriver().navigate().to(RunTestNG_CQ.Config.getProperty("ProdURL").toString());
			//System.out.println(RunTestNG_CQ.Config.getProperty("ProdURL"));
			login.loginTogetQuery(RunTestNG_CQ.Config.getProperty("username"),
					RunTestNG_CQ.Config.getProperty("password"));
			DefectsListPage defectList1= new DefectsListPage().openDefectsListPage();
			int defectCount1=defectList1.getDefectsList();
			String tableValues1="";
			if(defectCount1>0)
			{
				tableHeader=defectList1.getHeader();
				tableValues1=defectList1.getDefectsListValues(defectCount1);
			}
			
			String contentValues=tableHeader;
		
			if(defectCount>0)
			{
				contentValues=contentValues+tableValues;
			}
			if(defectCount1>0)
			{
				if(!contentValues.equals(tableHeader))
				{
					if(!tableValues1.equals(""))
					{
						contentValues=contentValues+","+tableValues1;
					}
						
				}else{
					contentValues=contentValues+tableValues1;
				}
				
			}
			
			if(!contentValues.equals(tableHeader))
			{
				htmlcontent=defectList1.getHtml(contentValues,RunTestNG_CQ.noofDefects);
			}
			if(htmlcontent.equals("")){
				htmlcontent=defectList.getEmpty();
			}
			//System.out.println(htmlcontent);
			String timeStamp = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss a").format(Calendar.getInstance().getTime());
			EmailUtil.sendEmailWithAttachment("",timeStamp+" "+RunTestNG_CQ.Config.getProperty("TimeStamp") ,htmlcontent);
			quit();
		}catch(Exception e1)
		{
		}
				
	}
	
	
	
	
	
}
