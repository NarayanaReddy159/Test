package com.nasco.CQ.utilities;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;

import com.nasco.CQ.Run.RunTestNG_CQ;

public class DataProviders {

	@DataProvider(name = "CQLoggingDP", parallel = false)
	public static Object[][] getDataG1(Method m) {

		ExcelReader excel = new ExcelReader(
				System.getProperty("user.dir") + RunTestNG_CQ.Config.getProperty("TestData_XL_PATH"));
		String testcase = m.getName();
		return DataUtil.getData(testcase, excel);

	}
	
	

}
