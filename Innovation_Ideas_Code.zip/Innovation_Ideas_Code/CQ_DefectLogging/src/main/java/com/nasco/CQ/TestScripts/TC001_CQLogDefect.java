package com.nasco.CQ.TestScripts;

import java.util.Hashtable;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.nasco.CQ.Base.BaseTest;
import com.nasco.CQ.Pages.HomePage;
import com.nasco.CQ.utilities.DataProviders;
import com.nasco.CQ.utilities.FileUtil;
import com.relevantcodes.extentreports.LogStatus;


public class TC001_CQLogDefect extends BaseTest {
	String defects="";
	

	@Test(dataProviderClass = DataProviders.class, dataProvider = "CQLoggingDP")
	public void AUTC001_CQLogDefect(Hashtable<String, String> data) throws Exception {
		HomePage homepage = new HomePage().openHomePage();
		String defectid=homepage.createNewDefect(data,i+1);
		defects=defects+defectid+"\n";
		//homepage.attchFile(data, i);
		i++;
	}
	
	@AfterClass
	public void tearDown()
	{
		FileUtil.createandwriteFile("DefectsList.txt", defects);
		try{
			//DriverManager.getDriver().close();
		}
		catch(Exception e1)
		{
		}
		test.log(LogStatus.INFO, "TC001_CQLogDefect Execution Completed.");
		log.debug("TC001_CQLogDefect Execution Completed.");
	}
	
	
}
