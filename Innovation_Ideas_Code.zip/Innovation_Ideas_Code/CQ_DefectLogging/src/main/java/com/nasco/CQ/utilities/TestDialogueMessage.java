package com.nasco.CQ.utilities;

public class TestDialogueMessage {

	public static void main(String[] args) {
		CreateOptionPane.dialoguePane();
}

}
