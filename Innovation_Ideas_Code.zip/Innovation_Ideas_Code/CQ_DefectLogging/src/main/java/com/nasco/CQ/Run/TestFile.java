package com.nasco.CQ.Run;

import java.io.File;
import java.util.Random;

import org.apache.commons.io.FilenameUtils;

public class TestFile {

	public static void main(String [] args)
	{
		File oldFilePath = new File("G:/@BaseGold_NCompass_Testing/Issues/07192021/Rel21.2ab_Reg_LI_Grouptab_GroupAddre_Section_NotPopulating.docx");
		String filepath=oldFilePath.getName();
		String file=oldFilePath.getAbsolutePath();
		file=file.substring(0,file.length()-filepath.length());	
		String fileName=FilenameUtils.removeExtension(filepath);
		String extension =FilenameUtils.getExtension(filepath);
		String updatedFilename="";
		System.out.println(file);
		System.out.println(fileName);
		System.out.println(extension);
		System.out.println(fileName.length());
		if(fileName.length()>45)
		{
			Random rand = new Random();
			int upperbound = 10000;
			int int_random = rand.nextInt(upperbound); 
			updatedFilename=fileName.substring(0,35)+"_"+int_random+"."+extension;
		}
		
		System.out.println(updatedFilename);
	}
}
