package com.nasco.CQ.utilities;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class FileUtil {

	public static void createandwriteFile(String fileName, String filecontent)
	{
		try {
		      File myObj = new File(System.getProperty("user.dir")+"/"+fileName);
		      if (myObj.createNewFile()) {
		      } else {
		      }
		    } catch (IOException e) {
		      e.printStackTrace();
		    }
		try {
		      FileWriter myWriter = new FileWriter(System.getProperty("user.dir")+"/"+fileName);
		      if(filecontent.equals(""))
		      {
		    	  myWriter.write(filecontent);
		      }else{
		    	  DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");  
		    	  LocalDateTime now = LocalDateTime.now();  
		    	  myWriter.write(dtf.format(now)+"\n"+filecontent);
		      }
		    	  
		      myWriter.close();
		     } catch (IOException e) {
		      e.printStackTrace();
		    }
	}
	
}
