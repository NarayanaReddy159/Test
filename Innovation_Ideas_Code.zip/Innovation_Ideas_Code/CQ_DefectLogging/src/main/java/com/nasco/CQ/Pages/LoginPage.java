package com.nasco.CQ.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.nasco.CQ.Base.BaseTest;
import com.nasco.CQ.Setup.BasePage;
import com.nasco.CQ.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;

@SuppressWarnings("rawtypes")
public class LoginPage extends BasePage {

	// Log in page Fields
	// user Name text box
	@FindBy(id = "loginId_Id")
	public WebElement txtUserName;
	// Password text box
	@FindBy(id = "passwordId")
	public WebElement txtPassword;

	@FindBy(id = "repositoryListId")
	public WebElement txtRepo;

	@FindBy(id = "loginButtonId")
	public WebElement btnConnect;

	@FindBy(id = "userDbListId")
	public WebElement txtdataBase;

	@FindBy(id = "cqConnectSubmitButtonId_label")
	public WebElement btnLogin;

	// open login page
	@SuppressWarnings("unchecked")
	public LoginPage open(String url) {
		BaseTest.log.info("Driver Initialized !!!");
		DriverManager.getDriver().navigate().to(url);
		BaseTest.log.info("Navigated to URL:" + url);
		test.log(LogStatus.INFO, "Navigated to URL:" + url);
		return (LoginPage) openPage(LoginPage.class);
	}

	// Login to application as valid user

	@SuppressWarnings("unchecked")
	public void doLoginAsValidUser(String username, String password, String repository, String dataBase) {

		try {
			webElementSendText(txtUserName, username, "User Name");
			webElementSendText(txtPassword, password, "Password");
			webElementSendText(txtRepo, repository, "Repository");
			webElementClick(btnConnect, "Connect");
			webElementSendText(txtdataBase, dataBase, "Data base");
			jsClick(btnLogin, "Login");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on doLoginAsValidUser method " + e);
			test.log(LogStatus.FAIL, "Error on doLoginAsValidUser method " + e);
			Assert.fail();
		}
	}
	
	@SuppressWarnings("unchecked")
	public void loginTogetQuery(String username, String password)
	{
		webElementSendText(txtUserName, username, "User Name");
		webElementSendText(txtPassword, password, "Password");
		webElementClick(btnConnect, "Connect");
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(txtPassword);
	}

}
