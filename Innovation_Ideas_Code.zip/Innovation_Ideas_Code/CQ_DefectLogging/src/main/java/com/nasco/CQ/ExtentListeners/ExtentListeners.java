package com.nasco.CQ.ExtentListeners;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.nasco.CQ.Run.RunTestNG_CQ;
import com.nasco.CQ.utilities.CreateOptionPane;
import com.nasco.CQ.utilities.DriverManager;
import com.nasco.CQ.utilities.EmailHTMLBuilder;
import com.nasco.CQ.utilities.EmailHTMLBuilder_Body;
import com.nasco.CQ.utilities.EmailUtil;
import com.nasco.CQ.utilities.ExcelReader;
import com.nasco.CQ.utilities.FileReaderUtil;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentListeners implements ITestListener {

	static Date d = new Date();
	static String fileName = "Extent_" + d.toString().replace(":", "_").replace(" ", "_") + ".html";

	Map<String, List<String>> results = new HashMap<String, List<String>>();
	String status = "";
	String reportFileName = "CQDefectLogging.xlsx";
	String reportFilePath = System.getProperty("user.dir") + RunTestNG_CQ.Config.getProperty("ReportFile")
			+ reportFileName;
	String extentFilepath = System.getProperty("user.dir")
			+ RunTestNG_CQ.Config.getProperty("EXTREPORT_LOC");
	public String timeStamp = new SimpleDateFormat("MM-dd-yyyy").format(Calendar.getInstance().getTime());
	public String timeStamp_email = timeStamp;
	EmailHTMLBuilder htmlbuilder_Summary = new EmailHTMLBuilder();
	EmailHTMLBuilder_Body htmlbuilder = new EmailHTMLBuilder_Body();
	DecimalFormat df = new DecimalFormat("###.##");
	static ExcelReader excel = null;
	String path1 = reportFileName.replace(".xlsx", "") + d.toString().replace(":", "_").replace(" ", "_") + ".xlsx";
	String reportFilePath1 = System.getProperty("user.dir") + RunTestNG_CQ.Config.getProperty("ReportFile")
			+ path1;
	private static ExtentReports extent = ExtentManager.getInstance();
	public static ThreadLocal<ExtentTest> testReport = new ThreadLocal<ExtentTest>();

	
	
	String starttime="";
	String endTime="";
	
	public void onTestStart(ITestResult result) {

		ExtentTest test = extent.startTest("TestCase : " + result.getMethod().getMethodName());
		DriverManager.setExtentReport(test);
		testReport.set(DriverManager.getExtentReport());
		try  
		{         
		File f= new File(System.getProperty("user.dir")+"/DefectsList.txt"); 
		File f1= new File(System.getProperty("user.dir")+"/UpdatedDefectsList.txt"); 
		f.delete();
		f1.delete();
		
		}  
		catch(Exception e)  
		{  
		
		}  
	   
	}

	public void onTestSuccess(ITestResult result) {

		String methodName = result.getMethod().getMethodName();
		testReport.get().log(LogStatus.PASS, methodName + " Test Case Passed");
		extent.endTest(testReport.get());
	}

	public void onTestFailure(ITestResult result) {

		String excepionMessage = Arrays.toString(result.getThrowable().getStackTrace());

		if (!excepionMessage.isEmpty())
			testReport.get().log(LogStatus.FAIL, excepionMessage);
		String methodName = result.getMethod().getMethodName();
		try {
			ExtentManager.captureScreenshot(methodName);
			testReport.get().log(LogStatus.FAIL,
					ExtentManager.screenshotName + testReport.get().addScreenCapture(ExtentManager.screenshotName));
		} catch (Exception e) {
			e.printStackTrace();
		}
		testReport.get().log(LogStatus.FAIL, methodName + " Test Case Failed");
		extent.endTest(testReport.get());
	}

	public void onTestSkipped(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		testReport.get().log(LogStatus.SKIP, methodName + " Test Case Skipped");
		extent.endTest(testReport.get());
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	public void onStart(ITestContext context) {
		extent.addSystemInfo("Environment", RunTestNG_CQ.Config.getProperty("Environment"));
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
	    Date date = new Date(); 
	    starttime=formatter.format(date);
	}

	@SuppressWarnings("unused")
	public void onFinish(ITestContext context) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
		SimpleDateFormat dateFormat=new SimpleDateFormat("MMddyyyy"); 
		SimpleDateFormat dateFormat1=new SimpleDateFormat("MMM");
		SimpleDateFormat dateFormat2=new SimpleDateFormat("YYYY");
		SimpleDateFormat dateFormat3=new SimpleDateFormat("MM");
	    Date date = new Date(); 
	    String reportsPath=RunTestNG_CQ.Config.getProperty("Reports_Loc")+dateFormat2.format(date)+"/"+dateFormat3.format(date)+"-"+dateFormat1.format(date).toUpperCase()+"/"+dateFormat.format(date);
	    endTime=formatter.format(date);
	    Date startDate=null;
	    Date endDate=null;
	    try {
	    	startDate=formatter.parse(starttime);
	    	endDate=formatter.parse(endTime);
	    	
	} catch (ParseException e) {
		
	}
	    long diff =endDate.getTime()-startDate.getTime();
	    long diffSeconds = diff / 1000 % 60;  
	    long diffMinutes = diff / (60 * 1000) % 60; 
	    long diffHours = diff / (60 * 60 * 1000);
	    
		if (extent != null) {

			String path = System.getProperty("user.dir") + RunTestNG_CQ.Config.getProperty("ReportFile");
			String suiteStatus_Subject;
			String Env_Subject = null;
			Env_Subject = RunTestNG_CQ.Config.getProperty("Environment");

			if (status.equalsIgnoreCase("")) {
				suiteStatus_Subject = "PASS";
			} else
				suiteStatus_Subject = "FAIL";
			//printMap(results);
			
			String header_content = RunTestNG_CQ.Config.getProperty("Body_Text") + timeStamp_email;
			String defectsList="";
			if(!FileReaderUtil.FileRead("DefectsList.txt").equals(""))
			{
				defectsList=FileReaderUtil.FileRead("DefectsList.txt");
			}
			if(!FileReaderUtil.FileRead("UpdatedDefectsList.txt").equals(""))
			{
				defectsList=defectsList+"\n"+"Updated Defects \n"+FileReaderUtil.FileRead("UpdatedDefectsList.txt");	
			}
			htmlbuilder_Summary.appendSummary_Header(header_content,defectsList);
			String htmlcontent = htmlbuilder_Summary.sb.toString();
			createApplicationLog();
			
			if(!defectsList.equals(""))
			{
				CreateOptionPane.optionPane("CQ Defect Creation / Updation completed \n Please validate.");
				EmailUtil.sendEmailWithAttachment(Env_Subject,timeStamp_email,htmlcontent);
			}
			
		}
		
	}

	


	public void createApplicationLog() {
		FileInputStream instream = null;
		FileOutputStream outstream = null;
		try {
			Date d = new Date();
			File infile = new File(System.getProperty("user.dir") + "/src/test/resources/logs/Application.log");
			File outfile = new File(System.getProperty("user.dir") + "/src/test/resources/logs/Application-"
					+ d.toString().replace(":", "_").replace(" ", "_") + ".log");
			instream = new FileInputStream(infile);
			outstream = new FileOutputStream(outfile);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = instream.read(buffer)) > 0) {
				outstream.write(buffer, 0, length);
			}
			instream.close();
			outstream.close();
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
	}
}
