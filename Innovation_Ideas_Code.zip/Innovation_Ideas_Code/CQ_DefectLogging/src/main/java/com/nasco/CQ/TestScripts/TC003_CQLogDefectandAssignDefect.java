package com.nasco.CQ.TestScripts;

import java.util.Hashtable;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.nasco.CQ.Base.BaseTest;
import com.nasco.CQ.Pages.HomePage;
import com.nasco.CQ.utilities.DataProviders;
import com.nasco.CQ.utilities.FileUtil;
import com.relevantcodes.extentreports.LogStatus;


public class TC003_CQLogDefectandAssignDefect extends BaseTest {
	String defects="";
	

	@Test(dataProviderClass = DataProviders.class, dataProvider = "CQLoggingDP")
	public void AUTC003_CQLogDefectandAssignDefect(Hashtable<String, String> data) throws Exception {
		HomePage homepage = new HomePage().openHomePage();
		
		  String defectid=homepage.createNewDefect(data,1);
		  homepage.createdefect(data); defects=defects+defectid+"\n";
		  System.out.println(data.get("AssignStatus")); if(null !=
		  data.get("AssignStatus") && !data.get("AssignStatus").isEmpty()) {
		  homepage.assignSaveDefect(data,defectid, 1); }
		 
	}
	
	@AfterClass
	public void tearDown()
	{
		FileUtil.createandwriteFile("DefectsList.txt", defects);
		test.log(LogStatus.INFO, "TC003_CQLogDefectandAssignDefect Execution Completed.");
		log.debug("TC003_CQLogDefectandAssignDefect Execution Completed.");
	}
	
	
}
