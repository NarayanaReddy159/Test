package com.nasco.CQ.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nasco.CQ.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked"})
public class DefectsListPage2 extends BasePage {

	
	@FindBy(xpath = "//span[@dojoattachpoint='outOfTotalCount']")
	public WebElement defectsCounnt;
	
	@FindBy(xpath = "//a[text()='Next']")
	public WebElement nextLink;

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		return ExpectedConditions.visibilityOf(defectsCounnt);
	}
	
	public DefectsListPage2 openDefectsListPage() {
		return (DefectsListPage2) openPage(DefectsListPage2.class);
	}
	
	public int getDefectsList()
	{
		int count=0;
		try{
			String defectsCount=webElementReadText(defectsCounnt);
			defectsCount=defectsCount.substring(3, defectsCount.length());
			count=Integer.valueOf(defectsCount);
		}
		catch(Exception e)
		{
			
		}
		
		return count;
	}

	public String getDefectsListValues(int defectsCount)
	{
		String emailContent="";
		try{
			int pages=defectsCount/20;
			float page=(float)defectsCount/20;
			if((float)pages<page)
			{
				pages++;
			}
			
			
			String tableRowsxpath="//table[@class='dojoxGrid-row-table']/tbody/tr";
			List<WebElement> rowsCount=driver.findElements(By.xpath(tableRowsxpath));
			String tablevalues="";
			tablevalues=tablevalues
					+driver.findElement(By.xpath(("("+tableRowsxpath+")[1]/th[1]"))).getText()
					+"|"
					+driver.findElement(By.xpath(("("+tableRowsxpath+")[1]/th[2]"))).getText()
					+"|"
					+"Release"
					+"|"
					+driver.findElement(By.xpath(("("+tableRowsxpath+")[1]/th[3]"))).getText()
					+"|"
					+driver.findElement(By.xpath(("("+tableRowsxpath+")[1]/th[4]"))).getText()
					+"|"
					+driver.findElement(By.xpath(("("+tableRowsxpath+")[1]/th[5]"))).getText()
					+"|"
					+driver.findElement(By.xpath(("("+tableRowsxpath+")[1]/th[6]"))).getText()
					+"|"
					+driver.findElement(By.xpath(("("+tableRowsxpath+")[1]/th[7]"))).getText()
					+"|"
					+"Status Date"
					+"|,";
			for(int p=1;p<=pages;p++)
			{
				if(p!=1)
				{
					nextLink.click();
					wait(3500);
				}
				for(int i=2;i<=rowsCount.size();i++)
				{
					String defect =driver.findElement(By.xpath(("("+tableRowsxpath+")["+i+"]/td[1]"))).getText();
					if(!defect.equals("TRAIN00111812") && !defect.equals("TRAIN00118255")
							&& !defect.equals("TRAIN00118256") && !defect.equals("TRAIN00119452")
							&& !defect.equals("TRAIN00122023") && !defect.equals("TRAIN00122027")
							)
					{
						tablevalues=tablevalues
								+driver.findElement(By.xpath(("("+tableRowsxpath+")["+i+"]/td[1]"))).getText()
								+"|"
								+driver.findElement(By.xpath(("("+tableRowsxpath+")["+i+"]/td[2]"))).getText()
								+"|"
								+driver.findElement(By.xpath(("("+tableRowsxpath+")["+i+"]/td[18]"))).getText()
								+"|"
								+driver.findElement(By.xpath(("("+tableRowsxpath+")["+i+"]/td[3]"))).getText()
								+"|"
								+driver.findElement(By.xpath(("("+tableRowsxpath+")["+i+"]/td[4]"))).getText()
								+"|"
								+driver.findElement(By.xpath(("("+tableRowsxpath+")["+i+"]/td[5]"))).getText()
								+"|"
								+driver.findElement(By.xpath(("("+tableRowsxpath+")["+i+"]/td[6]"))).getText()
								+"|"
								+driver.findElement(By.xpath(("("+tableRowsxpath+")["+i+"]/td[7]"))).getText()
								+"|"
								+driver.findElement(By.xpath(("("+tableRowsxpath+")["+i+"]/td[17]"))).getText()
								+"|";
						if(i<rowsCount.size())
						{
							tablevalues=tablevalues+",";
						}
					}else{
						defectsCount--;
					}
					
							
				}
			}
			if(defectsCount>0)
			{
				StringBuilder htmlHeader= new StringBuilder();
				String[] tablerows=tablevalues.split("\\|,");
				htmlHeader.append("<html> <head> <h5>Hello Team,</h5> <h4>Below Defects are Assigned to SIT Team`</h4>"
						+"<h5>Total Defect(s): "+defectsCount+"</h5>"
						+ " <style>table {margin-bottom:10px;border-collapse:collapse;empty-cells:show}th,td {border:1px solid #009;padding:.25em .5em}th {vertical-align:bottom}td {vertical-align:top}table a {font-weight:bold}.stripe td {background-color: #E6EBF9}.num {text-align:right}.passedodd td {background-color: #3F3}.passedeven td {background-color: #0A0}.skippedodd td {background-color: #DDD}.skippedeven td {background-color: #CCC}.failedodd td,.attn {background-color: #F33}.failedeven td,.stripe .attn {background-color: #D00}.stacktrace {white-space:pre;font-family:monospace}.totop {font-size:85%;text-align:center;border-bottom:2px solid #000}.invisible {display:none}</style> </head><body> <table> <tbody>");
				htmlHeader.append("<tr>");
				for(int i=0;i<tablerows.length;i++)
				{
					
					String tablerow=tablerows[i];
				
					String [] tableCols=tablerow.split("\\|");
					for(int j=0;j<tableCols.length;j++)
					{
						if(i==0)
						{
							htmlHeader.append("<th bgcolor='#8CDE96'>");
						}
						else{
							htmlHeader.append("<td>");
						}
						if(i==0)
						{
							htmlHeader.append(tableCols[j]+"</th>");
						}
						else{
							htmlHeader.append(tableCols[j]+"</td>");
						}
				}
					htmlHeader.append("</tr>");
				}
				//end
				htmlHeader.append("</tbody> </table><Br/><Br/><Br/><h5>Thanks,<Br/>Testing Team.</h5></body></html>");
				emailContent=htmlHeader.toString();	
			}
			
			
			
			//System.out.println(emailContent);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return emailContent;		
	}
	
	public String getEmpty()
	{
		String htmlReport="";
		StringBuilder htmlHeader= new StringBuilder();
		htmlHeader.append("<html> <head> <h5>Hello Team,</h5> <h4>No new defects assigned to SIT Team`at this time</h4> ");
		htmlHeader.append("<Br/><Br/><Br/><h5>Thanks,<Br/>Testing Team.</h5></body></html>");
		htmlReport=htmlHeader.toString();
		return htmlReport;
	}
}
