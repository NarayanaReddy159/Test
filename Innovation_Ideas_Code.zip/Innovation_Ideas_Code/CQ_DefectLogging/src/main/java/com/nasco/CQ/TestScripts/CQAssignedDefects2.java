package com.nasco.CQ.TestScripts;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Hashtable;

import org.testng.annotations.Test;

import com.nasco.CQ.Base.BaseTest;
import com.nasco.CQ.Pages.DefectsListPage;
import com.nasco.CQ.Pages.LoginPage;
import com.nasco.CQ.Run.RunTestNG_CQ;
import com.nasco.CQ.utilities.DataProviders;
import com.nasco.CQ.utilities.DriverManager;
import com.nasco.CQ.utilities.EmailUtil;


public class CQAssignedDefects2 extends BaseTest {
	
	
	@Test(dataProviderClass = DataProviders.class, dataProvider = "CQLoggingDP")
	public void GetAssignedDefects(Hashtable<String, String> data) throws Exception {
		setUpFramework();
		test = DriverManager.getExtentReport();
		openBrowser(RunTestNG_CQ.Config.getProperty("Browser").toString());
		LoginPage login = new LoginPage().open(RunTestNG_CQ.Config.getProperty("QueryURL").toString());
		login.loginTogetQuery(RunTestNG_CQ.Config.getProperty("username"),
				RunTestNG_CQ.Config.getProperty("password"));
		DefectsListPage defectList= new DefectsListPage().openDefectsListPage();
		int defectCount=defectList.getDefectsList();
		String htmlcontent="";
		if(defectCount>0)
		{
			htmlcontent=defectList.getDefectsListValues(defectCount);
		}
		if(htmlcontent.equals("")){
			htmlcontent=defectList.getEmpty();
		}
		String timeStamp = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss a").format(Calendar.getInstance().getTime());
		
		EmailUtil.sendEmailWithAttachment("",timeStamp+" "+RunTestNG_CQ.Config.getProperty("TimeStamp") ,htmlcontent);
		//System.out.println(htmlcontent);
		quit();
		
		
	}
	
	
	
	
	
}
