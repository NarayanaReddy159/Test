package com.nasco.CQ.TestScripts;

import java.util.Hashtable;

import org.testng.annotations.Test;

import com.nasco.CQ.Base.BaseTest;
import com.nasco.CQ.Pages.LoginPage;
import com.nasco.CQ.Run.RunTestNG_CQ;
import com.nasco.CQ.utilities.DataProviders;
import com.nasco.CQ.utilities.DriverManager;
import com.relevantcodes.extentreports.LogStatus;


public class AA_CQLogin extends BaseTest {
	String defects="";
	@Test(dataProviderClass = DataProviders.class, dataProvider = "CQLoggingDP")
	public void AALogintoCQ(Hashtable<String, String> data) throws Exception {
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside TC001_CQLogDefect");
		openBrowser(RunTestNG_CQ.Config.getProperty("Browser").toString());
		log.debug("TC001_CQLogDefect - Launched Browser : " + RunTestNG_CQ.Config.getProperty("Browser"));
		test.log(LogStatus.INFO, "Launched Browser : " + RunTestNG_CQ.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_CQ.Config.getProperty("URL").toString());
		login.doLoginAsValidUser(RunTestNG_CQ.Config.getProperty("username"),
				RunTestNG_CQ.Config.getProperty("password"), RunTestNG_CQ.Config.getProperty("repository"),
				RunTestNG_CQ.Config.getProperty("dataBase"));
	}
	
	
	
	
	
}
