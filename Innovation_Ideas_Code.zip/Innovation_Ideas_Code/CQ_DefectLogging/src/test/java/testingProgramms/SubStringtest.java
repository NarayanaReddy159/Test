package testingProgramms;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class SubStringtest {

	public static void main(String[] args) {
		String defectid="of 34";
		System.out.println(defectid.length());
		defectid=defectid.substring(3, defectid.length());
		System.out.println(defectid);
		int s=0;
		s=Integer.valueOf(defectid);
		int pages=s/20;
		System.out.println(pages);
		float page=(float)s/20;
		System.out.println(page);
		if((float)pages<page)
		{
			pages++;
		}
		System.out.println(pages);
		/*int s=Integer.getInteger(defectid);
		System.out.println(s/20);
		//System.out.println(defectid);
*/		
		/*String s=
				"id|Project|Testing_Phase|FunctionalArea|Headline|State|,TRAIN00111812|WebServicesSIT|SIT||Applied Status is showing in MembersEdge screen but service is not fetching this field.|Opened|,TRAIN00118255|NCompass_GoldBase|Shakeout Testing|Live Interaction|Address hover displays too long, sometimes when it shouldn’t|Resolved|,TRAIN00118256|NCompass_GoldBase|Shakeout Testing|Live Interaction|Issue with members displaying multiple times when searched by SSN|Resolved|,TRAIN00119452|NCompass_GoldBase|Shakeout Testing|Schedule Appointment|default to one appointment row, review harness displays additional row|Approved|,TRAIN00122023|NCompass_HZN|UAT|On-line Reporting|In the Search Email Us and Chat Inventory Report, the Chat Session ID column show Email Ticket Nbr for Email Interactions|Resolved|,TRAIN00122027|NCompass_HZN|UAT|Member Touchpoints|Route code value field is displaying along with additional values(Jumbo, etc). But additional value should not be displayed|Resolved|";
		String[] s1=s.split("\\|,");
		StringBuilder htmlHeader= new StringBuilder();
		htmlHeader.append("<html> <head> <h5>Hello Team,</h5> <h4>Below Defects are Assigned to SIT Team`</h4><style>table {margin-bottom:10px;border-collapse:collapse;empty-cells:show}th,td {border:1px solid #009;padding:.25em .5em}th {vertical-align:bottom}td {vertical-align:top}table a {font-weight:bold}.stripe td {background-color: #E6EBF9}.num {text-align:right}.passedodd td {background-color: #3F3}.passedeven td {background-color: #0A0}.skippedodd td {background-color: #DDD}.skippedeven td {background-color: #CCC}.failedodd td,.attn {background-color: #F33}.failedeven td,.stripe .attn {background-color: #D00}.stacktrace {white-space:pre;font-family:monospace}.totop {font-size:85%;text-align:center;border-bottom:2px solid #000}.invisible {display:none}</style> </head><body> <table> <tbody>");
		htmlHeader.append("<tr>");
		
		
		for(int i=0;i<s1.length;i++)
		{
			
			String s2=s1[i];
		
			String [] s3=s2.split("\\|");
			for(int j=0;j<s3.length;j++)
			{
				if(i==0)
				{
					htmlHeader.append("<th bgcolor='#8CDE96'>");
				}
				else{
					htmlHeader.append("<td>");
				}
				if(i==0)
				{
					htmlHeader.append(s3[j]+"</th>");
				}
				else{
					htmlHeader.append(s3[j]+"</td>");
				}
				
				
			}
			htmlHeader.append("</tr>");
		}
		//end
		htmlHeader.append("</tbody> </table><Br/><Br/><Br/><h5>Thanks,<Br/>HMHS Testing Team.</h5></body></html>");
		System.out.println(htmlHeader.toString());*/
		
		String timeStamp = new SimpleDateFormat("MM-dd-yyyy k:mm:ss a").format(Calendar.getInstance().getTime());
		System.out.println(timeStamp);
		
		
		
	}

}
