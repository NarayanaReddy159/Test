package testingProgramms;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRowWithtext {

	public static int rowNumber(String toFind,String Excelpath, String sheetName) throws Exception
	{
		
		int rowValue =-1;
		FileInputStream fileIn= new FileInputStream(Excelpath);
		XSSFWorkbook workbook = new XSSFWorkbook(fileIn);
		XSSFSheet sheet = workbook.getSheet(sheetName);
		DataFormatter formatter = new DataFormatter();
		out:
		for (Row row : sheet) {
		    for (Cell cell : row) {
		        CellReference cellRef = new CellReference(row.getRowNum(), cell.getColumnIndex());

		        // get the text that appears in the cell by getting the cell value and applying any data formats (Date, 0.00, 1.23e9, $1.23, etc)
		        String text = formatter.formatCellValue(cell);

		        // is it an exact match?
		        if (toFind.equals(text)) {
		        	rowValue= cellRef.getRow();
		        	break out;
		        }
		       
		    }
		}
	return rowValue;
	}
}
