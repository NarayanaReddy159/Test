package com.nasco.HMHS.TestScripts.G2.GSI;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Pages.WorkbasketPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC007_GSI_RouteIntentToCreatingOperator extends BaseTest{
	
	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC007_GSI_RouteIntentToCreatingOperator(Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC007_GSI_RouteIntentToCreatingOperator");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC007_GSI_RouteIntentToCreatingOperator - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		log.debug("HMHS_TC002_Report_Vaildate_SLABreakdownofOpenServiceRequests -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username2") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username2")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed");
		test.log(Status.INFO, "Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page");
		test.log(Status.INFO, data.get("Fname") + "Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO, "Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Member Verified successfully.");
        test.log(Status.INFO, "Member Verified successfully.");
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(Status.INFO,"Add Intent "+data.get("Intent"));
        ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
       
		TOT.Createnew(data);
		log.debug("Validate the Create new tab");
		TOT.submitGSI(data);
		log.debug("Validate the Review session tab");
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		
		DriverManager.getDriver().close();
		DriverManager.getDriver();
		setUpFramework();
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		LoginPage login1 = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage1 = login1.doLoginAsValidUser( 
					RunTestNG_NCompass_HMHS.Config.getProperty("username3"),
					RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		
		WorkbasketPage Workbasket = homepage1.openrecentWorkbasket();
		Workbasket.movetoWorkbasketPage();
		log.debug("Navigated to the Home-Workbasket Section");
		test.log(Status.INFO, "Navigated to the Home-Workbasket Section");
		Workbasket.Workbasketcheck(data);
		Workbasket.sortandSelectIntent(intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from Workbasket tab ");
		log.debug("Sorted and selected intent " + intentID + " from Workbasket tab ");
		test.log(Status.INFO, "Sorted and selected intent " + intentID + " from Workbasket tab ");
		Workbasket.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Navigate to Interaction screen ");
		Workbasket.vaildationsAssignedoperator("PegaGadget1Ifr",data);
		log.debug("Check the Assigned operator.");
		Workbasket.contractInformation(data);
		log.debug("Check the contract Information.");
		Workbasket.Servicerequestreview("PegaGadget1Ifr", data);
		log.debug("Validate the Service request review Workbasket table");
		test.log(Status.INFO, "Check the Service request review.");
		Workbasket.Routeintenttocreatingoperator(data);
		log.debug("Validate the Route intent to creating operator table");
		test.log(Status.INFO, "Click the Route intent to creating operator.");
		DriverManager.getDriver().close();
		DriverManager.getDriver();
		setUpFramework();
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		LoginPage login2 = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage2 = login2.doLoginAsValidUser( 
				RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		WorklistPage worklist= homepage2.openrecentWorklist();
		worklist.movetoWorklistPage();
		worklist.sortandSelectIntent(intentID);
		worklist.contractInformation(data);
		log.debug("Check the contract Information.");
		worklist.Servicerequestreview("PegaGadget1Ifr", data);
		log.debug("Validate the Service request review Workbasket table");
		test.log(Status.INFO, "Check the Service request review.");
		
		worklist.Resolve(data);
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  {

		test.log(Status.INFO, "HMHS_AUTC007_GSI_RouteIntentToCreatingOperator Completed.");
		log.debug("HMHS_AUTC007_GSI_RouteIntentToCreatingOperator Completed.");
		quit();
	}

}
