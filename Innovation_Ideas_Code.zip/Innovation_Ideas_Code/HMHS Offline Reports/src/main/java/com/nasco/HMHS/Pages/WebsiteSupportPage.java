package com.nasco.HMHS.Pages;

import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked","unused"})
public class WebsiteSupportPage extends BasePage {

	String excepionMessage = "";
	
//	String Websitetoolsandinformation="(//div[contains(@class,'flex content layout-content-inline_grid_triple  content-inline_grid_triple clearfix')])[1]//span[contains(text(),'%s')]//following::div[1]";
//	String WebsitegroupXpath="(//div[contains(@class,'flex content layout-content-inline_grid_triple  content-inline_grid_triple clearfix')])[2]//span[contains(text(),'%s')]//following::div[1]";
//	String GroupheaderXpath="(//div[contains(@class,' flex content layout-content-inline_grid_triple  content-inline_grid_triple clearfix')])//span[contains(text(),'%s')]//following::div[1]"; 
	
	String Websitetoolsandinformation="//span[contains(text(),'%s')]//following::div[1]";
	String WebsitegroupXpath="//span[contains(text(),'%s')]//following::div[1]";
	String GroupheaderXpath="//span[contains(text(),'%s')]//following::div[1]"; 

	
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	@FindBy(how = How.XPATH, using = "//button[@title='Add task']")
	public WebElement add;
	@FindBy(how = How.XPATH, using  = "//a[contains(text(),'CSR utility')]")
	public WebElement crsutility;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Registered on website')]")
	public WebElement Registeredonwebsite;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Registered on website')]//following::div[1]")
	public WebElement Membernotregistered;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Username')]")
	public WebElement Username;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Website account status')]")
	public WebElement Websiteaccountstatus;
	@FindBy(how = How.XPATH, using  = "(//span[contains(text(),'Website')])[3]")
	public WebElement Website;
	@FindBy(how = How.XPATH, using  = "//span[text()='Website']//following::div[1]")
	public WebElement WebsiteValue;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'ID card group status code')]")
	public WebElement IDcardgroup;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Website group feature')]")
	public WebElement groupfeature;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Eligible for care cost estimator')]")
	public WebElement eligibleforcarecost;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Benefit book on portal')]")
	public WebElement benefitbookonportal;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Mobile app enabled')]")
	public WebElement mobileappenabled;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Plan progress available')]")
	public WebElement planprogressavailable;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Wellness program')]")
	public WebElement wellnessprogram;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Telemedicine')]")
	public WebElement Telemedicine;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Telemedicine indicator')]")
	public WebElement telemedicine;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Telemedicine indicator')]//following::div[1]")
	public WebElement indicator;
	@FindBy(how = How.XPATH, using  = "//h3[contains(text(),'Group admin support details')]")
	public WebElement groupadminsupportdetails;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Group information')]")
	public WebElement groupinformation;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Client number')]")
	public WebElement clientnumber;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Client status')]")
	public WebElement clientstatus;
	@FindBy(how = How.XPATH, using  = "(//span[contains(text(),'Group number')])[1]")
	public WebElement groupnumber;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'Group status')]")
	public WebElement groupstatus;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Reason for inquiry')]")
	public WebElement Reasonforinquiry;
	@FindBy(how = How.XPATH, using  = "//h2[contains(text(),'Registered admin users')]")
	public WebElement Registeredadminusers;
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h2[text()='Contract information']")));
		//return ExpectedConditions.visibilityOf(add);
	} 
	public void WebsitesupportdetailsRecentwork(Hashtable<String, String> data)
	{
		try{
			wait(2500);
			////System.out.println(Memberregistered.getText());
			if (Registeredonwebsite.getText().equals("Member registered"))
			{
			try{
				String CRSutility =  crsutility.getText();
				assertEquals(CRSutility, data.get("ExpectedCRSutility"), "CSR utility");
			}catch(Exception e)
			{
			  //System.out.println("Member not registered " + e);
				
			}
			}
			else
			{
				String membernotregistered=Membernotregistered.getText();
				assertEquals(membernotregistered, data.get("ExpectedRegisteredonwebsite"), "Member not registered");
			}
			
			String registeredonwebsite=webElementReadText(Registeredonwebsite);
			String username=webElementReadText(Username);
			String websiteaccountstatus=webElementReadText(Websiteaccountstatus);
			String website=webElementReadText(Website)+"::"+webElementReadText(WebsiteValue);
			String IDcardgroupstatus=webElementReadText(IDcardgroup);
			String Websitetoolsheaders=registeredonwebsite+":"+username+":"+websiteaccountstatus+":"+website+":"+IDcardgroupstatus;
			////System.out.println(Websitetoolsheaders);
			String Websitetools= Websitetoolsheaders+"::"+getrowdata(data.get("Websitetoolsandinformationheader"), Websitetoolsandinformation); 
			////System.out.println(Websitetools);
			assertEquals(Websitetools, data.get("ExpectedWebsitetools"), "Website tools");
			wait(2500);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Websitesupportdetails method " + e);
			test.log(Status.FAIL, "Error on Websitesupportdetails method " + e);
			//throw e;
		}
	}
	public void WebsitegroupfeatureRecentwork(Hashtable<String, String> data)
	{
		try{
			wait(2500);
			String Groupfeatureheader=webElementReadText(groupfeature);
			String Eligibleforcarecost=webElementReadText(eligibleforcarecost);
			String Benefitbookonportal=webElementReadText(benefitbookonportal);
			String Mobileappenabled=webElementReadText(mobileappenabled);
			//String Planprogressavailable=webElementReadText(planprogressavailable);
			String Websitegroupheader=Groupfeatureheader+":"+Eligibleforcarecost+":"+Benefitbookonportal+":"+Mobileappenabled;
			String Websitegroupfeatures=Websitegroupheader+"::"+getrowdata(data.get("Websitegroupheaders"),WebsitegroupXpath);
			wait(2500);
			//System.out.println(Websitegroupfeatures);
			assertEquals(Websitegroupfeatures,data.get("ExpectedWebsitegroupfeature"),"Website group feature");
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Websitegroupfeature method " + e);
			test.log(Status.FAIL, "Error on Websitegroupfeature method " + e);
			throw e;
		}
	}
	public void WellnessprogramRecentwork(Hashtable<String, String> data)
	{
		String memberDetails = "";
		String header = "";
		try{
			wait(2500);
			String Wellnessprogramheader=webElementReadText(wellnessprogram);
			wait(2500);
			List<WebElement> hr = driver.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[1]//th")); 
			//System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[1]//th"));
				//System.out.println(hr.size());
			}
			
			String h = "(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[1]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			//System.out.println(Wellnessprogramheader+":"+header);

			
			assertEquals(data.get("ExpectedWellnessheader"), Wellnessprogramheader+":"+header, "Wellness program header");
			List<WebElement> ele = driver
					.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l1')]"));
			////System.out.println(ele.size());
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l1')]"));
				//System.out.println(ele.size());
			}
			
			String s = "//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l1')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String memdet = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				memberDetails = memberDetails + "," + memdet;
			}
			waitSleep(1000);
			//memberDetails = memberDetails.substring(1, memberDetails.length());
			//System.out.println(memberDetails);
			assertEquals(data.get("ExpectedWellness"), memberDetails, "Wellness program Value");

		
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Wellnessprogram method " + e);
			test.log(Status.FAIL, "Error on Wellnessprogram method " + e);
			throw e;
		}
	}
	public void TelemedicineRecentwork(Hashtable<String, String> data)
	{
		String memberDetails = "";
		String header = "";
		try{
			wait(2500);
			String Telemedicineheader=webElementReadText(Telemedicine);
			String Telemedicine=webElementReadText(telemedicine);
			String Indicator=webElementReadText(indicator);
			String Telemedicineindicator=Telemedicineheader+"::"+Telemedicine+"::"+Indicator;
			////System.out.println(Telemedicineindicator);
			assertEquals(data.get("ExpectedTelemedicineindicator"), Telemedicineindicator, "Telemedicine indicator header");


			wait(2500);
			List<WebElement> hr = driver.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[2]//th")); 
			//System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[2]//th"));
				//System.out.println(hr.size());
			}
			
			String h = "(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Vendor')])[2]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h ));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			//System.out.println(header);

			
			assertEquals(data.get("ExpectedTelemedicineheader"), header, "Telemedicine header");
			List<WebElement> ele = driver
					.findElements(By.xpath("//h2[contains(text(),'Telemedicine')]//following::tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l')]"));
			////System.out.println(ele.size());
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//h2[contains(text(),'Telemedicine')]//following::tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l')]"));
				//System.out.println(ele.size());
			}
			
			String s = "//h2[contains(text(),'Telemedicine')]//following::tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pVendors$l')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String memdet = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				memberDetails = memberDetails + "," + memdet;
			}
			waitSleep(1000);
			//memberDetails = memberDetails.substring(1, memberDetails.length());
			//System.out.println(memberDetails);
			assertEquals(data.get("ExpectedTelemedicine"), memberDetails, "Telemedicine Value");
		
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Telemedicine method " + e);
			test.log(Status.FAIL, "Error on Telemedicine method " + e);
			throw e;
		}
	}
	public void GroupadminsupportdetailsRecentwork(Hashtable<String, String> data)
	{
		try{
			wait(2500);
			webElementClick(groupadminsupportdetails, "group adminsupport details");
			String Groupinformation=webElementReadText(groupinformation);
			String Clientnumber=webElementReadText(clientnumber);
			String Clientstatus=webElementReadText(clientstatus);
			String Groupnumber=webElementReadText(groupnumber);
			String Groupstatus=webElementReadText(groupstatus);

			String Groupinformationheader=Groupinformation+":"+Clientnumber+":"+Clientstatus+":"+Groupnumber+":"+Groupstatus;
			String Groupinformationvalue=Groupinformationheader+"::"+getrowdata(data.get("Groupheader"),GroupheaderXpath);
			wait(2500);
			//System.out.println(Groupinformationvalue);
			assertEquals(Groupinformationvalue, data.get("ExpectedGroupinformationvalue"), "Group information value");
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Websitegroupfeature method " + e);
			test.log(Status.FAIL, "Error on Websitegroupfeature method " + e);
			throw e;
		}
	}
	public void RegisteredadminusersRecentwork(Hashtable<String, String> data)
	{
		String memberDetails = "";
		String header = "";
		try{
			wait(2500);
			String Registeredadminusersheader=webElementReadText(Registeredadminusers);
			//System.out.println(Registeredadminusersheader);
			wait(2500);
			List<WebElement> hr = driver.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Embed-Address')])[1]//th")); 
			//System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Embed-Address')])[1]//th"));
				//System.out.println(hr.size());
			}
			
			String h = "(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Embed-Address')])[1]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h ));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			//System.out.println(header);

			
			assertEquals(data.get("ExpectedRegisteredadminusersheader"), header, "Registered admin users header");
			List<WebElement> ele = driver
					.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pAddress$l')]"));
			////System.out.println(ele.size());
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pAddress$l')]"));
				//System.out.println(ele.size());
			}
			
			String s = "//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pAddress$l')][%d]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String memdet = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				memberDetails = memberDetails + "," + memdet;
			}
			waitSleep(1000);
			//memberDetails = memberDetails.substring(1, memberDetails.length());
			//System.out.println(memberDetails);
			assertEquals(data.get("ExpectedRegisteredadminusersvalue"),memberDetails, "Registered admin users values");

		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Registeredadminusers method " + e);
			test.log(Status.FAIL, "Error on Registeredadminusers method " + e);
			throw e;
		}
	}
	public void ServicerequestreviewRecentwork(Hashtable<String, String> data)
	{
		String memberDetails = "";
		String header = "";
		try{
			wait(2500);
			String Reasonforinquirys=webElementReadText(Reasonforinquiry);
			//System.out.println(Reasonforinquirys);
			wait(2500);
			List<WebElement> hr = driver.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-ServiceInquiry')])[1]//th")); 
			//System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-ServiceInquiry')])[1]//th"));
				//System.out.println(hr.size());
			}
			
			String h = "(//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-ServiceInquiry')])[1]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h ));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			//System.out.println(header);

			
			assertEquals(data.get("ExpectedReasonforinquirysheader"), header, "Reasonforinquirys header");
			List<WebElement> ele = driver
					.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$ppyWorkParty$gGroup$pAddress$l')]"));
			////System.out.println(ele.size());
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pInquiriesList$l')]"));
				//System.out.println(ele.size());
			}
			
			String s = "//tr[contains(@id,'$PpyWorkPage$pInquiriesList$l')][%d]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String memdet = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				memberDetails = memberDetails + "," + memdet;
			}
			waitSleep(1000);
			memberDetails = memberDetails.substring(1, memberDetails.length());
			//System.out.println(memberDetails);
			assertEquals(data.get("ExpectedReasonforinquirysvalue"),memberDetails, "Reasonforinquirys values");

		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Registeredadminusers method " + e);
			test.log(Status.FAIL, "Error on Registeredadminusers method " + e);
			throw e;
		}
	}
}

