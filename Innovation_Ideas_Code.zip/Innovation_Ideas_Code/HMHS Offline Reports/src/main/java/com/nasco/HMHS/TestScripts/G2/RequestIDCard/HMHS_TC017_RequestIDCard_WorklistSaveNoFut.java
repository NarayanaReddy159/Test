package com.nasco.HMHS.TestScripts.G2.RequestIDCard;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.RequestIDCardPage;
import com.nasco.HMHS.Pages.WorkbasketPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC017_RequestIDCard_WorklistSaveNoFut extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC017_RequestIDCard_WorklistSaveNoFut (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC017_RequestIDCard_WorklistSaveNoFut");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC017_RequestIDCard_WorklistSaveNoFut - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC017_RequestIDCard_WorklistSaveNoFut -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed.");
		test.log(Status.INFO,"Member Search Completed.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page.");
		test.log(Status.INFO,data.get("Fname") + " Selected from the search results and navigated to verify member page.");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO,"Member Submit Completed.");
		
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Member Verified successfully.");
        test.log(Status.INFO,"Member Verified successfully.");
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(Status.INFO,"Add Intent "+data.get("Intent"));
        
        String intentID = searchMember.getIntentIDReqID();
        log.debug("Intent id: " + intentID);
        test.log(Status.INFO,"Intent id: " + intentID);
		RequestIDCardPage ReqIDCard = homepage.RequestIDCardIntent();
		InteractionManager.PriorIntent(data.get("expectedDefault"),data.get("expectedALLValues"));
        log.debug("Validate the prior intent screen.");
        test.log(Status.INFO,"Validate the prior intent screen.");
        ReqIDCard.RequestIDCardTaskNoTempAdd( intentID,data.get("ReviewDupTxt"),data.get("VerifyReqTxt"),data.get("WarningMsg1"),data.get("WarningMsg3"),data.get("WarningMsg4"),data,data.get("FullReqTxt"),data.get("ReqIDcomments"));
		log.debug("Navigate to Request ID card intent screen to add task.");
		test.log(Status.INFO,"Navigate to Request ID card intent screen to add task.");
		
		InteractionManager.openTask();
		InteractionManagerPage wrap = searchMember.wrapIntent();
	    wrap.wrapUp(data.get("Comments"));
		log.debug("Wrapping up the intent.");
		test.log(Status.INFO,"Wrapping up the intent.");
		
		WorkbasketPage WB = homepage.openrecentWorkbasket();
		log.debug("Navigated to Workbasket page.");
		test.log(Status.INFO,"Navigated to Workbasket page.");
		WB.movetoWorkbasketPage();
		log.debug("Go to Workbasket page.");
		test.log(Status.INFO,"Go to Workbasket page.");
		WB.Workbasketcheck( data);
		log.debug("Select the Workbasket");
		test.log(Status.INFO,"Select the Workbasket.");
		WB.sortandSelectIntent( intentID);
		log.debug("Sorted and selected intent " + intentID + " from Worklist tab.");
		test.log(Status.INFO,"Sorted and selected intent " + intentID + " from Worklist tab.");
		WB.OtherActionsSaveToWorklist( intentID, data);
		log.debug("Able to open the intent in Workbasket and submit it.");
		test.log(Status.INFO,"Able to open the intent in Workbasket and submit it.");
		
		WorklistPage worklist = homepage.openrecentWorklist();
		worklist.movetoWorklistPage();
		log.debug("Navigated to the Worklist page.");
		test.log(Status.INFO,"Navigated to the Worklist page.");
		worklist.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from Worklist tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected intent " + intentID + " from recent work tab.");
		WB.WorkbasketComments( intentID, data);
		log.debug("Add comment and Submit from the Workbasket.");
		test.log(Status.INFO,"Add comment and Submit from the Workbasket.");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Home-Recentwork Section");
		test.log(Status.INFO,"Navigated to the Home-Recentwork Section.");
		recentWork.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from recent work tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected intent " + intentID + " from recent work tab.");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the intent status.");
		test.log(Status.INFO,"Check the intent status.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  {
		test.log(Status.INFO, "HMHS_TC017_RequestIDCard_WorklistSaveNoFut completed.");
		log.debug("HMHS_TC017_RequestIDCard_WorklistSaveNoFut completed.");
		quit();

	}
}
