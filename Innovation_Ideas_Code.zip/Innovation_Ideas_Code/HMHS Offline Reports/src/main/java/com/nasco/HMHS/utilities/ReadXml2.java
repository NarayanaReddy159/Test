package com.nasco.HMHS.utilities;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ReadXml2 {

	public static String getxmlTagData(String filelocation, String parentTag, String nodeListValue,String tagName) throws Exception
	{
		
		try   
    	{  
    	File file = new File(filelocation);  
    	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
    	DocumentBuilder db = dbf.newDocumentBuilder();  
    	Document doc = db.parse(file);  
    	doc.getDocumentElement().normalize();  
    	
    	XPath xPath = XPathFactory.newInstance().newXPath();
    	parentTag = parentTag+"/item/@id";
        NodeList nodeList = (NodeList) xPath.compile(parentTag).evaluate(doc, XPathConstants.NODESET);
        int nodeValue=0;
        for (int i = 0; i < nodeList.getLength(); i++) {
        	
        	// Update HHP_CS_CSD_WORK_PCP_1638 with actual intent item id value
            if(nodeList.item(i).getNodeValue().equals(nodeListValue))
            {
            	nodeValue=i;
            }
        }
    	
    	NodeList nodelist = doc.getElementsByTagName("item"); 
    	
    	Node node = nodelist.item(nodeValue);  
    	String s="";
    	if (node.getNodeType() == Node.ELEMENT_NODE)   
    	{  
    		Element eElement = (Element) node;
    		
    		int elementsCount=eElement.getElementsByTagName(tagName).getLength();
    		
    		for(int j=0;j<elementsCount;j++)
    		{
    			if(j==0)
    			{
    				s= eElement.getElementsByTagName(tagName).item(j).getTextContent();
    			}
    			else {
    				s=s+","+ eElement.getElementsByTagName(tagName).item(j).getTextContent();
    			}
    		}
    	}  
    	 return s;
    	}   
    	catch (Exception e)   
    	{  
    	e.printStackTrace();  
    	throw e;
    	} 

	}

}
