package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked"})
public class InteractionManagerPage extends BasePage {

	String excepionMessage = "";
	String taskNameXpath="//a[contains(text(),'%s')]";
	String taskNameXpath1="(//a[contains(text(),'%s')])[2]";

	@FindBy(how = How.XPATH, using = "//button[@title='Add task']")
	public WebElement add;
	
	@FindBy(how = How.XPATH, using = "(//button[contains(@name,'CPMTaskListMenu_pyWorkPage')])[2]")
	public WebElement addTask;
	
	@FindBy(how = How.XPATH, using = "//div[contains(@title,'Hide Next best action')]")
	public WebElement openTask;
	
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	
	@FindBy(how = How.XPATH, using  = "//div[contains(text(),'Submit')]")
	public WebElement WrapSubmit;
	
	@FindBy(how = How.XPATH, using  = "//button[@name='ConfirmWrapUp_D_Interaction_9']")
	public WebElement EndCancel;
	
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]")
	public WebElement submit;
	
	@FindBy(how = How.XPATH, using  = "//i[contains(@name,'CPMInteractionDriver_D_Interaction') and @title='Wrap up']")
	public WebElement wrapUpOpen;
	
	/*@FindBy(how = How.XPATH, using  = "//*[@id='RULE_KEY']/div[3]/div[1]/span/i")
	public WebElement wrapUpOpen;
	*/
	@FindBy(how = How.XPATH, using  = "//*[@id='e942eb82']")
	public WebElement comment;
	
	/*@FindBy(how = How.XPATH, using  = "(//*[@id='RULE_KEY']/div[3]/div[1]/span/i)[2]")
	public WebElement wrapUp;*/
    
	@FindBy(how = How.XPATH, using  = "//i[contains(@name,'CPMInteractionDriver_D_Interaction') and @title='Wrap up']")
	public WebElement wrapUp;
	
	@FindBy(how = How.XPATH, using  = "//a[contains(@name,'CPMInteractionDriver_D_Interaction') and @title='End Research']")
	public WebElement EndResearch;
	
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pReasonForInteraction")
	public WebElement reasonForInteraction;
	
	@FindBy(xpath = "//*[@id='RULE_KEY']/div/div/div/div[2]/div/div/div/div[5]/span/button[1]")
	public WebElement OtherActions;
	@FindBy(xpath = "//span[contains(text(),'Cancel Work')]")
	public WebElement CancelWork;
	@FindBy (how = How.XPATH, using = "//textarea[@id='196a85d3']")
	public WebElement CancelComments;
	
	@FindBy(xpath = "//span[contains(text(),'Save to Worklist')]")
	public WebElement SaveToWorklist;
	@FindBy(xpath = "//select[@id='745bd9d7']")
	public WebElement ReasonToPend;
	@FindBy (how = How.XPATH, using = "//textarea[@id='7454b91c']")
	public WebElement Mailcomment;
	
	@FindBy(xpath = "//span[contains(text(),'Route to Team')]")
	public WebElement RouteToTeam;
	@FindBy(xpath = "//div[1]/div[1]/div[1]/span[1]/label[1]")
	public WebElement TeamMemWork;
	@FindBy(xpath = "//input[@id='fc6c88b7']")
	public WebElement Operator;
	@FindBy(xpath = "//span[contains(text(),'Kiran Thakur')]")
	public WebElement SelectOpr;
	
	//@FindBy(how = How.XPATH, using = "//div[contains(@title,'Hide Open tasks')]")
	@FindBy (how = How.XPATH, using = "(//button[contains(text(),'Cancel')])[2]")
	public WebElement Cancel;
	@FindBy(how = How.XPATH, using  = "//*[@id='4a4a1e95']")
	public WebElement Primaryreason;
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Filter')]")
	public WebElement filter;
	@FindBy(how = How.XPATH, using  = "//div[contains(text(),'Warning ! You are closing the Interaction with ope')]")
	public WebElement WarningMsg;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(add);
	}
	//TO Add task for Interaction Manager 
	public void addTask(String intentName) {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			webElementClick( add, "add Task");
			waitSleep(1500);
			//webElementClick( driver.findElement(By.xpath(String.format(taskNameXpath, intentName))),"task Name");
			try{
				waitSleep(3500);
				//webElementClick(driver.findElement(By.xpath(String.format(taskNameXpath, intentName))), "Intent");
				WebElement elementAttr=driver.findElement(By.xpath(String.format(taskNameXpath, intentName)));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", (WebElement) elementAttr);
				elementAttr.click();
			//	System.out.println("intentName: "+intentName);
				
			}
			catch(Exception e)
			{
				WebElement elementAttr=driver.findElement(By.xpath(String.format(taskNameXpath1, intentName)));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", (WebElement) elementAttr);
				elementAttr.click();
			}
			waitSleep(500);
			webElementClick( addTask, "add Tasks");
			waitSleep(3500);
			/*Actions actions = new Actions(driver);
			actions.doubleClick(driver.findElement(By.xpath(String.format(taskNameXpath, intentName)))).perform();*/
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on addTask method " + e);
			test.log(Status.FAIL, "Error on addTask method " + e);
			throw e;
		}
	}
	
	public void cancelIntent(String intentID,Hashtable<String, String> data) {
		try{
			webElementClick(OtherActions, "to click on other Actions");
			wait(1500);
			webElementClick(CancelWork, "to select Cancel the Work");
			wait(1500);
			webElementSendText(CancelComments, data.get("comments"), "as Comments");
			waitSleep(2500);
			webElementClick(Submit, "to cancel the work successfully");
			wait(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Cancel task method " + e);
			test.log(Status.FAIL, "Error on Cancel task method " + e);
			throw e;
		}
	}

	public void cancelback(String intentID,Hashtable<String, String> data) {
		try{
			webElementClick(OtherActions, "to click on other Actions");
			wait(1500);
			webElementClick(CancelWork, "to select Cancel the Work");
			wait(1500);
			webElementSendText(CancelComments, data.get("comments"), "as Comments");
			waitSleep(2500);
			webElementClick(OtherActions, "to click on other Actions");
			wait(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Cancel back method " + e);
			test.log(Status.FAIL, "Error on Cancel back method " + e);
			throw e;
		}
	}
	
	public void SaveToWorklist(String intentID,Hashtable<String, String> data) {
		try{
			webElementClick(OtherActions, "to click on other Actions");
			wait(1500);
			webElementClick(SaveToWorklist, "to save to worklist");
			wait(1500);
			selectDropdownValueByVisibleText(ReasonToPend, data.get("ReasonToPend"), "to select Reason to Pend");
			wait(1500);
			webElementSendText(Mailcomment, data.get("comments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
			wait(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Save to Worklist method " + e);
			test.log(Status.FAIL, "Error on Save to Worklist  method " + e);
			throw e;
		}
	}
	
	public void SaveToWorklistBack(String intentID,Hashtable<String, String> data) {
		try{
			webElementClick(OtherActions, "to click on other Actions");
			wait(1500);
			webElementClick(SaveToWorklist, "to save to worklist");
			wait(1500);
			selectDropdownValueByVisibleText(ReasonToPend, data.get("ReasonToPend"), "to select Reason to Pend");
			wait(1500);
			webElementSendText(Mailcomment, data.get("comments"), "as Comments");
			wait(1500);
			webElementClick(OtherActions, "to click on other Actions");
			wait(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Save to Worklist Back method " + e);
			test.log(Status.FAIL, "Error on Save to Worklist Back  method " + e);
			throw e;
		}
	}
	
	
	public void RouteToTeam(String intentID,Hashtable<String, String> data) {
		try{
			switchToFrame("PegaGadget1Ifr");
			wait(1500);
			webElementClick(OtherActions, "to click on other Actions");
			wait(1500);
			webElementClick(RouteToTeam, "on Route to team");
			wait(1500);
			webElementClick(TeamMemWork, "to select the Team Member's Worklist");
			wait(2000);
			webElementSendText(Operator, data.get("Operator"), "enter the Operator ID");
			wait(2500);
			webElementSendText(Mailcomment, data.get("comments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
			wait(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Route To Team method " + e);
			test.log(Status.FAIL, "Error on Route To Team  method " + e);
			throw e;
		}
	}
	
	public void RouteToTeamBack(String intentID,Hashtable<String, String> data) {
		try{
			wait(1500);
			webElementClick(OtherActions, "to click on other Actions");
			wait(1500);
			webElementClick(RouteToTeam, "on Route to team");
			wait(1500);
			webElementClick(OtherActions, "to click on other Actions");
			wait(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Route To Team method " + e);
			test.log(Status.FAIL, "Error on Route To Team  method " + e);
			throw e;
		}
	}
	
	public void openTask() {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			List<WebElement> opentasks=driver.findElements(By.xpath("//div[contains(@title,'Hide Next best action')]"));
			if(opentasks.size()>0)
			{
			openTask.click();
			}
		}
		catch(Exception e)
		{
		}
	}
	public void wrapUpOpen(String Comments) {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			webElementClick(wrapUpOpen, "wrap Up Open");
			wait(3500);
			webElementClick(submit, "Submit Open intent");
			waitSleep(3500);
			openTask();
			waitSleep(3500);
			Select reason= new Select(reasonForInteraction);
			reason.selectByIndex(1);
			webElementSendText(comment, Comments, "Comments");
			webElementClick(WrapSubmit, "Submit");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapUpOpen method " + e);
			test.log(Status.FAIL, "Error on wrapUpOpen method " + e);
			throw e;
		}
	}
	public void wrapUp(String Comments) {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
			webElementClick(wrapUp, "to Wrap Up Open");
			/*Added code for INT issue on 11/12*/
			wait(3500);
			try {
				submit.click();
			}catch(Exception e)
			{
				System.out.println("No warning message");
			}
			/*Added code for INT issue on 11/12*/
			waitSleep(3500);
			openTask();
			waitSleep(1500);
			try{
				Select reason= new Select(reasonForInteraction);
				reason.selectByIndex(1);
			}
			catch(Exception e1)
			{
			}
			waitSleep(1000);
			webElementSendText(comment, "Wrap up comments", "Comments");
			waitSleep(1000);
			webElementClick(WrapSubmit, "Submit");
			waitSleep(2500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on wrapUp method " + e);
			test.log(Status.FAIL, "Error on wrapUp method " + e);
			throw e;
		}
	}
	
	public void EndResearch() {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			webElementClick(EndResearch, "to End the Research Ineraction.");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on EndResearch method " + e);
			test.log(Status.FAIL, "Error on EndResearch method " + e);
			throw e;
		}
	}

	public void EndResearchOpen() {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			webElementClick(EndResearch, "to End the Research Ineraction.to End the Research Ineraction.");
			wait(3500);
			String ActualErrMsg = webElementReadText(WarningMsg);
			String ExpectedErrMsg = "Warning ! You are closing the Interaction with open ServiceRequests. If you continue these will be moved to your WorkList. Do you want to continue ?";
			assertEquals(ActualErrMsg, ExpectedErrMsg, "Check for warning message it should be match.");
			waitSleep(1500);
			webElementClick(WrapSubmit, "Submit the Open intent");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on EndResearchOpen method " + e);
			test.log(Status.FAIL, "Error on EndResearchOpen method " + e);
			throw e;
		}
	}
	
	public void EndResearchCancel() {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			webElementClick(EndResearch, "to End the Research Ineraction.to End the Research Ineraction.");
			wait(3500);
			webElementClick(EndCancel, "Cancel the End Research intent");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on EndResearchOpen method " + e);
			test.log(Status.FAIL, "Error on EndResearchOpen method " + e);
			throw e;
		}
	}
	public CreateFollowUpPage opencreateFollowUpPage()
	{
		return (CreateFollowUpPage)openPage(CreateFollowUpPage.class);
	}
	
	public ViewBenefitsPage openViewBenefits()
	{
		return (ViewBenefitsPage)openPage(ViewBenefitsPage.class);
	}
	public ViewTotalPage openViewTotal()
	{
		return (ViewTotalPage)openPage(ViewTotalPage.class);
	}
	public void wrapUp(String reason,String Comments) {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			webElementClick( wrapUpOpen, "wrap Up Open");
			wait(3500);
			selectDropdownValueByVisibleText(Primaryreason ,reason, "Primary reason for interaction");
			waitSleep(1500);
			webElementSendText(comment, Comments, "Comments");
			
			webElementClick(WrapSubmit, "Submit");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on addTask method " + e);
			test.log(Status.FAIL, "Error on addTask method " + e);
			throw e;
		}
	}
	
	public void PriorIntent(String expectedDefault,String expectedALLValues ){
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			Select Workstatus=new Select(driver.findElement(By.xpath("//*[@name='$PpyWorkPage$pStatusWork']")));
			////System.out.println(Workstatus.getFirstSelectedOption().getText());
			waitSleep(2500);
			Select Opendaterange=new Select(driver.findElement(By.xpath("//*[@name='$PpyWorkPage$pPriorReqDateRange']")));
			String Default = Workstatus.getFirstSelectedOption().getText()+"|"+Opendaterange.getFirstSelectedOption().getText();
			//System.out.println(Default);
			assertEquals(expectedDefault, Default, "Default value is matched.");
			String ALLValues = driver.findElement(By.xpath("//*[@name='$PpyWorkPage$pStatusWork']")).getText()+"|"+driver.findElement(By.xpath("//*[@name='$PpyWorkPage$pPriorReqDateRange']")).getText();
			//System.out.println(ALLValues);
			assertEquals(expectedALLValues, ALLValues, "Expected all dropdown values are matched.");
			webElementClick(filter,"filter");
			waitSleep(5000);
			
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on PriorIntent method " + excepionMessage);
			test.log(Status.FAIL, "Error on PriorIntent method " + e);
			throw e;
		}
	}
	
	public void addTaskMenu(String ExpectedaddMenu) {
		String addMenuInformation="";
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			webElementClick( add, "add Task");
            List<WebElement> addMenu= driver.findElements(By.xpath("//div[contains(@class,'content    layout-content-inline content-inline ')]"));
			

	        //System.out.println(addMenu.size());

	        for (WebElement webElement : addMenu) {
	        	addMenuInformation = webElement.getText();
	            //System.out.println(webElement.getText());
	        }
			
			assertEquals(ExpectedaddMenu,addMenuInformation, "member Information");
			waitSleep(500);
			webElementClick( Cancel, "Cancel");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on addTask method " + e);
			test.log(Status.FAIL, "Error on addTask method " + e);
			throw e;
		}
	}
	public ManageClaimsPage openManageClaims()
	{
		return (ManageClaimsPage)openPage(ManageClaimsPage.class);
	}
	public void EndResearchOpen(String frame) {
		try{
			switchToFrame(frame);
			waitSleep(4500);
			webElementClick(EndResearch, "to End the Research Ineraction.to End the Research Ineraction.");
			wait(3500);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on EndResearchOpen method " + e);
			test.log(Status.FAIL, "Error on EndResearchOpen method " + e);
			throw e;
		}
	}
	public void openTask(String Frame) {
		try{
			switchToFrame(Frame);
			waitSleep(3500);
			List<WebElement> opentasks=driver.findElements(By.xpath("//div[contains(@title,'Hide Next best action')]"));
			if(opentasks.size()>0)
			{
			openTask.click();
			}
		}
		catch(Exception e)
		{
		}
	}
	
	
	public void addTask(String intentName, int index) {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			webElementClick( add, "add Task");
			waitSleep(1500);
			//webElementClick( driver.findElement(By.xpath(String.format(taskNameXpath, intentName))),"task Name");
			WebElement elementAttr=driver.findElement(By.xpath(String.format("(//a[contains(text(),'%s')])[%d]", intentName,index)));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", (WebElement) elementAttr);
			elementAttr.click();
			
			
			waitSleep(500);
			webElementClick( addTask, "add Tasks");
			waitSleep(3500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on addTask method " + e);
			test.log(Status.FAIL, "Error on addTask method " + e);
			throw e;
		}
	}
}