package com.nasco.offlineReports.ExtentListeners;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.nasco.HMHS.utilities.DriverManager;
import com.nasco.HMHS.utilities.EmailHTMLBuilder;
import com.nasco.HMHS.utilities.EmailHTMLBuilder_Body;
import com.nasco.HMHS.utilities.ExcelReader;
import com.nasco.offlineReports.Run.RunTestNG_OfflineReports;

public class ExtentListeners implements ITestListener {

	static Date d = new Date();
	static String fileName = "Extent_" + d.toString().replace(":", "_").replace(" ", "_") + ".html";
	Set<String> failedTc = new LinkedHashSet<String>();
	Map<String, List<String>> results = new HashMap<String, List<String>>();
	String status = "";
	String reportFileName = "HMHS_NCompass_Automation_Execution_Report.xlsx";
	String reportFilePath = System.getProperty("user.dir") + RunTestNG_OfflineReports.Config.getProperty("ReportFile")
			+ reportFileName;
	String extentFilepath = System.getProperty("user.dir")
			+ RunTestNG_OfflineReports.Config.getProperty("EXTREPORT_LOC");
	public String timeStamp = new SimpleDateFormat("MM-dd-yyyy").format(Calendar.getInstance().getTime());
	public String timeStamp_email = timeStamp;
	EmailHTMLBuilder htmlbuilder_Summary = new EmailHTMLBuilder();
	EmailHTMLBuilder_Body htmlbuilder = new EmailHTMLBuilder_Body();
	DecimalFormat df = new DecimalFormat("###.##");
	static ExcelReader excel = null;
	String path1 = reportFileName.replace(".xlsx", "") + d.toString().replace(":", "_").replace(" ", "_") + ".xlsx";
	String reportFilePath1 = System.getProperty("user.dir") + RunTestNG_OfflineReports.Config.getProperty("ReportFile")
			+ path1;
	String defectsListFile = System.getProperty("user.dir")
			+ RunTestNG_OfflineReports.Config.getProperty("DEFECTSLISTFILE_LOC");

	public static ExtentReports extent = ExtentManager.getInstance();
	public static ExtentReports extent1 = ExtentManager.getFailureInstance();
	public static ThreadLocal<ExtentTest> testReport = new ThreadLocal<ExtentTest>();
	public static ThreadLocal<ExtentTest> testReport1 = new ThreadLocal<ExtentTest>();

	long diff = 0;
	long diffMinutes = 0;
	long diffSeconds = 0;
	long diffHours = 0;

	String starttime = "";
	String endTime = "";
	List<ExtentTest> testList = new ArrayList<>();

	public void onTestStart(ITestResult result) {
		ExtentTest test;
		if (RunTestNG_OfflineReports.runCount > 0) {
			test = extent1.createTest("TestCase : " + result.getMethod().getMethodName());
			DriverManager.setExtentReport(test);
			testReport1.set(DriverManager.getExtentReport());
		} else {
			try {
				File f = new File(defectsListFile);
				f.delete();

			} catch (Exception e) {

			}
			test = extent.createTest("TestCase : " + result.getMethod().getMethodName());
			DriverManager.setExtentReport(test);
			testReport.set(DriverManager.getExtentReport());
			testList.add(test);
		}
	}

	public void onTestSuccess(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		if (RunTestNG_OfflineReports.runCount > 0) {
			testReport1.get().log(Status.PASS, methodName + " Test Case Passed");
			resultStatus(result, methodName, "Pass");

		} else {
			testReport.get().log(Status.PASS, methodName + " Test Case Passed");
			resultStatus(result, methodName, "Pass");
		}

	}

	public void onTestFailure(ITestResult result) {
		String excepionMessage = Arrays.toString(result.getThrowable().getStackTrace());
		String methodName = result.getMethod().getMethodName();
		System.out.println(methodName);
		if(RunTestNG_OfflineReports.runCount>0)
		{
			if (!excepionMessage.isEmpty())
				testReport1.get().log(Status.FAIL, excepionMessage);
			
			try {
				ExtentManager.captureScreenshot(methodName);
				testReport1.get().addScreenCaptureFromPath(ExtentManager.screenshotName).fail("<b><font color=red> Screen shot of failure</font></b>",MediaEntityBuilder.createScreenCaptureFromPath(ExtentManager.screenshotName).build());
				} catch (Exception e) {
				e.printStackTrace();
			}
			testReport1.get().log(Status.FAIL, methodName + " Test Case Failed");
			resultStatus(result, methodName, "Fail");
		}
		else{
			if (!excepionMessage.isEmpty())
				testReport.get().log(Status.FAIL, excepionMessage);
			if(!ExceptionUtils.getStackTrace(result.getThrowable()).contains("AssertionError")
					&&RunTestNG_OfflineReports.Config.getProperty("Rerun").toString().equalsIgnoreCase("Y"))
				{
				System.out.println(ExceptionUtils.getStackTrace(result.getThrowable()));
				for(int i=0;i<testList.size();i++)
				{
					if(testList.get(i).getModel().getName().contains(methodName) &&testList.get(i).getStatus().toString().equalsIgnoreCase("Fail"))
					{
						extent.removeTest(testList.get(i));
						failedTc.add(result.getTestClass().getName());
					}
				}
			}
			else{
				try {
					ExtentManager.captureScreenshot(methodName);
					testReport.get().addScreenCaptureFromPath(
							ExtentManager.screenshotName).fail("<b><font color=red> Screen shot of failure</font></b>",
							MediaEntityBuilder.createScreenCaptureFromPath(ExtentManager.screenshotName).build());
					/*
					 * String base64Screenshot =
					 * "data:image/png;base64,"+((TakesScreenshot)DriverManager.
					 * getDriver()). getScreenshotAs(OutputType.BASE64);
					 * 
					 * //Extentreports log and screenshot operations for failed tests.
					 * testReport.get().log(Status.FAIL,"Test Failed Screenshot",
					 * testReport.get().addBase64ScreenShot(base64Screenshot));
					 */
					/*for(int i=0;i<testList.size();i++)
					{
						if(testList.get(i).getModel().getName().contains(methodName) &&testList.get(i).getStatus().toString().equalsIgnoreCase("Fail"))
						{
							testList.get(i).fail("<b><font color=red> Screen shot of failure</font></b>",MediaEntityBuilder.createScreenCaptureFromPath(ExtentManager.screenshotName).build());
						}
					}
					testReport.get().log(Status.FAIL,
							ExtentManager.screenshotName + testReport.get().addScreenCaptureFromPath(ExtentManager.screenshotName));
				*/} catch (Exception e) {
					e.printStackTrace();
				}
				
				testReport.get().log(Status.FAIL, methodName + " Test Case Failed");
				resultStatus(result, methodName, "Fail");
			}
			
			
			
	}
		
		
		
	}

	public void onTestSkipped(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		if (RunTestNG_OfflineReports.runCount > 0) {
			testReport1.get().log(Status.SKIP, methodName + " Test Case Skipped");

		} else {
			testReport.get().log(Status.SKIP, methodName + " Test Case Skipped");

		}

	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	public void onStart(ITestContext context) {
		if (RunTestNG_OfflineReports.runCount > 0) {
			// extent1.setSystemInfo("Environment",
			// RunTestNG_OfflineReports.Config.getProperty("Environment"));

		} else {
			extent.setSystemInfo("User Name", System.getProperty("user.name").toUpperCase());
			extent.setSystemInfo("OS", System.getProperty("java.version"));
			extent.setSystemInfo("Java Version", System.getProperty("os.name"));
			try {
				extent.setSystemInfo("Host Name", InetAddress.getLocalHost().getHostName());
			} catch (UnknownHostException e) {
			}
			extent.setSystemInfo("Environment", RunTestNG_OfflineReports.Config.getProperty("Environment"));
			extent.setSystemInfo("Browser", RunTestNG_OfflineReports.Config.getProperty("Browser").toUpperCase());
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date date = new Date();
			starttime = formatter.format(date);
		}
	}

	@SuppressWarnings("unused")
	public void onFinish(ITestContext context) {
	}
	
	public void resultStatus(ITestResult result, String tcname, String tcstatus) {
		List<String> values = new ArrayList<String>();
		values.add(0, result.getTestClass().getName());
		values.add(1, tcname);
		values.add(2, tcstatus);
		results.put(tcname, values);
	}

	public void printMap(Map<String, List<String>> results) {
		for (String name : results.keySet()) {
			List<String> value = results.get(name);
			String result = value.get(0);
			String tcname = value.get(1);
			String tcstatus = value.get(2);
			updatedetailreport(result, tcname, tcstatus);
		}
	}

	public void updatedetailreport(String result, String tcname, String tcstatus) {
		int rowNum = 0;
		String pathLoc = System.getProperty("user.dir") + RunTestNG_OfflineReports.Config.getProperty("EXTREPORT_LOC");
		String reportLoc = pathLoc + ExtentManager.fileName;
		excel = new ExcelReader(reportFilePath);
		rowNum = excel.getCellRowNum("HMHS", "TestCases", tcname);
		excel.setCellData("HMHS", "Status", rowNum, tcstatus);
		excel.setCellData("HMHS", "Report File Name", rowNum, reportLoc);
	}

	public void getdetailreport(ITestResult result, String tcname, String tcstatus) {
		int rowNum = 0;
		String pathLoc = RunTestNG_OfflineReports.Config.getProperty("EXTREPORT_LOC");
		String reportLoc = System.getProperty("user.dir") + pathLoc + ExtentManager.fileName;
		excel = new ExcelReader(reportFilePath);
		rowNum = excel.getCellRowNum("HMHS", "TestCases", tcname);
		excel.setCellData("HMHS", "Status", rowNum, tcstatus);
		excel.setCellData("HMHS", "Report File Name", rowNum, reportLoc);
	}

	@SuppressWarnings("unused")
	public void refereshExcel() {
		FileInputStream excelFile;

		try {
			excelFile = new FileInputStream(new File(reportFilePath));
			XSSFWorkbook excelWorkbook = new XSSFWorkbook(excelFile);
			XSSFSheet excelSheet = excelWorkbook.getSheet("Execution Summary Report");
			XSSFFormulaEvaluator.evaluateAllFormulaCells(excelWorkbook);
			excelFile.close();
			FileOutputStream outExcelFile = new FileOutputStream(new File(reportFilePath));
			excelWorkbook.write(outExcelFile);
			outExcelFile.close();
			FileOutputStream outExcelFile1 = new FileOutputStream(new File(reportFilePath1));
			excelWorkbook.write(outExcelFile1);
			outExcelFile.close();

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void createApplicationLog() {
		FileInputStream instream = null;
		FileOutputStream outstream = null;
		try {
			Date d = new Date();
			File infile = new File(System.getProperty("user.dir") + "/src/test/resources/logs/Application.log");
			File outfile = new File(System.getProperty("user.dir") + "/src/test/resources/logs/Application-"
					+ d.toString().replace(":", "_").replace(" ", "_") + ".log");
			instream = new FileInputStream(infile);
			outstream = new FileOutputStream(outfile);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = instream.read(buffer)) > 0) {
				outstream.write(buffer, 0, length);
			}
			instream.close();
			outstream.close();
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
	}
}
