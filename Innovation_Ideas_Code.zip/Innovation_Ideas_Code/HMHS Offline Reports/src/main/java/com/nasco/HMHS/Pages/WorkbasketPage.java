package com.nasco.HMHS.Pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked"})
public class WorkbasketPage extends BasePage {

	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	@FindBy(xpath = "//span[contains(text(),'Home')]")
	public WebElement Home;
	@FindBy(xpath = "//div[1]/div/div/div/ul/li[2]/a/span[1]/span")
	public WebElement myWorkIcon;
	@FindBy(xpath = "//h3[contains(text(),'Recent work')]")
	public WebElement recentWork;

	@FindBy(xpath = "//label[contains(text(),'View queue for')]//following::th//div[contains(text(),'ID')]//following::a[1]")
	public WebElement idSort;
	String intentclick="//tr[@id='$PsetWBListPage$ppxResults$l1']//a[text()='%s']";
	
	
	@FindBy(xpath = "//label[text()='Search text']//following::input")
	public WebElement searchID;
	@FindBy(xpath = "//input[@id='e726b0d0']")
	public WebElement VerifyDOB;
	@FindBy(xpath = "//button[contains(text(),'Apply')]")
	public WebElement applyBtn;
	@FindBy(xpath = "(//a[@class='Header_nav'])[3]")
	public WebElement MenuDropdown;
	@FindBy(xpath = "//span[contains(text(),'Logout')]")
	public WebElement LogOut;
	@FindBy(xpath = "//span[text()='Status']//following::div[1]")
	public WebElement IntentStatusPend;
	//@FindBy(xpath = "//h3[contains(text(),'Worklist')]")
	//@FindBy(xpath = "//div[5]/div[1]/h3/text()")
    //@FindBy(xpath= "//div[@class='header']//h3[contains(text(),'Worklist')]")
    //public WebElement worklist;
	@FindBy(xpath= "//h3[contains(text(),'Worklist')]")
	public WebElement worklist;
	
	@FindBy(xpath= "//h3[contains(text(),'Workbasket')]")
	public WebElement workbasket;
	@FindBy(xpath= "//select[@id='f971990b']")
	public WebElement viewqueue;

	@FindBy (how = How.XPATH, using = "//textarea[@id='5e1978c7']")
	public WebElement Comments;
	
	@FindBy (how = How.XPATH, using = "//textarea[@id='1b8f750e']")
	public WebElement WBComments;
	
	@FindBy(xpath = "//input[@id='357249db']")
	public WebElement Outside;
	
	@FindBy(xpath = "//button[@title='Other actions']")
	public WebElement OtherActions;
	@FindBy(xpath = "//span[text()='Save to Worklist']")
	public WebElement SaveToWorklist;
	@FindBy(xpath = "//span[contains(text(),'Enrollment Perform Request ID Cards')]")
	public WebElement EnrollmentPerform;
	@FindBy(xpath = "//span[contains(text(),'Return to Creating Operator')]")
	public WebElement ReturnToOpr;
	@FindBy(xpath = "//select[@id='8b0fe3a6']")
	public WebElement ReasonToPend;
	
	@FindBy (how = How.XPATH, using = "//textarea[@id='22a25784']")
	public WebElement CommentsWB;
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	@FindBy (how = How.XPATH, using = "//button[contains(text(),'Next')]")
	public WebElement Next;
	@FindBy(xpath = "//span[contains(text(),'Assigned operator')]//following::span[1]")
	public WebElement Assignedoperator;
	@FindBy(xpath = "//i[contains(@class,'pi pi-wrench pi-medium pi-blue')] ")
	public WebElement History;
	@FindBy(xpath = "//span[contains(text(),'Type of inquiry')]//following::span[1]")
	public WebElement typeofinquiry;
	@FindBy(xpath = "//span[contains(text(),'Reason')]//following::span[1]")
	public WebElement reason;
	@FindBy(xpath = "//span[contains(text(),'Resolution')]//following::span[1]")
	public WebElement resolution;
	@FindBy(xpath = "//span[contains(text(),'View History')]")
	public WebElement ViewHistory;
	@FindBy(xpath = "//label[contains(text(),'Resolve')]")
	public WebElement Resolve;
	String commentSummaryHeader="//h2[contains(text(),'Comments summary')]/following::table[2]/tbody/tr/th";
	String IDCCommentSummaryHeader="//h2[contains(text(),'Comments summary')]//following::table[3]/tbody/tr/th";
	String tableValue="//td[@data-attribute-name='%s']";
	@FindBy(xpath = "//label[contains(text(),'Route intent to creating operator')]")
	public WebElement creatingoperator;
	@FindBy(xpath = "//label[contains(text(),'Route to workbasket')]")
	public WebElement  RoutetoWorkbasket;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pTypeofinquiryWB")
	public WebElement TypeOfInq;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pReasonWB")
	public WebElement Reason;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pResolutionWB")
	public WebElement Resolution;
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pComments")
	public WebElement comment;
//	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pNotes")
//	public WebElement GSIcomment;
	@FindBy(xpath = "//label[contains(text(),'Forward or update')]")
	public WebElement  Forwardorupdate;
	@FindBy(xpath = "//label[contains(text(),'Route intent to last assigned operator')]")
	public WebElement  Routeintenttolastassignedoperator;
	@FindBy(xpath = "//input[@name='$PpyWorkPage$pBypassSystemHold' and @class='checkbox chkBxCtl ']")
	public WebElement  Bypass;
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]//preceding::b[1]")
	public WebElement message;
	
	@FindBy(how = How.XPATH, using  = "//b[contains(text(),'Submit will resolve')]")
	public WebElement NewMsg9;
	
	@FindBy(how = How.NAME, using  = "$PpyWorkPage$pAdjustmentReason")
	public WebElement FinalReasontoAdjust;
	
	public void Workbasketcheck(Hashtable<String, String> data) throws Exception
	{
		try{
			waitSleep(3000);
			switchToFrame("PegaGadget0Ifr");
			webElementClick(viewqueue, "to select View Queue");
			waitSleep(1500);
			selectDropdownValueByVisibleText(viewqueue, data.get("TransferWB"), "to select Workbasket");
			waitSleep(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Worklist method " + e);
			test.log(Status.FAIL, "Error on Worklist method " + e);
			throw e;
		}
	}	
	
	
	public void Workbasketcheck1(Hashtable<String, String> data) throws Exception
	{
		try{
			waitSleep(3000);
			switchToFrame("PegaGadget0Ifr");
			webElementClick(viewqueue, "to select View Queue");
			waitSleep(1500);
			selectDropdownValueByVisibleText(viewqueue, data.get("TransferWB1"), "to select Workbasket");
			waitSleep(1500);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Worklist method " + e);
			test.log(Status.FAIL, "Error on Worklist method " + e);
			throw e;
		}
	}	
	public void movetoWorkbasketPage() throws Exception
	{
		try{
			waitSleep(3000);
			switchToFrame("PegaGadget0Ifr");
			waitSleep(500);
			webElementClick(myWorkIcon, "to check My Work");
			waitSleep(2000);
			webElementClick(recentWork, "to check RecentWork tab");
			waitSleep(2000);
			webElementClick(workbasket, "to check Workbasket tab"); 
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Worklist method " + e);
			test.log(Status.FAIL, "Error on Worklist method " + e);
			throw e;
		}
	}
	
	public void movetoWorklistPage(String pageLocatorsPath,String pageFiledsPath) throws Exception
	{
		try{
			waitSleep(3000);
			switchToFrame("PegaGadget0Ifr");
			webElementClick(myWorkIcon, "My Work");
			waitSleep(2000);
			webElementClick(recentWork, "RecentWork tab");
			waitSleep(2000);
			webElementClick(worklist, "Worklist tab"); 
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Worklist method " + e);
			test.log(Status.FAIL, "Error on Worklist method " + e);
			throw e;
		}
	}	

	// HMHS Sort and Select Intent on RecentWork page
	
	public void sortandSelectIntent( String intentID) {
		try {
			switchToFrame("PegaGadget0Ifr");
			waitSleep(4500);
			//waitForPageToLoad(ExpectedConditions.elementToBeClickable(idSort));
			webElementClick(idSort, "ID Sort");
			try{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
			    webElementSendText(searchID, intentID, "Search Intent");
			}catch(StaleElementReferenceException e)
			{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
				webElementSendText(searchID, intentID, "Search Intent");	
			}
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(applyBtn));
			webElementClick(applyBtn, "Apply");
			waitSleep(4500);
			WebElement intentClick=driver.findElement(By.xpath(String.format(intentclick,intentID)));
			//waitSleep(4500);
			try{
				intentClick.click();
				//webElementClick(intentClick, "Intent " + intentID);
				}
				catch(Exception e2){
					intentClick.click();
					//webElementClick(intentClick, "Intent " + intentID);
				}
			waitSleep(2500);
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(Status.FAIL, "Error on sortandSelectIntent method " + e);
			throw e;
		}
	}

	// HMHS IntentStatus on Workbasket
	public void IntentStatus( String IntStatus, String frame) {
		try {
			wait(2500);
			switchToFrame(frame);
			String actualMessage = webElementReadText(IntentStatusPend);
			String expected = String.format(IntStatus);
			assertEquals(actualMessage, expected, "Check the intent status.");
			 wait(1500);
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on IntentStatus method " + excepionMessage);
			test.log(Status.FAIL, "Error on IntentStatus method " + e);
			throw e;
		}
	}
	
	public void WorkbasketComments( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(2500);
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(Comments));
			webElementSendText(Comments, data.get("Workbasketcomments"), "as Comments");
			wait(1500);
			webElementClick(Outside, "as Request completed ouside of NCompass");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on WorkbasketComments & then Submit it." + e);
			test.log(Status.FAIL, "Error on WorkbasketComments & then Submit it." + e);
			throw e;
		}
	}
	
	
	public void WorkbasketByPass( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(2500);
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(Bypass));
			webElementClick(Bypass, "on Bypass system hold");
			/*try{
				Comments.sendKeys(data.get("Workbasketcomments"));
			}catch(StaleElementReferenceException e)
			{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(Comments));
				Comments.sendKeys(data.get("Workbasketcomments"));
			}*/
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on WorkbasketComments & then Submit it." + e);
			test.log(Status.FAIL, "Error on WorkbasketComments & then Submit it." + e);
			throw e;
		}
	}
	
	
	public void movetoHome() {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget0Ifr");
			waitSleep(1500);
			webElementClick(Home, "Home");
			waitSleep(3000);
			webElementClick(myWorkIcon, "My Work");
			waitSleep(2000);
			webElementClick(recentWork, "RecentWork tab");
		} catch (Exception e) {
			BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
			test.log(Status.FAIL, "Error on movetoRecentWorkPage method " + e);
			throw e;
		}
	}
	public void OtherActionsSaveToWorklist( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", OtherActions); 
			wait(1500);
			webElementClick(OtherActions, "to click on Other Actions");
			wait(3000);
			webElementClick(SaveToWorklist, "Save To Worklist");
			wait(3000);
			selectDropdownValueByVisibleText(ReasonToPend, data.get("ReasonToPend"), "to select Reason to Pend");
			wait(1500);
			webElementSendText(Comments, data.get("comments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActionsSaveToWorklist method " + e);
			test.log(Status.FAIL, "Error on OtherActionsSaveToWorklist method " + e);
			throw e;
		}
	}
	public void OtherActionsSaveToWorklistBackEnrol( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", OtherActions); 
			wait(1500);
			webElementClick(OtherActions, "to click on Other Actions");
			wait(3000);
			webElementClick(SaveToWorklist, "Save To Worklist");
			wait(3000);
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", OtherActions); 
			wait(1500);
			webElementClick(OtherActions, "to click on Other Actions");
			wait(2000);
			webElementClick(EnrollmentPerform, "EnrollmentPerform Request ID Cards");
			wait(2000);
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActionsSaveToWorklist method " + e);
			test.log(Status.FAIL, "Error on OtherActionsSaveToWorklist method " + e);
			throw e;
		}
	}
	
	public void OtherActionsReturnOpr( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", OtherActions); 
			wait(1500);
			webElementClick(OtherActions, "to click on Other Actions");
			wait(3000);
			webElementClick(ReturnToOpr, "to select Return to Creating Operator from Other Actions");
			wait(2000);
			String commentsVal="Comments";
			 try{
				 if(!data.get("CommentsWB").equals(""))
				 {
					 commentsVal=data.get("CommentsWB");
				 }
			 }catch(Exception e4)
			 {
				 
			 }
			webElementSendText(CommentsWB,commentsVal, "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActionsSaveToWorklist method " + e);
			test.log(Status.FAIL, "Error on OtherActionsSaveToWorklist method " + e);
			throw e;
		}
	}
	
@Override
protected ExpectedCondition getPageLoadCondition() {
switchToFrame("PegaGadget0Ifr");
return ExpectedConditions.visibilityOf(myWorkIcon);
}
public void vaildationsAssignedoperator (String frame,Hashtable<String, String> data) {
	wait(2500);
	switchToFrame(frame);
	try {
		
		String expectedValues=webElementReadText(Assignedoperator);
		assertEquals(expectedValues, data.get("Assignedoperator"), "Assigned operator");
		
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on vaildationsAssignedoperator method " + e);
		test.log(Status.FAIL, "Error on vaildationsAssignedoperator method " + e);
		throw e;
	}
}
public String vaildationshistory(String frame,Hashtable<String,String> data) 
{
	String AuditLog="";
	wait(2500);
	switchToFrame(frame);
	try {

	String parentWindow=driver.getWindowHandle();
	webElementClick(History, "History");
	webElementClick(ViewHistory, "History");
	waitSleep(2000);
	for (String windowHandle : driver.getWindowHandles())
	{
		if(!parentWindow.equals(windowHandle)){
			 driver.switchTo().window(windowHandle);
			 //System.out.println("Switched to"+windowHandle);
		}
		//System.out.println(windowHandle);
		
	}
	
	switchToDefault();
	AuditLog="The skill"+" "+data.get("Skill")+" "+"is"+" "+"applied";
	//System.out.println("SKILL:"+AuditLog);
	test.log(Status.INFO, "Skill:"+AuditLog);

	List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$ppxResults$l')]"));
	ele.size();
	String s="//tr[contains(@id,'$ppxResults$l%d')]";
	for(int i=0;i<ele.size();i++)
	{
		String s1=String.format(s, i+1);
		//System.out.println("Skill applied:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
		//System.out.println("Skill:"+AuditLog);
		if(driver.findElement(By.xpath(s1+"//td[2]")).getText().equals(AuditLog))
		{
	
			//System.out.println(driver.findElement(By.xpath(s1+"//td[2]")).getText());
			test.log(Status.PASS, "Skill IS MATCHED IN HISTORY "+AuditLog);
			//System.out.println("Skill IS  MATCHED IN HISTORY "+AuditLog);

			break;
		}
	} 
	driver.close();
	driver.switchTo().window(parentWindow);
	
	} catch (Exception e) {
        e.printStackTrace();
        BaseTest.log.error("Error on vaildationshistory method " + e);
        test.log(Status.FAIL, "Error on vaildationshistory method " + e);
        throw e;
	}
	return AuditLog;
}
public void contractInformation(Hashtable<String,String> data) 
{
	String Contractinformation ="";
	try{
		
		switchToFrame("PegaGadget1Ifr");
		List<String> headerRow= new ArrayList<String>();
        headerRow.add("Subscriber name");
        headerRow.add("Group number");
        headerRow.add("UMI");
        headerRow.add("Group name");
        


        ArrayList<String> rowData= new ArrayList<String>();
                                for(int j=0;j<headerRow.size();j++)
                                {	if(headerRow.get(j).equals("UMI"))
                            	{
                            		rowData.add(driver.findElement(By.xpath("(//div[text()='"+headerRow.get(j)+"']//following::span/a)[1]")).getText());
                            	}else {
                            		rowData.add(driver.findElement(By.xpath("//span[contains(text(),'"+headerRow.get(j)+"')]/following::div[1]")).getText());	
                            	}
                            										
                                      if(j==0){
                                    	  Contractinformation=rowData.get(j);
                                      }else{
                                    	  Contractinformation=Contractinformation + "|" + rowData.get(j);
                                      }
                                }
                    
                          
                    
                    waitSleep(4000);
                    //rowData=AuthRows;
                    //AuthRows=AuthRows.substring(1,AuthRows.length());
                    //System.out.println(Contractinformation);
                    //System.out.println(data.get("Expected_details"));
                    assertEquals(data.get("Expected_details"), Contractinformation, "Contract information");
                  
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getIntentID method " + e);
		test.log(Status.FAIL, "Error on getIntentID method " + e);
		throw e;
	}
}
public void Servicerequestreview(String frame,Hashtable<String,String> data) {
	try {
		wait(2500);
		switchToFrame(frame);
		String Typeofinquiry = webElementReadText(typeofinquiry);
		assertEquals(data.get("TypeOfInq"), Typeofinquiry, "Type of inquiry");
        String Reason = webElementReadText(reason);
        assertEquals(data.get("Reason"), Reason, "Reason");
        String Resolution = webElementReadText(resolution);
        assertEquals(data.get("Resolution"), Resolution, "Resolution");
        


	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Servicerequestreview method " + excepionMessage);
		test.log(Status.FAIL, "Error on Servicerequestreview method " + e);
		throw e;
	}
}
public void Commentssummary(String frame,Hashtable<String,String> data) {
	try {
		
		wait(2500);
		switchToFrame(frame);
		String headers="";
		
		String headerxpaths=commentSummaryHeader;
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_RequestIDCard"))||data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageClaims")) )
		{
			headerxpaths=IDCCommentSummaryHeader;
			test.log(Status.INFO,headerxpaths);
		}
		
		
		List<WebElement> tableHeaders=driver.findElements(By.xpath(headerxpaths));
		//System.out.println(tableHeaders.size());
        for(int i=0;i<tableHeaders.size();i++)
        {
        	if(i==0)
        	{
        		headers=tableHeaders.get(i).getText();
        		test.log(Status.INFO,headers );
        	}
        	else{
        		headers=headers+"|"+tableHeaders.get(i).getText();
        		test.log(Status.INFO,headers );
        	}
        }

        //System.out.println(data.get("CommetHeaders"));
        //System.out.println(headers);
        if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_CreateGSI"))||data.get("ViewClaim").equals("ViewClaim"))
        {
        	assertEquals(headers, data.get("GSICommentHeaders"), "Comment Summary Headers");
        	test.log(Status.INFO,headers );
        }
        else if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_RequestIDCard"))){
        	assertEquals(headers, data.get("IDCCommentHeaders"), "Comment Summary Headers");
        	test.log(Status.INFO,headers );
        }
        else{
        	assertEquals(headers, data.get("CommetHeaders"), "Comment Summary Headers");
        	test.log(Status.INFO,headers );
        }
        
        String ExpectedHeaders="";
        test.log(Status.INFO,ExpectedHeaders );
        //System.out.println(data.get("HeaderValues"));
        
    try{
    	String header=data.get("HeaderValues");
    	String [] headerValues =header.split("--");
    	for(int i=0;i<headerValues.length;i++)
    	{
    		if(i==0)
    		{
    			ExpectedHeaders=webElementReadText(driver.findElement(By.xpath(String.format(tableValue, headerValues[i]))));
    			test.log(Status.INFO,ExpectedHeaders );
    		}else{
    			ExpectedHeaders=ExpectedHeaders+"|"+webElementReadText(driver.findElement(By.xpath(String.format(tableValue, headerValues[i]))));
    			test.log(Status.INFO,ExpectedHeaders );
    		}
    			
    	}
    }
    catch(Exception e1)
    {
    	ExpectedHeaders=webElementReadText(driver.findElement(By.xpath(String.format(tableValue, data.get("HeaderValues")))));
    	test.log(Status.INFO,ExpectedHeaders );
    }
        
     assertEquals(ExpectedHeaders, data.get("ExpectedHeaderValues"), "Comment Summary");
     test.log(Status.INFO,ExpectedHeaders );
       
	} catch (Exception e) {
		
	}
}
public void Resolve(Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(2500);
		webElementClick(Resolve, "Resolve the intant");
		wait(1500);
		webElementSendText(Comments, data.get("Comments"), "as Comments");
		wait(1500);
		
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on Resolve." + e);
		test.log(Status.FAIL, "Error on Resolve." + e);
		throw e;
	}
}

public void ResolveNClose(Hashtable<String, String> data) {
	String Message9= "";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(2500);
		webElementClick(Resolve, "Resolve the intant");
		wait(1500);
		webElementSendText(WBComments, data.get("ResolveComments"), "as Comments");
		wait(1500);
		
		Message9 = webElementReadText(NewMsg9);
	    //System.out.println(Message9);
		assertEquals(Message9,data.get("Message9"),"Info massage matched as Submit will resolve.");
		wait(1500);
	    //selectDropdownValueByVisibleText(FinalReasontoAdjust, data.get("FinalReasontoAdjust"), "FinalReasontoAdjust");
		wait(1500);
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on Resolve." + e);
		test.log(Status.FAIL, "Error on Resolve." + e);
		throw e;
	}
}

public void Routeintenttocreatingoperator(Hashtable<String, String> data) {
	String Message="";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(2500);
		webElementClick(creatingoperator, "Route intent to creating operator");
		wait(1500);
		webElementSendText(Comments, data.get("Comments"), "as Comments");
		wait(1500);
		Message= webElementReadText(message, "Message");
		 //System.out.println(Message);
		
		assertEquals(data.get("ExpectedcreatingoperatorMessage"), Message, "Message");
		webElementClick(Submit, "Submit");
		wait(1500);
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on Resolve." + e);
		test.log(Status.FAIL, "Error on Resolve." + e);
		throw e;
	}
}
public void RoutetoWorkbasket(Hashtable<String, String> data) {
	
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(2500);
		webElementClick(RoutetoWorkbasket, "Route to Workbasket");
		wait(1500);
		webElementSendText(Comments, data.get("Comments"), "as Comments");
		wait(1500);
		
		webElementClick(Submit, "Submit");
		wait(1500);
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on Resolve." + e);
		test.log(Status.FAIL, "Error on Resolve." + e);
		throw e;
	}
}
public void Createnew(String typeOfInq,String reason,String resolution,String Comments,String Intent,Hashtable<String, String> data) {
	String Message= "";
	try {
		switchToFrame("PegaGadget1Ifr");
		waitSleep(4500);
		if(Intent.equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageOtherCoverage")))
		{
		 selectDropdownValueByVisibleText(TypeOfInq, typeOfInq, "Type Of Inquiry");
		 wait(2500);
		}
		selectDropdownValueByVisibleText(Reason, reason, "Reason");
		wait(2500);
		selectDropdownValueByVisibleText(Resolution, resolution, "Resolution");
		wait(2500);
//		if(Intent.equals("Create GSI"))
//		{
//			webElementSendText(GSIcomment, Comments, "Comments");
//		}else{
		webElementSendText(comment, Comments, "Comments");	
		Message= webElementReadText(message, "Message");
		 //System.out.println(Message);
		if(data.get("ExpectedWorkbasketMessage").equals(Message))
		{
		assertEquals(data.get("ExpectedWorkbasketMessage"), Message, "Message");
		}
		else{
			assertEquals(data.get("ExpectedResolvedworkMessage"), Message, "Message");
		}
		
		webElementClick(Submit, "Submit");
		wait(2500);
		
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on sortandSelectIntent method " + e);
		test.log(Status.FAIL, "Error on sortandSelectIntent method " + e);
		throw e;
	}
}
public void Forwardorupdate(Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(2500);
		webElementClick(Forwardorupdate, "Forward or update");
		wait(1500);
		webElementSendText(Comments, data.get("Comments"), "as Comments");
		wait(1500);

		webElementClick(Submit, "Submit");
		wait(1500);
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on Resolve." + e);
		test.log(Status.FAIL, "Error on Resolve." + e);
		throw e;
	}
}
  public void Routeintenttolastassignedoperator(Hashtable<String, String> data) {
	String Message="";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(2500);
		webElementClick(Routeintenttolastassignedoperator, "Route intent to last assigned operator");
		wait(2500);
		webElementSendText(Comments, data.get("Comments"), "as Comments");
		wait(2500);
		Message= webElementReadText(message, "Message");
		 //System.out.println(Message);
		 assertEquals(data.get("ExpectedlastassignedoperatorMessage"), Message, "Message");
		webElementClick(Submit, "Submit");
		wait(2500);
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on Resolve." + e);
		test.log(Status.FAIL, "Error on Resolve." + e);
		throw e;
	}
}

}
