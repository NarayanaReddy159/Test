package com.nasco.HMHS.TestScripts.G1;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class LI_Prospective_Member_MembershipType_PageLevel_Error_NotDisp extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void AUTC_LI_Prospective_Member_MembershipType_PageLevel_Error_NotDisp(Hashtable<String,String> data) throws Exception {
		try{
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside LI_Prospective_Member_MembershipType_PageLevel_Error_NotDisp");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("LI_Prospective_Member_MembershipType_PageLevel_Error_NotDisp - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("LI_Prospective_Member_MembershipType_PageLevel_Error_NotDisp -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		test.log(Status.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.movetoProsMem();
		log.debug("Moved to Prospective Member page");
		searchMember.AddProsMemNoMemberErrMsg( data, data.get("ExpectedErrMsg"), data.get("ExpectedErrMsg_1"));
		log.debug("Reading Error Message");	
		searchMember.WrapUp_MemberNotFound();
		searchMember.WrapUpMemNotFoundSubmit( "Wrap up interaction", "Wrong Number");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  {
		
		test.log(Status.INFO, "LI_Prospective_Member_MembershipType_PageLevel_Error_NotDisp Completed");
		log.debug("LI_Prospective_Member_MembershipType_PageLevel_Error_NotDisp Completed");
		quit();
		
	}
}
