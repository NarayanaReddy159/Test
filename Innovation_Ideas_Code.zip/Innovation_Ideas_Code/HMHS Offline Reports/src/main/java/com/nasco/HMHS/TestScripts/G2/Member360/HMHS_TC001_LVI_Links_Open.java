package com.nasco.HMHS.TestScripts.G2.Member360;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.Member360Page;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;

public class HMHS_TC001_LVI_Links_Open extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC001_LVI_Links_Open(Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_AUTC001_LVI_Links_Open Search");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_AUTC001_LVI_Links_Open - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_AUTC001_LVI_Links_Open -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		String interaction=data.get("SearchBy");
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork.");
		test.log(Status.INFO,"Navigated to the Recentwork.");
		String status=data.get("Status");
		recentWork.sortStatus(status);
		recentWork.sortandSelectIntent( interaction);
		//System.out.println("Sorted and selected interaction " + interaction + " from recent work tab.");
		log.debug("Sorted and selected interaction " + interaction + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected interaction " + interaction + " from recent work tab.");
		recentWork.contractInformation();
		log.debug("Check the intent status.");
		test.log(Status.INFO,"Check the intent status.");
		
		WorklistPage worklist = homepage.openrecentWorklist();
		worklist.movetoWorklistPage();
		worklist.sortStatus(status);
		worklist.sortandSelectIntent(interaction);
		Member360Page mem360=homepage.Member360Page();
		mem360.interactionHeader_memberInformation();
		mem360.closeInteraction();
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  {

		test.log(Status.INFO, "HMHS_AUTC001_LVI_Links_Open Completed.");
		log.debug("HMHS_AUTC001_LVI_Links_Open Completed.");
		quit();

	}
}
