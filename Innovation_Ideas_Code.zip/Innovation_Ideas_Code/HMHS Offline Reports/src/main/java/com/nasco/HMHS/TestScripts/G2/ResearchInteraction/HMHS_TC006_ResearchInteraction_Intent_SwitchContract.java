package com.nasco.HMHS.TestScripts.G2.ResearchInteraction;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.Member360Page;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC006_ResearchInteraction_Intent_SwitchContract extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC006_ResearchInteraction_Intent_SwitchContract (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC006_ResearchInteraction_Intent_SwitchContract");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC006_ResearchInteraction_Intent_SwitchContract - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC006_ResearchInteraction_Intent_SwitchContract -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSResearchInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		test.log(Status.INFO,"Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page.");
		log.debug("Member Submit Completed");
		InteractionManagerPage InteractionManager=searchMember.openInteractionPage();
		InteractionManager.openTask();
		Member360Page mem360=homepage.Member360Page();
		log.debug("Navigate to Member 360 page.");
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(Status.INFO, "Add Intent "+data.get("Intent"));
		
        ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		test.log(Status.INFO,"Intent id: " + intentID);
		
        mem360.contractTab_readContractDetails(data.get("Expected _policy"));
		log.debug("Validate the switched contract interactionHeader_memberInformation details.");
		test.log(Status.INFO,"Validate the switched contract interactionHeader_memberInformation details.");
		
		//Perform End Research
		InteractionManager.EndResearchOpen();
		log.debug("Navigate to End Research screen.");
		test.log(Status.INFO,"Navigate to End Research screen.");
		
		WorklistPage worklist = homepage.openrecentWorklist();
		worklist.movetoWorklistPage();
		log.debug("Navigated to the Worklist page.");
		test.log(Status.INFO,"Navigated to the Worklist page.");
		worklist.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from Worklist tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected intent " + intentID + " from recent work tab.");
		worklist.IntentStatusWorklist(data.get("IntentStatusWork"), "PegaGadget1Ifr");
		log.debug("Check the worklist Intent Status checked.");
		test.log(Status.INFO,"Check the worklist Intent Status checked.");
		worklist.WorklistComments(intentID, data);
		log.debug("Enter the worklist comments and Submit.");
		test.log(Status.INFO,"Enter the worklist comments and Submit.");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork.");
		test.log(Status.INFO,"Navigated to the Recentwork.");
		recentWork.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected interaction " + intentID + " from recent work tab.");
		log.debug("Sorted and selected interaction " + intentID + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected interaction " + intentID + " from recent work tab.");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the intent status.");
		test.log(Status.INFO,"Check the intent status.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}

	@AfterMethod
	public void tearDown() throws Exception  {
		test.log(Status.INFO, "HMHS_TC006_ResearchInteraction_Intent_SwitchContract completed.");
		log.debug("HMHS_TC006_ResearchInteraction_Intent_SwitchContract completed.");
		quit();

	}
}
