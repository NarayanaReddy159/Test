package com.nasco.HMHS.Pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked"})
public class RecentWorkPage extends BasePage {
	String XpathContractinformation="(//div[contains(@class,'layout-body clearfix layout-body clearfix')])[2]//span[contains(text(),'%s')]/following::div[1]";
	
	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	
	@FindBy(xpath = "//span[contains(text(),'Home')]")
	public WebElement Home;
	
	@FindBy(xpath = "//button[contains(@name,'CPMReviewInteractionWorkHeader_pyWorkPage')]")
	public WebElement closeButton;

	@FindBy(xpath = "//div[1]/div/div/div/ul/li[2]/a/span[1]/span")
	public WebElement myWorkIcon;

	@FindBy(xpath = "//h3[contains(text(),'Recent work')]")
	public WebElement recentWork;

	@FindBy(xpath = "(//*[@id='pui_filter'])[13]")
	public WebElement idSort;
	@FindBy(xpath = "(//*[@id='pui_filter'])[15]")
	public WebElement statusSort;
	@FindBy(xpath = "//span/div/div/div/div/div/div/div/span/input")
	public WebElement searchID;
	@FindBy(xpath = "//button[contains(text(),'Apply')]")
	public WebElement applyBtn;
	@FindBy(xpath = "//*[@id='$PpgRepPgSubSectionCPMMyRecentWorkBB$ppxResults$l1']/td[2]/div/span/a")
	public WebElement intentclick;
	@FindBy(xpath = "//span[text()='Status']//following::div[1]")
	public WebElement IntentStatus;
	@FindBy(xpath = "//span[2]/div/span[1]/div/div/div/div/div/div/div/div[2]/div/div/div/div[1]/div/div/div[1]/div/div/span")
	public WebElement IntentStatusCF;
	@FindBy(xpath = "(//a[@class='Header_nav'])[3]")
	public WebElement MenuDropdown;
	@FindBy(xpath = "//span[contains(text(),'Logout')]")
	public WebElement LogOut;
	@FindBy(xpath = "//span[contains(text(),'Type of inquiry')]//following::span[1]")
	public WebElement typeofinquiry;
	@FindBy(xpath = "//span[contains(text(),'Reason')]//following::span[1]")
	public WebElement reason;
	@FindBy(xpath = "//span[contains(text(),'Resolution')]//following::span[1]")
	public WebElement resolution;
	@FindBy(xpath = "//button[@title='Close']")
	public WebElement close;
	
	@FindBy(xpath = "//div[2]/div[1]/div[6]/div[1]/h3[1]/i[1]")
	public WebElement ReviewIDExpand;
	@FindBy(xpath = "//div[6]/div[2]/div/div[2]/div/div/div/div/div/div[1]/div/div/div[1]/div/strong")
	public WebElement SendIDMsg;
	
	String commentSummaryHeader="//h2[contains(text(),'Comments summary')]/following::table[2]/tbody/tr/th";
	String CancelcommentSummaryHeader="(//h2[text()='Comments summary'])[2]//following::table/tbody/tr/th";
	String IDCCommentSummaryHeader="//h2[contains(text(),'Comments summary')]//following::table[3]/tbody/tr/th";
	String tableValue="//td[@data-attribute-name='%s']";
	String cancelableValue="(//h2[text()='Comments summary'])[2]//following::table/tbody/tr/td[@data-attribute-name='%s']";
	String commentsXpath="//span[text()='%s']";
	
	@FindBy(xpath = "//button[contains(text(),'History')]")
	public WebElement History;
	@FindBy(xpath = "//span[contains(text(),'Assigned operator')]//following::span[1]")
	public WebElement Assignedoperator;
	// HMHS User will move to My Work and Recent Work page
	
	@FindBy(xpath = "//span[contains(text(),'Group number')]/following::a[1]")
	public WebElement Group;
	
	@FindBy(xpath = "//div[contains(text(),'UMI')]/following::a[1]")
	public WebElement UMI;
	
	public void movetoRecentWorkPage() {
		try {
			waitSleep(3000);
			switchToFrame("PegaGadget0Ifr");
			webElementClick(myWorkIcon, "My Work");
			waitSleep(2000);
			webElementClick(recentWork, "RecentWork tab");
		} catch (Exception e) {
			BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
			test.log(Status.FAIL, "Error on movetoRecentWorkPage method " + e);
			throw e;
		}
	}
	
	public void movetoHome() {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget0Ifr");
			waitSleep(1500);
			webElementClick(Home, "Home");
			waitSleep(3000);
			webElementClick(myWorkIcon, "My Work");
			waitSleep(2000);
			webElementClick(recentWork, "RecentWork tab");
		} catch (Exception e) {
			BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
			test.log(Status.FAIL, "Error on movetoRecentWorkPage method " + e);
			throw e;
		}
	}

	// HMHS Sort and Select Intent on RecentWork page
	
	public void sortandSelectIntent( String intentID) {
		try {
			switchToFrame("PegaGadget0Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(idSort));
			webElementClick(idSort, "ID Sort");
			try{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
				webElementSendText(searchID, intentID, "Search Intent");
				}catch(StaleElementReferenceException e){
					waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
					webElementSendText(searchID, intentID, "Search Intent");
				}
			waitSleep(1500);
			try{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(applyBtn));
				webElementClick(applyBtn, "Apply");
				}catch(StaleElementReferenceException e){
					webElementClick(applyBtn, "Apply");
				}
			waitSleep(1500);
			try{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(intentclick));
				webElementClick(intentclick, "Intent " + intentID);
				}catch(StaleElementReferenceException e){
					webElementClick(intentclick, "Intent " + intentID);
				}
			waitSleep(2500);
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(Status.FAIL, "Error on sortandSelectIntent method " + e);
			throw e;
		}
	}
	
	
	public void sortStatus(String status ) {
		try {
			switchToFrame("PegaGadget0Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(statusSort));
			webElementClick(statusSort, "Status Sort");
			try{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
				webElementSendText(searchID, status, "Search Status");
				}catch(StaleElementReferenceException e){
					waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
					webElementSendText(searchID, status, "Search Status");
				}
			waitSleep(1500);
			try{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(applyBtn));
				webElementClick(applyBtn, "Apply");
				}catch(StaleElementReferenceException e){
					webElementClick(applyBtn, "Apply");
				}
			waitSleep(1500);
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(Status.FAIL, "Error on sortandSelectIntent method " + e);
			throw e;
		}
	}
	
	// HMHS IntentStatus
	public void IntentStatus( String IntStatus, String frame) {
		try {
			wait(2500);
			switchToFrame(frame);
			String actualMessage = webElementReadText(IntentStatus);
			String expected = String.format(IntStatus);
			if (actualMessage.contains(expected)) {
				test.log(Status.PASS, "Intent status is matched.");
				test.log(Status.PASS,"Actual Intent status is: "+' '+actualMessage);
				test.log(Status.PASS,"Expected Intent status is: "+' '+expected);
			} else {
				test.log(Status.FAIL, "Intent status is not matched.");
				test.log(Status.PASS,"Actual Intent status is: "+' '+actualMessage);
				test.log(Status.PASS,"Expected Intent status is: "+' '+expected);
			}
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on IntentStatus method " + excepionMessage);
			test.log(Status.FAIL, "Error on IntentStatus method " + e);
			throw e;
		}
	}

	// HMHS Check Send ID Message for RequestID Card intent either it sent to Member or Group
	public void SendIDMsgReqIDCard ( String Msg, String frame) {
		try {
			wait(2500);
			switchToFrame(frame);
			webElementClick(ReviewIDExpand, "to expand the Review ID Card window.");
			wait(2500);
			String actualMessage = webElementReadText(SendIDMsg);
			String expected = String.format(Msg);
			if (actualMessage.contains(expected)) {
				test.log(Status.PASS, "Send ID Message is matched.");
				test.log(Status.PASS,"Actual Message: "+' '+actualMessage);
				test.log(Status.PASS,"Expected Message: "+' '+expected);
			} else {
				test.log(Status.FAIL, "Send ID Message is not matched.");
				test.log(Status.PASS,"Actual Message: "+' '+actualMessage);
				test.log(Status.PASS,"Expected Message: "+' '+expected);
			}
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on IntentStatus method " + excepionMessage);
			test.log(Status.FAIL, "Error on IntentStatus method " + e);
			throw e;
		}
	}	
	
	public void IntentStatusCF( String IntStatus, String frame) {
		try {
			wait(2500);
			switchToFrame(frame);
			String actualMessage = webElementReadText(IntentStatusCF);
			String expected = String.format(IntStatus);
			if (actualMessage.contains(expected)) {
				test.log(Status.PASS, "Intent status is matched.");
				test.log(Status.PASS,"Actual Intent status is: "+' '+actualMessage);
				test.log(Status.PASS,"Expected Intent status is: "+' '+expected);
			} else {
				test.log(Status.FAIL, "Intent status not matched.");
				test.log(Status.PASS,"Actual Intent status is: "+' '+actualMessage);
				test.log(Status.PASS,"Expected Intent status is: "+' '+expected);
			}
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on IntentStatus method " + excepionMessage);
			test.log(Status.FAIL, "Error on IntentStatus method " + e);
			throw e;
		}
	}
	
	// HMHS User will move to My Work and Recent Work page.
	public void movetomyWorkLogout() {
		try {
			waitSleep(3000);
			switchToDefault();
			webElementClick(MenuDropdown, "Menu Dropdown");
			waitSleep(3500);
			webElementClick(LogOut, "Log Out");
			driver.switchTo().alert().accept();
			waitSleep(3500);
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
			test.log(Status.FAIL, "Error on movetoRecentWorkPage method " + e);
			throw e;
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget0Ifr");
		return ExpectedConditions.visibilityOf(myWorkIcon);
	}
	
	
	public void contractInformation(Hashtable<String,String> data) 
	{
		String Contractinformation ="";
		try{
			
			switchToFrame("PegaGadget1Ifr");
			List<String> headerRow= new ArrayList<String>();
            headerRow.add("Subscriber name");
            headerRow.add("Group number");
            headerRow.add("UMI");
            headerRow.add("Group name");
            
          

            ArrayList<String> rowData= new ArrayList<String>();
                                    for(int j=0;j<headerRow.size();j++)
                                    {
                                    	if(headerRow.get(j).equals("UMI"))
                                    	{
                                    		rowData.add(driver.findElement(By.xpath("(//div[text()='"+headerRow.get(j)+"']//following::span/a)[1]")).getText());
                                    	}else {
                                    		rowData.add(driver.findElement(By.xpath("//span[contains(text(),'"+headerRow.get(j)+"')]/following::div[1]")).getText());	
                                    	}
                                    
                                          if(j==0){
                                        	  Contractinformation=rowData.get(j);
                                          }else{
                                        	  Contractinformation=Contractinformation + "|" + rowData.get(j);
                                          }
                                    }
                       waitSleep(4000);
                       assertEquals(data.get("Expected_details"), Contractinformation, "Contract information");
                      
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(Status.FAIL, "Error on getIntentID method " + e);
			throw e;
		}
	}
	
	public void contractInformation() 
	{
		String Contractinformation ="";
		try{
			
			switchToFrame("PegaGadget1Ifr");
			List<String> headerRow= new ArrayList<String>();
			
			headerRow.add("Customer type");
			headerRow.add("Contact");
            headerRow.add("Member name");
            //headerRow.add("UMI");
            ArrayList<String> rowData= new ArrayList<String>();
                                    for(int j=0;j<headerRow.size();j++)
                                    {											
                                    rowData.add(driver.findElement(By.xpath("(//div[contains(@class,'layout-body clearfix layout-body clearfix')])[2]//span[contains(text(),'"+headerRow.get(j)+"')]/following::div[1]")).getText());
                                          if(j==0){
                                        	  Contractinformation=rowData.get(j);
                                          }else{
                                        	  Contractinformation=Contractinformation + "|" + rowData.get(j);
                                          }
                                    }
            waitSleep(2000);
            test.log(Status.PASS, "Customer Details displayed "+Contractinformation);
            webElementClick(closeButton, "close");
            waitSleep(2000);
            
   	}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(Status.FAIL, "Error on getIntentID method " + e);
			throw e;
		}
	}
	
	public void Servicerequestreview(String frame,Hashtable<String,String> data) {
		try {
			wait(2500);
			switchToFrame(frame);
			String Typeofinquiry = webElementReadText(typeofinquiry);
			assertEquals(data.get("TypeOfInq"), Typeofinquiry, "Type of inquiry");
            String Reason = webElementReadText(reason);
            assertEquals(data.get("Reason"), Reason, "Reason");
            String Resolution = webElementReadText(resolution);
            assertEquals(data.get("Resolution"), Resolution, "Resolution");
            


		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Servicerequestreview method " + excepionMessage);
			test.log(Status.FAIL, "Error on Servicerequestreview method " + e);
			throw e;
		}
	}
	public void Commentssummary(String frame,Hashtable<String,String> data) {
		try {
			
			wait(2500);
			switchToFrame(frame);
			String headers="";
			
			String headerxpaths=commentSummaryHeader;
			if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_RequestIDCard"))||data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageClaims")) )
			{
				headerxpaths=IDCCommentSummaryHeader;
				test.log(Status.INFO,headerxpaths);
			}
			
			
			List<WebElement> tableHeaders=driver.findElements(By.xpath(headerxpaths));
			//System.out.println(tableHeaders.size());
            for(int i=0;i<tableHeaders.size();i++)
            {
            	if(i==0)
            	{
            		headers=tableHeaders.get(i).getText();
            		test.log(Status.INFO,headers );
            	}
            	else{
            		headers=headers+"|"+tableHeaders.get(i).getText();
            		test.log(Status.INFO,headers );
            	}
            }

            //System.out.println(data.get("CommetHeaders"));
            //System.out.println(headers);
            if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_CreateGSI"))||data.get("ViewClaim").equals("ViewClaim"))
            {
            	assertEquals(headers, data.get("GSICommentHeaders"), "Comment Summary Headers");
            	test.log(Status.INFO,headers );
            }
            else if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_RequestIDCard"))){
            	assertEquals(headers, data.get("IDCCommentHeaders"), "Comment Summary Headers");
            	test.log(Status.INFO,headers );
            }
            else{
            	assertEquals(headers, data.get("CommetHeaders"), "Comment Summary Headers");
            	test.log(Status.INFO,headers );
            }
            
            String ExpectedHeaders="";
            test.log(Status.INFO,ExpectedHeaders );
            //System.out.println(data.get("HeaderValues"));
            
        try{
        	String header=data.get("HeaderValues");
        	String [] headerValues =header.split("--");
        	for(int i=0;i<headerValues.length;i++)
        	{
        		if(i==0)
        		{
        			ExpectedHeaders=webElementReadText(driver.findElement(By.xpath(String.format(tableValue, headerValues[i]))));
        			test.log(Status.INFO,ExpectedHeaders );
        		}else{
        			ExpectedHeaders=ExpectedHeaders+"|"+webElementReadText(driver.findElement(By.xpath(String.format(tableValue, headerValues[i]))));
        			test.log(Status.INFO,ExpectedHeaders );
        		}
        			
        	}
        }
        catch(Exception e1)
        {
        	ExpectedHeaders=webElementReadText(driver.findElement(By.xpath(String.format(tableValue, data.get("HeaderValues")))));
        	test.log(Status.INFO,ExpectedHeaders );
        }
            
         assertEquals(ExpectedHeaders, data.get("ExpectedHeaderValues"), "Comment Summary");
         test.log(Status.INFO,ExpectedHeaders );
           
		} catch (Exception e) {
			
		}
	}
	
	public void closeRecentWork()
	{
		try{
			webElementClick(close, "Close button");
		}catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on closeRecentWork method " + excepionMessage);
			test.log(Status.FAIL, "Error on closeRecentWork method " + e);
			throw e;
		}
	}
	
	public void cancelCommentsSummary(String frame,Hashtable<String,String> data)
	{
		try{
			wait(2500);
			switchToFrame(frame);
			String headers="";
			
			List<WebElement> tableHeaders=driver.findElements(By.xpath(CancelcommentSummaryHeader));
            for(int i=0;i<tableHeaders.size();i++)
            {
            	if(i==0)
            	{
            		headers=tableHeaders.get(i).getText();
            	}
            	else{
            		headers=headers+"|"+tableHeaders.get(i).getText();
            	}
            }

            //System.out.println(data.get("CommetHeaders"));
            //System.out.println(headers);
            assertEquals(headers, data.get("CommetHeaders"), "Comment Summary Headers");
            
           
            //System.out.println(data.get("HeaderValues"));
           
            		
            /*String ExpectedHeaders=webElementReadText(driver.findElement(By.xpath(String.format("commentsXpath", data.get("Comments")))),"Comment");
            assertEquals(ExpectedHeaders, data.get("Comments"), "Commets");*/
            
            String ExpectedHeaders="";
            
            //System.out.println(data.get("HeaderValues"));
            
        try{
        	String header=data.get("HeaderValues");
        	String [] headerValues =header.split("--");
        	for(int i=0;i<headerValues.length;i++)
        	{
        		if(i==0)
        		{
        			ExpectedHeaders=webElementReadText(driver.findElement(By.xpath(String.format(cancelableValue, headerValues[i]))));
        		}else{
        			ExpectedHeaders=ExpectedHeaders+"|"+webElementReadText(driver.findElement(By.xpath(String.format(cancelableValue, headerValues[i]))));
        		}
        			
        	}
        }
        catch(Exception e1)
        {
        	ExpectedHeaders=webElementReadText(driver.findElement(By.xpath(String.format(cancelableValue, data.get("HeaderValues")))));
        }
            
         assertEquals(ExpectedHeaders, data.get("ExpectedHeaderValues"), "Comment Summary");
           
		}
		catch(Exception e)
		{
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on cancelCommentsSummary method " + excepionMessage);
			test.log(Status.FAIL, "Error on cancelCommentsSummary method " + e);
			throw e;
		}
	}
	
	public void IntentStatusFollowUp( String IntStatus, String frame) {
		try {
			wait(2500);
			switchToFrame(frame);
			String actualMessage = webElementReadText(IntentStatusCF);
			String expected = String.format(IntStatus);
			if (actualMessage.contains(expected)) {
				test.log(Status.PASS, "Intent status is matched.");
				test.log(Status.PASS,"Actual Intent status is: "+' '+actualMessage);
				test.log(Status.PASS,"Expected Intent status is: "+' '+expected);
			} else {
				test.log(Status.FAIL, "Intent status is not matched.");
				test.log(Status.PASS,"Actual Intent status is: "+' '+actualMessage);
				test.log(Status.PASS,"Expected Intent status is: "+' '+expected);
			}
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on IntentStatus method " + excepionMessage);
			test.log(Status.FAIL, "Error on IntentStatus method " + e);
			throw e;
		}
	}
	public String vaildationshistory(String frame,Hashtable<String,String> data) 
	{
		String AuditLog="";
		wait(2500);
		switchToFrame(frame);
		try {

		String parentWindow=driver.getWindowHandle();
		webElementClick(History, "History");
		waitSleep(2000);
		for (String windowHandle : driver.getWindowHandles())
		{
			if(!parentWindow.equals(windowHandle)){
				 driver.switchTo().window(windowHandle);
				 //System.out.println("Switched to"+windowHandle);
			}
			//System.out.println(windowHandle);
			
		}
		
		switchToDefault();
		AuditLog="The skill"+" "+data.get("Skill")+" "+"is"+" "+"applied";
		//System.out.println("SKILL:"+AuditLog);
		test.log(Status.INFO, "Skill:"+AuditLog);

		List<WebElement> ele= driver.findElements(By.xpath("//tr[contains(@id,'$ppxResults$l')]"));
		ele.size();
		String s="//tr[contains(@id,'$ppxResults$l%d')]";
		for(int i=0;i<ele.size();i++)
		{
			String s1=String.format(s, i+1);
			//System.out.println("Skill applied:"+driver.findElement(By.xpath(s1+"//td[2]")).getText());
			//System.out.println("Skill:"+AuditLog);
			if(driver.findElement(By.xpath(s1+"//td[2]")).getText().equals(AuditLog))
			{
		
				//System.out.println(driver.findElement(By.xpath(s1+"//td[2]")).getText());
				test.log(Status.PASS, "Skill IS MATCHED IN HISTORY "+AuditLog);
				//System.out.println("Skill IS  MATCHED IN HISTORY "+AuditLog);

				break;
			}
		} 
		driver.close();
		driver.switchTo().window(parentWindow);
		
		} catch (Exception e) {
	        e.printStackTrace();
	        BaseTest.log.error("Error on vaildationshistory method " + e);
	        test.log(Status.FAIL, "Error on vaildationshistory method " + e);
	        throw e;
		}
		return AuditLog;
	}
	public void vaildationsAssignedoperator (String frame,Hashtable<String, String> data) {
		wait(2500);
		switchToFrame(frame);
		try {
			
			String expectedValues=webElementReadText(Assignedoperator);
			assertEquals(expectedValues, data.get("Assignedoperator"), "Assigned operator");
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on vaildationsAssignedoperator method " + e);
			test.log(Status.FAIL, "Error on vaildationsAssignedoperator method " + e);
			throw e;
		}
	}

	public String resolveDate()
	{
		switchToFrame("PegaGadget1Ifr");
		String resolvedate=driver.findElement(By.xpath("//span[text()='Resolve date of last intent']//following::span[1]")).getText();
		return resolvedate;
	}
	
	public String resolveDateIntent()
	{
		switchToFrame("PegaGadget1Ifr");
		String resolvedate=driver.findElement(By.xpath("//span[text()='Resolve date']//following::span[1]")).getText();
		return resolvedate;
	}
	
	public void closeRecentwork()
	{
		driver.switchTo().defaultContent();
		wait(2500);
		driver.findElement(By.xpath("//span[@title='Close Tab']")).click();
	}
	
	public void switchToframe(String frame)
	{
		waitSleep(2500);
		driver.switchTo().frame(frame);
	}
	public void contractInformation(String Headersdata,String Expected_details) 
	{
		String Contractinformation ="";
		try{
			
			Contractinformation=getrowdata(Headersdata, XpathContractinformation);
			assertEquals(Expected_details, Contractinformation, "Check the data masking");
				}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(Status.FAIL, "Error on getIntentID method " + e);
			throw e;
		}
	}
	public void Servicerequestreview_SHC(String frame,Hashtable<String,String> data)
	{
		try{
			wait(2500);
			switchToFrame(frame);
			String header="";
			String ServiceValue="";
			
	
            
            List<WebElement> hr = driver.findElements(By.xpath("//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Providerdetails')]//th")); 
    		//System.out.println(hr.size());
    		if(hr.size()==0)
    		{
    			waitSleep(15000);
    			hr = driver
    					.findElements(By.xpath("//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Providerdetails')]//th"));
    			//System.out.println(hr.size());
    		}
    		
    		String h = "//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Providerdetails')]//th";				
    			List<WebElement> colums = driver.findElements(By.xpath(h ));
    			for (int j = 0; j < colums.size(); j++) {
    				if (j ==0) {
    					header = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    					
    				} else {
    					header = header + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    					
    					
    				}
    			}
    		//System.out.println(header);
    		assertEquals(header,data.get("ServiceHeaders"),"Service Headers");
            List<WebElement> ele = driver
    				.findElements(By.xpath("//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Providerdetails')]//tr"));
    		//System.out.println(ele.size());
    		
    			if(ele.size()==0)
    			{
    				waitSleep(15000);
    				ele = driver
    						.findElements(By.xpath("//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Providerdetails')]//tr"));
    				
    			}
    		String s = "//table[contains(@pl_prop_class,'NASCO-FW-CSD-Data-Providerdetails')]//tr";
    		for (int i = 0; i < ele.size(); i++) {
    			String s1 = String.format(s, i + 1);
    			String memdet = "";
    			List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
    			////System.out.println(colums1.size());
    			for (int j = 0; j < colums1.size(); j++) {
    				if (j ==0) {
    					memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
    				} else {
    					memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
    				}
    			}
    			ServiceValue = ServiceValue + "," + memdet;
    		}
    		waitSleep(1000);
    		ServiceValue = ServiceValue.substring(1, ServiceValue.length());
    		//System.out.println(ServiceValue);
    		assertEquals(ServiceValue, data.get("ServiceValue"), "Service Value");

		}
            catch(Exception e)
    		{
    			e.printStackTrace();
    			BaseTest.log.error("Error on getIntentID method " + e);
    			test.log(Status.FAIL, "Error on getIntentID method " + e);
    			throw e;
    		}
    	 
	}   
	public void Reviewedclaims(Hashtable<String, String> data)
	{
		String ReviewedclaimsHearder="";
		
		String Reviewedclaims="";
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);
			List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Reviewed claims')]//following::table[2]//th")); 
			//System.out.println(hr.size());
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[contains(text(),'Reviewed claims')]//following::table[2]//th"));
				//System.out.println(hr.size());
			}
			
			String h = "//h2[contains(text(),'Reviewed claims')]//following::table[2]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						ReviewedclaimsHearder = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						ReviewedclaimsHearder = ReviewedclaimsHearder + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
				//OtherinsuranceHearder = OtherinsuranceHearder.substring(1, OtherinsuranceHearder.length());
			//System.out.println(ReviewedclaimsHearder);
			assertEquals(data.get("ExpectedReviewedclaimsHearder"), ReviewedclaimsHearder, "ReviewedclaimsHearder");
List<WebElement> ele=driver.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pReviewedClaims$l')]"));
			
			
			if(ele.size()==0)
			{
				waitSleep(15000);
				ele = driver
						.findElements(By.xpath("//tr[contains(@id,'$PpyWorkPage$pReviewedClaims$l')]"));
				//System.out.println(ele.size());
			}
			
			String s = "//tr[contains(@id,'$PpyWorkPage$pReviewedClaims$l%d')]";
			for (int i = 0; i < ele.size(); i++) {
				String s1 = String.format(s, i + 1);
				String claiminformations = "";
				List<WebElement> colums1 = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < colums1.size(); j++) {
					if (j == 0) {
						claiminformations = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						claiminformations = claiminformations + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				Reviewedclaims = Reviewedclaims + "," + claiminformations;
			}
			waitSleep(1000);
			Reviewedclaims = Reviewedclaims.substring(2, Reviewedclaims.length());
			//System.out.println("Expected_Reviewedclaims::"+Reviewedclaims);
			// Commented for issue found on 1/19/2021 
			assertEquals(data.get("Expected_Reviewedclaims"), Reviewedclaims, "Medicaredollars");


			
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Paymentoffsetdetails method " + e);
			test.log(Status.FAIL, "Error on Paymentoffsetdetails method " + e);
			throw e;
		}
	}

public void groupRecurring (String frame) {
	wait(2500);
	switchToFrame(frame);
	try {
		
		webElementClick(Group, "Click on the Group recurring");
		wait(5500);
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on vaildationsAssignedoperator method " + e);
		test.log(Status.FAIL, "Error on vaildationsAssignedoperator method " + e);
		throw e;
	}
}
public void UMIRecurring (String frame) {
	wait(2500);
	switchToFrame(frame);
	try {
		
		webElementClick(UMI, "Click on the UMI recurring");
		wait(5500);
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on vaildationsAssignedoperator method " + e);
		test.log(Status.FAIL, "Error on vaildationsAssignedoperator method " + e);
		throw e;
	}
}


public List<String> resolvedIntentDetails()
{
	try {
			List<String> resolvedIntentDetails= new ArrayList<String>();
			switchToFrame("PegaGadget1Ifr");
			resolvedIntentDetails.add(driver.findElement(By.xpath("//span[contains(text(),'Status')]//following::span[1]")).getText());
			resolvedIntentDetails.add(driver.findElement(By.xpath("//span[contains(text(),'Create operator')]//following::label[1]")).getText());
			resolvedIntentDetails.add(driver.findElement(By.xpath("//span[contains(text(),'Creation date')]//following::div[1]")).getText());
			resolvedIntentDetails.add(driver.findElement(By.xpath("//span[contains(text(),'Resolve operator')]//following::div[1]")).getText());
			resolvedIntentDetails.add(driver.findElement(By.xpath("//span[contains(text(),'Resolve date')]//following::div[1]")).getText());
			return resolvedIntentDetails;
	}
	
	catch(Exception e)
	{
		BaseTest.log.error("Error on resolvedIntentDetails method " + e);
		test.log(Status.FAIL, "Error on resolvedIntentDetails method " + e);
		throw e;
	}
}

public List<String> savetoWorklistComments()
{
	try {
			List<String> resolvedIntentDetails= new ArrayList<String>();
			switchToFrame("PegaGadget1Ifr");
			resolvedIntentDetails.add(driver.findElement(By.xpath("//td[@data-attribute-name='Date/Time']")).getText());
			resolvedIntentDetails.add(driver.findElement(By.xpath("//td[@data-attribute-name='Comments']")).getText());
			resolvedIntentDetails.add(driver.findElement(By.xpath("//*[@id='$PpyWorkPage$ppyNotes$l1']/td[7]")).getText());
			resolvedIntentDetails.add(driver.findElement(By.xpath("//*[@id='$PpyWorkPage$ppyNotes$l1']/td[6]")).getText());
			resolvedIntentDetails.add(driver.findElement(By.xpath("//*[@id='$PpyWorkPage$ppyNotes$l1']/td[8]")).getText());
			return resolvedIntentDetails;
	}
	
	catch(Exception e)
	{
		BaseTest.log.error("Error on resolvedIntentDetails method " + e);
		test.log(Status.FAIL, "Error on resolvedIntentDetails method " + e);
		throw e;
	}
}

public List<String> routeToTeamDetails()
{
	try {
			List<String> resolvedIntentDetails= new ArrayList<String>();
			switchToFrame("PegaGadget1Ifr");
			resolvedIntentDetails.add(driver.findElement(By.xpath("//span[text()='Urgency']//following::span[2]")).getText());
			resolvedIntentDetails.add(driver.findElement(By.xpath("//span[text()='Service request goal']//following::span[1]")).getText());
			resolvedIntentDetails.add(driver.findElement(By.xpath("//span[text()='Service request deadline']//following::span[1]")).getText());
			resolvedIntentDetails.add(driver.findElement(By.xpath("//span[text()='Assigned operator']//following::span[1]")).getText());
			return resolvedIntentDetails;
	}
	
	catch(Exception e)
	{
		BaseTest.log.error("Error on resolvedIntentDetails method " + e);
		test.log(Status.FAIL, "Error on resolvedIntentDetails method " + e);
		throw e;
	}
}

public void closeIntent()
{
	try {
		webElementClick(driver.findElement(By.xpath("//button[@title='Close']")), "Close");
		wait(3500);
	}catch(Exception e)
	{
		BaseTest.log.error("Error on cloeIntent method " + e);
		test.log(Status.FAIL, "Error on cloeIntent method " + e);
		throw e;
	}
}

}	


