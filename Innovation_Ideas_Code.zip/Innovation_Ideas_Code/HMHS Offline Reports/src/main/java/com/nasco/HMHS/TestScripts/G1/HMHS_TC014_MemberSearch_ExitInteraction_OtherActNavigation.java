package com.nasco.HMHS.TestScripts.G1;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC014_MemberSearch_ExitInteraction_OtherActNavigation extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void HMHS_AUTC014_MemberSearch_ExitInteraction_OtherActNavigation(Hashtable<String,String> data) throws Exception {
		try{
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside HMHS_TC0014_ExitInteraction_MemSearch Search");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC0014_ExitInteraction_MemSearch - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("HMHS_TC0014_ExitInteraction_MemSearch -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		test.log(Status.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String intentID=searchMember.getLIInteractionID();
		log.debug("Interaction id: "+intentID);
		test.log(Status.INFO,"Interaction id: "+intentID);
		searchMember.ExitInteraction();
		log.debug("Moved to Exit Interaction page.");
		test.log(Status.INFO,"Moved to Exit Interaction page.");
		searchMember.ExitInteractionMemSearch( data.get("Comments"));
		log.debug("Moved to Member Search page");
		test.log(Status.INFO,"Moved to Member Search page.");
		searchMember.ExitInteraction();
		log.debug("Moved to Exit Interaction page.");
		test.log(Status.INFO,"Moved to Exit Interaction page.");
		searchMember.WrapUp_CallDisconnected();
		log.debug("Moved to Wrap Up Call Disconnected page.");
		test.log(Status.INFO,"Moved to Wrap Up Call Disconnected page.");
		searchMember.ExitInteraction();
		log.debug("Moved to Exit Interaction page.");
		test.log(Status.INFO,"Moved to Exit Interaction page.");
		searchMember.WrapUp_CallTransferred();
		log.debug("Moved to Wrap Up Call Transferred page.");
		test.log(Status.INFO,"Moved to Wrap Up Call Transferred page.");
		searchMember.ExitInteraction();
		log.debug("Moved to Exit Interaction page.");
		test.log(Status.INFO,"Moved to Exit Interaction page.");
		searchMember.WrapUp_MemberNotFound();
		log.debug("Moved to Wrap Up Member Not Found page");
		test.log(Status.INFO,"Moved to Wrap Up Member Not Found page");
		searchMember.ExitInteraction();
		log.debug("Moved to Exit Interaction page.");
		test.log(Status.INFO,"Moved to Exit Interaction page.");
		searchMember.movetoProsMem();
		log.debug("Moved to Prospective member page.");
		test.log(Status.INFO,"Moved to Prospective member page.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  {
		
		test.log(Status.INFO, "HMHS_TC0014_ExitInteraction_MemSearch Completed");
		log.debug("HMHS_TC0014_ExitInteraction_MemSearch Completed");
		quit();
		
	}
}
