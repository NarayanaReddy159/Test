package com.nasco.offlineReports.TestScripts;

import java.util.Hashtable;
import java.util.List;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.Member360Page;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.OtherActions;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.nasco.offlineReports.Run.RunTestNG_OfflineReports;

public class Offline_Reports_Extract016_ManageChecks extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "OfflineReportsCreate")
	public void Offline_Reports_ManageChecks (Hashtable<String, String> data) throws Exception {
		String methodName="Offline_Reports_ManageChecks";
		
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_OfflineReports.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_OfflineReports.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_OfflineReports.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_OfflineReports.Config.getProperty("username2"),
				RunTestNG_OfflineReports.Config.getProperty("password2"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_OfflineReports.Config.getProperty("username2") + " and Password entered as "
				+ RunTestNG_OfflineReports.Config.getProperty("password2"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_OfflineReports.Config.getProperty("username2")
				);
		
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		System.out.println("Interaction id: " + interaction);
		log.debug("Interaction id: " + interaction);
		test.log(Status.INFO, "Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed.");
		test.log(Status.INFO, "Member Search Completed.");
		String RelationShip=searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		System.out.println("RelationShip: "+RelationShip);
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		test.log(Status.INFO, data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO, "Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
		log.debug("Verify member");
		InteractionManager.openTask();
		
		Member360Page mem360=homepage.Member360Page();
		List<String> memberInfo=mem360.memberHeaderInformation();
		String memberName=memberInfo.get(0);
		String UMI=memberInfo.get(1);
		String DOB=memberInfo.get(2);
		System.out.println("Member Name: "+memberName);
		System.out.println("UMI: "+UMI);
		System.out.println("DOB: "+DOB);
		List<String> member360Details=mem360.mem360Details();
		String contractID= member360Details.get(0);
		String groupNumber=member360Details.get(1);
		String controlPlan=member360Details.get(2);
		String groupName=member360Details.get(3);
		System.out.println("contractID: "+contractID);
		System.out.println("Group Number: "+groupNumber);
		System.out.println("Control Plan: "+controlPlan);
		System.out.println("Group Name: "+groupName);
		InteractionManager.addTask(data.get("Intent").toString(),1);
		log.debug("Add Intent "+data.get("Intent"));
		String intentName=data.get("Intent");
		System.out.println("Intent Name: "+intentName);
		ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		System.out.println("intentID: "+intentID);
		String typeofEnquiry=data.get("TypeOfInq");
		String reason=data.get("Reason");
		String resolution=data.get("Resolution");
		String comments=data.get("Comments");
		System.out.println("Type of Enquiry: "+typeofEnquiry);
		System.out.println("Reason: "+reason);
		System.out.println("Resolution: "+resolution);
		System.out.println("Comments: "+comments);
		TOT.CreatenewIntent(data);
		waitSleep(3500);
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString(),2);
		String intentID1 = TOT.getIntentID();
		System.out.println("intentID1:"+intentID1);
		OtherActions otherActions=homepage.openOtherActions();
		otherActions.cancelWork(data); 
		System.out.println("Cancel Comments: "+data.get("CancelComments"));
		waitSleep(3500);
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString(),3);
		String intentID2 = TOT.getIntentID();
		System.out.println("intentID2:"+intentID2);
		TOT.CreateIntent(data);
		otherActions.saveToWorklist(data);
		System.out.println("Pend Comments: "+data.get("Comments"));
		System.out.println("Reason to pend:"+data.get("ReasonToPend"));
		waitSleep(3500);
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString(),4);
		String intentID3 = TOT.getIntentID();
		otherActions.routeToTeamMember(data);
		System.out.println("intentID3:"+intentID3);
		InteractionManager.openTask();
		InteractionManager.wrapUp("Wrapping interaction");
		WorklistPage worklist=homepage.openrecentWorklist();
		RecentWorkPage recentWorkPage=homepage.openrecentWork();
		worklist.movetoWorklistPage();
		worklist.sortandSelectIntent(intentID2);
		worklist.infoReceievedDate();
		recentWorkPage.movetoRecentWorkPage();
		recentWorkPage.sortandSelectIntent(intentID);
		List<String> resolvedIntentDetails=recentWorkPage.resolvedIntentDetails();
		String Status=resolvedIntentDetails.get(0);
		String CreateOperator=resolvedIntentDetails.get(1);
		String CreateDate=resolvedIntentDetails.get(2);
		String ResolveOperator=resolvedIntentDetails.get(3);
		String ResolveDate=resolvedIntentDetails.get(4);
		System.out.println("Status: "+Status);
		System.out.println("CreateOperator: "+CreateOperator);
		System.out.println("CreateDate: "+CreateDate);
		System.out.println("ResolveOperator: "+ResolveOperator);
		System.out.println("ResolveDate: "+ResolveDate);
		recentWorkPage.closeIntent();
		recentWorkPage.movetoRecentWorkPage();
		recentWorkPage.sortandSelectIntent(intentID2);
		List<String> savetoWorklistDetails=recentWorkPage.savetoWorklistComments();
		String pendCreateDate=savetoWorklistDetails.get(0);
		String pendCommnets=savetoWorklistDetails.get(1);
		String PendReason=savetoWorklistDetails.get(2);
		String CompletionDate=savetoWorklistDetails.get(3);
		String InfoRecievedDate=savetoWorklistDetails.get(4);
		System.out.println("pendCreateDate: "+pendCreateDate);
		System.out.println("pendCommnets: "+pendCommnets);
		System.out.println("PendReason: "+PendReason);
		System.out.println("CompletionDate: "+CompletionDate);
		System.out.println("InfoRecievedDate: "+InfoRecievedDate);
		recentWorkPage.closeIntent();
		recentWorkPage.movetoRecentWorkPage();
		recentWorkPage.sortandSelectIntent(intentID3);
		List<String> routeToTeamDetails=recentWorkPage.routeToTeamDetails();
		String urgency=routeToTeamDetails.get(0);
		String goalTime=routeToTeamDetails.get(1);
		String deadline=routeToTeamDetails.get(2);
		String assignedOp=routeToTeamDetails.get(3);
		System.out.println("urgency: "+urgency);
		System.out.println("goalTime: "+goalTime);
		System.out.println("deadline: "+deadline);
		System.out.println("assignedOp: "+assignedOp);
	}

	@AfterMethod
	public void tearDown() throws Exception  {

		test.log(Status.INFO, "HMHS_AUTC001_ManagePCPPOR_AddTask completed.");
		log.debug("HMHS_AUTC001_ManagePCPPOR_AddTask completed.");
		//quit();

	}
}
