package com.nasco.offlineReports.Run;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.nasco.HMHS.utilities.ExcelReader;
import com.nasco.HMHS.utilities.ReadXml;

public class Run_OfflineReports_Comparision {

	public static void main(String[] args) throws Exception {
		System.out.println("*************************");
		System.out.println("Execution Started.......");
		System.out.println("*************************");
		final Properties Config = new Properties();
		FileInputStream fis = null;
		try {
			String path = System.getProperty("user.dir")
					+ "\\src\\test\\resources\\properties\\OfflineReports_Config.properties";
			fis = new FileInputStream(path);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			Config.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		String filepath = System.getProperty("user.dir")
				+Config.getProperty("Offline_Execution_Report");
		FileInputStream excelFile = new FileInputStream(new File(filepath));
		XSSFWorkbook excelWorkbook = new XSSFWorkbook(excelFile);
		XSSFSheet sheet =excelWorkbook.getSheet("TestCases");
		ExcelReader excel = new ExcelReader(filepath);
		int rowsCount=sheet.getLastRowNum();
		
		for(int i=1;i<=rowsCount;i++)
		{
			String tagName=excel.getCellData("TestCases", "Tag Name", i+1);
			String extract=excel.getCellData("TestCases", "Extract", i+1);
			String expectedValue=excel.getCellData("TestCases", "Expected Value", i+1);
			if(expectedValue.contains("/"))
			{
				SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
				Date date = formatter.parse(expectedValue);
				SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
				expectedValue=formatter1.format(date);
			}
			
			String intentID=excel.getCellData("TestCases", "Intent ID", i+1);
			int rowNo=excel.getCellRowNum("ExtractNames", "Extract", extract);
			String fileName=excel.getCellData("ExtractNames","FileName",rowNo);
			String parentTag="";
			if(extract.equals("Interaction")){
				parentTag="HHP-CS-CSD-WORK-Interaction";
			} else if(extract.equals("Interaction History")){
				parentTag="History-HHP-CS-CSD-WORK-Interaction";
			} else if(extract.equals("Intent History")){
				parentTag="History-HHP-CS-CSD-WORK";
			} else if(extract.equals("Work Basket")){
				parentTag="Assign-WorkBasket";
			} else if(extract.equals("Work List")){
				parentTag="Assign-Worklist";
			} else if(extract.equals("Order ID Card")){
				parentTag="HHP-CS-CSD-WORK-OrderIDCard";
			} else if(extract.equals("Create Follow Up")){
				parentTag="HHP-CS-CSD-WORK-ScheduleActivity";
			} else if(extract.equals("General")){
				parentTag="HHP-CS-CSD-WORK-General";
			} else if(extract.equals("Respond To Customer")){
				parentTag="HHP-CS-CSD-WORK-Correspondence";
			} else if(extract.equals("Schedule Appointment")){
				parentTag="HHP-CS-CSD-WORK-ScheduleApp";
			} else if(extract.equals("Web Support")){
				parentTag="HHP-CS-CSD-WORK-WebSupport";
			} else if(extract.equals("View Authorizations")){
				parentTag="HHP-CS-CSD-WORK-ViewAuthorizations-Member";
			} else if(extract.equals("View Benefits")){
				parentTag="HHP-CS-CSD-WORK-MemberBenefits";
			} else if(extract.equals("View Otheroverage")){
				parentTag="HHP-CS-CSD-WORK-MemberCoverage";
			} else if(extract.equals("Manage PCP")){
				parentTag="HHP-CS-CSD-WORK-PCPUpdate";
			} else if(extract.equals("Manage Checks")){
				parentTag="HHP-CS-CSD-WORK-ManageChecks-Member";
			} else if(extract.equals("View Totals")){
				parentTag="HHP-CS-CSD-WORK-MemberTotals";
			} else if(extract.equals("Member Claims")){
				parentTag="HHP-CS-CSD-WORK-DisputeClaim-Member";
			}
			
					//excel.getCellData("ExtractNames","ParentTag",rowNo);
			String nodeValue="";
			if(!extract.equals("Interaction") ||!extract.equals("Interaction History") 
					||!extract.equals("Intent History") ||!extract.equals("Work Basket")
					||!extract.equals("Work List") )
			{
				nodeValue="HHP_CS_CSD_WORK_"+intentID.replace("-", "_");
			} else if(extract.equals("Interaction")){
				nodeValue="HHP_CS_CSD_WORK_INTERACTION_"+intentID.replace("-", "_");
			} else if(extract.equals("Work Basket")){
				nodeValue="ASSIGN_WORKBASKET_HHP_CS_CSD_WORK_"+intentID.replace("-", "_");
			} else if(extract.equals("Interaction History")){
				nodeValue="HISTORY_HHP_CS_CSD_WORK_INTERACTION_HHP_CS_CSD_WORK_INTERACTION_"+intentID.replace("-", "_");
			} else if(extract.equals("Intent History")){
				nodeValue="HISTORY_HHP_CS_CSD_WORK_HHP_CS_CSD_WORK_"+intentID.replace("-", "_");
			} else if(extract.equals("Work List")){
				nodeValue="ASSIGN_WORKLIST_HHP_CS_CSD_WORK_INTERACTION_"+intentID.replace("-", "_");
			}
			
			String xmlLocation = System.getProperty("user.dir")
					+ Config.getProperty("XmlLocation")	+fileName;
			String actualValue="";
			
			if(!expectedValue.equals(""))
			{
				actualValue = ReadXml.getxmlTagData(xmlLocation,parentTag,nodeValue,tagName);
				excel.setCellData("TestCases", "Actual Value", i+1, actualValue);
			}
			
			if(!expectedValue.equals(""))
			{
				
				if (actualValue.contains(expectedValue)) {
					excel.setCellData("TestCases", "Status", i+1, "Pass");
				}else {
					excel.setCellData("TestCases", "Status", i+1, "Fail");
				}
			}
		}
		excelWorkbook.close();
		
		// refresh all the formulas in the excel
		excelFile = new FileInputStream(new File(filepath));
		excelWorkbook = new XSSFWorkbook(excelFile);
		excelWorkbook.getSheet("Summary");
		XSSFFormulaEvaluator.evaluateAllFormulaCells(excelWorkbook);
		FileOutputStream outExcelFile = new FileOutputStream(new File(filepath));
		excelWorkbook.write(outExcelFile);
		outExcelFile.close();
		
		// Read output excel summary tab and create email body
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDateTime now = LocalDateTime.now();
		String date = dtf.format(now);
		StringBuilder sb = new StringBuilder();
		excelFile = new FileInputStream(new File(filepath));
		excelWorkbook = new XSSFWorkbook(excelFile);
		XSSFSheet sheetName = excelWorkbook.getSheet("Summary");
		sb.append("<html>");
		sb.append("<h4>" + "Hi All," + "</h4>");
		sb.append("<h4>" + "Please find offline reports execution summary on " + date + "</h4>");
		sb.append("<head><style>table {margin-bottom:10px;border-collapse:collapse;empty-cells:show}"
				+ "th,td {border:1px solid #009;padding:.25em .5em}th {vertical-align:bottom}td {vertical-align:top}"
				+ "table a {font-weight:bold}.stripe td {background-color: #E6EBF9}.num {text-align:right}.passedodd td {background-color: #3F3}.passedeven "
				+ "td {background-color: #0A0}.skippedodd td {background-color: #DDD}.skippedeven td {background-color: #CCC}.failedodd "
				+ "td,.attn {background-color: #F33}.failedeven td,.stripe .attn "
				+ "{background-color: #D00}.stacktrace {white-space:pre;font-family:monospace}.totop {font-size:85%;text-align:center;border-bottom:2px solid #000}.invisible {display:none}</style> "
				+"</head><body>");
		sb.append("<h3><b><u>" + "Execution Summary:" + "</b></u></h3>");
		sb.append("<table>"
				+ "<tr bgcolor='#8CDE96'><th>Total TC's</th><th>Executed</th><th>Pass</th><th>Fail</th><th>NA</th><th>Pass %</th><th>Fail %</th>");
		int totalTc = (int) sheetName.getRow(3).getCell(1).getNumericCellValue();
		int passCount = (int) sheetName.getRow(3).getCell(3).getNumericCellValue();
		int failCount = (int) sheetName.getRow(3).getCell(4).getNumericCellValue();
		int naCount = (int) sheetName.getRow(3).getCell(5).getNumericCellValue();
		int excuted = passCount + failCount;
		int passPercent = Math.round(passCount * 100 / excuted);
		int failPercent = Math.round(failCount * 100 / excuted);
		sb.append("</tr><tr><td align='center'>" + totalTc + "</td><td align='center'>" + excuted + "</td>" + "<td align='center'>" + passCount + "</td><td align='center'>"
				+ failCount + "</td>" + "<td align='center'>" + naCount + "</td>"+ "<td align='center'>" + passPercent + "</td><td align='center'>" + failPercent + "</td></tr>");
		sb.append("</table>");
		sb.append("<br/>");
		sb.append("<h3><b><u>" + "Extract wise Summary:" + "</b></u></h3>");
		sb.append("<table>"
				+ "<tr bgcolor='#8CDE96'><th>Extract</th><th>Total Tc's</th><th>Executed</th><th>Pass</th><th>Fail</th><th>NA</th></tr>");

		for (int i = 7; i < 26; i++) {
			sb.append("<tr>");
			for (int j = 1; j <= 6; j++) {
				if (j == 1) {
					sb.append("<td>" + sheetName.getRow(i).getCell(j).getStringCellValue() + "</td>");
				} else {
					sb.append("<td align='center'>" + (int) sheetName.getRow(i).getCell(j).getNumericCellValue() + "</td>");
				}
			}
			sb.append("</tr>");
		}
		sb.append("</table>");
		sb.append("<br/>");
		sb.append("<br/>");
		sb.append("<h5>" + "__" + "</h5>");
		sb.append("<h5>" + "Thanks," + "</h5>");
		sb.append("<h5>" + "NQEAST Team" + "</h5>");
		excelWorkbook.close();
		sb.append("</body></html>");

		// Send Mail with attachemt
		
		
		Config.put("mail.smtp.host", Config.getProperty("SMTP"));
		Config.put("mail.smtp.user", "test_automation@nasco.com");
		Config.put("mail.smtp.starttls.enable", "true");
		Config.put("mail.smtp.socketFactory.port", "25");
		Config.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		Config.put("mail.smtp.socketFactory.fallback", "true");
		Config.put("mail.smtp.auth", "true");
		Config.put("mail.smtp.port", "25");

		Session session = Session.getDefaultInstance(Config, new javax.mail.Authenticator() {
			protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(Config.getProperty("Email_Username"),
						Config.getProperty("Email_Password"));
			}
		});

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("Test-Automation@nasco.com"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(Config.getProperty("Email_list")));
			message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(Config.getProperty("Email_CC_list")));
			message.setSubject(Config.getProperty("Email_Subject") + " on - " + date);
			BodyPart messageBodyPart1 = new MimeBodyPart();
			messageBodyPart1.setContent(sb.toString(), "text/html");
			MimeBodyPart messageBodyPart3 = new MimeBodyPart();
			DataSource source1 = new FileDataSource(filepath);
			messageBodyPart3.setDataHandler(new DataHandler(source1));
			messageBodyPart3.setFileName("HMHS_OfflineReports_Execution_Report.xlsx");
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart1);
			multipart.addBodyPart(messageBodyPart3);
			message.setContent(multipart);
			Transport.send(message);
			System.out.println("*************************");
			System.out.println("Execution Completed....");
			System.out.println("*************************");

		} catch (MessagingException e) {

			throw new RuntimeException(e);

		}

	}

}
