package com.nasco.HMHS.TestScripts.G1;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.VerifyMemberPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC022_Contract_MultipleMem_MultLOBS extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void HMHS_AUTC022_Contract_MultipleMem_MultLOBS(Hashtable<String,String> data) throws Exception {
		try{
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside HMHS_TC022_Contract_MultipleMem_MultLOBS Search");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC022_Contract_MultipleMem_MultLOBS - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("HMHS_TC022_Contract_MultipleMem_MultLOBS -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		test.log(Status.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction=searchMember.getLIInteractionID();
		log.debug("Interaction id: "+interaction);
		test.log(Status.INFO,"Interaction id: "+interaction);
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed.");
		test.log(Status.INFO,"Member Search Completed.");
		searchMember.readMemberDetails(data.get("ExpectedMemberDetails"));
		log.debug("Reading Member Details Completed.");
		test.log(Status.INFO,"Reading Member Details Completed.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname")+ "Selected from the search results and navigated to verify member page");
		test.log(Status.INFO,data.get("Fname")+ "Selected from the search results and navigated to verify member page.");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO,"Member Submit Completed.");
		VerifyMemberPage verifyMember=searchMember.OpenVerifyMember();
		verifyMember.wrapUpnotVerified();
		log.debug("Member Wrapped up.");
		test.log(Status.INFO,"Member Wrapped up.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
        }
	
	@AfterMethod
	public void tearDown() throws Exception  {
		
		test.log(Status.INFO, "HMHS_TC022_Contract_MultipleMem_MultLOBS Completed");
		log.debug("HMHS_TC022_Contract_MultipleMem_MultLOBS Completed");
		quit();
		
	}
}
