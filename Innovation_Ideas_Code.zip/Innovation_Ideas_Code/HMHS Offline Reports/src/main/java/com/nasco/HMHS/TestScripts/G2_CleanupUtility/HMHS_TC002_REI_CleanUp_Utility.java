package com.nasco.HMHS.TestScripts.G2_CleanupUtility;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.ManagerToolsPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC002_REI_CleanUp_Utility extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC002_REI_CleanUp_Utility (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		String methodName="HMHS_AUTC002_REI_CleanUp_Utility";
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser :  " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username6"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password6"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username6") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password6"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username6")
				);

		MemberSearchPage searchMember = homepage.clickOnHMHSResearchInteractionMember();
		String InteractionId = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + InteractionId);
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		test.log(Status.INFO, "Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page");
		test.log(Status.INFO, data.get("Fname") + "Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO, "Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.openInteractionPage();
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(Status.INFO,"Add Intent "+data.get("Intent"));
        ViewTotalPage TOT=homepage.VeiwTotalPage();
		
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
       
		homepage.movetomyWorkLogout();
		log.debug("Able to log out from intent screen successsfully");
		DriverManager.getDriver().close();
		DriverManager.getDriver();
		setUpFramework();
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		LoginPage login1 = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		login1.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username6"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password6"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username6") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password6"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username6")
				);


		//String InteractionId="RI-3285";
		ManagerToolsPage managertools=homepage.openManagerToolsPage();
		managertools.movetoManageTools();
		log.debug("Navigate to movetoManageTools screen");
		test.log(Status.INFO,"Navigate to movetoManageTools screen. ");
		managertools.cleanUpUtility();
		log.debug("Click on clean Up Utility");
		test.log(Status.INFO,"Click on clean Up Utility. ");
		managertools.SearchBy(data.get("Workitem"),InteractionId);
		log.debug("Search for interaction .");
		test.log(Status.INFO,"Search for interaction.");
		managertools.SearchresultsHeader(data);
		log.debug("Check the SearchresultsHeader.");
		test.log(Status.INFO,"Check the SearchresultsHeader.");
		managertools.Statusforopen(InteractionId,data.get("Expectedstatus"));
		log.debug("Check  the Statusforopen.");
		test.log(Status.INFO,"Check  the Statusforopen.");
		
		//String intentID="FPR-1758";
		managertools.cleanUpUtility();
		log.debug("Click on clean Up Utility");
		test.log(Status.INFO,"Click on clean Up Utility. ");
		managertools.SearchBy(data.get("Workitem"),intentID);
		log.debug("Search for intent .");
		test.log(Status.INFO,"Search for intent.");
		managertools.SearchresultsHeader(data);
		log.debug("Check the SearchresultsHeader.");
		test.log(Status.INFO,"Check the SearchresultsHeader.");
		managertools.Statusforopen(intentID,data.get("Expectedstatus"));
		log.debug("Check  the Statusforopen.");
		test.log(Status.INFO,"Check  the Statusforopen.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}	
	}
	@AfterMethod
	public void tearDown() throws Exception  
	{	test.log(Status.INFO, "HMHS_TC002_REI_CleanUp_Utility completed.");
		log.debug("HMHS_TC002_REI_CleanUp_Utility completed.");
		quit();
	}
}
