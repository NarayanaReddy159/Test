package com.nasco.offlineReports.Run;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.testng.ITestNGListener;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.nasco.HMHS.utilities.ExcelReader;
import com.nasco.offlineReports.ExtentListeners.ExtentListeners;

public class RunTestNG_OfflineReports {
	public static Properties Config = new Properties();
	private static FileInputStream fis;
	public static int runCount=0;
	
	// Main method
	public static void main(String[] args) {
		initConfig();
		dynamicTestNG();
	}

	public static void dynamicTestNG() {
		// Create object of TestNG Class
		TestNG runner = new TestNG();
		// Create an instance of XML Suite and assign a name for it.
		XmlSuite mySuite = new XmlSuite();
		mySuite.setName("HMHSOfflineReportsSuite");
		mySuite.setParallel(XmlSuite.ParallelMode.CLASSES);
		mySuite.setThreadCount(Integer.parseInt(Config.getProperty("PARALLEL_THREAD_COUNT")));
		// Create an instance of XmlTest and assign a name for it.
		XmlTest myTest = new XmlTest(mySuite);
		List<XmlClass> myClasses = new ArrayList<XmlClass>();
		ExcelReader excel = new ExcelReader(System.getProperty("user.dir") + Config.getProperty("SUITE_XL_PATH"));
		int rows = excel.getRowCount(Config.getProperty("SUITE_SHEET"));
		String data, runmode, clsName = "", testRunMode;
		for (int rowNum = 2; rowNum <= rows; rowNum++) {
			data = excel.getCellData(Config.getProperty("SUITE_SHEET"), Config.getProperty("SUITENAME_COL"), rowNum);
			runmode = excel.getCellData(Config.getProperty("SUITE_SHEET"), Config.getProperty("RUNMODE_COL"), rowNum);
			ExcelReader excel1 = new ExcelReader(getTestDataSheetName(data));
			int rows1 = excel1.getRowCount(Config.getProperty("TESTCASE_SHEET"));
			if (runmode.equals(Config.getProperty("RUNMODE_YES"))) {
				myTest.setName(data);
				for (int rowNo = 2; rowNo <= rows1; rowNo++) {
					testRunMode = excel1.getCellData(Config.getProperty("TESTCASE_SHEET"),
							Config.getProperty("RUNMODE_COL"), rowNo);
					if (testRunMode.equalsIgnoreCase(Config.getProperty("RUNMODE_YES"))) {
						clsName = excel1.getCellData(Config.getProperty("TESTCASE_SHEET"),
								Config.getProperty("TESTCASE_ClassName"), rowNo);
						myClasses.add(new XmlClass(clsName));
					} 

				}
			} 
		}

		// Assign that to the XmlTest Object created earlier.
		myTest.setXmlClasses(myClasses);

		// Create a list of XmlTests and add the Xmltest you created earlier to
		// it.
		List<XmlTest> myTests = new ArrayList<XmlTest>();
		myTests.add(myTest);

		// add the list of tests to your Suite.
		mySuite.setTests(myTests);

		// Add the suite to the list of suites.
		List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
		mySuites.add(mySuite);
		////System.out.println("mySuite::" + mySuite.toXml());
		// Set the list of Suites to the testNG object you created earlier.
		runner.setXmlSuites(mySuites);
		runner.setUseDefaultListeners(false);
		List<Class<? extends ITestNGListener>> lst = new ArrayList<Class<? extends ITestNGListener>>();
		lst.add(ExtentListeners.class);
		runner.setListenerClasses(lst);
		// invoke run() - this will run your class.
		runner.run();

	}

	public static String getTestDataSheetName(String excelName) {
		String loc = "";

		if (excelName.equalsIgnoreCase("Offline_Reports_Create_TestData")) {
			loc = System.getProperty("user.dir") + Config.getProperty("Offline_Reports_Create_XL_PATH");
		}
		if (excelName.equalsIgnoreCase("HMHS_Ncompass_TestData_G2")) {
			loc = System.getProperty("user.dir") + Config.getProperty("TestData_G2_XL_PATH");
		}
		return loc;
	}

	public static void initConfig() {
		try {
			String path = System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\OfflineReports_Config.properties";
			fis = new FileInputStream(path);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			Config.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		;
	}

	
}
