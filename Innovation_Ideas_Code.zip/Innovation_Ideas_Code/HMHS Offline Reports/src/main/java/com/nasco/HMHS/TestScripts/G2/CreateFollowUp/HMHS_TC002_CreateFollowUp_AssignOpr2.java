package com.nasco.HMHS.TestScripts.G2.CreateFollowUp;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.CreateFollowUpPage;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.OtherActions;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC002_CreateFollowUp_AssignOpr2 extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC002_CreateFollowUp_AssignOpr2 (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC002_CreateFollowUp_AssignOpr2");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC002_CreateFollowUp_AssignOpr2 - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC002_CreateFollowUp_AssignOpr2 -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username3") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed");
		
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Create Follow up");
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));

        String intentID = searchMember.getIntentIDCF();
		log.debug("Intent id: " + intentID);
		OtherActions otheraction= homepage.openOtherActions();
        CreateFollowUpPage FollowUp = homepage.CreateFollowUpIntent();
        FollowUp.CreateFollowUpIntentAssignOpr2( intentID,data);
		log.debug("Navigate to Create Follow Up prior intent screen");
		otheraction.saveToWorklist212(data);
		log.debug("Navigate to save To Worklist screen");
		
		InteractionManagerPage wrap = searchMember.wrapIntent();
	    wrap.wrapUp(data.get("Comments"));
		log.debug("Wrapping up the intent");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetomyWorkLogout();
		DriverManager.getDriver().close();
		DriverManager.getDriver();
		setUpFramework();
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		LoginPage login2 = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage1 = login2.doLoginAsValidUser(RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password2")); 
		log.debug("Login again by using 2nd operator.");
		test.log(Status.INFO,"Login again by using 2nd operator.");
		
		WorklistPage worklist = homepage1.openrecentWorklist();
		worklist.movetoWorklistPage();
		log.debug("Navigated to the Worklist page ");
		worklist.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from Worklist tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab ");
		worklist.FollowUpAttemptSuccess( intentID, data);
		log.debug("Able to open the intent in Worklist and submit it with success");
		
		RecentWorkPage recentWork1 = homepage.openrecentWork();
		recentWork1.movetomyWorkLogout();
		DriverManager.getDriver().close();
		DriverManager.getDriver();
		setUpFramework();
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		LoginPage login3 = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		login3.doLoginAsValidUser( getDefaultUserName(),getDefaultPassword()); 
		
		RecentWorkPage recentWork2 = homepage.openrecentWork();
		recentWork2.movetoRecentWorkPage();
		log.debug("Navigated to the Home-Recentwork Section");
		recentWork2.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from recent work tab");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab");
		recentWork2.IntentStatusFollowUp( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Intent Status checked.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}

	@AfterMethod
	public void tearDown() throws Exception  {

		test.log(Status.INFO, "HMHS_TC002_CreateFollowUp_AssignOpr2 completed.");
		log.debug("HMHS_TC002_CreateFollowUp_AssignOpr2 completed.");
		quit();

	}
}
