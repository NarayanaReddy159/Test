package com.nasco.HMHS.Base;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Pages.CreateFollowUpPage;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.ManageClaimsPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.OtherActions;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Pages.WebsiteSupportPage;
import com.nasco.HMHS.Pages.WorkbasketPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DriverFactory;
import com.nasco.HMHS.utilities.DriverManager;

import io.github.bonigarcia.wdm.WebDriverManager;
public class BaseTest {
	
	private WebDriver driver;
	public static Logger log = LogManager.getLogger(BaseTest.class.getName());
	private String defaultUserName;
	private String defaultPassword;	
    public static JavascriptExecutor js;
    protected ExtentTest test;
	public String getDefaultUserName() {
		return defaultUserName;
	}

	public void setDefaultUserName(String defaultUserName) {
		this.defaultUserName = defaultUserName;
	}


	public String getDefaultPassword() {
		return defaultPassword;
	}

	public void setDefaultPassword(String defaultPassword) {
		this.defaultPassword = defaultPassword;
	}

	@BeforeSuite
	public void beforeSuite(){
		PropertyConfigurator.configure("log4j.properties");
	}
	
	public void setUpFramework() {
		DriverFactory.setChromeDriverExePath(System.getProperty("user.dir") + RunTestNG_NCompass_HMHS.Config.getProperty("ChromeDriver"));
		DriverFactory.setIeDriverExePath(System.getProperty("user.dir") + RunTestNG_NCompass_HMHS.Config.getProperty("IEDriver"));
	}
	
	
	public void extentLogWarning(String message) {
		
		test.log(Status.WARNING, message);
	}

	public void configureLog4jLogging() {
		System.setProperty("log4j.configurationFile", System.getProperty("user.dir")+RunTestNG_NCompass_HMHS.Config.getProperty("log4jPropertiesFilepath"));
	}

	//@SuppressWarnings("deprecation")
	public void openBrowser(String browser) {
		

		if (browser.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			/*System.setProperty("webdriver.chrome.driver",
					DriverFactory.getChromeDriverExePath());*/
			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("profile.default_content_setting_values.notifications", 2);
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("prefs", prefs);
			options.addArguments("--disable-extensions");
			options.addArguments("--disable-infobars");
			//options.getExperimentalOption("w3c");
			log.info("Launching Chrome");	
			driver = new ChromeDriver(options);
			((JavascriptExecutor)driver).executeScript("document.body.style.zoom='80%';");
		} else if (browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			/*System.setProperty("webdriver.gecko.driver",
					DriverFactory.getGeckoDriverExePath());*/
			driver = new FirefoxDriver();
			log.info("Launching firefox");
		} else if (browser.equalsIgnoreCase("ie")){
			WebDriverManager.iedriver().setup();
			//System. setProperty("webdriver.ie.driver", DriverFactory.getIeDriverExePath());
			InternetExplorerOptions options = new InternetExplorerOptions();
			options.ignoreZoomSettings();
			options.setCapability("nativeEvents",false);
			options.introduceFlakinessByIgnoringSecurityDomains();
			options.setCapability("disable-popup-blocking", true);
			driver = new InternetExplorerDriver(options);
			((JavascriptExecutor)driver).executeScript("document.body.style.zoom='80%';");
		}else if (browser.equalsIgnoreCase("edge")){
			WebDriverManager.edgedriver().setup();
			//System. setProperty("webdriver.ie.driver", DriverFactory.getIeDriverExePath());
			EdgeOptions options = new EdgeOptions();
			options.setCapability("inprivate", true);
			driver = new EdgeDriver(options);
			
		}else if (browser.equalsIgnoreCase("chromium")){
			WebDriverManager.chromiumdriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.setBinary(RunTestNG_NCompass_HMHS.Config.getProperty("Chromium_Path"));
			driver = new ChromeDriver(options);
			
		}

		DriverManager.setWebDriver(driver);
		log.info("Driver Initialized !!!");
		DriverManager.getDriver().manage().window().maximize();
		DriverManager.getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		setDefaultUserName(RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		setDefaultPassword(RunTestNG_NCompass_HMHS.Config.getProperty("password"));
	}

	public void quit() throws Exception {
		try {
			Thread.sleep(2000);
			DriverManager.getDriver().quit();
			log.info("Test Execution Completed !!!");
		} 
		catch (Exception e) {
            e.printStackTrace();
            String excepionMessage = Arrays.toString(e.getStackTrace());
            BaseTest.log.error("Not able to quit the browser " + excepionMessage);
            test.log(Status.FAIL, "Not able to quit the browser " + e);
            throw e;
		}

	}
	
	public void validateTask(String methodName,Hashtable<String, String> data)
	{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username2") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username2")
				);
		
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		test.log(Status.INFO, "Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed.");
		test.log(Status.INFO, "Member Search Completed.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		test.log(Status.INFO, data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO, "Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
		log.debug("Verify member");
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString());
		log.debug("Add Intent "+data.get("Intent"));
		ViewTotalPage TOT=homepage.VeiwTotalPage();
		
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_WebsiteSupport")))
		{
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ScheduleAppointment")))
		{
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_CreateGSI")))
		{
			if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ViewBenefits")))
			{
				TOT.movetoPriorIntentTab();
			}
			TOT.ViewTotalPriorIntent(data.get("expectedDefault"),data.get("expectedALLValues"));
			log.debug("Navigate to view Total prior intent screen");
			if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ViewBenefits")))
			{
				TOT.movetoViewBenefitsTab();
			}
		}
		}
		}
		
		if(!data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ViewAuthorizations")))
		{
			if(!data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageOtherCoverage")))
			{
				TOT.validateToolLinks(data);
				if(!data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ScheduleAppointment")))
				{
				if(!data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_WebsiteSupport")))
				{
				  if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_FindaProvider")))
				  {
					TOT.submitFPR(data);
				  }
				  
				}
				
		}
		}
		}
		if(!data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ScheduleAppointment"))
				&& !data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_WebsiteSupport"))
				&& !data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_FindaProvider"))
				&& !data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ViewBenefits")))
		{
			TOT.vaildationsDropdowns(data);
			log.debug("Type of inquiry, Reasons and Resolution dropdown values are validated");	
			TOT.Createnew(data);
		}
		
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ViewBenefits")))
		{
			TOT.validatateViewBenfits(data);
		}
		
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_WebsiteSupport")))
		{
			TOT.Websitesupportdetails(data);
			log.debug("Validate the Website support details tab");	
			TOT.Websitegroupfeature(data);
			log.debug("Validate the Website group feature tab");
			TOT.Wellnessprogram(data);
			log.debug("Validate the Wellness program tab");
			TOT.Telemedicine(data);
			log.debug("Validate the Telemedicine tab");
			TOT.Groupadminsupportdetails(data);
			log.debug("Validate the Group adminsupport details tab");
			TOT.Registeredadminusers(data);
			log.debug("Validate the Group Registered admin users table");
			TOT.vaildationswebsiteDropdowns(data);
			log.debug("Validate the website Dropdowns table");
			TOT.WebsiteCreatenew(data);
			
		}
		
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_CreateGSI")))
		{
			TOT.submitGSI(data);
		}
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ScheduleAppointment")))
		{
			TOT.Scheduleappointment_Newappointment(data);
			TOT.Scheduleappointment_Deleteappointment();
			TOT.Scheduleappointment_VaildateFields(data);
			TOT.Scheduleappointment_Createnew(data);
		}
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork ");
		recentWork.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from recent work tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab ");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Navigate to Interaction screen ");
		recentWork.contractInformation(data);
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_WebsiteSupport")))
		{  
			
			WebsiteSupportPage WEB=homepage.openWebsiteSupportPage();
			WEB.WebsitesupportdetailsRecentwork(data);
			log.debug("Validate the Website support details tab");	
			WEB.WebsitegroupfeatureRecentwork(data);
			log.debug("Validate the Website group feature tab");
			WEB.WellnessprogramRecentwork(data);
			log.debug("Validate the Wellness program tab");
			WEB.TelemedicineRecentwork(data);
			log.debug("Validate the Telemedicine tab");
			WEB.GroupadminsupportdetailsRecentwork(data);
			log.debug("Validate the Group adminsupport details tab");
			WEB.RegisteredadminusersRecentwork(data);
			log.debug("Validate the Group Registered admin users table");
			WEB.ServicerequestreviewRecentwork(data);
			log.debug("Validate the Service request review Recentwork table");
			
     }
		if(!data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ScheduleAppointment"))
				&&!data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_WebsiteSupport"))
				&&!data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_FindaProvider"))
				&&!data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ViewBenefits")))
		{ 
		
			recentWork.Servicerequestreview("PegaGadget1Ifr", data);	
		}
		
		recentWork.Commentssummary("PegaGadget1Ifr", data);	}

	public void validateTaskResearch(String methodName,Hashtable<String, String> data) throws Exception
	{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username2") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username2")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSResearchInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		test.log(Status.INFO,"Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed.");
		test.log(Status.INFO,"Member Search Completed.");
	//	searchMember.readMemberDetails(data.get("ExpectedMemberDetails"));
		log.debug("Reading Member Details Completed.");
	//	searchMember.HMHSMouseHovAddr( data.get("ExpectedAdrDetails"), "PegaGadget1Ifr");
		log.debug("Reading member address tooltips details.");
		test.log(Status.INFO,"Reading member address tooltips details.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page.");
		test.log(Status.INFO,data.get("Fname") + "Selected from the search results and navigated to verify member page.");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO,"Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.openInteractionPage();
		InteractionManager.openTask();
		log.debug("Member360 page should open.");
		test.log(Status.INFO,"Member360 page should open.");
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(Status.INFO, "Add Intent "+data.get("Intent"));
		ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		test.log(Status.INFO,"Intent id: " + intentID);
		InteractionManager.EndResearchOpen();
		log.debug("Navigate to End Research screen.");
		test.log(Status.INFO,"Navigate to End Research screen.");
		
		WorklistPage worklist = homepage.openrecentWorklist();
		worklist.movetoWorklistPage();
		log.debug("Navigated to the Worklist page.");
		test.log(Status.INFO,"Navigated to the Worklist page.");
		worklist.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from Worklist tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected intent " + intentID + " from recent work tab.");
		worklist.IntentStatusWorklist(data.get("IntentStatusWork"), "PegaGadget1Ifr");
		log.debug("Check the worklist Intent Status checked.");
		test.log(Status.INFO,"Check the worklist Intent Status checked.");
		worklist.WorklistComments(intentID, data);
		log.debug("Enter the worklist comments and Submit.");
		test.log(Status.INFO,"Enter the worklist comments and Submit.");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork.");
		test.log(Status.INFO,"Navigated to the Recentwork.");
		recentWork.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected interaction " + intentID + " from recent work tab.");
		log.debug("Sorted and selected interaction " + intentID + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected interaction " + intentID + " from recent work tab.");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the intent status.");
		test.log(Status.INFO,"Check the intent status.");
		recentWork.closeRecentwork();
		log.debug("Close the recent tab.");
		test.log(Status.INFO,"Close the recent tab.");
		
}
	
	public void cancelWork(String methodName,Hashtable<String, String> data)
	{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser :  " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		
		  MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		  String interaction = searchMember.getLIInteractionID();
		  log.debug("Interaction id: " + interaction);
		  searchMember.HMHSsearchMember(data.get("MemberID"));
		  log.debug("Member Search Completed");
		  searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		  log.debug(data.get("Fname") +
		  " Selected from the search results and navigated to verify member page");
		  log.debug("Member Submit Completed"); InteractionManagerPage
		  InteractionManager=searchMember.Verifymember(); log.debug("Verify member");
		  InteractionManager.openTask();
		  InteractionManager.addTask(data.get("Intent").toString());
		  log.debug("Add Intent "+data.get("Intent")); ViewTotalPage
		  TOT=homepage.VeiwTotalPage(); String intentID = TOT.getIntentID();
		  log.debug("Intent id: " + intentID); OtherActions
		  otherActions=homepage.openOtherActions();
		  otherActions.navigateBackIntentScreenCancelwork(data);
		  otherActions.cancelWork(data); InteractionManager.openTask();
		  InteractionManager.wrapUp(data.get("Comments"));
		  log.debug("Navigate to Wrap up screen");
		 
		
		//String intentID="BEN-2676";
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork ");
		recentWork.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from recent work tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab ");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Navigate to Interaction screen ");
		recentWork.contractInformation(data);
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_CreateGSI"))
				||data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageChecks"))
				||data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_FindaProvider"))
				||data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManagePCP"))
				||data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_CreateFollowUp"))
				||data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_RequestIDCard"))
				||data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageOtherCoverage"))
				||data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageClaims"))
				||data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageClaims")))
		{
			recentWork.Commentssummary("PegaGadget1Ifr", data);
		}else{
			recentWork.cancelCommentsSummary("PegaGadget1Ifr", data);	
		}
		
	}
	
	public void saveToWorklist(String methodName,Hashtable<String, String> data) throws Exception
	{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
		log.debug("Verify member");
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString());
		log.debug("Add Intent "+data.get("Intent"));
		ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		OtherActions otherActions=homepage.openOtherActions();
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_CreateFollowUp")))
		{
			OtherActions otheraction= homepage.openOtherActions();
			CreateFollowUpPage FollowUp = homepage.CreateFollowUpIntent();
			InteractionManager.openTask();
	        FollowUp.CreateFollowUpIntent(data);
	       log.debug("Navigate to Create Follow Up prior intent screen");
	       otheraction.saveToWorklist212(data);
			log.debug("Navigate to save To Worklist screen");
			
		}else{
			otherActions.navigateBackIntentScreen(data);
			otherActions.saveToWorklist(data);
		}
		
		InteractionManager.openTask();
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		
		//String intentID="IDC-576";
		RecentWorkPage recentWork = homepage.openrecentWork();
		WorklistPage worklist= homepage.openrecentWorklist();
		worklist.movetoWorklistPage();
		worklist.sortandSelectIntent( intentID);
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_CreateFollowUp")))
		{
			recentWork.contractInformation(data);
			recentWork.Commentssummary("PegaGadget1Ifr", data);
			otherActions.verifysaveToWorklist(data);
			worklist.FollowUpAttemptSuccess( intentID,data);
			log.debug("Successfully able to Save to worklist");
		
		}
		
		if(!data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_CreateFollowUp")))
		{
			recentWork.contractInformation(data);
			recentWork.Commentssummary("PegaGadget1Ifr", data);
			otherActions.cancelWork(data);	
		}
	}
	
	public void RouteToTeamMember(String methodName,Hashtable<String, String> data) throws Exception
	{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
		log.debug("Verify member");
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString());
		log.debug("Add Intent "+data.get("Intent"));
		ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_CreateGSI")))
		{
				
			TOT.Createnew(data);
			log.debug("Validate Type of inquiry, Reasons and Resolution");
		}
		OtherActions otherActions=homepage.openOtherActions();
		/*InteractionManager.openTask();*/
		otherActions.navigateBackIntentScreenRoutto(data);
		otherActions.routeToTeamMember(data);
		InteractionManager.openTask();
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetomyWorkLogout();
		log.debug("Able to log out from MyWork screen successsfully");
		DriverManager.getDriver().close();
		DriverManager.getDriver();
		setUpFramework();
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		LoginPage login1 = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage1 = login1.doLoginAsValidUser( 
					RunTestNG_NCompass_HMHS.Config.getProperty("username"),
					RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		//String intentID="TOT-369";
		RecentWorkPage recentWork1 = homepage1.openrecentWork();
		WorklistPage worklist1= homepage1.openrecentWorklist();
		worklist1.movetoWorklistPage();
		worklist1.sortandSelectIntent( intentID);
		recentWork1.contractInformation(data);
		recentWork1.Commentssummary("PegaGadget1Ifr", data);
	}
	public void validateskill (String methodName,Hashtable<String, String> data) throws Exception {
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username2") ,
				RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username2") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username2")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed");
		test.log(Status.INFO, "Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page");
		test.log(Status.INFO, data.get("Fname") + "Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO, "Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Member Verified successfully.");
        test.log(Status.INFO, "Member Verified successfully.");
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(Status.INFO,"Add Intent "+data.get("Intent"));
        ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
       
		TOT.Createnew(data);
		log.debug("Validate the Create new tab");
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_CreateGSI")))
		{
			TOT.submitGSI(data);
		}
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		
		WorkbasketPage Workbasket = homepage.openrecentWorkbasket();
		Workbasket.movetoWorkbasketPage();
		log.debug("Navigated to the Home-Workbasket Section");
		test.log(Status.INFO, "Navigated to the Home-Workbasket Section");
		Workbasket.Workbasketcheck(data);
		Workbasket.sortandSelectIntent(intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from Workbasket tab ");
		log.debug("Sorted and selected intent " + intentID + " from Workbasket tab ");
		test.log(Status.INFO, "Sorted and selected intent " + intentID + " from Workbasket tab ");
		Workbasket.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Navigate to Interaction screen ");
		Workbasket.vaildationsAssignedoperator("PegaGadget1Ifr",data);
		log.debug("Check the Assigned operator.");
		if(data.get("SkillApplied").equals("Yes"))
		{
			Workbasket.vaildationshistory("PegaGadget1Ifr",data);
			log.debug("Validate the Skill audit Recentwork table");
		}
		Workbasket.contractInformation(data);
		log.debug("Check the contract Information.");
		Workbasket.Servicerequestreview("PegaGadget1Ifr", data);
		log.debug("Validate the Service request review Workbasket table");
		test.log(Status.INFO, "Check the Service request review.");
		Workbasket.Commentssummary("PegaGadget1Ifr", data);
		Workbasket.Resolve(data);
	}

	public void routeToWorkbasket(Hashtable<String, String> data,String methodName) throws Exception
	{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username1"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password1"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username1") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password1"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username1")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
		log.debug("Verify member");
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString());
		log.debug("Add Intent "+data.get("Intent"));
		ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		OtherActions otherActions=homepage.openOtherActions();
		InteractionManager.openTask();
		otherActions.navigateBackIntentScreenRoutto(data);
		otherActions.routeToWorkbasket(data);
		InteractionManager.openTask();
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		//string intentID="TOT-1306";
		RecentWorkPage recentWork = homepage.openrecentWork();
		WorkbasketPage workbasket =homepage.openrecentWorkbasket();
		workbasket.movetoWorkbasketPage();
		workbasket.Workbasketcheck(data);
		workbasket.sortandSelectIntent(intentID);
		recentWork.contractInformation(data);
		recentWork.Commentssummary("PegaGadget1Ifr", data);
		otherActions.cancelWork(data);
	}

	public void createNewFollowup(String methodName,Hashtable<String, String> data) throws Exception
	{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username3"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username3") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username3")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
		log.debug("Verify member");
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString());
		log.debug("Add Intent "+data.get("Intent"));
		ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageClaims")))
		{ 
		TOT.RecurringMsg4(data);
		}
		
		InteractionManager.wrapUpOpen(data.get("Comments"));
		WorklistPage worklist=homepage.openrecentWorklist();
		worklist.movetoWorklistPage();
		worklist.sortandSelectIntent(intentID);
		worklist.interactionID(intentID, interaction);
		
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageClaims")))
		{ 
		TOT.RecurringMsg4(data);
		}
		
		worklist.createNewFollowup(data.get("Intent"));
		worklist.validateFollowuptask(interaction,intentID);
	}
	
	public void createNewWork(String methodName,Hashtable<String, String> data) throws Exception
	{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username3"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username3") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username3")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		test.log(Status.INFO,"Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed.");
		test.log(Status.INFO,"Member Search Completed.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		test.log(Status.INFO,data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO,"Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
		log.debug("Verify the member");
		test.log(Status.INFO,"Verify the member");
		InteractionManager.openTask();
		InteractionManager.addTask(data.get("Intent").toString());
		log.debug("Add Intent "+data.get("Intent"));
		test.log(Status.INFO,"Add Intent "+data.get("Intent"));
		ViewTotalPage TOT=homepage.VeiwTotalPage();
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
		test.log(Status.INFO,"Intent id: " + intentID);
		
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageClaims")))
		{ 
		TOT.RecurringMsg4(data);
		}
		
		InteractionManager.wrapUpOpen(data.get("Comments"));
		log.debug("Wrapping up the inent.");
		test.log(Status.INFO,"Wrapping up the inent.");
		WorklistPage worklist=homepage.openrecentWorklist();
		RecentWorkPage recentWorkPage=homepage.openrecentWork();
		worklist.movetoWorklistPage();
		worklist.sortandSelectIntent(intentID);
		worklist.interactionID(intentID, interaction);
		log.debug("Check the InteractionID.");
		test.log(Status.INFO,"Check the InteractionID.");
		recentWorkPage.contractInformation(data);
		log.debug("Validate the contract Information- Subscriber name,Group no,UMI, Group name.");
		test.log(Status.INFO,"Validate the contract Information- Subscriber name,Group no,UMI, Group name.");
		
		if(data.get("Intent").equals(RunTestNG_NCompass_HMHS.Config.getProperty("AddTask_ManageClaims")))
		{ 
		TOT.RecurringMsg4(data);
		}
		
		worklist.createNewWork(data.get("Intent"));
		log.debug("Select Create New Work.");
		test.log(Status.INFO,"Select Create New Work.");
		worklist.validateInteractionID(interaction);
		log.debug("Validate InteractionID.");
		test.log(Status.INFO,"Validate InteractionID.");
		String childIntent=worklist.getChildintentid();
		log.debug("Create New intent.");
		test.log(Status.INFO,"Create New intent.");
		//System.out.println(childIntent);
		worklist.contractInformation(data,"PegaGadget2Ifr");
		log.debug("Validate the contract Information of New intent- Subscriber name,Group no,UMI, Group name.");
		test.log(Status.INFO,"Validate the contract Information of New intent- Subscriber name,Group no,UMI, Group name.");
		worklist.getChildHistory();
		log.debug("Validate the new intent.");
		test.log(Status.INFO,"Validate the new intent.");
		worklist.closeChildIntent(childIntent);
		log.debug("Close the new intent.");
		test.log(Status.INFO,"Close the new intent.");
		worklist.getParentHistory();
		log.debug("Validate the old intent.");
		test.log(Status.INFO,"Validate the old intent.");
		OtherActions otherActions=homepage.openOtherActions();
		otherActions.cancelWork(data);
		log.debug("Perform cancel work for old intent.");
		test.log(Status.INFO,"Perform cancel work for old intent.");
		recentWorkPage.movetoRecentWorkPage();
		recentWorkPage.sortandSelectIntent(interaction);
		log.debug("Open the ineteraction.");
		test.log(Status.INFO,"Open the ineteraction.");
		String resolveDate=recentWorkPage.resolveDate();
		//System.out.println("resolveDate"+resolveDate);
		recentWorkPage.closeRecentwork();
		log.debug("Close the recent tab.");
		test.log(Status.INFO,"Close the recent tab.");
		worklist.movetoWorklistPage();
		worklist.sortandSelectIntent(childIntent);
		log.debug("Go to Worklist and open New Intent.");
		test.log(Status.INFO,"Go to Worklist and open New Intent.");
		recentWorkPage.switchToFrame("PegaGadget1Ifr");
		otherActions.cancelWork(data);
		log.debug("Perform cancel work for New intent.");
		test.log(Status.INFO,"Perform cancel work for New intent.");
		recentWorkPage.movetoRecentWorkPage();
		recentWorkPage.sortandSelectIntent(interaction);
		log.debug("Open the interaction from Recent work page.");
		test.log(Status.INFO,"Open the interaction from Recent work page.");
		resolveDate=recentWorkPage.resolveDate();
		log.debug("resolveDate"+resolveDate);
		test.log(Status.INFO,"resolveDate"+resolveDate);
		//System.out.println("resolveDate"+resolveDate);
		recentWorkPage.closeRecentwork();
		log.debug("Close the recent tab.");
		test.log(Status.INFO,"Close the recent tab.");
		recentWorkPage.movetoRecentWorkPage();
		recentWorkPage.sortandSelectIntent(childIntent);
		log.debug("Go to Recent work and open New Intent.");
		test.log(Status.INFO,"Go to Recent work and open New Intent.");
		String resolveDateIntent=recentWorkPage.resolveDateIntent();
		log.debug("resolveDateIntent:"+resolveDateIntent);
		test.log(Status.INFO,"resolveDateIntent:"+resolveDateIntent);
		//System.out.println("resolveDateIntent:"+resolveDateIntent);
		recentWorkPage.closeRecentwork();
		log.debug("Close the recent tab.");
		test.log(Status.INFO,"Close the recent tab.");
		recentWorkPage.assertEquals(resolveDate, resolveDateIntent, "Resolved date");
	}

public void adjustandresolveClaim(Hashtable<String, String> data,String methodName) throws Exception
{
	setUpFramework();
	test = DriverManager.getExtentReport();
	log.info("Inside "+methodName);
	openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
	log.debug(methodName+" - Launched Browser : "
			+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
	test.log(Status.INFO, "Launched Browser :  " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
	LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
	HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username3"),
			RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
	log.debug(methodName+" -Username entered as "
			+ RunTestNG_NCompass_HMHS.Config.getProperty("username3") + " and Password entered as "
			+ RunTestNG_NCompass_HMHS.Config.getProperty("password3"));
	test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username3")
			);
	MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
	String interaction = searchMember.getLIInteractionID();
	log.debug("Interaction id: " + interaction);
	searchMember.HMHSsearchMember(data);
	log.debug("Member Search Completed");
	searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
	log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
	log.debug("Member Submit Completed");
	InteractionManagerPage InteractionManager=searchMember.Verifymember();
	log.debug("Verify member");
	InteractionManager.openTask();
	InteractionManager.addTask(data.get("Intent").toString());
	log.debug("Add Intent "+data.get("Intent"));
	ManageClaimsPage manageClaim=InteractionManager.openManageClaims();
	ViewTotalPage TOT=homepage.VeiwTotalPage();
	String intentID = TOT.getIntentID();
	log.debug("Intent id: " + intentID);
	test.log(Status.INFO,"Intent id: " + intentID);
	manageClaim.searchClaims(data);
	log.debug("Navigate to Search for claim screen.");
	test.log(Status.INFO,"Navigate to Search for claim screen. ");
	manageClaim.AdjustClaim(data);
	log.debug("Cilck on the adjust checkbox.");
	test.log(Status.INFO,"Cilck on the adjust checkbox. ");
	manageClaim.adjust(data);
	log.debug("User selected the claim screen.");
	test.log(Status.INFO,"User selected the claim screen. ");
	manageClaim.SelectotheractionOptions(data.get("Options"));
	log.debug("User able to select the Adjust option.");
	test.log(Status.INFO,"User able to select the Adjust option.");
	manageClaim.Claimsselectedforadjustment(data);
	log.debug("Cilck on the Confirm Button.");
	test.log(Status.INFO,"Cilck on the Confirm Button. ");

	manageClaim.AdjustReason(data);
	log.debug("Cilck on the Confirm Button.");
	test.log(Status.INFO,"Cilck on the Confirm Button. ");
	
	InteractionManagerPage wrap = searchMember.wrapIntent();
    wrap.wrapUp(data.get("Comments"));
	log.debug("Wrapping up the intent");
	
	WorkbasketPage WB = homepage.openrecentWorkbasket();
	log.debug("Navigated to Workbasket page.");
	test.log(Status.INFO,"Navigated to Workbasket page.");
	WB.movetoWorkbasketPage();
	log.debug("Go to Workbasket page.");
	test.log(Status.INFO,"Go to Workbasket page.");
	WB.Workbasketcheck(data);
	log.debug("Select the Workbasket");
	test.log(Status.INFO,"Select the Workbasket.");
	WB.sortandSelectIntent( intentID);
	log.debug("Sorted and selected intent " + intentID + " from Workbasket tab.");
	test.log(Status.INFO,"Sorted and selected intent " + intentID + " from Workbasket tab.");
	WB.ResolveNClose(data);
	log.debug("Resolve and Close the Claim inten." + intentID);
	test.log(Status.INFO,"Resolve and Close the Claim inten." + intentID);
	
	RecentWorkPage recentWork = homepage.openrecentWork();
	recentWork.movetoRecentWorkPage();
	log.debug("Navigated to the Home-Recentwork Section");
	recentWork.sortandSelectIntent( intentID);
	//System.out.println("Sorted and selected intent " + intentID + " from recent work tab");
	log.debug("Sorted and selected intent " + intentID + " from recent work tab");
	recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
	log.debug("Check the Intent Status.");
}

public void waitSleep(int time) {
	try {
		Thread.sleep(time);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}
}
