package com.nasco.HMHS.Pages;

import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked","unused"})
public class ReportPage extends BasePage {
	String workbasketXpath="(//span[contains(text(),'%s')])[1]";
	String header="//label[contains(text(),'%s')]";
	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	@FindBy(xpath = "//div[1]/div/div/div/ul/li[2]/a/span[1]/span")
	public WebElement myWorkIcon;
	@FindBy(xpath = "//li[@title='My Reports']")
	public WebElement MyReport;
	
 @Override
  protected ExpectedCondition getPageLoadCondition() {
  switchToFrame("PegaGadget0Ifr");
  return ExpectedConditions.visibilityOf(myWorkIcon);
  }
 @FindBy(xpath = "//label[contains(text(),'Route intent to last assigned operator')]")
	public WebElement  Routeintenttolastassignedoperator;
 @FindBy(xpath = "//h2[contains(text(),'Open inventory')] ")
	public WebElement openInventory;
 @FindBy(xpath = "//a[contains(text(),'SLA Breakdown of Open Tasks')]")
	public WebElement Slabreakdown;
 @FindBy(xpath = "//a[contains(text(),'Research Invalid Work Objects')]")
	public WebElement Researchinvalid;
 @FindBy(xpath = "//h2[contains(text(),'Throughput')]")
	public WebElement ThroughPut;
 @FindBy(xpath = "//a[contains(text(),'Throughput Timeliness')]")
	public WebElement Timeliness;
	@FindBy(xpath = "//a[contains(text(),'Throughput Summary')]")
	public WebElement Summary;
	@FindBy(xpath = "//h1[contains(text(),'SLA Breakdown of Open Service Requests')]")
	public WebElement Slabreakdowntitle;
	@FindBy(xpath = "//div[contains(@class,'content   layout-content-stacked content-stacked  clearfix')]")
	public WebElement SlaNote;
	@FindBy(xpath = "//tbody/tr[2]/td[6]/nobr[1]/span[1]/i[1]/img[1]")
	public WebElement workbasket;
	@FindBy(id = "ModalButtonCancel")
	public WebElement Cancel;
	@FindBy(xpath = "//tbody/tr[@id='GrandTotal']/td[2]")
	public WebElement DrillDown;
	@FindBy(xpath = "//h1[contains(text(),'Research Invalid Work Objects')]")
	public WebElement Researchtitle;
	@FindBy(xpath = "//h1[contains(text(),'Throughput Timeliness')]")
	public WebElement ThroughputtimelinessTitle;
	@FindBy(xpath = "//h1[contains(text(),'Throughput Summary')]")
	public WebElement ThroughputSummaryTitle;
	@FindBy(xpath = "//a[contains(text(),'Export to PDF')]")
	public WebElement ExportToPDF;
	@FindBy(xpath = "//a[contains(text(),'Export to Excel')]")
	public WebElement ExportToExcel;
	@FindBy(xpath = "//span[contains(text(),'Generated on')]")
	public WebElement generatedon;
	
	
 public void MyReport(Hashtable<String, String> data) throws Exception
	{
		try{
			waitSleep(3000);
			switchToFrame("PegaGadget0Ifr");
			webElementClick(MyReport, "My Report");
			waitSleep(1500);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on MyReport method " + e);
			test.log(Status.FAIL, "Error on MyReport method " + e);
			throw e;
		}
	}
 public void OpenInventory(Hashtable<String, String> data) throws Exception
	{
		try{
			waitSleep(3000);
			switchToFrame("PegaGadget0Ifr");
			String OpenInventory=webElementReadText(openInventory);
			String SlaBreakdown=webElementReadText(Slabreakdown)+"::"+Slabreakdown.getAttribute("title").toString();
			assertEquals(SlaBreakdown, data.get("ExpectedSlaBreakdown"), "Sla Breakdown");
			String ResearchInvalid=webElementReadText(Researchinvalid)+"::"+Researchinvalid.getAttribute("title").toString();
			assertEquals(ResearchInvalid, data.get("ExpectedResearchInvalid"), "Sla Breakdown");
			//System.out.println(OpenInventory+"::"+SlaBreakdown+"::"+ResearchInvalid);
			waitSleep(1500);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on OpenInventory method " + e);
			test.log(Status.FAIL, "Error on OpenInventory method " + e);
			throw e;
		}
		}
		public void Throughput(Hashtable<String, String> data) throws Exception
		{
			try{
				waitSleep(3000);
				switchToFrame("PegaGadget0Ifr");
				String Throughput=webElementReadText(ThroughPut);
				String ThroughputTimeliness=webElementReadText(Timeliness)+"::"+Timeliness.getAttribute("title").toString();
				assertEquals(ThroughputTimeliness, data.get("ExpectedThroughputTimeliness"), "Throughput Timeliness");
				String ThroughputSummary=webElementReadText(Summary)+"::"+Summary.getAttribute("title").toString();
				assertEquals(ThroughputSummary, data.get("ExpectedThroughputSummary"), "Throughput Summary");
				//System.out.println(Throughput+"::"+ThroughputTimeliness+"::"+ThroughputSummary);
				waitSleep(1500);
			
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on Throughput method " + e);
				test.log(Status.FAIL, "Error on Throughput method " + e);
				throw e;
			}
	}
		public void ReportName(Hashtable<String, String> data) throws Exception
		{
			
			try{
				waitSleep(3000);
				switchToFrame("PegaGadget0Ifr");
				
				if(data.get("ReportName").equals("SLA Breakdown of Open Service Requests"))
				{
					webElementClick(Slabreakdown, "SLA Breakdown of OpenService Requests");
				}else if(data.get("ReportName").equals("Research Invalid Work Objects"))
				{
					webElementClick(Researchinvalid, "Research Invalid Work Objects");
				}else if(data.get("ReportName").equals("Throughput Timeliness"))
				{
					driver.findElement(By.xpath("//*[@id='EXPAND-INNERDIV']/div/div[2]")).click();
					webElementClick(Timeliness, "Throughput Timeliness");
				}else if(data.get("ReportName").equals("Throughput Summary"))
				{
					webElementClick(Summary, "Throughput Summary");
				}
				
				waitSleep(1500);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on ReportName method " + e);
				test.log(Status.FAIL, "Error on ReportName method " + e);
				throw e;
			}
		}
				
		
		public void VaildationSLABreakdownofOpenServiceRequests(Hashtable<String, String> data) throws Exception
		{
			
			try{
				waitSleep(3000);
				switchToFrame("PegaGadget0Ifr");
				waitSleep(1500);
				
				String parentWindow=driver.getWindowHandle();
				for (String windowHandle : driver.getWindowHandles())
				{
					if(!parentWindow.equals(windowHandle)){
						 driver.switchTo().window(windowHandle);
						 //System.out.println("Switched to"+windowHandle);
					}
					//System.out.println(windowHandle);
					
				}
				
				switchToDefault();
				Slanote(data);
				if(data.get("ReportName").equals("SLA Breakdown of Open Service Requests"))
				{
					String SlaBreakdownTitle=webElementReadText(Slabreakdowntitle);
	                assertEquals(SlaBreakdownTitle, data.get("ReportName"), "SlaBreakdownTitle");
	                Tableheader(data);
	                
				}else if(data.get("ReportName").equals("Research Invalid Work Objects"))
				{
					String ResearchTitle=webElementReadText(Researchtitle);
					assertEquals(ResearchTitle, data.get("ReportName"), "ResearchTitle");
					Tableheader(data);
					
				}else if(data.get("ReportName").equals("Throughput Timeliness"))
				{
					String ThroughputTimelinesstitle=webElementReadText(ThroughputtimelinessTitle);
					assertEquals(ThroughputTimelinesstitle, data.get("ReportName"), "ThroughputTimelinesstitle");
					Tableheader(data);
					
				}else if(data.get("ReportName").equals("Throughput Summary"))
				{
					String ThroughputSummarytitle=webElementReadText(ThroughputSummaryTitle);
					assertEquals(ThroughputSummarytitle, data.get("ReportName"), "ThroughputSummarytitle");
					TableheaderThroughputSummary(data);
				}
				VaildateFieldName(data);
				if(data.get("DrillDown").equals("Yes"))
				{   
					if(data.get("ReportName").equals("Research Invalid Work Objects"))
					{
					workbasket(data);
					}else{
						SLA_workbasket();
					}
				    DrillDown(data);
				}
				driver.close();
				driver.switchTo().window(parentWindow);

			
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on VaildationSLABreakdownofOpenServiceRequests method " + e);
				test.log(Status.FAIL, "Error on VaildationSLABreakdownofOpenServiceRequests method " + e);
				throw e;
			}
		}
		public void workbasket(Hashtable<String, String> data) throws Exception
		{
			String workbaskets="";
			try{
				waitSleep(3000);
				
				webElementClick(workbasket, "work basket");
				waitSleep(1500);
				 List<WebElement> hr = driver.findElements(By.xpath("//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]")); 
	    			//System.out.println(hr.size());
	    			if(hr.size()==0)
	    			{
	    				waitSleep(15000);
	    				hr = driver
	    						.findElements(By.xpath("//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]"));
	    				//System.out.println(hr.size());
	    			}
	    			
	    			String h = "(//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]//td[2])[%d]";				
	    				for(int i=1;i<=hr.size();i++)
	    				{	
	    					workbaskets = workbaskets + "|" + driver.findElement(By.xpath(String.format(h, i))).getText();
	    						
	    						
	    				}	
	    				
	    			////System.out.println(workbaskets);
	    			assertEquals(data.get("Expectedworkbaskets"), workbaskets, "workbaskets");
	    			 webElementClick(Cancel,"Cancel");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on SLABreakdownofOpenServiceRequests method " + e);
				test.log(Status.FAIL, "Error on SLABreakdownofOpenServiceRequests method " + e);
				throw e;
			}
		}
		public void Slanote(Hashtable<String, String> data) throws Exception
		{
			
			try{
				waitSleep(1500);
				
                String Slanote=webElementReadText(SlaNote);
                assertEquals(Slanote, data.get("ExpectedSlanote"), "Slanote");
				waitSleep(1500);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on Slanote method " + e);
				test.log(Status.FAIL, "Error on Slanote method " + e);
				throw e;
			}
		}
		public void VaildateFieldName(Hashtable<String, String> data) throws Exception
		{
			
			try{
				waitSleep(3000);
				 String HeaderofallFields=getrowdata(data.get("HeadersField"), header);
				 String ExporttoPDF=webElementReadText(ExportToPDF);
				 String ExporttoExcel=webElementReadText(ExportToExcel);
				 String Generatedon=webElementReadText(generatedon);
				 String field=ExporttoPDF+"::"+ExporttoExcel+"::"+Generatedon;
				
				 assertEquals(field, data.get("ExpectedHeaderField"), "Header Field Name");
	             assertEquals(HeaderofallFields, data.get("ExpectedFieldtab"), "Header Field Name");
	              
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on VaildateFieldName method " + e);
				test.log(Status.FAIL, "Error on VaildateFieldName method " + e);
				throw e;
			}
		}
		public void Tableheader(Hashtable<String, String> data) throws Exception
		{
			String SLaheader="";
			try{
				waitSleep(3000);
				List<WebElement> hr = driver.findElements(By.xpath("//th[contains(@class,'dataLabelRead cellCont gridCell ellipsis')]")); 
    			//System.out.println(hr.size());
    			if(hr.size()==0)
    			{
    				waitSleep(15000);
    				hr = driver
    						.findElements(By.xpath("(//th[contains(@class,'dataLabelRead cellCont gridCell ellipsis')]"));
    				//System.out.println(hr.size());
    			}
    			
    			String h = "//th[contains(@class,'dataLabelRead cellCont gridCell ellipsis')]";				
    				List<WebElement> colums = driver.findElements(By.xpath(h));
    				for (int j = 0; j < colums.size(); j++) {
    					if (j ==0) {
    						SLaheader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    					} else {
    						SLaheader = SLaheader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    						
    					}
    				}
    			////System.out.println(SLaheader);
    			assertEquals(data.get("ExpectedSLaheader"), SLaheader, "SLaheader");
              
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on Tableheader method " + e);
				test.log(Status.FAIL, "Error on Tableheader method " + e);
				throw e;
			}
		}
		public void DrillDown(Hashtable<String, String> data) throws Exception
		{
			
			try{
				waitSleep(3000);
				

				webElementClick(DrillDown, "Open SR Drill Down");
				waitSleep(1500);
				Slanote(data);
				VaildateFieldName(data);
				DrillDownTableheader(data);
				if(data.get("ReportName").equals("Research Invalid Work Objects"))
				{
				workbasket(data);
				}else{
					SLA_workbasket();
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on DrillDown method " + e);
				test.log(Status.FAIL, "Error on DrillDown method " + e);
				throw e;
			}
		}
				
		public void DrillDownTableheader(Hashtable<String, String> data) throws Exception
		{
			String SLaheader="";
			try{
				waitSleep(3000);
				List<WebElement> hr = driver.findElements(By.xpath("//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle   ')]")); 
    			//System.out.println(hr.size());
    			if(hr.size()==0)
    			{
    				waitSleep(15000);
    				hr = driver
    						.findElements(By.xpath("//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle   ')]"));
    				//System.out.println(hr.size());
    			}
    			
    			String h = "//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle   ')]";				
    				List<WebElement> colums = driver.findElements(By.xpath(h));
    				for (int j = 0; j < colums.size(); j++) {
    					if (j ==0) {
    						SLaheader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    					} else {
    						SLaheader = SLaheader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    						
    					}
    				}
    			////System.out.println(SLaheader);
    			assertEquals(data.get("ExpectedDrillDown"), SLaheader, "SLaheader");
              
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on DrillDownTableheader method " + e);
				test.log(Status.FAIL, "Error on DrillDownTableheader method " + e);
				throw e;
			}
		}
		public void TableheaderThroughputSummary(Hashtable<String, String> data) throws Exception
		{
			String SLaheader="";
			try{
				waitSleep(3000);
				List<WebElement> hr = driver.findElements(By.xpath("//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle')]")); 
    			//System.out.println(hr.size());
    			if(hr.size()==0)
    			{
    				waitSleep(15000);
    				hr = driver
    						.findElements(By.xpath("//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle')]"));
    				//System.out.println(hr.size());
    			}
    			
    			String h = "//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle')]";				
    				List<WebElement> colums = driver.findElements(By.xpath(h));
    				for (int j = 0; j < colums.size(); j++) {
    					if (j ==0) {
    						SLaheader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    					} else {
    						SLaheader = SLaheader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    						
    					}
    				}
    			////System.out.println(SLaheader);
    			assertEquals(data.get("ExpectedSLaheader"), SLaheader, "SLaheader");
              
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on TableheaderThroughputSummary method " + e);
				test.log(Status.FAIL, "Error on TableheaderThroughputSummary method " + e);
				throw e;
			}
		}
		public void SLA_workbasket() throws Exception
		{
			String workbaskets = " ";
			try{
				waitSleep(3000);

				webElementClick(workbasket, "work basket");
				waitSleep(1500);
				
				waitSleep(1500);
				 List<WebElement> hr = driver.findElements(By.xpath("//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]")); 
	    			//System.out.println(hr.size());
	    			if(hr.size()==0)
	    			{
	    				waitSleep(15000);
	    				hr = driver
	    						.findElements(By.xpath("//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]"));
	    				//System.out.println(hr.size());
	    			}
	    			
	    			String h = "(//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]//td[2])[%d]";
	    			boolean workbasketvalue =true;
	    				for(int i=1;i<=hr.size();i++)
	    				{	
	    					//workbaskets = workbaskets + "|" + driver.findElement(By.xpath(String.format(h, i))).getText();
	    						if(driver.findElement(By.xpath(String.format(h, i))).getText().equals(""))
	    						{
	    							workbasketvalue=false;
	    							break;
	    						}
	    					
	    							
	    						
	    				}	
	    	
				if(workbasketvalue)
				{
					BaseTest.log.debug("Workbasket values are displaying");
					test.log(Status.PASS, "Workbasket values are displaying ");
				}else{
				     Assert.fail();
				     
				}

				
				webElementClick(Cancel,"Cancel");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on SLABreakdownofOpenServiceRequests method " + e);
				test.log(Status.FAIL, "Error on SLABreakdownofOpenServiceRequests method " + e);
				throw e;
			}
		}
}
