package com.nasco.HMHS.Setup;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

@SuppressWarnings("hiding")
public abstract class BasePage<T> {

	protected WebDriver driver;
	protected ExtentTest test;
	public Actions builder;
	private long LOAD_TIMEOUT = 30;
	protected WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), LOAD_TIMEOUT);

	public BasePage() {
		this.driver = DriverManager.getDriver();
		this.test = DriverManager.getExtentReport();
	}

	@SuppressWarnings({ "unused", "rawtypes", "unchecked" })
	public T openPage(Class<T> clazz) {
		T page = null;
		try {
			driver = DriverManager.getDriver();
			wait = new WebDriverWait(DriverManager.getDriver(), LOAD_TIMEOUT);
			page = PageFactory.initElements(driver, clazz);
			String frame = "PegaGadget0Ifr";
			ExpectedCondition pageLoadCondition = ((BasePage) page).getPageLoadCondition();
			waitForPageToLoad(pageLoadCondition);
		} catch (NoSuchElementException e) {
			throw new IllegalStateException(String.format("This is not the %s page", clazz.getSimpleName()));
		}
		return page;
	}

	public void waitForPageToLoad(ExpectedCondition<T> pageLoadCondition) {
		WebDriverWait wait = new WebDriverWait(driver, LOAD_TIMEOUT);
		wait.until(pageLoadCondition);
	}

	protected abstract ExpectedCondition<T> getPageLoadCondition();
	// protected abstract ExpectedCondition<T> getPageLoadCondition(String
	// frame);

	public void switchToDefault() {
		driver.switchTo().defaultContent();
	}

	public void switchToFrame(String frame) {
		driver.switchTo().defaultContent().switchTo().frame(frame);
	}

	public void verifyEquals(String expected, String actual, String logname)
	{
			if(actual.equals(expected))
			{
				test.log(Status.INFO, "Expected Value: " + expected);
				test.log(Status.INFO, "Actual Value: " + actual);
				test.log(Status.PASS, "Actual and excepted values are matched for '" + logname + "'");
				BaseTest.log.debug("Expected Value: " + expected + " and Actual Value: " + actual + " are matched for '"
						+ logname + "'");	
			}else{
				test.log(Status.FAIL, "Actual Value: " + actual);
				test.log(Status.FAIL, "Expected Value: " + expected);
				test.log(Status.FAIL, "Actual and excepted values are mismatched for '" + logname + "'");
				test.log(Status.FAIL, "Mismatched values are "+mismatchStrings(actual,expected,"|"));
				BaseTest.log.debug("Expected Value: " + expected + " and Actual Value: " + actual + " are not matched for '"
						+ logname + "'");
			}
	}
	public void assertEquals(String expected, String actual, String logname) {
		try {
			Assert.assertEquals(actual, expected);
			test.log(Status.INFO, "Expected Value: " + expected);
			test.log(Status.INFO, "Actual Value: " + actual);
			test.log(Status.PASS, "Actual and excepted values are matched for '" + logname + "'");
			BaseTest.log.debug("Expected Value: " + expected + " and Actual Value: " + actual + " are matched for '"
					+ logname + "'");
		} catch (AssertionError e) {
			test.log(Status.FAIL, "Actual Value: " + actual);
			test.log(Status.FAIL, "Expected Value: " + expected);
			test.log(Status.FAIL, "Actual and excepted values are mismatched for '" + logname + "'");
			test.log(Status.FAIL, "Mismatched values are "+mismatchStrings(actual,expected,"|"));
			BaseTest.log.debug("Expected Value: " + expected + " and Actual Value: " + actual + " are not matched for '"
					+ logname + "'");
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error(excepionMessage);
			test.log(Status.FAIL, e);
			throw e;
		}
	}

	public String mismatchStrings(String actual, String expected, String qualifier) {
		
		String mismatches="";
		String qalifierValu="\\"+qualifier;
		String [] actualValues=actual.split(qalifierValu);
		String [] expectedValues=expected.split(qalifierValu);
		
		if(actualValues.length==expectedValues.length)
		{
			for(int i=0;i<actualValues.length;i++)
			{
								
				if(!actualValues[i].equals(expectedValues[i]))
				{
					mismatches=mismatches+" Actual Value: "+actualValues[i]+" Expected value: "+expectedValues[i];
				}
			}
		}
		return mismatches;
	}
	public String readTableData(String rowWebelement, String rowWebelements) {
		String memberDetails = "";
		List<WebElement> membersRow = driver.findElements(By.xpath(rowWebelement));
		if (membersRow.size() != 0) {
			String s = rowWebelements;
			for (int i = 0; i < membersRow.size(); i++) {
				String s1 = String.format(s, i + 1);
				String memdet = "";
				List<WebElement> membersCol = driver.findElements(By.xpath(s1 + "//td"));
				for (int j = 0; j < membersCol.size(); j++) {
					if (j == 0) {
						memdet = driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					} else {
						memdet = memdet + "|" + driver.findElement(By.xpath(s1 + "//td[" + (j + 1) + "]")).getText();
					}
				}
				memberDetails = memberDetails + "," + memdet;
			}
			waitSleep(1000);
			memberDetails = memberDetails.substring(1, memberDetails.length());
			BaseTest.log.debug("Actual memberdetails: " + memberDetails);
			// //System.out.println("Actual memberdetails: "+memberDetails);
		}
		return memberDetails;
	}

	public String getListitemstext(String webElement) {
		String text = "";
		List<WebElement> membersRow = driver.findElements(By.xpath(webElement));
		for (int i = 1; i <= membersRow.size(); i++) {
			text = text + "|" + driver.findElement(By.xpath(webElement + "[" + i + "]")).getText();

		}
		return text;
	}

	public void assertContains(String expected, String actual, String logname) {
		try {
			Assert.assertTrue(actual.contains(expected));// .assertEquals(actual,
			test.log(Status.INFO, "Expected Value: " + expected);
			test.log(Status.INFO, "Actual Value: " + actual);
			test.log(Status.PASS, "Actual and excepted values are matched for '" + logname + "'");
			BaseTest.log.debug("Expected Value: " + expected + " and Actual Value: " + actual
					+ " Expected value contains an Actual value '" + logname + "'");

		} catch (AssertionError e) {
			test.log(Status.FAIL, "Actual Value: " + actual);
			test.log(Status.FAIL, "Expected Value: " + expected);
			test.log(Status.FAIL, "Actual and excepted values are mismatched for '" + logname + "'");
			BaseTest.log.debug("Expected Value: " + expected + " and Actual Value: " + actual
					+ " Expected value does not contains an Actual value '" + logname + "'");
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error(excepionMessage);
			test.log(Status.FAIL, e);
			throw e;
		}
	}

	// HMHS Element Present
	public void elementPresent(WebElement webelement, String logname) {

		try {
			webelement.isDisplayed();
			test.log(Status.PASS, "WebElement is displayed '" + logname + "'");
			BaseTest.log.debug("WebElement is displayed: " + webelement + "" + logname + "'");

		}

		catch (Exception e1) {
			//System.out.println("element not displayed");
			test.log(Status.FAIL, "Welement not displayed '" + logname + "'");
			BaseTest.log.debug("WebElement not displayed: " + webelement + "" + logname + "'");
			e1.printStackTrace();
			String excepionMessage = Arrays.toString(e1.getStackTrace());
			BaseTest.log.error(excepionMessage);
			test.log(Status.FAIL, e1);
			throw e1;
		}

	}

	public void waitForElementsToVisible(String xpath) {

		wait.until(ExpectedConditions.visibilityOfAllElements((List<WebElement>) driver.findElements(By.xpath(xpath))));
	}

	public void waitForFrameTobeVisible(String frameName) {
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.name(frameName)));
	}

	public void waitForElementNotToStale(String locatorTypeIdentifier, String locatorValueIdentifier,
			String fieldValue) {
		if (locatorTypeIdentifier.equals("id")) {
			wait.until(ExpectedConditions.stalenessOf((WebElement) (By.id(locatorValueIdentifier))));
		} else if (locatorTypeIdentifier.equals("name")) {
			wait.until(ExpectedConditions.stalenessOf((WebElement) (By.name(locatorValueIdentifier))));
		}
		if (locatorTypeIdentifier.equals("xpath")) {
			wait.until(ExpectedConditions.stalenessOf(driver
					.findElement(By.xpath(String.format(locatorValueIdentifier, fieldValue).replace("/:", ":")))));
		}
		

	}
	
	public void waitForElementNotToStale(WebElement element)
	{
		wait.until(ExpectedConditions.stalenessOf(element));
	}
	
	public void waitForNoSuchElement(WebElement element)
	{
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public void clickOnPage() {
		driver.findElement(By.xpath("//body")).click();
	}

	public void wait(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {

		}
	}

	public void waitOnIE(int time) throws Exception {
		try {
			if (RunTestNG_NCompass_HMHS.Config.get("Browser").toString().equalsIgnoreCase("ie"))
				Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error(excepionMessage);
			test.log(Status.FAIL, e);
			throw e;
		}
	}

	public void elementNotPresent(WebElement webelement, String logname) {

		try {
			webelement.isDisplayed();
			test.log(Status.FAIL, "Welement is displayed '" + logname + "'");
			BaseTest.log.debug("WebElement is displayed: " + webelement + "" + logname + "'");
			throw new ElementNotVisibleException("");
		}

		catch (Exception e1) {
			//System.out.println("element not displayed");
			test.log(Status.PASS, "WebElement not displayed '" + logname + "'");
			BaseTest.log.debug("WebElement not displayed: " + webelement + "" + logname + "'");
		}

	}
	// WebElemntClick Method by using JAVA Generics

	public <T> void webElementClick(T elementAttr, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", (By) elementAttr);
				wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr)).click();
				test.log(Status.PASS, "Successfully clicked " + logname);
				BaseTest.log.debug("Successfully clicked " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to click " + logname);
				BaseTest.log.debug("Unable to click " + logname);
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", (WebElement) elementAttr);
				wait.until(ExpectedConditions.elementToBeClickable(((WebElement) elementAttr))).click();
				test.log(Status.PASS, "Successfully clicked " + logname);
				BaseTest.log.debug("Successfully clicked " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to click " + logname);
				BaseTest.log.debug("Unable to click " + logname);
				e.printStackTrace();
				throw e;
			}
		}
	}

	// Write Text by using JAVA Generics
	public <T> void webElementSendText(T elementAttr, String text, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr)).clear();
				wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr)).sendKeys(text);
				test.log(Status.PASS, "Successfully entered data '" + text + "' in text field " + logname);
				BaseTest.log.debug("Successfully entered data '" + text + "' in text field " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to enter data '" + text + "' in text field " + logname);
				BaseTest.log.debug("Unable to enter data '" + text + "' in text field " + logname);
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				wait.until(ExpectedConditions.elementToBeClickable(((WebElement) elementAttr))).clear();
				wait.until(ExpectedConditions.elementToBeClickable(((WebElement) elementAttr))).sendKeys(text);
				test.log(Status.PASS, "Successfully entered data '" + text + "' in text field " + logname);
				BaseTest.log.debug("Successfully entered data '" + text + "' in text field " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to enter data '" + text + "' in text field " + logname);
				BaseTest.log.debug("Unable to enter data '" + text + "' in text field " + logname);
				e.printStackTrace();
				throw e;
			}
		}
	}

	// Click Method by using JAVA Script Executor (You can use both By or
	// Webelement)
	public <T> void jsClick(T elementAttr, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", (By) elementAttr);
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", loc);
				test.log(Status.PASS, "Successfully clicked " + logname);
				BaseTest.log.debug("Successfully clicked " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to click " + logname);
				BaseTest.log.debug("Unable to click " + logname);
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", (WebElement) elementAttr);
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(((WebElement) elementAttr)));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", loc);
				test.log(Status.PASS, "Successfully clicked " + logname);
				BaseTest.log.debug("Successfully clicked " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to click " + logname);
				BaseTest.log.debug("Unable to click " + logname);
				e.printStackTrace();
				throw e;
			}
		}
	}

	// Scroll Method by using JAVA Script Executor (You can use both By or
	// Webelement)
	public <T> void jsScroll(T elementAttr, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].scrollIntoView(true);", loc);
				test.log(Status.PASS, "Scroll success");
				BaseTest.log.debug("Scroll success");
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to scroll");
				BaseTest.log.debug("Unable to scroll");
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(((WebElement) elementAttr)));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].scrollIntoView(true);", loc);
				test.log(Status.PASS, "Scroll success");
				BaseTest.log.debug("Scroll success");
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to scroll");
				BaseTest.log.debug("Unable to scroll");
				e.printStackTrace();
				throw e;
			}
		}
	}

	// Clear Text by using JAVA Generics (You can use both By or Webelement)
	public <T> void clearText(T elementAttr, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr)).clear();
				test.log(Status.PASS, "Successfully cleared data in text field " + logname);
				BaseTest.log.debug("Successfully cleared data in text field " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to clear data in text field " + logname);
				BaseTest.log.debug("Unable to clear data in text field " + logname);
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				wait.until(ExpectedConditions.elementToBeClickable(((WebElement) elementAttr))).clear();
				test.log(Status.PASS, "Successfully cleared data in text field " + logname);
				BaseTest.log.debug("Successfully cleared data in text field " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to clear data in text field " + logname);
				BaseTest.log.debug("Unable to clear data in text field " + logname);
				e.printStackTrace();
				throw e;
			}
		}
	}

	// Read Text by using JAVA Generics (You can use both By or Webelement)
	public <T> String webElementReadText(T elementAttr) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				String text=wait.until(ExpectedConditions.presenceOfElementLocated((By) elementAttr)).getText();
				test.log(Status.PASS, "Data Read:"+text);
				BaseTest.log.debug("Data Read:"+text);
				
				return text;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				String text=wait.until(ExpectedConditions.visibilityOf((WebElement) elementAttr)).getText();
				test.log(Status.PASS, "Data Read:"+text);
				BaseTest.log.debug("Data Read:"+text);
				return text;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
	}
	
	public <T> String webElementReadText(T elementAttr, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				String text=wait.until(ExpectedConditions.presenceOfElementLocated((By) elementAttr)).getText();
				test.log(Status.PASS, "Data Read for "+logname+" is "+text);
				BaseTest.log.debug("Data Read for "+logname+" is "+text);
				
				return text;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				return wait.until(ExpectedConditions.visibilityOf((WebElement) elementAttr)).getText();
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
	}

	// Close popup if exists
	public void handlePopup(By by) throws InterruptedException {
		List<WebElement> popup = driver.findElements(by);
		if (!popup.isEmpty()) {
			popup.get(0).click();
			Thread.sleep(200);
		}
	}

	// To refresh the browser
	public void refresh() throws Exception {
		driver.navigate().refresh();
	}

	// To return the current page title
	public String getTitle() {
		return driver.getTitle();
	}

	// To return the current page URL
	public String getCurrentURL() {
		return driver.getCurrentUrl();
	}

	// To return the current page Source
	public String getPageSource() {
		return driver.getPageSource();
	}

	// Assert the text displayed in field with expected text
	public <T> void assertText(T elementAttr, String actualText, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				String text = wait.until(ExpectedConditions.presenceOfElementLocated((By) elementAttr)).getText();
				if ((text.trim()).equals(actualText.trim())) {
					test.log(Status.PASS, "Successfully Verified data in field " + logname + " to be:" + actualText);
					BaseTest.log.debug("Successfully Verified data in field " + logname + " to be:" + actualText);
				} else {
					test.log(Status.FAIL, "Unable to verify data in field " + logname + " Expected Text:"
							+ actualText + " actualText:" + text);
					BaseTest.log.debug("Unable to verify data in field " + logname + " Expected Text:" + actualText
							+ " actualText:" + text);
				}
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to locate element " + elementAttr);
				BaseTest.log.debug("Unable to locate element " + elementAttr);
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				String text = wait.until(ExpectedConditions.visibilityOf(((WebElement) elementAttr))).getText();
				if ((text.trim()).equals(actualText.trim())) {
					test.log(Status.PASS, "Successfully Verified data in field " + logname + " to be:" + actualText);
					BaseTest.log.debug("Successfully Verified data in field " + logname + " to be:" + actualText);
				} else {
					test.log(Status.FAIL, "Unable to verify data in field " + logname + " Expected Text:"
							+ actualText + " actualText:" + text);
					BaseTest.log.debug("Unable to verify data in field " + logname + " Expected Text:" + actualText
							+ " actualText:" + text);
				}
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to verify data in text field " + logname);
				BaseTest.log.debug("Unable to locate element " + elementAttr);
				e.printStackTrace();
				throw e;
			}
		}
	}

	// Assert the text displayed in field with expected text
	public <T> void assertSubText(T elementAttr, String actualText, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				String text = wait.until(ExpectedConditions.presenceOfElementLocated((By) elementAttr)).getText();
				if ((text.trim()).indexOf(actualText.trim()) > -1) {
					test.log(Status.PASS, "Successfully Verified data in field " + logname + " to be:" + actualText);
					BaseTest.log.debug("Successfully Verified data in field " + logname + " to be:" + actualText);
				} else {
					test.log(Status.FAIL, "Unable to verify data in field " + logname + " Expected Text:"
							+ actualText + " actualText:" + text);
					BaseTest.log.debug("Unable to verify data in field " + logname + " Expected Text:" + actualText
							+ " actualText:" + text);
				}
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to locate element " + elementAttr);
				BaseTest.log.debug("Unable to clear data in text field " + logname);
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				String text = wait.until(ExpectedConditions.visibilityOf(((WebElement) elementAttr))).getText();
				if ((text.trim()).indexOf(actualText.trim()) > -1) {
					test.log(Status.PASS, "Successfully Verified data in field " + logname + " to be:" + actualText);
					BaseTest.log.debug("Successfully Verified data in field " + logname + " to be:" + actualText);
				} else {
					test.log(Status.FAIL, "Unable to verify data in field " + logname + " Expected Text:"
							+ actualText + " actualText:" + text);
					BaseTest.log.debug("Unable to verify data in field " + logname + " Expected Text:" + actualText
							+ " actualText:" + text);
				}
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to clear data in text field " + logname);
				BaseTest.log.debug("Unable to clear data in text field " + logname);
				e.printStackTrace();
				throw e;
			}
		}
	}

	// Assert the title displayed with expected title
	public void assertTitle(String actualText) {
		try {
			String text = getTitle();
			if (text.equals(actualText)) {
				test.log(Status.PASS, "Successfully Verified page Title to be:" + actualText);
				BaseTest.log.debug("Successfully Verified page Title to be:" + actualText);
			} else {
				test.log(Status.FAIL,
						"Unable to verify page Title Expected Text:" + actualText + " actualText:" + text);
				BaseTest.log.debug("Unable to verify page Title Expected Text:" + actualText + " actualText:" + text);
			}
		} catch (Exception e) {
			test.log(Status.FAIL, "Unable to verify page Title");
			BaseTest.log.debug("Unable to verify page Title");
			e.printStackTrace();
			throw e;
		}
	}

	// Select Value from dropdown VisibleText by using JAVA Generics (You can
	// use both By or Webelement)
	public <T> void selectDropdownValueByVisibleText(T elementAttr, String valueToSelect, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr));
				Select dropdown = new Select(loc);
				try {
					dropdown.selectByVisibleText(valueToSelect);
				}catch(Exception e2)
				{
					dropdown.selectByVisibleText(valueToSelect.replaceAll(" ",""));
				}
				
				test.log(Status.PASS,
						"Successfully selected the value " + valueToSelect + " in Dropdown: " + logname);
				BaseTest.log.debug("Successfully selected the value " + valueToSelect + " in Dropdown: " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to select value " + valueToSelect + " in Dropdown: " + logname);
				BaseTest.log.debug("Unable to select value " + valueToSelect + " in Dropdown: " + logname);
				e.printStackTrace();
				throw e;
			}
		} else { 
			try {
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(((WebElement) elementAttr)));
				Select dropdown = new Select(loc);
				try {
					dropdown.selectByVisibleText(valueToSelect);
				}catch(Exception e2)
				{
					dropdown.selectByVisibleText(valueToSelect.replaceAll(" ",""));
				}
				test.log(Status.PASS,
						"Successfully selected the value " + valueToSelect + " in Dropdown: " + logname);
				BaseTest.log.debug("Successfully selected the value " + valueToSelect + " in Dropdown: " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to select value " + valueToSelect + " in Dropdown: " + logname);
				BaseTest.log.debug("Unable to select value " + valueToSelect + " in Dropdown: " + logname);
				e.printStackTrace();
				throw e;
			}
		}
	}

	// Select Value from dropdown VisibleText by using JAVA Generics (You can
	// use both By or Webelement)
	public <T> void selectDropdownValueByValue(T elementAttr, String valueToSelect, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr));
				Select dropdown = new Select(loc);
				dropdown.selectByValue(valueToSelect);
				test.log(Status.PASS,
						"Successfully selected the value " + valueToSelect + " in Dropdown: " + logname);
				BaseTest.log.debug("Successfully selected the value " + valueToSelect + " in Dropdown: " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to select value " + valueToSelect + " in Dropdown: " + logname);
				BaseTest.log.debug("Unable to select value " + valueToSelect + " in Dropdown: " + logname);
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(((WebElement) elementAttr)));
				Select dropdown = new Select(loc);
				dropdown.selectByValue(valueToSelect);
				test.log(Status.PASS,
						"Successfully selected the value " + valueToSelect + " in Dropdown: " + logname);
				BaseTest.log.debug("Successfully selected the value " + valueToSelect + " in Dropdown: " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to select value " + valueToSelect + " in Dropdown: " + logname);
				BaseTest.log.debug("Unable to select value " + valueToSelect + " in Dropdown: " + logname);
				e.printStackTrace();
				throw e;
			}
		}
	}

	public void stopExecutionOnFail() {
		driver.close();
	}

	public void waitSleep(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public <T> boolean isElementPresent(T elementAttr) {

		if (elementAttr.getClass().getName().contains("By")) {
			try {
				driver.findElement((By) elementAttr).isDisplayed();
				return true;
			} catch (org.openqa.selenium.NoSuchElementException e) {
				return false;
			}
		} else {
			try {
				((WebElement) elementAttr).isDisplayed();
				return true;
			} catch (org.openqa.selenium.NoSuchElementException e) {
				return false;
			}
		}
	}

	// send Text by using JavascriptExecutor (You can use both By or Webelement)
	public <T> void jswriteText(T elementAttr, String text, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr)).clear();
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].value='" + text + "';", loc);
				test.log(Status.PASS, "Successfully entered data '" + text + "' in text field " + logname);
				BaseTest.log.debug("Successfully entered data '" + text + "' in text field " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to enter data '" + text + "' in text field " + logname);
				BaseTest.log.debug("Unable to enter data '" + text + "' in text field " + logname);
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				wait.until(ExpectedConditions.elementToBeClickable(((WebElement) elementAttr))).clear();
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(((WebElement) elementAttr)));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].value='" + text + "';", loc);
				test.log(Status.PASS, "Successfully entered data '" + text + "' in text field " + logname);
				BaseTest.log.debug("Successfully entered data '" + text + "' in text field " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to enter data '" + text + "' in text field " + logname);
				BaseTest.log.debug("Unable to enter data '" + text + "' in text field " + logname);
				e.printStackTrace();
				throw e;
			}
		}
	}
	
	public List<String> getAllValues(WebElement s, String text) throws InterruptedException
	 {

	    Select sel = new Select(s);
	    List<WebElement> we = sel.getOptions();
	    List<String> ls = new ArrayList<String>();
	    for(WebElement a : we)
	    {
	        //System.out.println(ls);
	        if(!a.getText().equals("Select")){
	            ls.add(a.getText());
	        }
	    }
	    return ls;
	 }
	
	// Get Drop down values for Type of inquiry, reasons and resolutions
	public String getAlldropdownvalues(WebElement typeofInq, WebElement reasons, WebElement resolutions)
	{
		switchToFrame("PegaGadget1Ifr");
		waitSleep(4500);
		 Select s = new Select(typeofInq);
	      List <WebElement> op = s.getOptions();
	      int size = op.size();
	      List<String> typeofInquiry= new ArrayList<String>();
	      List<String> Reasons= new ArrayList<String>();
	      List<String> Resolutions= new ArrayList<String>();
	      for(int i =0; i<size ; i++){
		         String options = op.get(i).getText();
		         //System.out.println(options);
		         if(!op.get(i).getText().equals("Select")){
		        	 typeofInquiry.add(options);	 
		         }
	      }
	     
	     for(int i=0;i<typeofInquiry.size();i++)
	      {
	    	  s.selectByVisibleText(typeofInquiry.get(i));
	    	  waitSleep(10000);
	    	  Select s1 = new Select(reasons);
	    	  List <WebElement> op1 = s1.getOptions();
		      int size1 = op1.size();
		      for(int j =0; j<size1; j++){
			         String options1 = op1.get(j).getText();
			         //System.out.println(options1);
			         if(!op1.get(j).getText().equals("Select")){
			        	 Reasons.add(typeofInquiry.get(i)+"_"+options1);	 
			         }
		      }
	      }
	     
	      String expectedValues="";
	      
	      for(int i=0;i<typeofInquiry.size();i++)
	      {
	    	  s = new Select(typeofInq);
	    	  s.selectByVisibleText(typeofInquiry.get(i));
	    	  for(int j =0; j<Reasons.size(); j++){
	    		  Select s1 = new Select(reasons);
	    		  waitSleep(1000);
	    		  String reasonValues=Reasons.get(j);
	    		  String reasonValue [] =reasonValues.split("_");
	    		  //System.out.println("type of inquiry: "+reasonValue[0]);
	    		  //System.out.println("type of inquiry:"+typeofInquiry.get(i));
	    		  //System.out.println("Reason: "+reasonValue[1]);
	    		  if(reasonValue[0].equals(typeofInquiry.get(i)))
	    		  {
	    			  s1.selectByVisibleText(reasonValue[1]);
	    			  waitSleep(1500);
	    			  Select s2 = null;
	    			  try{
	    				  s2 = new Select(resolutions);  
	    			  }
	    			  catch(Exception e1)
	    			  {
	    				  waitSleep(800);
	    				  s2 = new Select(resolutions); 
	    			  }
			    	  
		    		  List <WebElement> op2 = s2.getOptions();
				      int size2 = op2.size();
				      //System.out.println("resolutions size:"+size2);
		    		  for(int k=0;k<size2;k++)
		    		  {
		    			  String options2 = op2.get(k).getText();
					         //System.out.println(options2);
					         if(!op2.get(k).getText().equals("Select")){
					        	 Resolutions.add(options2);
					        	 //System.out.println(options2);
					        	 if(k==0)
					        	 {
					        		 expectedValues="|"+reasonValue[0]+"-"+reasonValue[1]+"-"+options2+"|";
					        	 }
					        	 else{
					        		 expectedValues=expectedValues+"|"+reasonValue[0]+"-"+reasonValue[1]+"-"+options2+"|";
					        	 }
					        }
		    		  }
	    		  }
	    		  
		      }
	      }
	      
	     
	      //System.out.println("Expected dropdown values:"+expectedValues);
	      return expectedValues;
		
	}

	// Click Method by using JAVA Generics (You can use both By or Webelement)
	public <T> void HoverOnElement(T elementAttr, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				builder = new Actions(driver);
				builder.moveToElement((WebElement) elementAttr, 0, 0).build().perform();
				;
				test.log(Status.PASS, "Successfully mouse hovered to " + logname);
				BaseTest.log.debug("Successfully mouse hovered to " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to hover " + logname);
				BaseTest.log.debug("Unable to hover " + logname);
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				builder = new Actions(driver);
				builder.moveToElement((WebElement) elementAttr, 0, 0).build().perform();
				;
				// wait.until(ExpectedConditions.visibilityOf(((WebElement)
				// elementAttr))).click();
				test.log(Status.PASS, "Successfully mouse hovered to " + logname);
				BaseTest.log.debug("Successfully mouse hovered to " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to hover " + logname);
				BaseTest.log.debug("Unable to hover " + logname);
				e.printStackTrace();
				throw e;
			}
		}
	}

	// Mouseover Method by using JAVA Script Executor (You can use both By or
	// Webelement)
	public <T> void jsMouseOver(T elementAttr, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].onmouseover()", loc);
				test.log(Status.PASS, "Successfully mouse hovered to " + logname);
				BaseTest.log.debug("Successfully mouse hovered to " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to hover " + logname);
				BaseTest.log.debug("Unable to hover " + logname);
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				WebElement loc = wait.until(ExpectedConditions.elementToBeClickable(((WebElement) elementAttr)));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].onmouseover()", loc);
				test.log(Status.PASS, "Successfully mouse hovered to " + logname);
				BaseTest.log.debug("Successfully mouse hovered to " + logname);
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to hover " + logname);
				BaseTest.log.debug("Unable to hover " + logname);
				e.printStackTrace();
				throw e;
			}
		}
	}

	// Assert the text displayed in field with expected text
	public <T> void assertElement(T elementAttr, String logname) {
		if (elementAttr.getClass().getName().contains("By")) {
			try {
				boolean isDisplayed = wait.until(ExpectedConditions.presenceOfElementLocated((By) elementAttr))
						.isDisplayed();
				if (isDisplayed) {
					test.log(Status.PASS, "Element displayed-" + logname);
					BaseTest.log.debug("Element displayed-" + logname);
				} else {
					test.log(Status.FAIL, "Element not found-" + logname);
					BaseTest.log.debug("Element not found-" + logname);
				}
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to locate element " + elementAttr);
				BaseTest.log.debug("Unable to locate element " + elementAttr);
				e.printStackTrace();
				throw e;
			}
		} else {
			try {
				boolean isDisplayed = wait.until(ExpectedConditions.visibilityOf((WebElement) elementAttr))
						.isDisplayed();
				if (isDisplayed) {
					test.log(Status.PASS, "Element displayed-" + logname);
					BaseTest.log.debug("Element displayed-" + logname);
				} else {
					test.log(Status.FAIL, "Element not found-" + logname);
					BaseTest.log.debug("Element not found-" + logname);
				}
			} catch (Exception e) {
				test.log(Status.FAIL, "Unable to locate element " + elementAttr);
				BaseTest.log.debug("Unable to locate element " + elementAttr);
				e.printStackTrace();
				throw e;
			}
		}
	}
	public String getrowdata(String Headersdata,String Xpathvalue)
	{
		String rowDatavalue ="";
		List<String> headerRow= new ArrayList<String>();
	
		String hearders[]=Headersdata.split("--");
		for (int i=0;i<hearders.length;i++)
		{
			 headerRow.add(hearders[i]);
		}

      ArrayList<String> rowData= new ArrayList<String>();
                              for(int j=0;j<headerRow.size();j++)
                              {											
                            	rowData.add(driver.findElement(By.xpath(String.format(Xpathvalue, headerRow.get(j)))).getText());
                                    if(j==0){
                                    	rowDatavalue=rowData.get(j);
                                    }else{
                                    	rowDatavalue=rowDatavalue + "|" + rowData.get(j);
                                    }
                              }
                  
                        
     return rowDatavalue;
	}
	public String getTooltipMessage(WebElement element1,WebElement element2)
	{
		String TooltipMessage="";
		Actions act = new Actions(driver);
		act.moveToElement(element1).perform();
		waitSleep(5000);
		TooltipMessage = element2.getText();
		return TooltipMessage ;
		
	}
}
