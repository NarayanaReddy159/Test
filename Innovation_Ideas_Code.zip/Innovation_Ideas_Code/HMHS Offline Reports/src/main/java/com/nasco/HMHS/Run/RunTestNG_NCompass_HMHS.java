package com.nasco.HMHS.Run;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.testng.ITestNGListener;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.nasco.HMHS.ExtentListeners.ExtentListeners;
import com.nasco.HMHS.utilities.ExcelReader;

public class RunTestNG_NCompass_HMHS {
	public static Properties Config = new Properties();
	private static FileInputStream fis;
	private static Object[][] arrayCounts = new Object[1][4];
	static int includeCount = 0, naCount = 0;
	public static int runCount=0;
	public static int excTcCount =0,passedCount =0,failedCount =0, pass=0,fail=0;
	public static int passMemSecnt = 0, failMemSecnt = 0,passProsMemcnt = 0,failProsMemcnt = 0;
	public static int passVeriMemcnt = 0,failVeriMemcnt = 0, passMem360cnt = 0,failMem360cnt = 0;
	public static int passDatamask = 0, failDatamask = 0, passRole = 0,failRole = 0;
	public static int passGSI = 0,failGSI = 0,passMOC = 0, failMOC = 0;
	public static int passFOL = 0, failFOL = 0, passFPR = 0, failFPR = 0;
	public static int passManageChecks = 0, failManageChecks= 0, passCLM=0,failCLM=0;
	public static int passPCP=0, failPCP=0, passWS=0,failWS=0;
	public static int passReports=0, failReports=0,passIDC=0,failIDC=0;
	public static int passRI, failRI=0, passRTC=0, failRTC=0, passSCH=0, failSCH=0;	
	public static int passAUT=0, failAUT=0, passBEN=0, failBEN=0, passTOT=0, failTOT=0;
	public static Map<String,List<Hashtable<String, String>>> failedData= new HashMap<String,List<Hashtable<String, String>>>();
	public static List<String> failedMethods = new ArrayList<>();
	public static void main(String[] args) {
		initConfig();
		dynamicTestNG();
	}

	public static void dynamicTestNG() {
		// Create object of TestNG Class
		TestNG runner = new TestNG();
		// Create an instance of XML Suite and assign a name for it.
		XmlSuite mySuite = new XmlSuite();
		mySuite.setName("HMHSRegressionSuite");
		mySuite.setParallel(XmlSuite.ParallelMode.CLASSES);
		mySuite.setThreadCount(Integer.parseInt(Config.getProperty("PARALLEL_THREAD_COUNT")));
		// Create an instance of XmlTest and assign a name for it.
		XmlTest myTest = new XmlTest(mySuite);
		List<XmlClass> myClasses = new ArrayList<XmlClass>();
		ExcelReader excel = new ExcelReader(System.getProperty("user.dir") + Config.getProperty("SUITE_XL_PATH"));
		int rows = excel.getRowCount(Config.getProperty("SUITE_SHEET"));
		String data, runmode, clsName = "", testRunMode;
		for (int rowNum = 2; rowNum <= rows; rowNum++) {
			data = excel.getCellData(Config.getProperty("SUITE_SHEET"), Config.getProperty("SUITENAME_COL"), rowNum);
			runmode = excel.getCellData(Config.getProperty("SUITE_SHEET"), Config.getProperty("RUNMODE_COL"), rowNum);
			ExcelReader excel1 = new ExcelReader(getTestDataSheetName(data));
			int rows1 = excel1.getRowCount(Config.getProperty("TESTCASE_SHEET"));
			if (runmode.equals(Config.getProperty("RUNMODE_YES"))) {
				myTest.setName(data);
				includeCount = 0;
				naCount = 0;
				for (int rowNo = 2; rowNo <= rows1; rowNo++) {
					testRunMode = excel1.getCellData(Config.getProperty("TESTCASE_SHEET"),
							Config.getProperty("RUNMODE_COL"), rowNo);
					if (testRunMode.equalsIgnoreCase(Config.getProperty("RUNMODE_YES"))) {
						clsName = excel1.getCellData(Config.getProperty("TESTCASE_SHEET"),
								Config.getProperty("TESTCASE_ClassName"), rowNo);
						myClasses.add(new XmlClass(clsName));

						includeCount++;
					} else if (testRunMode.equalsIgnoreCase(Config.getProperty("RUNMODE_NA"))) {
						naCount++;
					}

				}
				get_Include_TCs_Count(getTestDataSheetName(data), rows1, includeCount, naCount);
			} else {
				get_Include_TCs_Count(getTestDataSheetName(data), rows1, 0, 0);
			}
		}

		// Assign that to the XmlTest Object created earlier.
		myTest.setXmlClasses(myClasses);

		// Create a list of XmlTests and add the Xmltest you created earlier to
		// it.
		List<XmlTest> myTests = new ArrayList<XmlTest>();
		myTests.add(myTest);

		// add the list of tests to your Suite.
		mySuite.setTests(myTests);

		// Add the suite to the list of suites.
		List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
		mySuites.add(mySuite);
		////System.out.println("mySuite::" + mySuite.toXml());
		// Set the list of Suites to the testNG object you created earlier.
		runner.setXmlSuites(mySuites);
		runner.setUseDefaultListeners(false);
		List<Class<? extends ITestNGListener>> lst = new ArrayList<Class<? extends ITestNGListener>>();
		lst.add(ExtentListeners.class);
		runner.setListenerClasses(lst);
		displayCounts(arrayCounts);
		// invoke run() - this will run your class.
		runner.run();

	}

	public static String getTestDataSheetName(String excelName) {
		String loc = "";

		if (excelName.equalsIgnoreCase("HMHS_Ncompass_TestData_G1")) {
			loc = System.getProperty("user.dir") + Config.getProperty("TestData_G1_XL_PATH");
		}
		if (excelName.equalsIgnoreCase("HMHS_Ncompass_TestData_G2")) {
			loc = System.getProperty("user.dir") + Config.getProperty("TestData_G2_XL_PATH");
		}
		return loc;
	}

	public static void initConfig() {
		try {
			String path = System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\Config.properties";
			fis = new FileInputStream(path);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			Config.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		;
	}

	public static void get_Include_TCs_Count(String dataSheetName, int totRows, int incCnt, int naCnt) {
		totRows = totRows - 1;

		if (dataSheetName.contains("HMHS_Ncompass")) {
			arrayCounts[0][0] = "HMHS";
			arrayCounts[0][1] = totRows;
			arrayCounts[0][2] = incCnt;
			arrayCounts[0][3] = naCnt;
		}

	}

	public static void displayCounts(Object[][] array) {

		for (int i = 0; i < array.length; i++) {

		}
	}

	public static Object[][] getCountsObj() {
		return arrayCounts;
	}

}
