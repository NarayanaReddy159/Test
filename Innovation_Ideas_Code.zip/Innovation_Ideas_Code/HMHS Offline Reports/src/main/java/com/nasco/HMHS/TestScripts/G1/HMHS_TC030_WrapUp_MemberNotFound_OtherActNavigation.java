package com.nasco.HMHS.TestScripts.G1;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC030_WrapUp_MemberNotFound_OtherActNavigation extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void HMHS_AUTC030_WrapUp_MemberNotFound_OtherActNavigation(Hashtable<String,String> data) throws Exception {
		try{
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside HMHS_AUTC030_WrapUp_MemberNotFound_OtherActNavigation");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_AUTC030_WrapUp_MemberNotFound_OtherActNavigation - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("HMHS_AUTC030_WrapUp_MemberNotFound_OtherActNavigation -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		test.log(Status.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String intentID=searchMember.getLIInteractionID();
		log.debug("Interaction id: "+intentID);
		
		searchMember.WrapUp_MemberNotFound();
		log.debug("Moved to Wrap Up Member Not Found page");
		searchMember.ExitInteractionMemSearch( data.get("Comments"));
		log.debug("Moved to Member Search page");
		searchMember.WrapUp_MemberNotFound();
		log.debug("Moved to Wrap Up Member Not Found page");
		searchMember.ExitInteraction();
		log.debug("Moved to Exit Interaction page");
		searchMember.WrapUp_MemberNotFound();
		log.debug("Moved to Wrap Up Member Not Found page");
		searchMember.WrapUp_CallDisconnected();
		log.debug("Moved to Wrap Up Call Disconnected page");
		searchMember.WrapUp_MemberNotFound();
		log.debug("Moved to Wrap Up Member Not Found page");
		searchMember.WrapUp_CallTransferred();
		log.debug("Moved to WrapUp Call Transferred page");
		searchMember.WrapUp_MemberNotFound();
		log.debug("Moved to Wrap Up Member Not Found page");
		searchMember.movetoProsMem();
		log.debug("Moved to Prospective member page.");
		test.log(Status.INFO,"Moved to Prospective member page.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  {
		test.log(Status.INFO, "HMHS_AUTC030_WrapUp_MemberNotFound_OtherActNavigation Completed");
		log.debug("HMHS_AUTC030_WrapUp_MemberNotFound_OtherActNavigation Completed");
		quit();
		
	}
}
