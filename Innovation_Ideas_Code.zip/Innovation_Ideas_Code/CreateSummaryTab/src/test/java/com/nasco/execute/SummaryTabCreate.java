/*******************************************************************
 * SummaryTabCreation Class for creating Summary tab in given excel*
 * Created by: K L Narayana Reddy **********************************
 *******************************************************************/

package com.nasco.execute;

import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/******************************************************
 * Summary tab create for choose file using jframe UI *
 ******************************************************/
public class SummaryTabCreate implements ActionListener{

	public JFrame jframe;
	JLabel fileChooseLable;
	JButton fileUpload,generateSummaryTab;
	@SuppressWarnings("rawtypes")
	JComboBox testCaseIdCB,stautsCB,groupsCB;
	String filepath="";
	String sheetName="";
	String testcaseValue,statusValue,groupValue;
	
	/**Get frame method to create frame to choose the excel and other required fields**/
	public void getframe()
	{
		jframe= new JFrame();
    	jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setLayout(new FlowLayout());
    	jframe.setPreferredSize(new Dimension(550,300));
    	jframe.setTitle("Generate Summary tab");
		fileChooseLable= new JLabel("File to upload: ");
		fileUpload = new JButton("Choose File");
		fileUpload.addActionListener(this);
		jframe.add(fileChooseLable);
		jframe.add(fileUpload);
		jframe.setBounds(250, 20, 50, 20);
		fileChooseLable.setBounds(10, 15, 250, 25);
		fileUpload.setBounds(120,15,100,25);
		generateSummaryTab= new JButton("Generate Summary Tab");
		generateSummaryTab.addActionListener(this);
		jframe.add(generateSummaryTab);
		//
		jframe.setLayout(null);
		jframe.pack();
		jframe.setVisible(true);
	}
	
	/**Action Performed method for capturing the test case, status and group/ cycle headers for excel chosen**/
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==fileUpload) {
			
			JFileChooser fileChooser = new JFileChooser();
			
			fileChooser.setCurrentDirectory(new File(".")); 
			
			int response = fileChooser.showOpenDialog(null); 
			
			if(response == JFileChooser.APPROVE_OPTION) {
				fileUpload.setEnabled(false);
				fileUpload.setBounds(0, 0, 0, 0);
				
				File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
				filepath=file.getAbsolutePath();
				fileChooseLable.setText("File: "+Paths.get(filepath).getFileName().toString());
				fileChooseLable.setBounds(10,15,600,15);
				try {
					List<String>sheets= getSheetNames(filepath);
					JLabel sheetsLabel= new JLabel("Select Sheet Name:");
					jframe.add(sheetsLabel);
					sheetsLabel.setBounds(10, 45, 250, 20);
					final JComboBox excelSheets= new JComboBox(sheets.toArray()); 
					excelSheets.setBounds(150,45,200,20);
					jframe.add(excelSheets);
					SwingUtilities.updateComponentTreeUI(jframe);
					excelSheets.addActionListener( new ActionListener() {
						 public void actionPerformed(ActionEvent e) {
							sheetName= String.valueOf(excelSheets.getSelectedItem());
							try{
								List<String> headers=getHeaders(filepath);
								JLabel testCaseIdLabel= new JLabel("Choose Test case id:");
								jframe.add(testCaseIdLabel);
								testCaseIdLabel.setBounds(10, 75, 200, 20);
								testCaseIdCB= new JComboBox(headers.toArray()); 
								jframe.add(testCaseIdCB);
								for(int i=0;i<headers.size();i++)
								{
									String testCaseValue=headers.get(i).toString();
									testCaseValue.toLowerCase();
									if(testCaseValue.toLowerCase().contains("test case"))
									{
										testCaseIdCB.setSelectedItem(headers.get(i).toString());
									}
								}
								testCaseIdCB.setBounds(150, 75, 200, 20);
								JLabel stautsLabel= new JLabel("Choose status:");
								jframe.add(stautsLabel);
								stautsLabel.setBounds(10, 105, 250, 20);
								stautsCB= new JComboBox(headers.toArray()); 
								jframe.add(stautsCB);
								for(int i=0;i<headers.size();i++)
								{
									String testCaseValue=headers.get(i).toString();
									testCaseValue.toLowerCase();
									if(testCaseValue.toLowerCase().contains("status"))
									{
										stautsCB.setSelectedItem(headers.get(i).toString());
									}
								}
								stautsCB.setBounds(150, 105, 200, 20);
								JLabel groupLabel= new JLabel("Choose Group / Cycle:");
								jframe.add(groupLabel);
								groupLabel.setBounds(10, 135, 250, 20);
								groupsCB= new JComboBox(headers.toArray()); 
								jframe.add(groupsCB);
								for(int i=0;i<headers.size();i++)
								{
									String testCaseValue=headers.get(i).toString();
									testCaseValue.toLowerCase();
									if(testCaseValue.toLowerCase().contains("group"))
									{
										groupsCB.setSelectedItem(headers.get(i).toString());
									}
									if(testCaseValue.toLowerCase().contains("cycle"))
									{
										groupsCB.setSelectedItem(headers.get(i).toString());
									}
								}
								groupsCB.setBounds(150, 135, 200, 20);
								generateSummaryTab.setBounds(60, 175, 175, 25);
								SwingUtilities.updateComponentTreeUI(jframe);
							}catch(Exception e4)
							{
								
							}
						 }
					});
					
				}
				catch(Exception e2)
				{
					
				}
					
		}
			
		}
		
		if(e.getSource()==generateSummaryTab) {
			
			try {
				testcaseValue=String.valueOf(testCaseIdCB.getSelectedItem());
				statusValue=String.valueOf(stautsCB.getSelectedItem());
				groupValue=String.valueOf(groupsCB.getSelectedItem());
				if(!statusValue.equals("Select"))
				{
					int value=FormulaCreation.createSummarytab(filepath,testcaseValue,statusValue,groupValue);
					jframe.dispose();
					if(value>0)
					{
						try {
							File fileloc= new File(filepath);
							refreshExcel(filepath);
							Desktop.getDesktop().browse(fileloc.toURI());
						} catch (Exception e3) {
							
							e3.printStackTrace();
						}	
					}else{
						CreateOptionPane.optionPane("No Changes made to test matrix");
					}
					
				}else{
					jframe.dispose();
					CreateOptionPane.optionPane("Status Column should be present in test matrix to generate summary tab");
				}
				
				
				
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			
		}
	}
	/**refresh excel method to refresh excel formula in the given excel**/
	public void refreshExcel(String Filepath) throws Exception
	{
		XSSFWorkbook excelWorkbook = new XSSFWorkbook(new FileInputStream(new File(Filepath)));
		XSSFFormulaEvaluator.evaluateAllFormulaCells(excelWorkbook);
	}
	
	/**get sheet names method to get all sheets in the given excel **/
	public List<String> getSheetNames(String Filepath) throws Exception
	{
		List<String> sheetNames= new ArrayList<String>();
		FileInputStream fis=new FileInputStream(Filepath);
		Workbook workbook = new XSSFWorkbook(fis);
		sheetNames.add("Select Sheet");
		for(int i=0;i<workbook.getNumberOfSheets();i++)
		{
			sheetNames.add(workbook.getSheetName(i));
		}
		fis.close();
		return sheetNames;
	}
	/**get headers method to get all headers in the given excel **/
	public List<String> getHeaders(String Filepath) throws Exception
	{
		List<String> headers= new ArrayList<String>();
		FileInputStream fis=new FileInputStream(Filepath);
		Workbook workbook = new XSSFWorkbook(fis);
		Sheet sheet = workbook.getSheet(sheetName);
		int testCols = 0;
		int headerRow=99999;
		Outloop:
		for (Row row : sheet) {
		    for (Cell cell : row) {
		    	try{
		    		 String text =cell.getStringCellValue();
		    		 if(text.toLowerCase().contains("expected results"))
						{
		    			 headerRow=row.getRowNum();
			    		 break Outloop;
						}	
		    	}catch(Exception er1) 
		    	{
		    		
		    	}
		    	
		    }
		}
		headers.add("Select");
		if(headerRow!=99999)
		{
			testCols = sheet.getRow(headerRow).getLastCellNum();
			for (int cNum = 0; cNum < testCols; cNum++) {
					String headerValue=sheet.getRow(headerRow).getCell(cNum).toString();
					if(!headerValue.equals(""))
					{
						headers.add(sheet.getRow(headerRow).getCell(cNum).toString());
					}
				}
				
		}
		
		fis.close();
		return headers;
	}
}
