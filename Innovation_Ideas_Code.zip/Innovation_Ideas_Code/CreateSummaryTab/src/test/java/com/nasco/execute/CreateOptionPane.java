package com.nasco.execute;

import javax.swing.JOptionPane;

public class CreateOptionPane {

	public static void optionPane(String message)
	{
		@SuppressWarnings("unused")
		final JOptionPane pane =new JOptionPane();
        Thread t1 = new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(30000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }               
                JOptionPane.getRootFrame().dispose();
            }
        });
        t1.start();
        JOptionPane.showMessageDialog(null, message);
        System.exit(0);
		
	}
	

}
