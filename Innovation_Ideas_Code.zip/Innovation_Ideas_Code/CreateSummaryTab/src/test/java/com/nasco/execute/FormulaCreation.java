/****************************************************************
 * FormulaCreation Class for creating Summary tab in given excel*
 * Created by: K L Narayana Reddy *******************************
 ****************************************************************/

package com.nasco.execute;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FormulaCreation {

	/********************************************************************
	 * Create Summary tab method for creating Summary tab in given excel*
	 ********************************************************************/
	public static int createSummarytab(String fileName,String testcaseValue,
			String statusValue,String groupValue) throws Exception {
		int returnvalue=0;
		FileInputStream fis=new FileInputStream(fileName);
		Workbook workbook = new XSSFWorkbook(fis);
		Map<String,List<String>> formulaValues= new HashMap<String,List<String>>();
		int formulaRow=0;
		for(int s=0;s<workbook.getNumberOfSheets();s++)
		{
			List<String> totalTC= new ArrayList<String>();
			List<String> groups= new ArrayList<String>();
			List<String> pass= new ArrayList<String>();
			List<String> fail= new ArrayList<String>();
			List<String> hold= new ArrayList<String>();
			List<String> inprogress= new ArrayList<String>();
			List<String> NA= new ArrayList<String>();
			List<String> totalExecuted= new ArrayList<String>();
			Sheet sheet= workbook.getSheetAt(s);
			String sheetName=sheet.getSheetName();
			//System.out.println("sheetName: "+sheetName);
			if(!sheetName.toLowerCase().contains("ui_")||!sheetName.toLowerCase().equals("summary"))
			{
				int headerRow=99999; /***Constant Header Row***/
				int rows= sheet.getLastRowNum();
				Outloop:
				for (Row row : sheet) {
				    for (Cell cell : row) {
				    	try{
				    		 String text =cell.getStringCellValue();
				    		 if(text.equals(testcaseValue))
								{
				    			 //System.out.println("text in if: "+text);
					    		 headerRow=row.getRowNum(); /**Header row value matching test case header value**/
					    		 break Outloop;
								}	
				    	}catch(Exception er1) 
				    	{
				    		
				    	}
				    	
				    }
				}
				//System.out.println("Header Row:"+headerRow);
				if(headerRow!=99999) /**Enter when headerRow is not 99999**/
				{
					    int columns=sheet.getRow(headerRow).getLastCellNum();
					    Set<String> groupValues= new HashSet<String>();
					    List<String> groupValuesList= new ArrayList<String>();
					    String groupcellName="";
						String testcaseCellName="";
						String statusCellName="";
						String foumulaHeader="COUNTIF('";
						for(int i=0;i<columns;i++)
						{
							/**Group or Cycle value exists**/
							if(sheet.getRow(headerRow).getCell(i).toString().toLowerCase().contains("group")
									||sheet.getRow(headerRow).getCell(i).toString().toLowerCase().equals("cycle")
									)
							{
								groupcellName=getCellName(sheet,i,headerRow);
								for(int j=1+headerRow;j<rows;j++)
								{
									String group="";
									try{
										group=sheet.getRow(j).getCell(i).getStringCellValue();
									}catch(Exception e4)
									{
										
									}
									//System.out.println("************:"+group);		
									if(!group.equals(""))
									{
										groupValues.add(group);
									}
								}
							}
							/**Test Case Cell Name**/
							if(sheet.getRow(headerRow).getCell(i).toString().equals(testcaseValue))
							{
								testcaseCellName=getCellName(sheet,i,headerRow);
								//System.out.println("test case Cell name: "+testcaseCellName);
							}
							/**Status Cell Name**/
							if(sheet.getRow(headerRow).getCell(i).toString().equals(statusValue))
							{
								statusCellName=getCellName(sheet,i,headerRow);
								//System.out.println("Status Cell name: "+statusCellName);
							}		
							
						}
						/**Group values list**/
						for(Iterator<String> it=groupValues.iterator();it.hasNext();){
							groupValuesList.add(it.next());
						}
						List<String> headers= new ArrayList<String>();
						headers.add("Intent");
						if(groupValues.size()>0)
						{
							foumulaHeader="COUNTIFS('";
							headers.add("Group");
						}
						headers.add("Total TC's"); /**Table header values**/
						headers.add("Pass");
						headers.add("Fail");
						headers.add("Hold");
						headers.add("Inprogress");
						headers.add("NA");
						headers.add("Total Executed");
						formulaValues.put(formulaRow+"Header_"+sheetName, headers);
						formulaRow=formulaRow+1;
						String totalTcFormula="";
						String passFormula="";
						String failFormula="";
						String inprogressFormula="";
						String holdFormula="";
						String NAFormula="";
						
						String totalTCCount="";
						String totalPass="";
						String totalFail="";
						String totalInprogress="";
						String totalHold="";
						String totalNa="";
						String totalExeuctedCount="";
						
						/**Building formula**/
						if(groupValues.size()>0) 
						{
								
							for(int i=0;i<groupValuesList.size();i++){
								List<String> values= new ArrayList<String>();
								totalTcFormula="COUNTIF('"+sheetName+"'!"+groupcellName+(headerRow+2)+":"+groupcellName+"1000,\""+groupValuesList.get(i)+"\")";
								passFormula=foumulaHeader+sheetName+"'!"+groupcellName+(headerRow+2)+":"+groupcellName+"1000,\""+groupValuesList.get(i)+"\",'"
										+sheetName+"'!"+statusCellName+(headerRow+2)+":"+statusCellName+"1000,\"Pass\")";
								failFormula=foumulaHeader+sheetName+"'!"+groupcellName+(headerRow+2)+":"+groupcellName+"1000,\""+groupValuesList.get(i)+"\",'"
										+sheetName+"'!"+statusCellName+(headerRow+2)+":"+statusCellName+"1000,\"Fail\")";
								holdFormula=foumulaHeader+sheetName+"'!"+groupcellName+(headerRow+2)+":"+groupcellName+"1000,\""+groupValuesList.get(i)+"\",'"
										+sheetName+"'!"+statusCellName+(headerRow+2)+":"+statusCellName+"1000,\"Hold\")";
								inprogressFormula=foumulaHeader+sheetName+"'!"+groupcellName+(headerRow+2)+":"+groupcellName+"1000,\""+groupValuesList.get(i)+"\",'"
										+sheetName+"'!"+statusCellName+(headerRow+2)+":"+statusCellName+"1000,\"Inprogress\")";
								NAFormula=foumulaHeader+sheetName+"'!"+groupcellName+(headerRow+2)+":"+groupcellName+"1000,\""+groupValuesList.get(i)+"\",'"
										+sheetName+"'!"+statusCellName+(headerRow+2)+":"+statusCellName+"1000,\"NA\")";
								values.add(sheetName);
								values.add(groupValuesList.get(i).toString());
								values.add(totalTcFormula);
								values.add(passFormula);
								values.add(failFormula);
								values.add(holdFormula);
								values.add(inprogressFormula);
								values.add(NAFormula);
								values.add(passFormula+"+"+failFormula);
								totalTC.add(totalTcFormula);
								groups.add(groupValuesList.get(i));
								pass.add(passFormula);
								fail.add(failFormula);
								hold.add(holdFormula);
								inprogress.add(inprogressFormula);
								NA.add(NAFormula);
								totalExecuted.add(passFormula+"+"+failFormula);
								formulaValues.put(formulaRow+"Row"+i+"_"+sheetName, values);
								formulaRow=formulaRow+1;
							}
							
						}else{
							List<String> values= new ArrayList<String>();
							totalTcFormula="COUNTA('"+sheetName+"'!"+testcaseCellName+(headerRow+2)+":"+testcaseCellName+"1000)";
							passFormula="COUNTIF('"+sheetName+"'!"+statusCellName+(headerRow+2)+":"+statusCellName+"1000,\""+"Pass"+"\")";
							failFormula="COUNTIF('"+sheetName+"'!"+statusCellName+(headerRow+2)+":"+statusCellName+"1000,\""+"Fail"+"\")";
							holdFormula="COUNTIF('"+sheetName+"'!"+statusCellName+(headerRow+2)+":"+statusCellName+"1000,\""+"Hold"+"\")";
							inprogressFormula="COUNTIF('"+sheetName+"'!"+statusCellName+(headerRow+2)+":"+statusCellName+"1000,\""+"Inprogress"+"\")";
							NAFormula="COUNTIF('"+sheetName+"'!"+statusCellName+(headerRow+2)+":"+statusCellName+"1000,\""+"NA"+"\")";
							values.add(sheetName);
							values.add(totalTcFormula);
							values.add(passFormula);
							values.add(failFormula);
							values.add(holdFormula);
							values.add(inprogressFormula);
							values.add(NAFormula);
							values.add(passFormula+"+"+failFormula);
							totalTC.add(totalTcFormula);
							pass.add(passFormula);
							fail.add(failFormula);
							hold.add(holdFormula);
							NA.add(NAFormula);
							inprogress.add(inprogressFormula);
							totalExecuted.add(passFormula+"+"+failFormula);
							formulaValues.put(formulaRow+"Row0"+"_"+sheetName, values);
							formulaRow=formulaRow+1;
						}
						
						if(groupValuesList.size()>0)
						{
							List<String> values= new ArrayList<String>();	
							for(int i=0;i<groupValuesList.size();i++)
							{
								if(i==0)
								{
									totalTCCount=totalTC.get(i);
									totalPass=pass.get(i);
									totalPass=pass.get(i);
									totalFail=fail.get(i);
									totalInprogress=inprogress.get(i);
									totalHold=hold.get(i);
									totalNa=NA.get(i);
									totalExeuctedCount=totalExecuted.get(i);
								}
								else{
									totalTCCount=totalTCCount+"+"+totalTC.get(i);
									totalPass=totalPass+"+"+pass.get(i);
									totalFail=totalFail+"+"+fail.get(i);
									totalInprogress=totalInprogress+"+"+inprogress.get(i);
									totalHold=totalHold+"+"+hold.get(i);
									totalNa=totalNa+"+"+NA.get(i);
									totalExeuctedCount=totalExeuctedCount+"+"+totalExecuted.get(i);
								}
							}
							values.add("Total");
							values.add("");
							values.add(totalTCCount);
							values.add(totalPass);
							values.add(totalFail);
							values.add(totalInprogress);
							values.add(totalHold);
							values.add(totalNa);
							values.add(totalExeuctedCount);
							formulaValues.put(formulaRow+"Total"+"_"+sheetName, values);
							formulaRow=formulaRow+1;
						}
				}
				
			    
			   }
		} 
		returnvalue=formulaValues.size();
		//System.out.println("FormulaSize:"+formulaValues.size());
		 /**Generate summary tab for work book with formula build**/
		if(formulaValues.size()>0)
		{
			generateWorkbookwithSummarytab(workbook, fileName, formulaValues);
		}
		
	return returnvalue;
	}
	
	 /**Get Cell name for cell with row and colunm values**/
	public static String getCellName(Sheet sheet,int column,int row)
	{
		String cellName="";
		cellName=CellReference.convertNumToColString(sheet.getRow(row).getCell(column).getColumnIndex());
		return cellName;
	}
	 
	/**Generate Workbook with Summary tab**/
	public static void generateWorkbookwithSummarytab(Workbook workbook,String fileName, Map<String, List<String>> formulaValues) throws Exception
	{
		
		String summarySheetName="SummaryTab";
		FileOutputStream out =  null;
		
		int startingRow=3;
		try{
			out =new FileOutputStream(fileName);
			Sheet summarySheet = null;
			try{
				summarySheet=workbook.createSheet(summarySheetName);
			}catch(Exception e1)
			{
				summarySheet=workbook.getSheet(summarySheetName);
			}
			workbook.setSheetOrder(summarySheet.getSheetName().toString(),0);
			CellStyle headerRowstyle = workbook.createCellStyle();  
			headerRowstyle.setBorderBottom(CellStyle.BORDER_THIN); 
			headerRowstyle.setBorderLeft(CellStyle.BORDER_THIN);
			headerRowstyle.setBorderRight(CellStyle.BORDER_THIN);
			headerRowstyle.setBorderTop(CellStyle.BORDER_THIN);
			headerRowstyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.index);
			headerRowstyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
			
			CellStyle dataRowstyle = workbook.createCellStyle();  
			dataRowstyle.setBorderBottom(CellStyle.BORDER_THIN); 
			dataRowstyle.setBorderLeft(CellStyle.BORDER_THIN);
			dataRowstyle.setBorderRight(CellStyle.BORDER_THIN);
			dataRowstyle.setBorderTop(CellStyle.BORDER_THIN);
			 TreeMap<String, List<String>> sorted = new TreeMap<String, List<String>>();
			 sorted.putAll(formulaValues);
			 
			 /*for (String entry : sorted.keySet()) {
			   // String key = entry.toString();
			    //System.out.println("Key: "+key);
			    List<String> value = sorted.get(entry);
			    for(int i=0;i<value.size();i++)
			    {
			    	//System.out.println("Value: "+value.get(i));
			    }
			   
			}*/
			Row headeRow = null;
			for (String entry : sorted.keySet()) {
			    String key = entry.toString();
			    int startingcell=6;
			    if(key.contains("Header"))
			    {
			    	startingRow=startingRow+2;
			    }
			    if(key.contains("Row")||key.contains("Total"))
			    {
			    	startingRow=startingRow+1;
			    }
			    
			    headeRow= summarySheet.createRow(startingRow);
			    List<String> value = sorted.get(entry);
			    for(int i=0;i<value.size();i++)
			    {
			    	 if(key.contains("Header"))
					    {
					    	Cell intentCell=headeRow.createCell(startingcell++);
							intentCell.setCellStyle(headerRowstyle);
							intentCell.setCellValue(value.get(i));
					    }
			    	 if(key.contains("Row")||key.contains("Total"))
					    {
			    		 	Cell groupData=headeRow.createCell(startingcell++);
							groupData.setCellStyle(dataRowstyle);
							if(value.get(i).contains("COUNT"))
							{
								//System.out.println("Cell Value:"+value.get(i)+" Cell: "+startingcell);
								groupData.setCellFormula(value.get(i));	
							}else{
								groupData.setCellValue(value.get(i));
							}
						 }
			    }
			    for(int i=headeRow.getFirstCellNum();i<headeRow.getLastCellNum();i++)
				{
					workbook.getSheet(summarySheetName).autoSizeColumn(i);	
				}
			}
			
			 XSSFFormulaEvaluator.evaluateAllFormulaCells((XSSFWorkbook) workbook);	 /**Refresh excel**/
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		workbook.write(out);
		out.close();
	}
}
