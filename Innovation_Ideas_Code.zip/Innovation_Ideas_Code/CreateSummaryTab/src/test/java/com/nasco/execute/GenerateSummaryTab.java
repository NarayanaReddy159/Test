/*******************************************************************
 * GenerateSummaryTab Class for creating Summary tab in given excel*
 * Created by: K L Narayana Reddy **********************************
 *******************************************************************/
package com.nasco.execute;

public class GenerateSummaryTab {

	public static void main(String[] args) {
	
		SummaryTabCreate createSummary = new SummaryTabCreate();
		createSummary.getframe();
	}

}
