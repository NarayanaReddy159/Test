package com.nasco.Base;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.BeforeSuite;

import com.nasco.ExtentListeners.ExtentListeners;
import com.nasco.Run.RunTestNG_APITestScripts;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class BaseTest {
	
	public static Logger log = LogManager.getLogger(BaseTest.class.getName());
	 protected ExtentTest test;
   
	@BeforeSuite
	public void beforeSuite(){
		PropertyConfigurator.configure("log4j.properties");
	}
	
	public void extentLogWarning(String message) {
		
		ExtentListeners.testReport.get().log(LogStatus.WARNING, message);
	}

	public void configureLog4jLogging() {
		System.setProperty("log4j.configurationFile", System.getProperty("user.dir")+RunTestNG_APITestScripts.Config.getProperty("log4jPropertiesFilepath"));
	}

	
	
}
