package com.nasco.utilities;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;

import com.nasco.Run.RunTestNG_APITestScripts;

public class DataProviders {

	@DataProvider(name = "API_DP", parallel = false)
	public static Object[][] getDataW1(Method m) {

		ExcelReader excel = new ExcelReader(
				System.getProperty("user.dir") + RunTestNG_APITestScripts.Config.getProperty("TestData_XL_PATH"));
		String testcase = m.getName();
		return DataUtil.getData(testcase, excel);

	}
	
	
}
