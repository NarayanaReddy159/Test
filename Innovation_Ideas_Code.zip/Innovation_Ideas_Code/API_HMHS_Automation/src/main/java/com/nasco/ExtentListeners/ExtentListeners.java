package com.nasco.ExtentListeners;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.nasco.Run.RunTestNG_APITestScripts;
import com.nasco.utilities.DriverManager;
import com.nasco.utilities.EmailHTMLBuilder;
import com.nasco.utilities.EmailHTMLBuilder_Body;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class ExtentListeners implements ITestListener {

	static Date d = new Date();
	static String fileName = "Extent_" + d.toString().replace(":", "_").replace(" ", "_") + ".html";

	Map<String, List<String>> results = new HashMap<String, List<String>>();
	String status = "";
	String reportFileName = "GoldBase_NCompass_Automation_Execution_Report.xlsx";
	String reportFilePath = System.getProperty("user.dir") + RunTestNG_APITestScripts.Config.getProperty("ReportFile")
			+ reportFileName;
	String extentFilepath = System.getProperty("user.dir")
			+ RunTestNG_APITestScripts.Config.getProperty("EXTREPORT_LOC");
	public String timeStamp = new SimpleDateFormat("MM-dd-yyyy").format(Calendar.getInstance().getTime());
	public String timeStamp_email = timeStamp;
	EmailHTMLBuilder htmlbuilder_Summary = new EmailHTMLBuilder();
	EmailHTMLBuilder_Body htmlbuilder = new EmailHTMLBuilder_Body();
	DecimalFormat df = new DecimalFormat("###.##");
	String path1 = reportFileName.replace(".xlsx", "") + d.toString().replace(":", "_").replace(" ", "_") + ".xlsx";
	String reportFilePath1 = System.getProperty("user.dir") + RunTestNG_APITestScripts.Config.getProperty("ReportFile")
			+ path1;
	private static ExtentReports extent = ExtentManager.getInstance();
	public static ThreadLocal<ExtentTest> testReport = new ThreadLocal<ExtentTest>();

	
	String starttime="";
	String endTime="";
	
	public void onTestStart(ITestResult result) {
		ExtentTest test = extent.startTest("TestCase : " + result.getMethod().getMethodName());
		DriverManager.setExtentReport(test);
		testReport.set(DriverManager.getExtentReport());
	}

	public void onTestSuccess(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		testReport.get().log(LogStatus.PASS, methodName + " Test Case Passed");
		extent.endTest(testReport.get());
	}

	public void onTestFailure(ITestResult result) {

		String excepionMessage = Arrays.toString(result.getThrowable().getStackTrace());

		if (!excepionMessage.isEmpty())
			testReport.get().log(LogStatus.FAIL, excepionMessage);
		String methodName = result.getMethod().getMethodName();
		
		testReport.get().log(LogStatus.FAIL, methodName + " Test Case Failed");
		extent.endTest(testReport.get());
	}

	public void onTestSkipped(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		testReport.get().log(LogStatus.SKIP, methodName + " Test Case Skipped");
		extent.endTest(testReport.get());
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	public void onStart(ITestContext context) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
	    Date date = new Date(); 
	    starttime=formatter.format(date);
	}

	@SuppressWarnings("unused")
	public void onFinish(ITestContext context) {
		if (extent != null) {

			extent.flush();

			String path = System.getProperty("user.dir") + RunTestNG_APITestScripts.Config.getProperty("ReportFile");
			String filename_Attachment = ExtentManager.fileName;
			String suiteStatus_Subject;

			String Env_Subject = null;
			Env_Subject = RunTestNG_APITestScripts.Config.getProperty("Environment");

			if (status.equalsIgnoreCase("")) {
				suiteStatus_Subject = "PASS";
			} else
				suiteStatus_Subject = "FAIL";
			
			String htmlcontent = htmlbuilder_Summary.sb.toString();
			createApplicationLog();
			//EmailUtil.sendEmailWithAttachment(path,Env_Subject,suiteStatus_Subject,timeStamp_email,path1,htmlcontent,extentFilepath,filename_Attachment);

		}

	}

	


	public void createApplicationLog() {
		FileInputStream instream = null;
		FileOutputStream outstream = null;
		try {
			Date d = new Date();
			File infile = new File(System.getProperty("user.dir") + "/src/test/resources/logs/Application.log");
			File outfile = new File(System.getProperty("user.dir") + "/src/test/resources/logs/Application-"
					+ d.toString().replace(":", "_").replace(" ", "_") + ".log");
			instream = new FileInputStream(infile);
			outstream = new FileOutputStream(outfile);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = instream.read(buffer)) > 0) {
				outstream.write(buffer, 0, length);
			}
			instream.close();
			outstream.close();
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
	}
}
