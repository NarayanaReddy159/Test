package com.nasco.Setup;

import com.nasco.utilities.DriverManager;
import com.relevantcodes.extentreports.ExtentTest;

public abstract class BasePage<T> {

	protected ExtentTest test;
	
	
	public BasePage() {
		this.test = DriverManager.getExtentReport();
	}

	
}
