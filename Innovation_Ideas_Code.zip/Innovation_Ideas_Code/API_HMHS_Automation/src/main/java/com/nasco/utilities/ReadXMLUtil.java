package com.nasco.utilities;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ReadXMLUtil {
	public static void readXMLFile(String fileName)
    {
    	try   
    	{  
    	//creating a constructor of file class and parsing an XML file  
    	File file = new File(System.getProperty("user.dir")+"/"+fileName);  
    	//an instance of factory that gives a document builder  
    	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
    	//an instance of builder to parse the specified xml file  
    	DocumentBuilder db = dbf.newDocumentBuilder();  
    	Document doc = db.parse(file);  
    	doc.getDocumentElement().normalize();  
    	NodeList nodeList = doc.getElementsByTagName("mbr:Person");  
    	for (int itr = 0; itr < nodeList.getLength(); itr++)   
    	{  
    	Node node = nodeList.item(itr);  
    	if (node.getNodeType() == Node.ELEMENT_NODE)   
    	{  
    	Element eElement = (Element) node;  
    	System.out.println("Last Name: "+ eElement.getElementsByTagName("cmn:LastName").item(0).getTextContent());
    	System.out.println("First Name: "+ eElement.getElementsByTagName("cmn:FirstName").item(0).getTextContent());
    	System.out.println("Middle Name: "+ eElement.getElementsByTagName("cmn:MiddleName").item(0).getTextContent());
    	System.out.println("DOB: "+ eElement.getElementsByTagName("person:BirthDate").item(0).getTextContent());
    	System.out.println("Gender Code: "+ eElement.getElementsByTagName("person:GenderCode").item(0).getTextContent());
    	System.out.println("AddressLine1: "+ eElement.getElementsByTagName("add:AddressLine1").item(0).getTextContent());
    	System.out.println("AddressLine2: "+ eElement.getElementsByTagName("add:AddressLine2").item(0).getTextContent());
    	System.out.println("AddressLine3: "+ eElement.getElementsByTagName("add:AddressLine3").item(0).getTextContent());
    	System.out.println("AddressLine4: "+ eElement.getElementsByTagName("add:AddressLine4").item(0).getTextContent());
    	System.out.println("AddressTypeCode: "+ eElement.getElementsByTagName("add:AddressTypeCode").item(0).getTextContent());
    	System.out.println("AddressTypeCodeDescription: "+ eElement.getElementsByTagName("add:AddressTypeCodeDescription").item(0).getTextContent());
    	System.out.println("City: "+ eElement.getElementsByTagName("add:City").item(0).getTextContent());
    	System.out.println("State: "+ eElement.getElementsByTagName("add:State").item(0).getTextContent());
    	System.out.println("PostalCode: "+ eElement.getElementsByTagName("add:PostalCode").item(0).getTextContent());
    	System.out.println("CountryName: "+ eElement.getElementsByTagName("add:CountryName").item(0).getTextContent());
    	System.out.println("CountryNameDescription: "+ eElement.getElementsByTagName("add:CountryNameDescription").item(0).getTextContent());
    	
    	}  
    	}  
    	}   
    	catch (Exception e)   
    	{  
    	e.printStackTrace();  
    	} 
    }
}
