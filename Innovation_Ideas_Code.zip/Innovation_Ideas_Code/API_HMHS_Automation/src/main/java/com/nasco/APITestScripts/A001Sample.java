package com.nasco.APITestScripts;

import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.Base.BaseTest;
import com.nasco.utilities.CreateFileUtil;
import com.nasco.utilities.DataProviders;
import com.nasco.utilities.DriverManager;
import com.nasco.utilities.ReadXMLUtil;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class A001Sample extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "API_DP") //Hashtable<String, String> data
	public void AUTC001_A001Sample() throws Exception {
		RestAssured.baseURI="https://10.201.114.132";
		try{
			//System.out.println(data);
			test = DriverManager.getExtentReport();
			
			String homeplancode="865",WorkPlanCode="865",OriginatingAppName="NCOMPASS",
	    			OriginatingUserName="SOAPUI",TransactionId="1234";
	    	String ControlPlanCode="780",ExternalContractID="115794046001",
	    			BeginDate="2020-01-01",EndDate="2020-12-31";
	    	
	    	String myEnvelope = "<soap:Envelope xmlns:soap='http://www.w3.org/2003/05/soap-envelope' xmlns:req='http://www.nasco.com/common/schema/message/requestheader' xmlns:nas='http://www.nasco.com/common/schema/message/nascoheader_v2' xmlns:cs='http://www.nasco.com/internal/customerservicing/schema/member/cs_searchmemberrequest_v2' xmlns:cs1='http://www.nasco.com/internal/customerservicing/schema/common/cs_common_v2'><soap:Header><req:NASCOHeader><nas:SenderInfo>"
	    			+ "<nas:HomePlanCode>"+homeplancode+"</nas:HomePlanCode>"
	    			+ "<nas:WorkPlanCode>"+WorkPlanCode+"</nas:WorkPlanCode>"
	    			+ "<nas:OriginatingAppName>"+OriginatingAppName+"</nas:OriginatingAppName>"
	    			+ "<nas:OriginatingUserName>"+OriginatingUserName+"</nas:OriginatingUserName>"
	    			+ "</nas:SenderInfo><nas:TransactionId>"+TransactionId+"</nas:TransactionId>"
	    			+ "</req:NASCOHeader>"
	    			+ "</soap:Header>"
	    			+ "<soap:Body>"
	    			+ "<cs:SearchMemberRequest>"
	    			+ "<cs:ControlPlanCode>"+ControlPlanCode+"</cs:ControlPlanCode>"
	    			+ "<cs:ContractID>"
	    			+ "<cs1:ExternalContractID>"+ExternalContractID+"</cs1:ExternalContractID>"
	    			+ "<cs:DateRange>"
	    			+ "<cs1:BeginDate>"+BeginDate+"</cs1:BeginDate>"
	    			+ "<cs1:EndDate>"+EndDate+"</cs1:EndDate>"
	    			+ "</cs:DateRange></cs:ContractID></cs:SearchMemberRequest></soap:Body></soap:Envelope>";

	    	CreateFileUtil.createandwriteFile("SoapRequestFile.xml",myEnvelope);
	    	FileInputStream fileinputStream = new FileInputStream(System.getProperty("user.dir")+"//SoapRequestFile.xml");
	    	System.out.println(myEnvelope);
	    	
	    	
	    	Response response=
	    			given()
	    			.relaxedHTTPSValidation()
	    			.header("Content-Type","text/xml")
	    			.header("Authorization","Bearer eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCIsIng1dCI6ImVoQW9uRkltRllGQjg5bUNGWDVTMmFWcFZqZyIsImtpZCI6Im9yYWtleSJ9.eyJ1aWQiOiJ2aWQ5MjY5Iiwic3ViIjoidmlkOTI2OSIsInNuIjoiS3VzdW1hIiwib3JhY2xlLm9hdXRoLnVzZXJfb3JpZ2luX2lkX3R5cGUiOiJMREFQX1VJRCIsIm9yYWNsZS5vYXV0aC51c2VyX29yaWdpbl9pZCI6InZpZDkyNjkiLCJpc3MiOiJvYXV0aHFhLmhpZ2htYXJrLmNvbSIsImdpdmVubmFtZSI6IlJhamVzaCIsIm9yYWNsZS5vYXV0aC5zdmNfcF9uIjoiTkFTQ09TZXJ2aWNlUHJvZmlsZSIsImlhdCI6MTYyMzMwMzEzOSwib3JhY2xlLm9hdXRoLnBybi5pZF90eXBlIjoiTERBUF9VSUQiLCJvcmFjbGUub2F1dGgudGtfY29udGV4dCI6InJlc291cmNlX2FjY2Vzc190ayIsImV4cCI6MTYyMzMzMTkzOSwicHJuIjoidmlkOTI2OSIsImp0aSI6IjIyMzE4NDdkLWZiNWQtNGY2OS05MmUwLTE2NDkwYmNhMmMyNiIsIm9yYWNsZS5vYXV0aC5zY29wZSI6Im5hc2NvVGVzdC5yZWFkT25seSIsIm9yYWNsZS5vYXV0aC5jbGllbnRfb3JpZ2luX2lkIjoiNDNhNzk2NjktZmU3NS00NTc5LTgwODYtZDllOGYzODZkZDI5IiwiaXNtZW1iZXJvZiI6IkNMTS1DbGFpbXMgSW5xdWlyZXItSU5ULCBDTE0tQ2xhaW1zIElucXVpcmVyLUhMVEhTVkNfMDEtSU5ULCBDTE0tQ2xhaW1zIElucXVpcmVyLU1TQkNCU18wMy1JTlQsIEZJTkFOQ0UtSU5RVUlSWS1ITUFSSy1FTlRJVElFUy1JTlQsIENMTS1DbGFpbXMgSW5xdWlyZXItQkNCU0RFXzA3LUlOVCwgTkNILUJhY2tPZmZpY2VTVS1JTlQsIEVEUi1BcHBsaWNhdGlvbiBUZXN0ZXItSU5ULCBOQ0gtQXBwbGljYXRpb24gVGVzdGVyLUlOVCwgTkNILUZ1bmN0aW9uYWxCQS1JTlQsIE5DSC1NYW5hZ2VyLUlOVCwgTkNILUJhY2tPZmZpY2UtSU5ULCBOQ0gtRGV2ZWxvcGVyLUlOVCwgTkNILUNvbW1hbmRDZW50ZXItSU5ULCBOQ0gtRGV2QkEtSU5ULCBOQ0gtQ1NSLUlOVCwgRFItMDIgQUEtRFlOLCBEUi0wMSAwLURZTiwgSUNJUyB0byBPU0NBUiBWaWV3IFRleHQgT25seS1JTlQsIFNWUC1BQ0NFU1MtSU5ULCBTVlAtRXh0ZXJuYWwgVXNlci1JTlQsIEZpbmFuY2UgQ29tcGFueSBQYXltZW50IFNlcnZpY2VzLUlOVCwgQ2FtcGFpZ24gTWFuYWdlci1JTlNJTlEgQmFzZS1JTlQsIERSLVN1cGVydXNlci1IZWFsdGggU3ZjIENsYWltLUNTRC1SZWFkLUlOVCwgRFItU3VwZXJ1c2VyLU1lbWJlci1DU0QtUmVhZC1JTlQsIERSLVN1cGVydXNlci1JVFMgQmx1ZSBTcXVhcmVkLUNTRC1SZWFkLUlOVCwgRFItU3VwZXJ1c2VyLUlucXVpcnktQ1NELVJlYWQtSU5ULCBEUi1TdXBlcnVzZXItTWFuYWdlZCBDYXJlIFJlY29yZHMtQ1NELVJlYWQtSU5ULCBEUi1TdXBlcnVzZXItTWVkaWNhbCBSZXZpZXcgUmVjb3Jkcy1DU0QtUmVhZC1JTlQsIEVEUi1CUEQtSGlnaG1hcmsgSGVhbHRoIFBsYW4tSU5ULCBFRFItQlBELVVDQ0ktSU5ULCBFRFItQlBELUhpZ2htYXJrIFdWLUlOVCwgRURSLUJQRC1DYXJlRmlyc3QtSU5ULCBFRFItQlBELUJDQlMgb2YgTG91aXNpYW5hLUlOVCwgRURSLUJQRC1JbmRlcGVuZGVuY2UgQkMtSU5ULCBFRFItRW5yU3JjLTAwNSBVQ0NJLUlOVCwgRURSLUVuclNyYy0wNzEgRGVsYXdhcmUgTWVkaWNhaWQtSU5ULCBFRFItRW5yU3JjLTA4NiBQQSBGRVAtSU5ULCBFRFItRW5yU3JjLTM2MiBJbmRlcGVuZGVuY2UgQmx1ZSBDcm9zcy1JTlQsIEVEUi1FbnJTcmMtMzYzIEhpZ2htYXJrIEJDQlMtSU5ULCBFRFItRW5yU3JjLTM2NCBORVBBLUlOVCwgRURSLUVuclNyYy0zNzUgQW1lcmloZWFsdGggTkotSU5ULCBFRFItRW5yU3JjLTM3NyBISElDLUlOVCwgRURSLUVuclNyYy01NzAgQkNCU0RFIEZFUC1JTlQsIEVEUi1FbnJTcmMtOTQ0IEhpZ2htYXJrIEJDQlNXViBGRVAtSU5ULCBFRFItRW5yU3JjLTk0NSBXZXN0IFZpcmdpbmlhIE1lZGljYWlkLUlOVCwgRURSLUVuclNyYy05OTkgT3V0T2ZBcmVhLUlOVCwgTkNILUJhY2tPZmZpY2VTVS1JTlQiLCJvcmFjbGUub2F1dGguaWRfZF9pZCI6IjU1NzllNDQ0LWQ5MjEtNDVmMC1hN2JmLWViYjU5ZTNmNzJiZCIsInVzZXIudGVuYW50Lm5hbWUiOiJOQVNDTyJ9.f6C1i76cqppTuhpxPhfp9g0YtmjLpB4x6Lqegnji2yIHdRWIsMQWMjvnf9BL8jdHPM7colqNBWnPxc2vpWlgTO9V4rGGLIFqosFZjMc1xp8PctGuKmFCutXI5UXANEQZp65nvRxqjSF9k-ESKG8-i66r9JviroXoo6j9zkxnNtM")
	    			.and()
	    			.body(IOUtils.toString(fileinputStream,"UTF-8"))//myEnvelope
	    			//.config(RestAssuredConfig.config().xmlConfig(XmlConfig.xmlConfig().disableLoadingOfExternalDtd()))
	    			.when()
	    			.post("/wsdl/CSMemberInquiry_v5")
	    			.then()
	    			//.log().all()
	    			.extract().response();
	    	
	    	response.then().statusCode(200);
	    	System.out.println("time taken: "+response.timeIn(TimeUnit.SECONDS)+ "Seconds");
	    	CreateFileUtil.createandwriteFile("SoapResponseFile.xml",response.asString());
	    	ReadXMLUtil.readXMLFile("SoapResponseFile.xml");
	    	CreateFileUtil.deleteFile("SoapResponseFile.xml");	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		

	}

	@AfterMethod
	public void tearDown() {

		

	}
}
