package com.nasco.utilities;

import com.relevantcodes.extentreports.ExtentTest;

public class DriverManager {

	public static ThreadLocal<ExtentTest> testReport = new ThreadLocal<ExtentTest>();

	public static ExtentTest getExtentReport() {

		return testReport.get();
	}

	public static void setExtentReport(ExtentTest test) {

		testReport.set(test);

	}

	

}
