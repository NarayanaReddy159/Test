package com.nasco.ExtentListeners;

import java.io.File;
import java.util.Date;

import com.nasco.Run.RunTestNG_APITestScripts;
import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;

public class ExtentManager {
	private static ExtentReports extent;
	public static String fileName;
	public static String logFileName;

	public static ExtentReports getInstance() {

		if (extent == null) {
			Date d = new Date();
			fileName = "NCompass_GoldBase_ExtentReport" + d.toString().replace(":", "_").replace(" ", "_") + ".html";
			logFileName = System.getProperty("user.dir") + "src/test/resources/logs/Application"
					+ d.toString().replace(":", "_").replace(" ", "_") + ".log";
			extent = new ExtentReports(System.getProperty("user.dir")
					+ RunTestNG_APITestScripts.Config.getProperty("EXTREPORT_LOC") + fileName, true,
					DisplayOrder.OLDEST_FIRST);
			extent.loadConfig(new File(
					System.getProperty("user.dir") + RunTestNG_APITestScripts.Config.getProperty("EXTREPORTCONFIG")));
		}

		return extent;

	}
	
	
}
