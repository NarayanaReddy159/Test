package com.nasco.utilities;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreateFileUtil {
	
	public static void createandwriteFile(String fileName, String filecontent)
    {
    	try {
		      File myObj = new File(System.getProperty("user.dir")+"/"+fileName);
		      if (myObj.createNewFile()) {
		      } else {
		      }
		    } catch (IOException e) {
		      e.printStackTrace();
		    }
		try {
		      FileWriter myWriter = new FileWriter(System.getProperty("user.dir")+"/"+fileName);
		      myWriter.write(filecontent);
		      myWriter.close();
		     } catch (IOException e) {
		      e.printStackTrace();
		    }
    }
	
	public static void deleteFile(String fileName)
    {
    	try{
    		File newFile= new File(System.getProperty("user.dir")+"/"+fileName);
			newFile.delete();
    	}
    	catch(Exception e)
    	{
    		
    	}
    }
}
