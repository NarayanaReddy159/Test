package com.nasco.utils;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class CreateOptionPane {

	
	public static void optionPane(String message)
	{
		JFrame f= new JFrame();
		JOptionPane.showMessageDialog(f, message);
		
	}
	

}
