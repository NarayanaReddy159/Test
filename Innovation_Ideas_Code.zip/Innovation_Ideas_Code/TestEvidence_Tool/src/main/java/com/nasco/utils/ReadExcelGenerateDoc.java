package com.nasco.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Hashtable;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;



public class ReadExcelGenerateDoc {
	/*
	 * public List<String> readLines(File filename) throws Exception {
	 * BufferedReader bufferedReader = new BufferedReader(new FileReader(filename));
	 * List<String> lines =
	 * bufferedReader.lines().filter(Objects::nonNull).collect(Collectors.toList());
	 * bufferedReader.close(); return lines; }
	 */

	public static void generateDoc() throws Exception {
		Properties prop= new Properties();
		
	    FileInputStream input = new FileInputStream(System.getProperty("user.dir")+"//config.properties");
	    prop.load(input);
	    String filepath=prop.get("FilePath").toString();
	    String fileName=Paths.get(filepath).getFileName().toString();
	    String interaction= prop.get("Interaction").toString();
	    String intent= prop.get("Intent").toString();
	    String planName=prop.get("PlanName").toString();
	    String sheetName=prop.get("SheetName").toString();
	    String testCase=prop.get("TestCase").toString();
	    String testScenario=prop.get("TestScenario").toString();
	    String testObjective=prop.get("TestObjective").toString();
	    String expectedResults=prop.get("ExpectedResults").toString();
	    String actualResults=prop.get("ActualResults").toString();;
	    String status=prop.get("Status").toString();
	    String testSteps=prop.get("TestSteps").toString();
	    String dataForTest=prop.get("TestData").toString();
	    String testingPhase=prop.get("TestingPhase").toString();
	    String release=prop.get("Release").toString();
	    String cycle=prop.get("Cycle").toString();
	    String testscenario="";
	    String releaseValue="";
	    String cycleValue="";
	    
	    FileInputStream fis=null;
	    try{
	    	fis = new FileInputStream(filepath);
	    }
	    catch(Exception e)
	    {
	    	throw new MyException("File not found please check file existence if file is present then in file path replace \\ with / or \\\\");
	    }
		 
		Workbook workbook = new XSSFWorkbook(fis);
		Sheet sheet = workbook.getSheet(sheetName);
		int testRows =0;
		try{
			testRows =sheet.getLastRowNum();
		}catch(Exception e)
		{
			String message="";
			String [] sheets=sheetName.split(" ");
			if(sheets.length>1)
			{
				message="Remove Space in the SheetName update excel and config and rerun";
			}else{
				message="Sheet "+sheetName+" not found in the excel please check";
			}
			throw new MyException(message);
		}
		 
		int dataStartRowNum = 1;
		int testCols = 0;
		testCols = sheet.getRow(0).getLastCellNum();
		for (int rNum = dataStartRowNum; rNum <= testRows; rNum++) {
			Hashtable<String, String> table = new Hashtable<String, String>();
			for (int cNum = 0; cNum < testCols; cNum++) {
				String colName = "";
				String testData = "";
				try {
					colName = sheet.getRow(0).getCell(cNum).toString();
					testData = sheet.getRow(rNum).getCell(cNum).toString();
				} catch (Exception e1) {
				}
				table.put(colName, testData);
			}
			try{
				if(!table.get(testCase).equals(""))
				{
				}
				
			}
			catch(Exception e)
			{
				throw new MyException("Test case ID column name is mismatched, Plase check check and update form the test matrix including spaces");
			}
			try{
				if(!table.get(testScenario).equals(""))
				{
					testscenario=table.get(testScenario);
				}
			}
			catch(Exception e)
			{
				throw new MyException("Test Scenario ID column name is mismatched, Plase check check and update form the test matrix including spaces");
			}
			try{
				if(!table.get(dataForTest).equals(""))
				{
				}
			}
			catch(Exception e)
			{
				throw new MyException("Test Data column name is mismatched, Plase check check and update form the test matrix including spaces");
			}
			try{
				if(!table.get(testObjective).equals(""))
				{
				}
			}
			catch(Exception e)
			{
				throw new MyException("Test Objective column name is mismatched, Plase check check and update form the test matrix including spaces");
			}
			try{
				if(!table.get(expectedResults).equals(""))
				{
				}
			}
			catch(Exception e)
			{
				throw new MyException("Expected Results column name is mismatched, Plase check check and update form the test matrix including spaces");
			}
			try{
				if(!table.get(actualResults).equals(""))
				{
				}
			}
			catch(Exception e)
			{
				throw new MyException("Actual Results column name is mismatched, Plase check check and update form the test matrix including spaces");
			}
			try{
				if(!table.get(status).equals(""))
				{
				}
			}
			catch(Exception e)
			{
				throw new MyException("Status column name is mismatched, Plase check check and update form the test matrix including spaces");
			}
			try{
				if(!table.get(testSteps).equals(""))
				{
				}
			}
			catch(Exception e)
			{
				throw new MyException("Test Steps column name is mismatched, Plase check check and update form the test matrix including spaces");
			}
			if (!Paths.get("./GeneratedDocs").toFile().exists())
				Files.createDirectories(Paths.get("./GeneratedDocs"));
			
			if(!table.get(testCase).equals("")){
				XWPFDocument document = new XWPFDocument();
				FileOutputStream out = new FileOutputStream(
						"GeneratedDocs/" + testingPhase+"_"+intent+"_" + table.get(testCase) + ".docx");
				addParagraphSetText(document, "Test Matrix File name < " + fileName + " >");
				XWPFTable pfttable = document.createTable();
				pfttable.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
				XWPFTableRow tableRowOne = pfttable.getRow(0);
				tableRowOne.getCell(0).setText(" Test Scenario# : " + testscenario);
				tableRowOne.addNewTableCell().setText(" Intent: " + interaction + "-" + intent);
				addTableRow(pfttable, " Test case ID: " + table.get(testCase), " Sprint#:");
				addTableRow(pfttable, " Defect ID:", " Plan: " + planName);
				try{
					if(!release.equals(""))
					{
						releaseValue=table.get(release);
						if(table.get(release).equals(null))
						{
							releaseValue=release;
						}
					}
					
				}
				catch(Exception e1)
				{
					releaseValue=release;
				}
				try{
					if(!cycle.equals(""))
					{
						cycleValue=table.get(cycle);
						if(table.get(cycle).equals(null))
						{
							cycleValue=cycle;
						}
					}
				}
				catch(Exception e1)
				{
					cycleValue=cycle;
				}
				addTableRow(pfttable, " Release: "+releaseValue, " Cycle: "+ cycleValue);
				addTableRow(pfttable, " Quality Reviewer: ", "Approve Date: ");
				addParagraphBreakTest(document);
				addParagraphBold(document, "Type of Interaction: ",interaction);
				addParagraphBold(document, "Test Data: ",table.get(dataForTest));
				addParagraphSetText(document, "� Member id:");
				addParagraphSetText(document, "� Claim Number:");
				addParagraphBold(document, "Test case: ",table.get(testCase));
				addParagraphBold(document, "Test Objective:  ",table.get(testObjective));
				addParagraphBold(document, "Expected Result: ", table.get(expectedResults));
				addParagraphBold(document, "Actual Result: ",table.get(actualResults));
				addParagraphBold(document, "Status:  " + table.get(status));
				addParagraphBold(document, "Screen shots:  ", "See screen shots below for reference");
				addParagraphBold(document, "Letter Template Evidence:   ","NA");
				addParagraphBold(document, "Screen shots provided:  ");
				String s = table.get(testSteps);
				String[] s1 = s.split("\n");
				if(s1.length>0)
				{
					for (int i = 0; i < s1.length; i++) {
						addParagraphSetText(document, s1[i]);
					}
					
				}
				else{
					addParagraphSetText(document, s);
				}
				document.write(out);
	            out.close();
			}
			
            fis.close();
       }
		
	}

	public static void addParagraphBreakTest(XWPFDocument document) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.addBreak();
	}

	public static void addParagraphBold(XWPFDocument document, String textToSet) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.setBold(true);
		run.setText(textToSet);
	}
	
	public static void addParagraphBold(XWPFDocument document, String boldText, String plainText) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.setBold(true);
		run.setText(boldText);
		XWPFRun run1 = paragraph.createRun();
		run1.setText(plainText);
	}

	public static void addParagraphSetText(XWPFDocument document, String textToSet) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.setText(textToSet);
	}

	public static void addTableRow(XWPFTable table, String cellOValue, String cell1Value) {
		XWPFTableRow tableRow = table.createRow();
		tableRow.getCell(0).setText(cellOValue);
		tableRow.getCell(1).setText(cell1Value);
	}

}