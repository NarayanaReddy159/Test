package com.nasco.utils;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;


@SuppressWarnings({ "rawtypes", "unchecked" })
public class TestEvidenceToolFrame implements ActionListener{
	public JFrame jframe;
	JButton button,GenerateReportBtn;
	public JTextField relaseText,cycleText,interationTF,intentTF,planNameTF,testingPhaseTF;
	String filepath="";
	String fileName="";
	String sheetName="";
	String testCase="";
    String testScenario="";
    String testObjective="";
    String expectedResults="";
    String actualResults="";
    String status="";
    String testSteps="";
    String dataForTest="";
    String testingPhase="";
    String release="";
    String cycle="";
    String interaction="";
    String intent="";
    String planName="";
    

    public void getFrame()
    {
    	jframe= new JFrame();
    	jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jframe.setLayout(new FlowLayout());
    	jframe.setPreferredSize(new Dimension(780,620));
    	jframe.setTitle("Test Evidence genrate Tool");
		JLabel fileChooseLable= new JLabel("File to upload: ");
		button = new JButton("Choose File");
		button.addActionListener(this);
		jframe.add(fileChooseLable);
		jframe.setBounds(250, 20, 50, 20);
		fileChooseLable.setBounds(10, 15, 250, 25);
		button.setBounds(200,15,150,30);
		jframe.add(button);
		relaseText= new JTextField(50);
		cycleText= new JTextField(50);
		interationTF= new JTextField(50);
		jframe.add(interationTF);
		intentTF= new JTextField(50);
		jframe.add(intentTF);
		testingPhaseTF= new JTextField(50);
		jframe.add(testingPhaseTF);
		planNameTF= new JTextField(50);
		jframe.add(planNameTF);
		GenerateReportBtn= new JButton("Generate Docs");
		jframe.add(GenerateReportBtn);
		jframe.add(relaseText);
		jframe.add(cycleText);
		jframe.setLayout(null);
		jframe.pack();
		jframe.setVisible(true);
    }
    
	public TestEvidenceToolFrame(){		
		
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==button) {
			
			JFileChooser fileChooser = new JFileChooser();
			
			fileChooser.setCurrentDirectory(new File(".")); 
			
			int response = fileChooser.showOpenDialog(null); 
			
			if(response == JFileChooser.APPROVE_OPTION) {
				File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
				filepath=file.getAbsolutePath();
				fileName=Paths.get(filepath).getFileName().toString();
				try {
					List<String>sheets= getSheetNames(filepath);
					JLabel sheetsLabel= new JLabel("Choose Sheet Name:");
					jframe.add(sheetsLabel);
					sheetsLabel.setBounds(10, 50, 250, 25);
					final JComboBox excelSheets= new JComboBox(sheets.toArray()); 
					excelSheets.setBounds(200,50,300,30);
					jframe.add(excelSheets);
					SwingUtilities.updateComponentTreeUI(jframe);
					excelSheets.addActionListener( new ActionListener() {
						 public void actionPerformed(ActionEvent e) {
							sheetName= String.valueOf(excelSheets.getSelectedItem());
							String [] spaceSheet=sheetName.split(" ");
							if(spaceSheet.length==1)
							{
								try {
									List<String> headers=getHeaders(filepath);
									JLabel testCaseIdLabel= new JLabel("Choose Test case id:");
									jframe.add(testCaseIdLabel);
									testCaseIdLabel.setBounds(10, 85, 250, 25);
									final JComboBox testCaseIdCB= new JComboBox(headers.toArray()); 
									jframe.add(testCaseIdCB);
									testCaseIdCB.setBounds(200, 85, 300, 35);
									JLabel testScenarioIdLabel= new JLabel("Choose Test Scenario id:");
									jframe.add(testScenarioIdLabel);
									testScenarioIdLabel.setBounds(10, 130, 250, 25);
									final JComboBox testScenarioIdCB= new JComboBox(headers.toArray()); 
									jframe.add(testScenarioIdCB);
									testScenarioIdCB.setBounds(200, 130, 300, 35);
									JLabel testObjectiveLabel= new JLabel("Choose Test Objective:");
									jframe.add(testObjectiveLabel);
									testObjectiveLabel.setBounds(10, 175, 250, 25);
									final JComboBox testObjectiveCB= new JComboBox(headers.toArray()); 
									jframe.add(testObjectiveCB);
									testObjectiveCB.setBounds(200, 175, 300, 35);
									JLabel testDataLabel= new JLabel("Choose Test Data:");
									jframe.add(testDataLabel);
									testDataLabel.setBounds(10, 220, 250, 25);
									final JComboBox testDataCB= new JComboBox(headers.toArray()); 
									jframe.add(testDataCB);
									testDataCB.setBounds(200, 220, 300, 35);
									JLabel testStepsLabel= new JLabel("Choose Test Steps:");
									jframe.add(testStepsLabel);
									testStepsLabel.setBounds(10, 265, 250, 25);
									final JComboBox testStepsCB= new JComboBox(headers.toArray()); 
									jframe.add(testStepsCB);
									testStepsCB.setBounds(200, 265, 300, 35);
									JLabel expectedResultsLabel= new JLabel("Choose Expected Results:");
									jframe.add(expectedResultsLabel);
									expectedResultsLabel.setBounds(10, 310, 250, 25);
									final JComboBox expectedResultsCB= new JComboBox(headers.toArray()); 
									jframe.add(expectedResultsCB);
									expectedResultsCB.setBounds(200, 310, 300, 35);
									JLabel actualResultsLabel= new JLabel("Choose Actual Results:");
									jframe.add(actualResultsLabel);
									actualResultsLabel.setBounds(10, 355, 250, 25);
									final JComboBox actualResultsCB= new JComboBox(headers.toArray()); 
									jframe.add(actualResultsCB);
									actualResultsCB.setBounds(200, 355, 300, 35);
									JLabel statusLabel= new JLabel("Choose Status:");
									jframe.add(statusLabel);
									statusLabel.setBounds(10, 400, 250, 25);
									final JComboBox statusCB= new JComboBox(headers.toArray()); 
									jframe.add(statusCB);
									statusCB.setBounds(200, 400, 300, 35);
									JLabel releaseLabel= new JLabel("Choose Release:");
									jframe.add(releaseLabel);
									releaseLabel.setBounds(10, 445, 250, 25);
									final JComboBox releaseCB= new JComboBox(headers.toArray()); 
									jframe.add(releaseCB);
									releaseCB.setBounds(200, 445, 300, 35);
									JLabel cycleLabel= new JLabel("Choose Cycle:");
									jframe.add(cycleLabel);
									cycleLabel.setBounds(10, 490, 250, 25);
									final JComboBox cycleCB= new JComboBox(headers.toArray()); 
									jframe.add(cycleCB);
									cycleCB.setBounds(200, 490, 300, 35);
									JLabel interactionLabel= new JLabel("Interaction:");
									jframe.add(interactionLabel);
									interactionLabel.setBounds(560, 55, 125, 25);
									jframe.add(interationTF);
									final JComboBox interactionCB= new JComboBox(headers.toArray());
									jframe.add(interactionCB);
									interactionCB.setBounds(530, 90, 150, 25);
									interactionCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											interaction=String.valueOf(interactionCB.getSelectedItem());
											if(interaction.equals("No value to select"))
											{
												interationTF.setBounds(530, 120, 150, 25);
												SwingUtilities.updateComponentTreeUI(jframe);
											}
										}
									});
									
									JLabel intentLabel= new JLabel("Intent:");
									jframe.add(intentLabel);
									intentLabel.setBounds(560, 150, 125, 25);
									jframe.add(intentTF);
									final JComboBox intentCB= new JComboBox(headers.toArray());
									jframe.add(intentCB);
									intentCB.setBounds(530, 180, 150, 25);
									intentCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											intent=String.valueOf(intentCB.getSelectedItem());
											if(intent.equals("No value to select"))
											{
												intentTF.setBounds(530, 210, 150, 25);
												SwingUtilities.updateComponentTreeUI(jframe);
											}
										}
									});
									
									JLabel planNameLabel= new JLabel("Plan Name:");
									jframe.add(planNameLabel);
									planNameLabel.setBounds(560, 240, 125, 25);
									jframe.add(planNameTF);
									planNameTF.setBounds(530, 270, 150, 25);
									JLabel testingPhaseLabel= new JLabel("Testing Phase:");
									jframe.add(testingPhaseLabel);
									testingPhaseLabel.setBounds(560, 300, 125, 25);
									jframe.add(testingPhaseTF);
									testingPhaseTF.setBounds(530, 330, 150, 25);
									GenerateReportBtn.setBounds(250,540,150,30);
									SwingUtilities.updateComponentTreeUI(jframe);
									GenerateReportBtn.addActionListener(new ActionListener() {
										
										public void actionPerformed(ActionEvent e) {
											if(release.equals("No value to select"))
											{
											release=relaseText.getText();
											}
											if(cycle.equals("No value to select"))
											{
												cycle=cycleText.getText();
											}
											if(interaction.equals("No value to select"))
											{
												interaction=interationTF.getText();
											}
											intent=intentTF.getText();
											planName=planNameTF.getText();
											testingPhase=testingPhaseTF.getText();
											generateReport(filepath, interaction, intent, planName, 										sheetName, testCase, testScenario, testObjective, 										expectedResults, actualResults, status, testSteps, dataForTest, 										testingPhase, release, cycle);
											jframe.dispose();
											CreateOptionPane.optionPane("Test Evidence docs are generated, please check @ GeneratedDocs folder");
										}
									});
									releaseCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											release=String.valueOf(releaseCB.getSelectedItem());
											if(release.equals("No value to select"))
											{
												relaseText.setBounds(530, 445, 150, 25);
												SwingUtilities.updateComponentTreeUI(jframe);
											}
										}
									});
									
									cycleCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											cycle=String.valueOf(cycleCB.getSelectedItem());
											if(cycle.equals("No value to select"))
											{
												cycleText.setBounds(530, 490, 150, 25);
												SwingUtilities.updateComponentTreeUI(jframe);
											}
										}
									});
									
									
									
									testCaseIdCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											testCase=String.valueOf(testCaseIdCB.getSelectedItem());
										}
									});
									
									testScenarioIdCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											testScenario=String.valueOf(testScenarioIdCB.getSelectedItem());
										}
									});
									
									testObjectiveCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											testObjective=String.valueOf(testObjectiveCB.getSelectedItem());
										}
									});
									
									expectedResultsCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											expectedResults=String.valueOf(expectedResultsCB.getSelectedItem());
										}
									});
									
									actualResultsCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											actualResults=String.valueOf(actualResultsCB.getSelectedItem());
										}
									});
									
									statusCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											status=String.valueOf(statusCB.getSelectedItem());
										}
									});
									
									testStepsCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											testSteps=String.valueOf(testStepsCB.getSelectedItem());
										}
									});
									
									testDataCB.addActionListener( new ActionListener() {
										public void actionPerformed(ActionEvent e) {
											dataForTest=String.valueOf(testDataCB.getSelectedItem());
										}
									});
									
								} catch (Exception e1) {
								e1.printStackTrace();
									jframe.dispose();
									CreateOptionPane.optionPane("No Header values present in the selected sheet,  please check and re run by selecting correct sheet");
								}
							}
							else{
								jframe.dispose();
								CreateOptionPane.optionPane("Sheet Name is having spaces, please update without spaces and re run");
							}
						}
					 }	);
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
				
				
			}
		}
		
		
		
	}
	
	public List<String> getSheetNames(String Filepath) throws Exception
	{
		List<String> sheetNames= new ArrayList<String>();
		FileInputStream fis=new FileInputStream(Filepath);
		Workbook workbook = new XSSFWorkbook(fis);
		sheetNames.add("Select Sheet");
		for(int i=0;i<workbook.getNumberOfSheets();i++)
		{
			sheetNames.add(workbook.getSheetName(i));
		}
		fis.close();
		return sheetNames;
	}
	
	public void generateReport(String filepath,String interaction,String intent,
			String planName,String sheetName,String testCase,String testScenario,String testObjective,
			String expectedResults,String actualResults, String status,String testSteps, String 			dataForTest,String testingPhase,String release,String cycle
			)
	{
		String fileName=Paths.get(filepath).getFileName().toString();
		String releaseValue="";
		String cycleValue="";
		try{
			 FileInputStream fis=new FileInputStream(filepath);
			 Workbook workbook = new XSSFWorkbook(fis);
			Sheet sheet = workbook.getSheet(sheetName);
			int testRows=sheet.getLastRowNum();
			int dataStartRowNum = 1;
			int testCols = 0;
			testCols = sheet.getRow(0).getLastCellNum();
			for (int rNum = dataStartRowNum; rNum <= testRows; rNum++) {
				Hashtable<String, String> table = new Hashtable<String, String>();
				for (int cNum = 0; cNum < testCols; cNum++) {
					String colName = "";
					String testData = "";
					try {
						colName = sheet.getRow(0).getCell(cNum).toString();
						testData = sheet.getRow(rNum).getCell(cNum).toString();
					} catch (Exception e1) {
					}
					table.put(colName, testData);
				}
				
				
				if (!Paths.get("./GeneratedDocs").toFile().exists())
					Files.createDirectories(Paths.get("./GeneratedDocs"));
				
				if(!table.get(testCase).equals("")){
					XWPFDocument document = new XWPFDocument();
					FileOutputStream out = new FileOutputStream(
							"GeneratedDocs/" + testingPhase+"_"+table.get(testCase)+"_" +intent+".docx");
					addParagraphSetText(document, "Test Matrix File name < " + fileName + " >");
					XWPFTable pfttable = document.createTable();
					//pfttable.getCTTbl().addNewTblPr().addNewTblW().setW(BigInteger.valueOf(10000));
					XWPFTableRow tableRowOne = pfttable.getRow(0);
					tableRowOne.getCell(0).setText(" Test Scenario# : " + table.get(testScenario));
					try{
						if(!table.get(interaction).equals(null))
						{
							interaction=table.get(interaction);
						}
					}
					catch(Exception e3)
					{
						
					}
					
					try{
						if(!table.get(intent).equals(null))
						{
							intent=table.get(intent);
						}
					}
					catch(Exception e3)
					{
						
					}
					
					tableRowOne.addNewTableCell().setText(" Intent: " + interaction + "-" + intent);
					addTableRow(pfttable, " Test case ID: " + table.get(testCase), " Sprint#:");
					addTableRow(pfttable, " Defect ID:", " Plan: " + planName);
					try{
						if(!release.equals(""))
						{
							releaseValue=table.get(release);
							if(table.get(release).equals(null))
							{
								releaseValue=release;
							}
						}
						
					}
					catch(Exception e1)
					{
						releaseValue=release;
					}
					try{
						if(!cycle.equals(""))
						{
							cycleValue=table.get(cycle);
							if(table.get(cycle).equals(null))
							{
								cycleValue=cycle;
							}
						}
					}
					catch(Exception e1)
					{
						cycleValue=cycle;
					}
					addTableRow(pfttable, " Release: "+releaseValue, " Cycle: "+ cycleValue);
					addTableRow(pfttable, " Quality Reviewer: ", " ");
					addParagraphBreakTest(document);
					addParagraphBold(document, "Type of Interaction: ",interaction);
					addParagraphBold(document, "Test Data: ",table.get(dataForTest));
					addParagraphSetText(document, "• Member id:");
					addParagraphSetText(document, "• Claim Number:");
					addParagraphBold(document, "Test case: ",table.get(testCase));
					addParagraphBold(document, "Test Objective:  ",table.get(testObjective));
					addParagraphBold(document, "Expected Result: ", table.get(expectedResults));
					addParagraphBold(document, "Actual Result: ",table.get(actualResults));
					addParagraphBold(document, "Status:  " + table.get(status));
					addParagraphBold(document, "Screen shots:  ", "See screen shots below for reference");
					addParagraphBold(document, "Letter Template Evidence:   ","NA");
					addParagraphBold(document, "Screen shots provided:  ");
					String s = table.get(testSteps);
					String[] s1 = s.split("\n");
					if(s1.length>0)
					{
						for (int i = 0; i < s1.length; i++) {
							addParagraphSetText(document, s1[i]);
						}
						
					}
					else{
						addParagraphSetText(document, s);
					}
					document.write(out);
		            out.close();
				}
				fis.close();
	       }
		}catch(Exception e)
		{
			
		}
	}
	public List<String> getHeaders(String Filepath) throws Exception
	{
		List<String> headers= new ArrayList<String>();
		FileInputStream fis=new FileInputStream(Filepath);
		Workbook workbook = new XSSFWorkbook(fis);
		Sheet sheet = workbook.getSheet(sheetName);
		int testCols = 0;
		testCols = sheet.getRow(0).getLastCellNum();
		headers.add("Select");
		headers.add("No value to select");
		for (int cNum = 0; cNum < testCols; cNum++) {
			String headerValue=sheet.getRow(0).getCell(cNum).toString();
			if(!headerValue.equals(""))
			{
				headers.add(sheet.getRow(0).getCell(cNum).toString());
			}
		}
		
		fis.close();
		return headers;
	}
	
	public static void addParagraphBreakTest(XWPFDocument document) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.addBreak();
	}

	public static void addParagraphBold(XWPFDocument document, String textToSet) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.setBold(true);
		run.setText(textToSet);
	}
	
	public static void addParagraphBold(XWPFDocument document, String boldText, String plainText) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.setBold(true);
		run.setText(boldText);
		XWPFRun run1 = paragraph.createRun();
		run1.setText(plainText);
	}

	public static void addParagraphSetText(XWPFDocument document, String textToSet) {
		XWPFParagraph paragraph = document.createParagraph();
		XWPFRun run = paragraph.createRun();
		run.setText(textToSet);
	}

	public static void addTableRow(XWPFTable table, String cellOValue, String cell1Value) {
		XWPFTableRow tableRow = table.createRow();
		tableRow.getCell(0).setText(cellOValue);
		tableRow.getCell(1).setText(cell1Value);
	}
}