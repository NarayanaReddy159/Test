package com.nasco.utils;

@SuppressWarnings("serial")
public class MyException extends Exception{

	public MyException(String s)
    {
       super(s);
    }
}
