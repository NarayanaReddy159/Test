package com.nasco.execute;

@SuppressWarnings("serial")
public class MyException extends Exception{

	public MyException(String s)
    {
       super(s);
    }
}
