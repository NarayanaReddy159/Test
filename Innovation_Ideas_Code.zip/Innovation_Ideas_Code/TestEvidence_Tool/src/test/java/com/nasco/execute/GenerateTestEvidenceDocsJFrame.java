package com.nasco.execute;

import com.nasco.utils.TestEvidenceToolFrame;

public class GenerateTestEvidenceDocsJFrame {
	public static void main(String[] args) {
		TestEvidenceToolFrame createFrame= new TestEvidenceToolFrame();
		createFrame.getFrame();
	}
}
