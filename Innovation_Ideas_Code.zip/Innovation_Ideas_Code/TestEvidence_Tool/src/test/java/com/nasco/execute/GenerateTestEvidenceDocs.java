package com.nasco.execute;

import com.nasco.utils.CreateOptionPane;
import com.nasco.utils.ReadExcelGenerateDoc;

public class GenerateTestEvidenceDocs {
    public static void main(String[] args) throws Exception {
    String message="";
    	
    try{
    		ReadExcelGenerateDoc.generateDoc();
    	}
    catch(MyException e)
    {
    	message=e.getMessage();
   }
    catch(Exception e)
    {
    	e.printStackTrace();
    }
    if(message.equals(""))
        {
        	message="Test Evidence docs are generated, please check @ GeneratedDocs folder";	
        }else{
        	
        }
    CreateOptionPane.optionPane(message);
  }
 }
