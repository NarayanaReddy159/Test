package com.nasco.HMHS.TestScripts.G1;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC009_MemberSearch_WrapUp_MemberNotFound extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G1DP")
	public void HMHS_AUTC009_MemberSearch_WrapUp_MemberNotFound(Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC009_MemberSearch_WrapUp_MemberNotFound Search");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC009_MemberSearch_WrapUp_MemberNotFound- Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC009_MemberSearch_WrapUp_MemberNotFound -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);

		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String intentID = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + intentID);
		test.log(Status.INFO,"Interaction id: " + intentID);
		searchMember.WrapUp_MemberNotFound();
		log.debug("Moved to Wrap Up Member Not Found page.");
		test.log(Status.INFO, "Moved to Wrap Up Member Not Found page.");
		searchMember.WrapUpMemNotFoundSubmit( data.get("Comments"),
				data.get("InteractionReason"));
		log.debug("Comments submitted.");
		test.log(Status.INFO, "Comments submitted.");
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigate to the Recentwork.");
		test.log(Status.INFO, "Navigate to the Recentwork.");
		recentWork.sortandSelectIntent( intentID);
		//System.out.println("Navigate to selected intent " + intentID + " from recent work tab ");
		log.debug("Navigate to selected intent " + intentID + "from recent work tab.");
		test.log(Status.INFO, "Navigate to selected intent " + intentID + "from recent work tab.");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Navigate to Interaction screen.");
		test.log(Status.INFO, "Navigate to Interaction screen.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}

	@AfterMethod
	public void tearDown() throws Exception  {

		test.log(Status.INFO, "HMHS_TC009_MemberSearch_WrapUp_MemberNotFound Completed");
		log.debug("HMHS_TC009_MemberSearch_WrapUp_MemberNotFound Completed");
		quit();

	}
}
