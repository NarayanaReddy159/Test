package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked","unused"})
public class OtherActions extends BasePage {

	String excepionMessage = "";

	// web elements
	// New interaction
	String otherActionXpath="//ul[contains(@id,'pyNavigation')]/li[1]";
	
	@FindBy(how = How.XPATH, using = "//button[@title='Add task']")
	public WebElement add;
	
	@FindBy(how = How.CLASS_NAME, using = "actionTitleBarLabelStyle")
	public WebElement intnetTitle;
	
	
	
	@FindBy(id = "PegaGadget1Ifr")
	public WebElement frame1;
	
	@FindBy(xpath = "//button[@title='Other actions']")
	public WebElement otherActions;
	
	//Other Actions
	
	@FindBy(xpath = "//span[contains(text(),'Cancel Work')]")
	public WebElement cancelWork;
	
	@FindBy(xpath = "//span[contains(text(),'Route to Team')]")
	public WebElement routeTeam;
	
	@FindBy(xpath = "//label[text()='Route to']//following::label[1]")
	public WebElement routeTeamMember;
	
	@FindBy(xpath = "//label[text()='Route to']//following::label[2]")
	public WebElement Workbasket;
	
	@FindBy(name = "$PpyWorkPage$pOperator")
	public WebElement assignToTeamMember;
	
	@FindBy(name = "$PpyWorkPage$pRoutedToWB")
	public WebElement assignToWorkbasket;
	
	
	
	@FindBy(xpath = "//span[contains(text(),'Save to Worklist')]")
	public WebElement saveToWorkList;
	
	@FindBy(name = "$PpyWorkPage$pWrapUpComments")
	public WebElement comments;
	
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	
	@FindBy(name = "$PpyWorkPage$pReasonToPend")
	public WebElement ReasonToPend;
	
	@FindBy(how = How.XPATH, using  = "//label[contains(text(),'Comments')]//following::button[2]")
	public WebElement IDCSubmit;
	@FindBy(how = How.NAME,using = "$PpyWorkPage$pComments")
	public WebElement savetoworklisComments;
	@FindBy(how = How.XPATH, using  = "//span[@class='standard']//preceding::label[1]")
	public WebElement Intentname;
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]//preceding::b[1]")
	public WebElement message;
	@FindBy(how = How.XPATH, using = "//b[contains(text(),'Submit to save to worklist')]")
	public WebElement NewMsg2;
	@FindBy(how = How.XPATH, using = "//b[contains(text(),'Submit will route to your worklist')]")
	public WebElement NewMsg3;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(intnetTitle);
	}

	//cancel work
	public void cancelWork(Hashtable<String, String> data)
	{ String Message= "";
		try{
			webElementClick(otherActions, "Other Actions");
			waitSleep(2000);
			webElementClick(cancelWork,"Cancel Work");
			waitSleep(2000);
			 Message= webElementReadText(message, "Message");
			 //System.out.println(Message);
			 String commentsVal="comments";
			 try{
				 if(!data.get("CancelComments").equals(""))
				 {
					 commentsVal=data.get("CancelComments");
				 }
			 }catch(Exception e4)
			 {
				 
			 }
			webElementSendText(comments,commentsVal, "Comments");
			waitSleep(2000);
			
			if(data.get("Intent").equals("Request ID Card"))
			{
				webElementClick(IDCSubmit, "Submit");
			}
			else{
				 
				webElementClick(Submit, "Submit");	
			}
			
			wait(1000);
			assertEquals(data.get("ExpectedMessage"), Message, "Message");
		   }
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on cancelWork method " + excepionMessage);
			test.log(Status.FAIL, "Error on cancelWork method " + e);
			throw e;
		}
	}

	public void saveToWorklist(Hashtable<String, String> data)
	{String Message= "";
		try{
			waitSleep(2000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(2000);
			webElementClick(saveToWorkList,"Save to Worklist");
			waitSleep(2000);
			selectDropdownValueByVisibleText(ReasonToPend, data.get("ReasonToPend"), "to select Reason to Pend");
			wait(1500);
			webElementSendText(savetoworklisComments, data.get("Comments"), "as Comments");
			wait(1500);
			Message= webElementReadText(message, "Message");
			 //System.out.println(Message);
			webElementClick(Submit, "Submit");
			wait(1500);
			assertEquals(data.get("ExpectedSavetoworkMessage"), Message, "Message");
		}	
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on cancelWork method " + excepionMessage);
			test.log(Status.FAIL, "Error on cancelWork method " + e);
			throw e;
		}
	}
	
    public void routeToTeamMember(Hashtable<String, String> data)
    {
    	String assignOp="//span[contains(text(),'%s')]";
    	String deactiveText="//div[contains(text(),'%s')]";
    	String Message="";
    	try{
			waitSleep(2500);
			try{
				waitForNoSuchElement(otherActions);
				otherActions.click();
				waitSleep(2000);
				waitForNoSuchElement(routeTeam);
				routeTeam.click();
				waitSleep(2000);
			}
			catch(Exception e1)
			{
				//System.out.println("Entered Exception"+e1);
				jsClick(otherActions, "Other Actions");
				waitSleep(2000);
				jsClick(routeTeam, "Route to Team");
				waitSleep(2000);
			}
			
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", routeTeamMember);
			webElementClick(routeTeamMember, "Route to Team member");
			waitSleep(2500);
			webElementClick(routeTeamMember, "Route to Team member");
			if(!data.get("DeactivatedTeam").equals("vid9219"))
			{
				waitSleep(2000);
				webElementSendText(assignToTeamMember, data.get("DeactivatedTeam"), "Assign To");
				driver.findElement(By.xpath(String.format(assignOp, data.get("DeactivatedTeam")))).click();
				waitSleep(2000);
				String deactivemsg=webElementReadText(driver.findElement(By.xpath(String.format(deactiveText, data.get("DeactiveText")))), "Deactive Message");
				assertEquals(data.get("DeactiveText"), deactivemsg, "Deactive Operator Message");
				webElementClick(Workbasket, "Route to workbakset");
				waitSleep(2000);
				webElementClick(routeTeamMember, "Route to Team member");
			}
			waitSleep(2000);
			webElementSendText(assignToTeamMember, data.get("TeamMember"), "Assign To");
			//webElementSendText(assignToTeamMember, RunTestNG_NCompass_HMHS.Config.getProperty("username2"), "Assign To");
			try{
				waitSleep(2000);
				driver.findElement(By.xpath(String.format(assignOp, data.get("TeamMember")))).click();
				//driver.findElement(By.xpath("//tr[contains(@id,'$PD_GetOperatorsbyWG_pa') and contains(@id,'pz$ppxResults$')]")).click();
			}
			catch(Exception e1)
			{
				//System.out.println("Error "+e1);
			}
			wait(1500);
			Message= webElementReadText(message, "Message");
			 //System.out.println(Message);
			 assertEquals(data.get("ExpectedWorklistMessage"), Message, "WorklistMessage");
			webElementSendText(savetoworklisComments, data.get("Comments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
			wait(1500);
		}	
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on routeToTeamMember method " + excepionMessage);
			test.log(Status.FAIL, "Error on routeToTeamMember method " + e);
			throw e;
		}
    }
  
    public void navigateBackIntentScreen(Hashtable<String, String> data)
	{
		try{
			waitSleep(2000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(2000);
			webElementClick(saveToWorkList,"Save to Worklist");
			waitSleep(3000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(3000);
			webElementClick(driver.findElement(By.xpath(String.format(otherActionXpath,data.get("Intent")))),"Other option");
			waitSleep(2500);
		    String IntentName=webElementReadText(Intentname, "Intentname");
			//System.out.println(IntentName);
		}	
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on navigateBackIntentScreen method " + excepionMessage);
			test.log(Status.FAIL, "Error on navigateBackIntentScreen method " + e);
			throw e;
		}
	}
    public void navigateBackIntentScreenRoutto(Hashtable<String, String> data)
	{
		try{
			waitSleep(2000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(2000);
			webElementClick(routeTeam,"Route to Team");
			waitSleep(3000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(3000);
			webElementClick(driver.findElement(By.xpath(String.format(otherActionXpath,data.get("Intent")))),"Other option");
			waitSleep(2500);
		    String IntentName=webElementReadText(Intentname, "Intentname");
			//System.out.println(IntentName);
		}	
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on navigateBackIntentScreen method " + excepionMessage);
			test.log(Status.FAIL, "Error on navigateBackIntentScreen method " + e);
			throw e;
		}
	}
    public void navigateBackIntentScreenCancelwork(Hashtable<String, String> data)
   	{
   		try{
   			waitSleep(1500);
   			webElementClick(otherActions, "Other Actions");
   			waitSleep(1500);
   			webElementClick(cancelWork,"cancel Work");
   			waitSleep(2500);
   			webElementClick(otherActions, "Other Actions");
   			waitSleep(2500);
   			webElementClick(driver.findElement(By.xpath(String.format(otherActionXpath,data.get("Intent")))),"Other option");
   			waitSleep(1500);
   		    String IntentName=webElementReadText(Intentname, "Intentname");
   			//System.out.println(IntentName);
   		}	
   		catch(Exception e)
   		{
   			excepionMessage = Arrays.toString(e.getStackTrace());
   			BaseTest.log.error("Error on navigateBackIntentScreen method " + excepionMessage);
   			test.log(Status.FAIL, "Error on navigateBackIntentScreen method " + e);
   			throw e;
   		}
   	}
    
    public void routeToWorkbasket(Hashtable<String, String> data)
    {
    	String assignWB="//span[contains(text(),'%s')]";
    	String Message="";
    	try{
			waitSleep(2500);
			try{
				waitForNoSuchElement(otherActions);
				otherActions.click();
				waitSleep(2000);
				waitForNoSuchElement(routeTeam);
				routeTeam.click();
				waitSleep(2000);
			}
			catch(Exception e1)
			{
				//System.out.println("Entered Exception"+e1);
				jsClick(otherActions, "Other Actions");
				waitSleep(2000);
				jsClick(routeTeam, "Route to Team");
				waitSleep(2000);
			}
			
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", routeTeamMember);
			webElementClick(Workbasket, "Route to Workbasket");
			waitSleep(2500);
			webElementSendText(assignToWorkbasket, data.get("Workbasket"), "Assign To");
			try{
				waitSleep(2000);
				driver.findElement(By.xpath(String.format(assignWB, data.get("Workbasket")))).click();	
			}
			catch(Exception e1)
			{
				//System.out.println("Error "+e1);
			}
			wait(1500);
			Message= webElementReadText(message, "Message");
			 //System.out.println(Message);
			 assertEquals(data.get("ExpectedWorkbasketMessage"), Message, "WorkbasketMessage");
			webElementSendText(savetoworklisComments, data.get("Comments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
			wait(1500);
		}	
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on routeToTeamMember method " + excepionMessage);
			test.log(Status.FAIL, "Error on routeToTeamMember method " + e);
			throw e;
		}
    }
    public void saveToWorklist212(Hashtable<String, String> data)
	{
    	String ActualMsg = "";
		try{
			
			waitSleep(2000);
			selectDropdownValueByVisibleText(ReasonToPend, data.get("ReasonToPend"), "to select Reason to Pend");
			wait(1500);
			String comment="Comments";
			try{
				if(!data.get("Comment").equals(""))
				{
					comment=data.get("Comment");
				}
			}catch(Exception e4)
			{
				
			}
			
			webElementSendText(savetoworklisComments, comment, "as Comments");
			wait(1500);
			ActualMsg = webElementReadText(NewMsg3);
		    //System.out.println(ActualMsg);
		    String ExpectedMsg = "Submit will route to your worklist";
			assertEquals(ActualMsg,ExpectedMsg,"Info massage matched as Submit will route to your worklist.");
			webElementClick(Submit, "Submit");
			wait(1500);
		}	
		catch(Exception e)
		{
			excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on cancelWork method " + excepionMessage);
			test.log(Status.FAIL, "Error on cancelWork method " + e);
			throw e;
		}
	}

    public void verifysaveToWorklist(Hashtable<String, String> data)
	{
		try{
			waitSleep(2000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(2000);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", otherActions);
			waitSleep(2500);
			try{
			if(driver.findElement(By.xpath("//span[contains(text(),'Save to Worklist')]")).isDisplayed())
			{
				test.log(Status.INFO, "Save to Worklist is displayed ");
			}
			}
		   catch(Exception e1)
			{

				test.log(Status.INFO, "Save to Worklist is not displayed ");	
			
			waitSleep(3500);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on verifysaveToWorklist method " + e);
			test.log(Status.FAIL, "Error on verifysaveToWorklist method " + e);
			throw e;
		}
	}
}
