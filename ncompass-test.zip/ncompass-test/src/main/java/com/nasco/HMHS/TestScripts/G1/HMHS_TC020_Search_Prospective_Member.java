package com.nasco.HMHS.TestScripts.G1;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC020_Search_Prospective_Member extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void HMHS_AUTC020_Search_Prospective_Member(Hashtable<String,String> data) throws Exception {
		try{
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside TC020_Search_Prospective_Member");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("TC020_Search_Prospective_Member - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("TC020_Search_Prospective_Member -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		test.log(Status.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.movetoProsMem();
		searchMember.HMHSPrsFieldsPresent( "PegaGadget1Ifr");
		log.debug("First Name Webelement present on Prospective Member screen.");
		test.log(Status.INFO,"First Name Webelement present on Prospective Member screen.");
		log.debug("Pros Member Last Name Webelement present on Prospective Member screen");
		test.log(Status.INFO,"Pros Member DOB Webelement present on Prospective Member screen.");
		log.debug("Pros Member DOB Webelement present on Prospective Member screen");
		test.log(Status.INFO,"Pros Member DOB Webelement present on Prospective Member screen.");
		log.debug("prosMedicareNo Webelement not present before checkbox  of Capture new prospective member.");
		test.log(Status.INFO,"prosMedicareNo Webelement not present before checkbox  of Capture new prospective member.");
		searchMember.searchProsMem( data);		
		log.debug("Prospective member search completed.");
		test.log(Status.INFO,"Prospective member search completed.");
		InteractionManagerPage interactionManager=searchMember.openInteractionPage();
		interactionManager.wrapUp("Testing");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  {
		
		test.log(Status.INFO, "AUTC020_Search_Prospective_Member Completed");
		log.debug("AUTC020_Search_Prospective_Member Completed");
		quit();
		
	}
}
