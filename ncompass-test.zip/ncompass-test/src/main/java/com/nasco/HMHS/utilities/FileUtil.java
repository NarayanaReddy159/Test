package com.nasco.HMHS.utilities;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class FileUtil {

	public static void createandwriteFile(String fileName, List<String> failedMethods)
	{
		
		String filecontent="";
		for(int i=0;i<failedMethods.size();i++)
		{
			filecontent=filecontent+failedMethods.get(i)+" "+"\n";
		}
		try {
		      File myObj = new File(fileName);
		      if (myObj.createNewFile()) {
		      } else {
		      }
		    } catch (IOException e) {
		      e.printStackTrace();
		    }
		try {
		      FileWriter myWriter = new FileWriter(fileName);
		      if(filecontent.equals(""))
		      {
		    	  myWriter.write(filecontent);
		      }else{
		    	  DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");  
		    	  LocalDateTime now = LocalDateTime.now();  
		    	  myWriter.write(dtf.format(now)+" "+"\n"+filecontent);
		      }
		    	  
		      myWriter.close();
		     } catch (IOException e) {
		      e.printStackTrace();
		    }
	}
	
}
