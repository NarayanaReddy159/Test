package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked"})
public class RespondToCustomerPage extends BasePage {

	String excepionMessage = "";
	String taskNameXpath="//a[contains(text(),'%s')]";
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Add task')]")
	public WebElement addTask;
	@FindBy(how = How.XPATH, using = "//button[@title='Add task']")
	public WebElement add;
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Correspondence')]")
	public WebElement Correspondence;
	
	
	@FindBy (how = How.XPATH, using = "//select[@name='$PpyWorkPage$pCorrType']")
	public WebElement Method;
	@FindBy (how = How.XPATH, using = "//a[contains(text(),'Client letter')]")
	public WebElement LetterLink;
	@FindBy (how = How.XPATH, using = "//a[contains(text(),'BISCOM')]")
	public WebElement BISCOM;
	
	@FindBy (how = How.XPATH, using = "//input[@id='a8342120']")
	public WebElement ClientIDMail;
	@FindBy (how = How.XPATH, using = "//input[@id='6f7da890']")
	public WebElement ClientIDFax;
	@FindBy (how = How.XPATH, using = "//input[@name='$PpyWorkPage$pMessageCenterDetails$pClientLetterIDList$l1$pClientLetterID']")
	public WebElement ClientIDLetterID;
	@FindBy (how = How.XPATH, using = "//tbody/tr[@id='$PpyWorkPage$pMessageCenterDetails$pClientLetterIDList$l1']/td[2]/div[1]/span[1]/a[1]")
	public WebElement Plus;
	@FindBy (how = How.XPATH, using = "//input[@id='9b8392c0']")
	public WebElement ClientIDLetterID2;
	@FindBy (how = How.XPATH, using = "//div[2]/span[1]/i[1]/img[1]")
	public WebElement RegisteredEmailMsg;
	
	@FindBy (how = How.XPATH, using = "//div[contains(text(),'Member is not registered on the portal. Select a different method to respond to the member.')]")
	public WebElement NotRegisterMsg;
	@FindBy (how = How.XPATH, using = "//div[contains(text(),'Registered email is the email the member registered with for notification to be sent to when a reply is via message center.')]")
	public WebElement HelpMessage;
	
	@FindBy (how = How.XPATH, using = "//textarea[@id='7454b91c']")
	public WebElement Mailcomment;
	@FindBy (how = How.XPATH, using = "//textarea[@id='81fbe981']")
	public WebElement Faxcomment;
	@FindBy (how = How.XPATH, using = "//textarea[@id='c9fa51c6']")
	public WebElement MessageCentercomment;
	@FindBy (how = How.XPATH, using = "//textarea[@id='456a52fc']")
	public WebElement FaxMsg;
	@FindBy (how = How.XPATH, using = "//textarea[@id='2703a376']")
	public WebElement MessageCenterMsg;
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	@FindBy(how = How.XPATH, using = "//select[@id='4a4a1e95']")
	public WebElement Reason;
	@FindBy(how = How.XPATH, using="//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[1]/aside[1]/div[1]/div[1]/span[1]/div[1]/span[1]/div[1]/span[2]/div[1]/div[1]/div[3]/div[1]/span[1]/i[1]")
	public WebElement Wrapup;
	@FindBy(name = "$PpyWorkPage$pWrapUpComments")
	public WebElement WrapUpComments;
	@FindBy(xpath = "//div[contains(text(),'Submit')]//ancestor::button")
	public WebElement SubmitWrapUp;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Callback')]")
	public WebElement Callback;
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Scheduled')]")
	public WebElement Scheduled;
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Now')]")
	public WebElement Now;
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Yes')]")
	public WebElement LeaveMSG;
	
	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Submit for next steps')]")
	public WebElement NewMsg1;
	@FindBy(how = How.XPATH, using = "//b[contains(text(),'Submit to save to worklist')]")
	public WebElement NewMsg2;
	@FindBy(how = How.XPATH, using = "//b[contains(text(),'Submit will resolve')]")
	public WebElement NewMsg3;
	
	@FindBy(how = How.XPATH, using = "//select[@id='e2c615f9']")
	public WebElement CallbackReason;
	@FindBy(how = How.XPATH, using = "//input[@id='9e8aa4a8']")
	public WebElement CallbackNumber;
	@FindBy (how = How.XPATH, using = "//textarea[@id='b8561375']")
	public WebElement CallbackComments;
	@FindBy(xpath = "//*[@id='RULE_KEY']/div/div/div/div[2]/div/div/div/div[6]/span/button[1]")
	public WebElement OtherActions;
	@FindBy(xpath = "//span[contains(text(),'Cancel Work')]")
	public WebElement CancelWork;
	@FindBy (how = How.XPATH, using = "//textarea[@id='196a85d3']")
	public WebElement CancelComments;
	@FindBy(xpath = "//span[contains(text(),'Create Correspondence')]")
	public WebElement CreateCorrespondence;
	@FindBy(xpath = "//span[contains(text(),'Callback')]")
	public WebElement GotoCallback;
	@FindBy(xpath = "//span[contains(text(),'Save to Worklist')]")
	public WebElement SaveToWorklist;
	@FindBy(xpath = "//select[@id='745bd9d7']")
	public WebElement ReasonToPend;
	@FindBy(xpath = "//span[contains(text(),'Route to Team')]")
	public WebElement RouteToTeam;
	@FindBy(xpath = "//div[1]/div[1]/div[1]/span[1]/label[1]")
	public WebElement TeamMemWork;
	@FindBy(xpath = "//input[@id='fc6c88b7']")
	public WebElement Operator;
	@FindBy(xpath = "//div[@id='acspin']//following::div[1]")
	public WebElement ErrorMsg;
	
	@FindBy(xpath = "//input[@id='46a926d0']")
	public WebElement VerifyDOB;
	@FindBy(xpath = "//input[@id='7af0abde']")
	public WebElement VerifyAddress;
	@FindBy(xpath = "//select[@id='da2ffe19']")
	public WebElement Resolution;
	@FindBy(xpath = "//textarea[@id='03b33de1']")
	public WebElement ResolutionComments;

	@FindBy(xpath = "//div[2]/table[1]/tbody[1]/tr[1]/td[2]/div[1]/table[1]/tbody[1]/tr[1]/th[3]/div[1]/span[1]/a[1]")
	public WebElement RelatedIntentFilter;
	@FindBy(xpath = "//input[@id='65d778e1']")
	public WebElement EnterStatus;
	@FindBy(xpath = "//button[contains(text(),'Apply')]")
	public WebElement Apply;
	
	@FindBy(xpath = "//select[@name='$PpyWorkPage$pCategory']")
	public WebElement EmailCategory;
	@FindBy(xpath = "//select[@name='$PpyWorkPage$pSubCategory']")
	public WebElement EmailSubCategory;
	@FindBy(xpath = "//input[@id='a00de78c']")
	public WebElement EmailAddress;
	@FindBy(xpath = "//span[text()='Confirm email']//following::input[1]")
	public WebElement ConfirmEmailAddress;
	@FindBy(xpath = "//span[text()='Message']//following::div[1]")
	public WebElement Message;
	@FindBy(xpath = "//a[text()='Add attachment']")
	public WebElement Addattachments;
	@FindBy(name = "$PpyAttachmentPage$ppxAttachName")
	public WebElement Choosefile;
	@FindBy(xpath = "//button[contains(text(),'Submit')]//ancestor::td[1]")
	public WebElement SubmitAttachment;
	@FindBy(name = "$PpyWorkPage$pComments")
	public WebElement Comments;
	@FindBy(xpath = "//span[text()='Confirm email']//following::input[3]")
	public WebElement RequestQualityCheck;
	@FindBy(xpath ="//input[@id='d8fba1b9Approve']")
	public WebElement RTCApprove;
	
	
	//@FindBy(xpath = "//button[@type='button' and @name='ConfirmWrapUp_D_Interaction_pa960286505645232pz_12']")
	@FindBy(xpath = "//tbody/tr[1]/td[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/span[1]/button[1]']")
	public WebElement SubmitPopUp;
	@FindBy(how = How.XPATH, using  = "//b[contains(text(),'Submit will resolve')]")
	public WebElement NewMsg9;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(add);
	}
	
public void RespondToCustomerIntentMail (
			String memberSearchFname,Hashtable<String, String> data){
	    String Message1 = "";
	    String Message9 = "";
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			webElementClick(Correspondence, "Select Correspondence");
			wait(1500);
			
			Message1 = webElementReadText(NewMsg1);
		    //System.out.println(Message1);
			assertEquals(Message1,data.get("NextMsg"),"Info massage matched to go to next page.");
			
			webElementClick(Submit, "Submit");
			wait(1500);
			selectDropdownValueByVisibleText(Method, data.get("MethodMail"), "Method of Response as Mail");
			wait(1500);
			webElementSendText(ClientIDMail, data.get("ClientID"), "Client Letter ID");
			wait(1500);
			webElementSendText(Mailcomment, data.get("Comment"), "Enter Comment");
			wait(1500);
			Message9 = webElementReadText(NewMsg9);
		    //System.out.println(Message9);
			assertEquals(Message9,data.get("Message9"),"Info massage matched as Submit will resolve.");
			wait(1500);

			webElementClick(Submit, "to submit the comments");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Respond To Customer Intent Mail method " + excepionMessage);
			test.log(Status.FAIL, "Error on Respond To Customer Intent Mail method " + e);
			throw e;
		}
	}

public void RTCCorrespondenceMail (
		String memberSearchFname,Hashtable<String, String> data){
	String Message1= "";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		webElementClick(Correspondence, "Select Correspondence");
		//System.out.println("Select Correspondence");
		wait(1500);
		Message1 = webElementReadText(NewMsg1);
	    //System.out.println(Message1);
		assertEquals(Message1,data.get("NextMsg"),"Info massage matched to go to next page.");
		wait(1500);
		webElementClick(Submit, "Submit");
		wait(1500);
		selectDropdownValueByVisibleText(Method, data.get("MethodMail"), "Method of Response as Mail");
		//System.out.println("Select Mail");
		wait(1500);
		webElementSendText(ClientIDMail, data.get("ClientID"), "Client Letter ID");
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Mail then go for Cancel Work method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Mail then go for Cancel method " + e);
		throw e;
	}
}

public void OtherActionsCreateCorrespondence (
		String memberSearchFname,Hashtable<String, String> data){
	try {
		switchToFrame("PegaGadget1Ifr");
		webElementClick(CreateCorrespondence, "to go back to Correspondence Mail screen");
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Mail -Go to the Cancel screen again move back to correspondence screen method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Mail -Go to the Cancel screen again move back to correspondence screen method " + e);
		throw e;
	}
}

public void RespondToCustomerIntentMailRouteToTeam (
		String memberSearchFname,Hashtable<String, String> data){
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(1500);
		webElementClick(OtherActions, "to click on other Actions");
		wait(1500);
		webElementClick(RouteToTeam, "on Route to team");
		wait(1500);
		webElementClick(TeamMemWork, "to select the Team Member's Worklist");
		wait(2000);
		webElementSendText(Operator, data.get("Operator"), "to select Reason to Pend");
		wait(1500);
		webElementSendText(Mailcomment, data.get("comments"), "as Comments");
		wait(1500);
		webElementClick(Submit, "Submit");
		wait(1500);
		webElementClick(Wrapup, "to Wrap up the Intent");
		wait(1500);
		webElementClick(Reason, "to select the Reason");
		wait(1500);
		webElementSendText(WrapUpComments, data.get("comments"), "as Comments");
		waitSleep(2500);
		webElementClick(SubmitWrapUp, "to Wrap Up successfully");
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Mail Save To Worklist method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To CustomerIntent Mail Save To Worklist method " + e);
		throw e;
	}
}
public void RespondToCustomerIntentMailRouteToTeamErrorCheck (
		String memberSearchFname,Hashtable<String, String> data, String expectedMessage){
	try {
		switchToFrame("PegaGadget1Ifr");
		webElementClick(OtherActions, "to click on other Actions");
		wait(1500);
		webElementClick(RouteToTeam, "on Route to team");
		wait(1500);
		webElementClick(TeamMemWork, "to select the Team Member's Worklist");
		wait(2500);
		Operator.clear();
		wait(2500);
		try{
		webElementSendText(Operator, data.get("Operator"), "to Enter the inactive operator");
		}
		catch(StaleElementReferenceException e){
		webElementSendText(Operator, data.get("Operator"), "to Enter the inactive operator");
		}
		wait(1500);
		Operator.sendKeys(Keys.TAB);
		wait(2000);
		String actualMessage = webElementReadText(ErrorMsg);
		wait(1500);
		String expected = String.format(expectedMessage);
		if (actualMessage.contains(expected)) {
			test.log(Status.PASS, "Message Matched as The operator that you selected is not active. Please select a different operator name.");
		} else {
		//	test.log(Status.FAIL, "Message not Matched");
		}
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Mail Save To Worklist method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To CustomerIntent Mail Save To Worklist method " + e);
		throw e;
	}
}

public void RespondToCustomerIntentFax (
		String memberSearchFname,Hashtable<String, String> data){
	String Message1= "";
	String Message9= "";
	try {
		switchToFrame("PegaGadget1Ifr");
		waitSleep(3000);
		webElementClick(Correspondence, "Select Correspondence");
		wait(1500);
		Message1 = webElementReadText(NewMsg1);
	    //System.out.println(Message1);
		assertEquals(Message1,data.get("NextMsg"),"Info massage matched to go to next page.");
		wait(1500);
		webElementClick(Submit, "Submit");
		wait(1500);
		selectDropdownValueByVisibleText(Method, data.get("MethodFax"), "Method of Response as Fax");
		wait(1500);
		webElementClick(LetterLink, "Able to click on Client Letter Link");
		wait(1500);
		String actualTitle = driver.getTitle();
		String expectedTitle = "CPMHC Interaction Portal";
		assertEquals(expectedTitle,actualTitle,memberSearchFname);
		webElementClick(BISCOM, "Able to click on BISCOM Link");
		wait(1500);
		String actualTitle1 = driver.getTitle();
		String expectedTitle1 = "CPMHC Interaction Portal";
		assertEquals(expectedTitle1,actualTitle1,memberSearchFname);
		
		webElementSendText(ClientIDFax, data.get("ClientID"), "Client Letter ID");
		wait(1500);
		webElementSendText(FaxMsg, data.get("FaxMsg"), "Client Letter ID");
		wait(1500);
		webElementSendText(Faxcomment, data.get("Comment"), "Enter Comment");
		wait(1500);
		Message9 = webElementReadText(NewMsg9);
	    //System.out.println(Message9);
		assertEquals(Message9,data.get("Message9"),"Info massage matched as Submit will resolve.");
		wait(1500);
		webElementClick(Submit, "to submit the comments");
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Fax method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Fax method " + e);
		throw e;
	}
}

public void RespondToCustomerIntentFax1 (
		String memberSearchFname,Hashtable<String, String> data){
	try {
		switchToFrame("PegaGadget2Ifr");
		waitSleep(3000);
		//waitForElementsToVisible("//label[contains(text(),'Correspondence')]");
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Correspondence); ;
		webElementClick(Correspondence, "Select Correspondence");
		wait(1500);
		webElementClick(Submit, "Submit");
		wait(5000);
		selectDropdownValueByVisibleText(driver.findElement(By.name("$PpyWorkPage$pCorrType")), data.get("MethodFax"), "Method of Response as Fax");
		wait(1500);
		webElementSendText(driver.findElement(By.name("$PpyWorkPage$pFaxDetails$pClientLetterIDList$l1$pClientLetterID")), data.get("ClientID"), "Client Letter ID");
		wait(1500);
		webElementSendText(driver.findElement(By.name("$PpyWorkPage$pFaxDetails$pFaxConfirmation")), data.get("FaxMsg"), "Client Letter ID");
		wait(1500);
		webElementSendText(driver.findElement(By.name("$PpyWorkPage$pFaxDetails$pComments")), data.get("Comment"), "Enter Comment");
		wait(1500);
		webElementClick(Submit, "to submit the comments");
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Fax method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Fax method " + e);
		throw e;
	}
}

public void RespondToCustomerIntentFaxID (
		String memberSearchFname,Hashtable<String, String> data){
	String Message1 = "";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		webElementClick(Correspondence, "Select Correspondence");
		wait(1500);
		Message1 = webElementReadText(NewMsg1);
	    //System.out.println(Message1);
		assertEquals(Message1,data.get("NextMsg"),"Info massage matched to go to next page.");
		wait(1500);
		webElementClick(Submit, "Submit");
		wait(1500);
		selectDropdownValueByVisibleText(Method, data.get("MethodFax"), "Method of Response as Fax");
		wait(1500);
		webElementSendText(ClientIDFax, data.get("ClientID"), "Client Letter ID");
		wait(1500);
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Fax method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Fax method " + e);
		throw e;
	}
}

public void RespondToCustomerIntentMessageCenter (
		String memberSearchFname,Hashtable<String, String> data){
	String Message1 = "";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		webElementClick(Correspondence, "Select Correspondence");
		wait(1500);
		Message1 = webElementReadText(NewMsg1);
	    //System.out.println(Message1);
		assertEquals(Message1,data.get("NextMsg"),"Info massage matched to go to next page.");
		wait(1500);
		webElementClick(Submit, "Submit");
		wait(3000);
		WebDriverWait wait = new WebDriverWait(driver, 20);
		WebElement source_dropdown=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='a5225365']")));
		Select source = new Select(source_dropdown);
		source.selectByIndex(3);
		
		//selectDropdownValueByVisibleText(Method, data.get("MethodMessageCenter"), "Method of Response as Message Center");
		wait(3000);
		webElementSendText(ClientIDLetterID, data.get("ClientID"), "To Enter Client Letter ID");
		wait(1500);
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Message Center method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Message Center method " + e);
		throw e;
	}
}

public void RespondToCustomerIntentMessageCenter (
		String memberSearchFname,Hashtable<String, String> data,String expectedMessage,String NotRegExpectedMessage){
	String Message1="";
	String Message9 = "";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		webElementClick(Correspondence, "Select Correspondence");
		wait(1500);
		
		Message1 = webElementReadText(NewMsg1);
	    //System.out.println(Message1);
		assertEquals(Message1,data.get("NextMsg"),"Info massage matched to go to next page.");
		wait(1500);
		webElementClick(Submit, "Submit");
		wait(3000);
		/*
		 * WebDriverWait wait = new WebDriverWait(driver, 20); WebElement
		 * source_dropdown=wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
		 * "//select[@id='a5225365']"))); Select source = new Select(source_dropdown);
		 * source.selectByIndex(3);
		 */selectDropdownValueByVisibleText(Method, data.get("MethodMessageCenter"), "Method of Response as Message Center");
		wait(1500);
		
		String ActualMessage = webElementReadText(NotRegisterMsg);
		String ExpectedNotRegMsg = String.format(NotRegExpectedMessage);
		 if (ActualMessage.contains(NotRegExpectedMessage)) {
			test.log(Status.PASS, "Registered Email Help Text mathched: ");
			test.log(Status.PASS,"Expected Message: "+' '+ExpectedNotRegMsg);
			test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
		 } else {
			test.log(Status.FAIL, "Registered Email Help Text not Matched." );
			test.log(Status.PASS,"Expected Message: "+' '+ExpectedNotRegMsg);
			test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			Assert.fail();
		 }	
		
		//webElementClick(LetterLink, "Able to click on Client Letter Link");
		wait(1500);
		
		String actualTitle = driver.getTitle();
		String expectedTitle = "CPMHC Interaction Portal";
		assertEquals(expectedTitle,actualTitle,memberSearchFname);
		
		webElementSendText(ClientIDLetterID, data.get("ClientID"), "Enter Client Letter ID");
		wait(1500);
		webElementClick(Plus, "To add 1 more Client Letter ID");
		wait(1500);
		webElementSendText(ClientIDLetterID2, data.get("ClientID2"), "Enter 2nd Client Letter ID");
		wait(1500);
		webElementClick(RegisteredEmailMsg, "Registered Email Message.");
		Actions act = new Actions(driver);
		waitSleep(4000);
		act.moveToElement(RegisteredEmailMsg);
		waitSleep(5000);
		String actual = webElementReadText(HelpMessage);
		String expected = String.format(expectedMessage);
		 if (actual.contains(expected)) {
			test.log(Status.PASS, "Registered Email Help Text mathched: ");
			test.log(Status.PASS,"Expected Message: "+' '+expectedMessage);
			test.log(Status.PASS,"Actual Message: "+' '+actual);
		 } else {
			test.log(Status.FAIL, "Registered Email Help Text not Matched." );
			test.log(Status.PASS,"Expected Message: "+' '+expectedMessage);
			test.log(Status.PASS,"Actual Message: "+' '+actual);
			Assert.fail();
		 }	
		webElementSendText(MessageCenterMsg, data.get("MessageCenterMsg"), "Enter the Message Center Message");
		wait(2000);
		webElementSendText(MessageCentercomment, data.get("Comment"), "Enter Comment");
		wait(2000);
		Message9 = webElementReadText(driver.findElement(By.xpath("//div[contains(text(),'Submit will send the message and resolve')]")));
	    //System.out.println(Message9);
		assertEquals(Message9,"Submit will send the message and resolve","Info massage matched");
		wait(1500);
		webElementClick(Submit, "to submit the Correspondence Message center");
	} 
	catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Message Center method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Message Center method " + e);
		throw e;
	}
}

public void RespondToCustomerIntentCallback (
		String memberSearchFname,Hashtable<String, String> data){
	String Message1= "";
	String Message2="";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		webElementClick(Callback, "to select Callback");
		wait(1500);
		
	    Message1 = webElementReadText(NewMsg1);
	    //System.out.println(Message1);
		assertEquals(Message1,data.get("NextMsg"),"Info massage matched to go to next page.");
		
		wait(1500);
		webElementClick(Submit, "able to Submit");
		wait(1500);
		selectDropdownValueByVisibleText(CallbackReason, data.get("CallbackReason"), "Enter Callback Reason");
		wait(1500);
		webElementClick(Scheduled, "to scheduled the Callback");
		wait(1500);
		webElementClick(LeaveMSG, "to Yes - Leave Message");
		wait(1500);
		webElementSendText(CallbackNumber, data.get("CallbackNumber"), "Enter Callback Number");
		wait(1500);
		webElementSendText(CallbackComments, data.get("comments"), "Enter Comment");
		wait(1500);
		
	    Message2 = webElementReadText(NewMsg2);
	    //System.out.println(Message2);
		assertEquals(Message2,data.get("WorklistMsg"),"Info massage matched as Submit to save to worklist.");
		
		wait(1500);
		webElementClick(Submit, "to submit for Callback");
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Callback method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Callback method " + e);
		throw e;
	}
}
public void RespondToCustomerIntentCallbackNow (
		String memberSearchFname,Hashtable<String, String> data){
	String Message1= "";
	String Message3= "";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		webElementClick(Callback, "to select Callback");
		wait(1500);
		webElementClick(Callback, "to select Callback");
		wait(1500);
		
		Message1 = webElementReadText(NewMsg1);
		assertEquals(Message1,data.get("NxtMsg"),"Info massage matched to go to next page.");
		
		webElementClick(Submit, "able to Submit");
		wait(1500);
		selectDropdownValueByVisibleText(CallbackReason, data.get("CallbackReason"), "Enter Callback Reason");
		wait(1500);
		webElementClick(Now, "to scheduled the callback now.");
		wait(1500);
		webElementClick(LeaveMSG, "to Yes - Leave Message");
		wait(1500);
		webElementSendText(CallbackNumber, data.get("CallbackNumber"), "Enter Callback Number");
		wait(1500);
		webElementSendText(CallbackComments, data.get("comments"), "Enter Comment");
		wait(1500);
		
		Message3 = webElementReadText(NewMsg1);
		assertEquals(Message3,data.get("NxtMsg"),"Info massage matched as Submit to save to worklist");
	
		wait(1500);
		webElementClick(Submit, "to submit for Callback");
		wait(3500);
		try{
			VerifyDOB.click();
		}
		catch(Exception e1)
		{
			
		}
		//webElementClick(VerifyDOB, "to verify the DOB");
		wait(1500);
		selectDropdownValueByVisibleText(Resolution, data.get("Resolution"), "Enter Resolution");
		wait(1500);
		webElementSendText(ResolutionComments, data.get("ResolutionComments"), "as Comments");
		waitSleep(2500);
		wait(1500);
		webElementClick(Submit, "to submit for Callback");
		wait(1500);
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Callback Now method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Callback Now method " + e);
		throw e;
	}
}

public void RelatedIntentCheck (
		String memberSearchFname,Hashtable<String, String> data){
	String Message1= "";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		webElementClick(Callback, "to select Callback");
		wait(1500);
		Message1 = webElementReadText(NewMsg1);
		assertEquals(Message1,data.get("NxtMsg"),"Info massage matched to go to next page.");
		webElementClick(Submit, "able to Submit.");
		wait(3500);
		
		webElementClick(RelatedIntentFilter, "on to Filter the Related Intent status.");
		wait(4500);
		webElementSendText(EnterStatus, data.get("IntStatus"), "to check the status");
		wait(1500);
		webElementClick(Apply, "to click on Apply.");
		wait(2500);
		
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on RelatedIntentCheck method " + excepionMessage);
		test.log(Status.FAIL, "Error on RelatedIntentCheck method " + e);
		throw e;
	}
}


public void OtherActionsCallback (
		String memberSearchFname,Hashtable<String, String> data){
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(1500);
		webElementClick(GotoCallback, "to go back to Callback screen");
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Callback method during Cancel Work" + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Callback method during Cancel Work" + e);
		throw e;
	}
}
public void RTCCallbackPend(
		String memberSearchFname,Hashtable<String, String> data){
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		webElementClick(Callback, "to select Callback");
		wait(1500);
		webElementClick(Submit, "able to Submit");
		wait(1500);
		selectDropdownValueByVisibleText(CallbackReason, data.get("CallbackReason"), "Enter Callback Reason");
		wait(1500);
		webElementClick(Scheduled, "to scheduled the Callback");
		wait(1500);
		webElementClick(LeaveMSG, "to Yes - Leave Message");
		wait(1500);
		webElementSendText(CallbackNumber, data.get("CallbackNumber"), "Enter Callback Number");
		wait(1500);
		webElementSendText(CallbackComments, data.get("comments"), "Enter Comment");
		wait(1500);
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Callback method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Callback method " + e);
		throw e;
	}
}
public void RespondToCustomerIntentCallbackDiffOpr(
		String memberSearchFname,Hashtable<String, String> data, String expectedMessage1){
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		webElementClick(Callback, "to select Callback");
		wait(1500);
		
		//String actualmsg1 = webElementReadText(NewMsg1);
		//String expectedmsg1 = String.format(expectedMessage1);
		//assertEquals(actualmsg1,expectedmsg1,"Info massage matched to go to next page.");
		webElementClick(Submit, "able to Submit");
		wait(1500);
		
		webElementSendText(Operator, data.get("Operator"), "to select different operator");
		wait(1500);
		Operator.sendKeys(Keys.TAB);
		wait(2000);
		selectDropdownValueByVisibleText(CallbackReason, data.get("CallbackReason"), "Enter Callback Reason");
		wait(1500);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Scheduled); 
		wait(1500);
		webElementClick(Scheduled, "to scheduled the Callback");
		wait(1500);
		webElementClick(LeaveMSG, "to Yes - Leave Message");
		wait(1500);
		webElementSendText(CallbackNumber, data.get("CallbackNumber"), "Enter Callback Number");
		wait(1500);
		webElementSendText(CallbackComments, data.get("comments"), "Enter Comment");
		wait(1500);
		webElementClick(Submit, "to submit for Callback");
		wait(1500);
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Respond To Customer Intent Callback method " + excepionMessage);
		test.log(Status.FAIL, "Error on Respond To Customer Intent Callback method " + e);
		throw e;
	}
}
	public RespondToCustomerPage opencreateFollowUpPage()
	{
		return (RespondToCustomerPage)openPage(RespondToCustomerPage.class);
	}
	
	public void RespondToCustomerIntentEmail (
			String memberSearchFname,Hashtable<String, String> data){
	    String Message1 = "";
	    try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			webElementClick(Correspondence, "Select Correspondence");
			wait(1500);
			
			Message1 = webElementReadText(NewMsg1);
		    //System.out.println(Message1);
			assertEquals(Message1,data.get("NextMsg"),"Info massage matched to go to next page.");
			
			webElementClick(Submit, "Submit");
			wait(1500);
			selectDropdownValueByVisibleText(Method, data.get("MethodEmail"), "Method of Response as Email");
			wait(1500);
			selectDropdownValueByVisibleText(EmailCategory, data.get("Category"), "Category");
			wait(1500);
			selectDropdownValueByVisibleText(EmailSubCategory, data.get("SubCategory"), "SubCategory");
			wait(1500);
			webElementSendText(EmailAddress, data.get("EmailAddress"), "EmailAdd");
			wait(1500);
			webElementSendText(ConfirmEmailAddress, data.get("ConfirmEmailAddress"), "ConfirmEmailAdd");
			wait(1500);
			
		//	webElementSendText(Message, data.get("Message"), "Message");
			wait(1500);
			webElementClick(RequestQualityCheck, "Click on RequestQualityCheck");
			wait(1500);
			
				try{
					webElementClick(Addattachments, "Addattachments");
					wait(1500);
					Choosefile.sendKeys(System.getProperty("user.dir")+RunTestNG_NCompass_HMHS.Config.getProperty("ATTACH_IMG_PATH")+data.get("Attachment_Name"));
					webElementClick(SubmitAttachment, "Submit Attachment");
					waitSleep(1500);
					
				}catch(Exception e)
				{
					e.printStackTrace();
					test.log(Status.FAIL, "Error on email method " + e);
					throw e;
				}
			webElementSendText(Comments, data.get("Comments"), "Comments");
			wait(1500);

			webElementClick(Submit, "Submit to review");
			wait(3500);
			webElementClick(Submit, "Submit");
			wait(3500);
			
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Respond To Customer Intent Mail method " + excepionMessage);
			test.log(Status.FAIL, "Error on Respond To Customer Intent Mail method " + e);
			throw e;
		}
	}

	public void RespondToCustomerIntentEmail_RoutetoWorkbasket (
			String memberSearchFname,Hashtable<String, String> data){
	    String Message1 = "";
	    try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			webElementClick(Correspondence, "Select Correspondence");
			wait(1500);
			
			Message1 = webElementReadText(NewMsg1);
		    //System.out.println(Message1);
			assertEquals(Message1,data.get("NextMsg"),"Info massage matched to go to next page.");
			
			webElementClick(Submit, "Submit");
			wait(1500);
			selectDropdownValueByVisibleText(Method, data.get("MethodEmail"), "Method of Response as Email");
			wait(1500);
			selectDropdownValueByVisibleText(EmailCategory, data.get("Category"), "Category");
			wait(1500);
			selectDropdownValueByVisibleText(EmailSubCategory, data.get("SubCategory"), "SubCategory");
			wait(1500);
			webElementSendText(EmailAddress, data.get("EmailAddress"), "EmailAdd");
			wait(1500);
			webElementSendText(ConfirmEmailAddress, data.get("ConfirmEmailAddress"), "ConfirmEmailAdd");
			wait(1500);
			
		//	webElementSendText(Message, data.get("Message"), "Message");
			wait(1500);
			
			
				try{
					webElementClick(Addattachments, "Addattachments");
					wait(1500);
					Choosefile.sendKeys(System.getProperty("user.dir")+RunTestNG_NCompass_HMHS.Config.getProperty("ATTACH_IMG_PATH")+data.get("Attachment_Name"));
					webElementClick(SubmitAttachment, "Submit Attachment");
					waitSleep(1500);
					
				}catch(Exception e)
				{
					e.printStackTrace();
					test.log(Status.FAIL, "Error on email method " + e);
					throw e;
				}
			webElementSendText(Comments, data.get("Comments"), "Comments");
			wait(1500);

			webElementClick(Submit, "Submit to review");
			wait(2500);
			webElementClick(Submit, "Submit");
			wait(3500);
			
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Respond To Customer Intent Mail method " + excepionMessage);
			test.log(Status.FAIL, "Error on Respond To Customer Intent Mail method " + e);
			throw e;
		}
	}
	




public void RTCEmailApprove (
		Hashtable<String, String> data)
{	
	wait(1500);
	webElementClick(RTCApprove, "RTC Email Approve");
	wait(2000);
	webElementClick(Submit, "Submit");
	wait(1500);
}
}
