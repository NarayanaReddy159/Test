
package com.nasco.HMHS.TestScripts.G2.RespondToCustomer;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RespondToCustomerPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC028_RespondToCustomer_Callback_Unsuccess_Correspondence_Fax extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC028_RespondToCustomer_Callback_Unsuccess_Correspondence_Fax (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC028_RespondToCustomer_Callback_Unsuccess_Correspondence_Fax");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC028_RespondToCustomer_Callback_Unsuccess_Correspondence_Fax - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC028_RespondToCustomer_Callback_Unsuccess_Correspondence_Fax -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed.");
		test.log(Status.INFO,"Member Search Completed.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page.");
		test.log(Status.INFO,data.get("Fname") + "Selected from the search results and navigated to verify member page.");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO,"Member Submit Completed.");
		
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Member Verified successfully.");
        test.log(Status.INFO,"Member Verified successfully.");
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(Status.INFO,"Add Intent "+data.get("Intent"));
        
        String intentID = searchMember.getIntentID();
		log.debug("Intent id: " + intentID);
		test.log(Status.INFO,"Intent id: " + intentID);
        RespondToCustomerPage RTC = homepage.RespondToCustomerIntentCallback();
        RTC.RespondToCustomerIntentCallbackDiffOpr( intentID,data,data.get("NextMsg"));
		log.debug("Navigate to Respond to Customer intent screen to add task against Message Center method.");
		test.log(Status.INFO,"Navigate to Respond to Customer intent screen to add task against Message Center method.");
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Wrapping up the intent");
		test.log(Status.INFO,"Wrapping up the intent");
		
		WorklistPage worklist = homepage.openrecentWorklist();
		worklist.movetoWorklistPage();
		log.debug("Navigated to the Worklist page.");
		test.log(Status.INFO,"Navigated to the Worklist page.");
		worklist.sortandSelectIntent(data, intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from Worklist tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab ");
		test.log(Status.INFO,"Sorted and selected intent " + intentID + " from recent work tab");
		worklist.IntentStatusWorklist(data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the Intent Status.");
		test.log(Status.INFO,"Check the Intent Status.");
		worklist.CallbackAttempt( intentID, data);
		log.debug("Perform the callback attempt.");
		test.log(Status.INFO,"Perform the callback attempt.");
		
		WorklistPage worklist2 = homepage.openrecentWorklist();
		worklist2.sortandSelectIntent( data,intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from Worklist tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected intent " + intentID + " from recent work tab.");
		worklist2.IntentStatusWorklist(data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the Intent Status.");
		test.log(Status.INFO,"Check the Intent Status.");
		worklist.CallbackAttempt( intentID, data);
		log.debug("Perform the callback attempt.");
		test.log(Status.INFO,"Perform the callback attempt.");
		
		WorklistPage worklist3 = homepage.openrecentWorklist();
		worklist3.sortandSelectIntent( data,intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from Worklist tab.");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected intent " + intentID + " from recent work tab.");
		worklist3.IntentStatusWorklist(data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the Intent Status.");
		test.log(Status.INFO,"Add Intent "+data.get("Intent"));
		worklist3.LimitMsg( intentID, data, data.get("LimitMsg"));
		log.debug("Message should be displayed as Recommended number of callback attempts reached.");
		test.log(Status.INFO,"Message should be displayed as Recommended number of callback attempts reached.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}

	@AfterMethod
	public void tearDown() throws Exception  {
		test.log(Status.INFO, "HMHS_TC028_RespondToCustomer_Callback_Unsuccess_Correspondence_Fax completed.");
		log.debug("HMHS_TC028_RespondToCustomer_Callback_Unsuccess_Correspondence_Fax completed.");
		quit();

	}
}
