package com.nasco.HMHS.TestScripts.G2.MOCRouting;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;

public class HMHS_TC006_MOC_UpdateOPL_HMKOPLAccident extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC006_MOC_UpdateOPL_HMKOPLAccident (Hashtable<String, String> data) throws Exception {
		try{
		UpdateOPL("HMHS_AUTC006_MOC_UpdateOPL_HMKOPLAccident", data);
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
		}
 @AfterMethod
	public void tearDown() throws Exception  
	{	test.log(Status.INFO, "HMHS_TC006_MOC_UpdateOPL_HMKOPLAccident");
		log.debug("HMHS_TC006_MOC_UpdateOPL_HMKOPLAccident");
		quit();
	}


}
