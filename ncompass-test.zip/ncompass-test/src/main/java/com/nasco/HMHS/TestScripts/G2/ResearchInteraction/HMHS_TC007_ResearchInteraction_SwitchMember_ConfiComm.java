package com.nasco.HMHS.TestScripts.G2.ResearchInteraction;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.Member360Page;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC007_ResearchInteraction_SwitchMember_ConfiComm extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC007_ResearchInteraction_SwitchMember_ConfiComm (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC007_ResearchInteraction_SwitchMember_ConfiComm");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC007_ResearchInteraction_SwitchMember_ConfiComm - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC007_ResearchInteraction_SwitchMember_ConfiComm -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSResearchInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		test.log(Status.INFO,"Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed.");
		test.log(Status.INFO,"Member Search Completed.");
//		searchMember.readMemberDetails(data.get("ExpectedMemberDetails"));
//		log.debug("Reading Member Details Completed.");
		searchMember.HMHSConfCommImg("PegaGadget1Ifr");
		log.debug("Select the record for which Confidential Communication/Privacy flag present.");
		test.log(Status.INFO, "Select the record for which Confidential Communication/Privacy flag present.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page.");
		test.log(Status.INFO,data.get("Fname") + " Selected from the search results and navigated to verify member page.");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO,"Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.openInteractionPage();
		InteractionManager.openTask();
		Member360Page mem360=homepage.Member360Page();
		log.debug("Navigate to Member 360 page.");
		test.log(Status.INFO,"Navigate to Member 360 page.");
		InteractionManager.openTask();
		
		//Check the Confidential Communication/Privacy flag.
		searchMember.HMHSConfCommImg("PegaGadget1Ifr");
		log.debug("On Contract tab Member information section Confidential Communication/Privacy flag present.");
		test.log(Status.INFO, "On Contract tab Member information section Confidential Communication/Privacy flag present.");
		
		//Perform Switch to another member
		mem360.SwitchMemberConf();
		log.debug("Switched to another member.");
		test.log(Status.INFO,"Switched to another member.");
		InteractionManager.openTask();
	
		mem360.ResearchinteractionHeader_memberInformation(data.get("ExpectedmemberInformation"));
		log.debug("Validate the switched member interactionHeader_memberInformation details.");
		test.log(Status.INFO,"Validate the switched member interactionHeader_memberInformation details.");
		
		    
	  	// member tab
	  	mem360.memberTab_Generalinformation(data.get("Memberheader"),data.get("expectedGeneralinformation"));
	  	mem360.memberTab_Address(data.get("ExpectedMembersaddressheader"), data.get("ExpectedaddressDetails"));
	  	mem360.memberTab_Memberpreferences(data.get("ExpectedMemberpreferencesheader"), data.get("MemberpreferencesResult"),data.get("preferencesdetail"));
	  	mem360.memberTab_Associatedcontactslist(data.get("ExpectedAssociatedcontactsheader"), data.get("AssociatedResult"));
	  	mem360.memberTab_Othermemberidentifiers(data.get("ExpectedOthermemberidentifiersheader"),data.get("OthermemberidentifiersResult"));
	  	mem360.memberTab_Extendedeligibility(data.get("ExpectedExtendedeligibilityheader"),data.get("ExtendedeligibilityResult"));
	  	
		
		//Perform End Research
		InteractionManager.EndResearch();
		log.debug("Navigate to End Research screen.");
		test.log(Status.INFO,"Navigate to End Research screen.");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork.");
		test.log(Status.INFO,"Navigated to the Recentwork.");
		recentWork.sortandSelectIntent( interaction);
		//System.out.println("Sorted and selected interaction " + interaction + " from recent work tab.");
		log.debug("Sorted and selected interaction " + interaction + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected interaction " + interaction + " from recent work tab.");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the intent status.");
		test.log(Status.INFO,"Check the intent status.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}

	@AfterMethod
	public void tearDown() throws Exception  {
		test.log(Status.INFO, "HMHS_TC007_ResearchInteraction_SwitchMember_ConfiComm completed.");
		log.debug("HMHS_TC007_ResearchInteraction_SwitchMember_ConfiComm completed.");
		quit();

	}
}
