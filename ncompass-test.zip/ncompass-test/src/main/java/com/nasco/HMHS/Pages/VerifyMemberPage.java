package com.nasco.HMHS.Pages;

import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;


@SuppressWarnings({"rawtypes","unchecked"})
public class VerifyMemberPage extends BasePage{

	
	
	@FindBy(id = "PegaGadget1Ifr")
	public WebElement frame;
	
	@FindBy(xpath = "//input[@name='$PpyWorkPage$pSelectedMemberPage$pDateOfBirthCheck' and @type='checkbox']")
	public WebElement VerifyDOB;
	
	@FindBy(xpath = "//input[@name='$PZipCodeAndAddrRadioBtn$ppxResults$l1$ppySelected' and @type='checkbox']")
	public WebElement VerifyAddress;
	
	@FindBy(xpath = "//button[text()='Submit']")
	public WebElement Submit;
	
	@FindBy(xpath = "//button[@title='Other actions']")
	public WebElement otherActions;
	
	@FindBy(xpath = "//span[text()='Wrap Up, Contact Not Verified']")
	public WebElement wrapupNotVerified;
	
	@FindBy(xpath = "//span[text()='Verify Member']")
	public WebElement verifyMember;
	
	@FindBy(xpath = "//span[text()='Member Search']")
	public WebElement memberSearch;
	
	
	@FindBy(xpath = "//span[text()='Exit Interaction']")
	public WebElement exitInt;
	
	@FindBy(xpath = "//span[text()='Create Quick Contact']")
	public WebElement QuickContact;
	
	@FindBy(xpath = "//input[@name='$PNewContact$pFirstName']")
	public WebElement QuickContactFN;
	
	@FindBy(xpath = "//input[@name='$PNewContact$pLastName']")
	public WebElement QuickContactLN;
	
	
	@FindBy(xpath = "//input[@name='$PNewContact$pLinkRoleDescription']")
	public WebElement QuickContactType;
	
	@FindBy(xpath = "//span[text()='Select An Associated Contact']")
	public WebElement AssoContact;
	
	
	
	
	String associateContactRow="//tr[contains(@id,'$PpyWorkPage$pContactList$l')]";
	String associateContact="//tr[contains(@id,'$PpyWorkPage$pContactList$l%d')]";
	String associateMember="//span[text()='%s']";
	
	@FindBy(xpath = "//div[text()='No ADHI or Law document exists for the member.']")
	public WebElement NoADHI;
	
	
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		waitSleep(1500);
		switchToFrame("PegaGadget1Ifr");
		try{
			ExpectedConditions.visibilityOf(Submit);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		return ExpectedConditions.visibilityOf(Submit);
	}

	
	public void Verifymember() {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			try{
			jsClick(VerifyDOB, "Verify DOB");
			}
			catch(StaleElementReferenceException e){
				jsClick(VerifyDOB, "Verify DOB");
			}
			waitSleep(2500);
			jsClick(VerifyAddress, "Verify Address");
			jsClick(Submit, "Submit");
			waitSleep(2500);
		}

		catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on Verifymember method " + e);
			test.log(Status.FAIL, "Error on Verifymember method " + e);
			throw e;
		}
	}
	
	public void NotVerifymember() {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(2500);
			try{
				jsClick(Submit, "Submit");
			}
			catch(StaleElementReferenceException e){
				jsClick(Submit, "Submit");
			}
			waitSleep(2500);
		}

		catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on Verifymember method " + e);
			test.log(Status.FAIL, "Error on Verifymember method " + e);
			throw e;
		}
	}
	
	public void wrapUpnotVerified()
	{
		try{
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(otherActions, "Other Actions");
			waitSleep(700);
			webElementClick(wrapupNotVerified, "Wrap up, not verified");
			waitSleep(2000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(700);
			webElementClick(verifyMember, "Verify Member");
			waitSleep(2000);
			webElementClick(otherActions, "Other Actions");
			waitSleep(700);
			webElementClick(wrapupNotVerified, "Wrap up, not verified");
			waitSleep(700);
			webElementClick(Submit, "Submit");
		}catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on wrapUpnotVerified method " + e);
			test.log(Status.FAIL, "Error on wrapUpnotVerified method " + e);
			throw e;
		}
	}
	
	public void memberSearch()
	{
		try{
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(otherActions, "Other Actions");
			waitSleep(500);
			webElementClick(memberSearch, "Member Search");
			waitSleep(3500);
		}catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on memberSearch method " + e);
			test.log(Status.FAIL, "Error on memberSearch method " + e);
			throw e;
		}
	}
	
	public void getAssociateMemberList(Hashtable<String, String> data)
	{
		try{
			List<WebElement> rows= driver.findElements(By.xpath(associateContactRow));
			String associateContacts="|";
			for(int i=1;i<=rows.size();i++)
			{
				associateContacts=associateContacts
						+driver.findElement(By.xpath(String.format(associateContact,i)+"/td[1]")).getText()
						+"|"
						+driver.findElement(By.xpath(String.format(associateContact,i)+"/td[2]")).getText()
						+"|";
				if(i!=rows.size())
				{
					associateContacts=associateContacts+",|";
				}
			}
			//System.out.println("Associated Contacts:"+associateContacts);
			assertEquals(data.get("ExpectedAssociateContacts"), associateContacts, "Associated Contacts");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getAssociateMemberList method " + e);
			test.log(Status.FAIL, "Error on getAssociateMemberList method " + e);
			throw e;	
		}
		
		
		
	}
	
	public void selectAssociateMember(Hashtable<String, String> data)
	{
		try{
			webElementClick(driver.findElement(By.xpath(String.format(associateMember, data.get("ContactName")))),
					"Associate Members");
			waitSleep(1500);
			webElementClick(Submit,"Submit");
			waitSleep(1500);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectAssociateMember method " + e);
			test.log(Status.FAIL, "Error on selectAssociateMember method " + e);
			throw e;	
		}
	}
	
	public void verifyAssociate(Hashtable<String, String> data)
	{
		try{
			waitSleep(1500);
			try {
				NoADHI.click();
			}catch(Exception e1)
			{
				driver.findElement(By.xpath("//label[text()='Contact is not authorized']")).click();
			}
			//webElementReadText(NoADHI, "No ADHI or Law document");
			waitSleep(1500);
			webElementClick(Submit,"Submit");
			waitSleep(3500);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on verifyAssociate method " + e);
			test.log(Status.FAIL, "Error on verifyAssociate method " + e);
			throw e;	
		}
	}
	
	public void movetoQuickContact()
	{
		try{
			waitSleep(2500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(otherActions, "Other Actions");
			waitSleep(500);
			webElementClick(QuickContact, "Quick Contact");
			waitSleep(3500);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on movetoQuickContact method " + e);
			test.log(Status.FAIL, "Error on movetoQuickContact method " + e);
			throw e;	
		}
	}
	
	public void addQuickContact(Hashtable<String, String> data)
	{
		try{
			webElementSendText(QuickContactFN, data.get("QuickContactFN"), "Contact First name");
			webElementSendText(QuickContactLN, data.get("QuickContactLN"), "Contact Last name");
			webElementSendText(QuickContactType, data.get("QuickContactType"), "Contact type");
			waitSleep(1500);
			webElementClick(driver.findElement(By.xpath(String.format(associateMember, data.get("QuickContactType")))), "Contact type");
			waitSleep(1500);
			webElementClick(Submit, "Submit");
			waitSleep(3500);
		}catch(Exception e)
		{
			BaseTest.log.error("Error on addQuickContact method " + e);
			test.log(Status.FAIL, "Error on addQuickContact method " + e);
			e.printStackTrace();
			throw e;	
		}
	}
	
	public void movetoAssociateContact()
	{
		try{
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(otherActions, "Other Actions");
			waitSleep(500);
			webElementClick(AssoContact, "Associate Contact");
			waitSleep(1500);
		}catch(Exception e)
		{
			BaseTest.log.error("Error on movetoAssociateContact method " + e);
			test.log(Status.FAIL, "Error on movetoAssociateContact method " + e);
			e.printStackTrace();
			throw e;	
		}
	}
	
	public void movetoMemberSearch()
	{
		try{
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(otherActions, "Other Actions");
			waitSleep(500);
			webElementClick(memberSearch, "Member");
			waitSleep(1500);
		}catch(Exception e)
		{
			BaseTest.log.error("Error on movetoMemberSearch method " + e);
			test.log(Status.FAIL, "Error on movetoMemberSearch method " + e);
			e.printStackTrace();
			throw e;	
		}
	}	
	
	public void exitInteraction()
	{
		try{
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			webElementClick(otherActions, "Other Actions");
			waitSleep(500);
			webElementClick(exitInt, "Exit Interaction");
			waitSleep(1500);
			webElementClick(Submit, "Submit");
		}catch(Exception e)
		{
			BaseTest.log.error("Error on exitInteraction method " + e);
			test.log(Status.FAIL, "Error on exitInteraction method " + e);
			e.printStackTrace();
			throw e;	
		}
	}
	public Member360Page OpenMember360Page() {
		return (Member360Page)openPage(Member360Page.class);
	}
}
