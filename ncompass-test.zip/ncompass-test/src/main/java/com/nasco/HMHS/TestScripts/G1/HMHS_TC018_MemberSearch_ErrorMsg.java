package com.nasco.HMHS.TestScripts.G1;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC018_MemberSearch_ErrorMsg extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void HMHS_AUTC018_MemberSearch_ErrorMsg(Hashtable<String,String> data) throws Exception {
		try{
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside HMHS_AUTC018_MemberSearch_ErrorMsg ");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_AUTC018_MemberSearch_ErrorMsg - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("HMHS_AUTC018_MemberSearch_ErrorMsg -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		test.log(Status.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction=searchMember.getLIInteractionID();
		log.debug("Interaction id: "+interaction);
		test.log(Status.INFO,"Interaction id: "+interaction);
		searchMember.HMHSNoMemberValue();
		log.debug("Value is blank in Member search textbox");
		test.log(Status.INFO,"Value is blank in Member search textbox");
		searchMember.HMHSValueBlankMess( data.get("MemberBlankErrMsg"), "PegaGadget1Ifr");
		log.debug("Reading Error Message.");
		test.log(Status.INFO,"Reading Error Message.");
		
		//Invalid search
		searchMember.HMHSsearchMember( data.get("InvalidMemID"));
		searchMember.HMHSNoRecordMess( data.get("NoRecordMsg"), "PegaGadget1Ifr");
		log.debug("Reading Error Message");
		test.log(Status.INFO,"Reading Error Message.");
		
		//Code to submit without selecting member list
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed.");
		test.log(Status.INFO,"Member Search Completed.");
		searchMember.HMHSNoMemberSubmit();
		log.debug("Click on Submit.");
		test.log(Status.INFO,"Click on Submit.");
		searchMember.HMHSMemberNotListMess( data.get("MemNotListErrorMessage"), "PegaGadget1Ifr");
		log.debug("Reading Error Message.");
		test.log(Status.INFO,"Reading Error Message.");
		searchMember.HMHClearErrMess();
		log.debug("Click on Clear button.");
		test.log(Status.INFO,"Click on Clear button.");
		searchMember.HMHSClearMemNotListMess( "PegaGadget1Ifr");
		log.debug("Error message cleared.");
		test.log(Status.INFO,"Error message cleared.");
		
		//Uncheck Contact Selected Member List and submit and verify the error message
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed.");
		test.log(Status.INFO,"Member Search Completed.");
		//Checkbox is disabled, so commenting this line of code
		//searchMember.HMHSUnCheckboxContact();
		//log.debug("Uncheck Contact Selected Member Checkbox");
		searchMember.HMHSNoMemberSubmit();
		log.debug("Click on Submit.");
		test.log(Status.INFO,"Click on Submit.");
		searchMember.HMHSMemberNotListMess( data.get("MemNotListErrorMessage"), "PegaGadget1Ifr");
		log.debug("Reading Error Message."); 
		test.log(Status.INFO,"Reading Error Message.");
		searchMember.HMHSsearchMember(data.get("InvalidUMI"));
		searchMember.HMHSInvalidUMI("PegaGadget1Ifr",data.get("Excepterror"));
		log.debug("Error Message for invalid UMI matched.");
		test.log(Status.INFO,"Error Message for invalid UMI matched.");
		
		searchMember.ExitInteraction();
		log.debug("Moved to Exit Interaction page.");
		test.log(Status.INFO,"Moved to Exit Interaction page.");
		searchMember.WrapUpSubmit("Wrap up intent");
		log.debug("Comments submitted.");
		test.log(Status.INFO,"Comments submitted.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
		
		}
	@AfterMethod
	public void tearDown() throws Exception  {
		
		test.log(Status.INFO, "HMHS_AUTC018_MemberSearch_ErrorMsg Completed");
		log.debug("HMHS_AUTC018_MemberSearch_ErrorMsg Completed");
		quit();
		
	}
}
