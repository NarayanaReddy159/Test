package com.nasco.HMHS.TestScripts.G2_CleanupUtility;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.ManagerToolsPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC001_LIV_CleanUp_Utility extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC001_LIV_CleanUp_Utility (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		String methodName="HMHS_AUTC001_LIV_CleanUp_Utility";
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser :  " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username6"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password6"));
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username6") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password6"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username6")
				);

		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		test.log(Status.INFO, "Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page");
		test.log(Status.INFO, data.get("Fname") + "Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO, "Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Member Verified successfully.");
        test.log(Status.INFO, "Member Verified successfully.");
        String InteractionId =  searchMember.getLIInteractionID();
        log.debug("Intent id: " + InteractionId);
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(Status.INFO,"Add Intent "+data.get("Intent"));
        ViewTotalPage TOT=homepage.VeiwTotalPage();
		
		String intentID = TOT.getIntentID();
		log.debug("Intent id: " + intentID);
       
		TOT.WebsiteCreatenew(data);
		log.debug("Validate the Website Create new tab");
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		test.log(Status.INFO,"Navigate to Wrap up screen. ");
		//String InteractionId="LVI-47390";
		ManagerToolsPage managertools=homepage.openManagerToolsPage();
		managertools.movetoManageTools();
		log.debug("Navigate to movetoManageTools screen");
		test.log(Status.INFO,"Navigate to movetoManageTools screen. ");
		managertools.cleanUpUtility();
		log.debug("Click on clean Up Utility");
		test.log(Status.INFO,"Click on clean Up Utility. ");
		managertools.Search_Worktype(data.get("WorkType"),data.get("Operator"));
		log.debug("Search for interaction .");
		test.log(Status.INFO,"Search for interaction.");
		managertools.SearchresultsHeader(data);
		log.debug("Check the SearchresultsHeader.");
		test.log(Status.INFO,"Check the SearchresultsHeader.");
		managertools.sortandSelectIntent(InteractionId);
		managertools.selectTask(InteractionId);
		log.debug("Select  the workitem.");
		test.log(Status.INFO,"Select  the workitem.");
		
		managertools.resultsHeader(data);
		log.debug("Check the resultsHeader.");
		test.log(Status.INFO,"Check the resultsHeader.");
		managertools.statusOfResult(data.get("IntStatus"),"PegaGadget1Ifr");
		
//		ManagerToolsPage managertools=homepage.openManagerToolsPage();
//		managertools.movetoManageTools();
//		log.debug("Navigate to movetoManageTools screen");
//		test.log(Status.INFO,"Navigate to movetoManageTools screen. ");
		managertools.cleanUpUtility();
		log.debug("Click on clean Up Utility");
		test.log(Status.INFO,"Click on clean Up Utility. ");
		managertools.Search_Worktype(data.get("WorkTypeInt"),data.get("Operator"));
		log.debug("Search for interaction .");
		test.log(Status.INFO,"Search for interaction.");
		managertools.SearchresultsHeader(data);
		log.debug("Check the SearchresultsHeader.");
		test.log(Status.INFO,"Check the SearchresultsHeader.");
		managertools.sortandSelectIntent(intentID);
		managertools.selectTask(intentID);
		log.debug("Select  the workitem.");
		test.log(Status.INFO,"Select  the workitem.");
		
		managertools.resultsHeader(data);
		log.debug("Check the resultsHeader.");
		test.log(Status.INFO,"Check the resultsHeader.");
		managertools.statusOfResult(data.get("IntStatus"),"PegaGadget1Ifr");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
		
	}
	@AfterMethod
	public void tearDown() throws Exception  
	{	test.log(Status.INFO, "HMHS_TC001_LIV_CleanUp_Utility completed.");
		log.debug("HMHS_TC001_LIV_CleanUp_Utility completed.");
		quit();
	}
}
