package com.nasco.HMHS.TestScripts.G2.ResearchInteraction;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.ResearchInteractionPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC002_ResearchInteraction_ErrCheck extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC002_ResearchInteraction_ErrCheck (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC002_ResearchInteraction_ErrCheck");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC002_ResearchInteraction_ErrCheck - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC002_ResearchInteraction_ErrCheck -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSResearchInteractionMember();
		String interaction = searchMember.getREInteractionID();
		log.debug("Interaction id: " + interaction);
		test.log(Status.INFO,"Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data);
		log.debug("Member Search Completed.");
		test.log(Status.INFO, "Member Search Completed.");
		
		//Enter invalid UMI number to get error message as "No member records were found using the search criteria. Retry the search."
		searchMember.HMHSInvalidUMI("PegaGadget1Ifr",data.get("Excepterror"));
		log.debug("Error Message for invalid UMI matched.");
		test.log(Status.INFO,"Error Message for invalid UMI matched.");
		
		//Enter invalid UMI number to get error message as "No member records were found using the search criteria. Retry the search."
		searchMember.HMHSsearchMember(data.get("MemberID_1"));
		log.debug("Member Search Completed.");
		test.log(Status.INFO,"Member Search Completed.");
		searchMember.HMHSNoMemberSubmit();
		log.debug("Without selecting the member Click on Submit to check the error message as Please select the member from the list.");
		test.log(Status.INFO,"Without selecting the member Click on Submit to check the error message as Please select the member from the list.");
		
		//From Exit Interaction come back to Member Search screen.
		searchMember.ExitInteractionBackToSearch();
		log.debug("Exit Interaction come back to Member Search screen.");
		test.log(Status.INFO,"Exit Interaction come back to Member Search screen.");
		
		//Perform the Exit Interaction.
		ResearchInteractionPage research= homepage.ResearchInteraction();
		research.ExitInteraction(data);
		log.debug("Moved to Exit Interaction page enter the comments and Submit.");
		test.log(Status.INFO,"Moved to Exit Interaction page enter the comments and Submit.");
		
		
//		for(int i=0;i<7;i++)
//		{
//			MemberSearchPage searchMember1 = homepage.clickOnHMHSResearchInteractionMember1();
//			wait(5000);
//		}
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}

	@AfterMethod
	public void tearDown() throws Exception  {
		test.log(Status.INFO, "HMHS_TC002_ResearchInteraction_ErrCheck completed.");
		log.debug("HMHS_TC002_ResearchInteraction_ErrCheck completed.");
		quit();

	}
}
