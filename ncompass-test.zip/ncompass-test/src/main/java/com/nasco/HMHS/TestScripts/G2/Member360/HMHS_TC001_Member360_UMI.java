package com.nasco.HMHS.TestScripts.G2.Member360;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.Member360Page;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC001_Member360_UMI extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC001_Member360_UMI(Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC001_Member360_UMI Search");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC001_Member360_UMI - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		log.debug("HMHS_TC001_Member360_UMI -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username2") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
		log.debug("Verify member");
		Member360Page mem360=homepage.Member360Page();
		log.debug("Navigate to Member 360 page ");
		InteractionManager.openTask();
		
		// header details
//		mem360.Interactionheader_details(data.get("ExpectedinteractionDetails"));
//		log.debug("Navigate to Member 360 page Interactionheader_details ");
		
		//issue reported on 1/5/21
		/*if(data.get("Addphone").equals("Yes"))
		{
			mem360.interactionHeader_AddContact(data.get("Type"),data.get("Number"),data.get("ExceptedError"),data.get("ExceptErrorchar"));
		}*/
		//mem360.interactionHeader_contactInformation(data.get("ExpectedcontactInformation"));
		//log.debug("Navigate to Member 360 page Interactionheader_details ");
		mem360.interactionHeader_memberInformation(data.get("ExpectedmemberInformation"));
		log.debug("Navigate to Member 360 page interactionHeader_memberInformation ");
		
		//mem360.interactionHeader_ALERTS(ExpectedALERTSInformation, Alert, ExceptedmessageMouseover);
		
		// Contract tab
		mem360.contractTab_readMemberDetails(data.get("Expected _policy ") ,data.get("expectedheader"),data.get("ExpectedMember"));
		//issue reported on 1/4/21
		mem360.contractTab_Policy(data.get("Group"));
		log.debug("Navigate to Member 360 page contractTab_Policy ");
		mem360.contractTab_contractdetails(data.get("Contractheader"),data.get("Contractheader1"),data.get("Expectedcontractdetails"),data.get("ExpectedMessagearea"),data.get("ExpectedMessagearea"));
	    mem360.contractTab_Spendingaccount(data.get("ExpectedSpendingaccount"),data.get("ExpectedSpendingheader"));	
		//issue reported on 1/5/21
	    mem360.contractTab_Members(data.get("ExpectedMembers"), data.get("ExpectedMembersheader"), data.get("memberResult"));
		mem360.contractTab_MembersICON(data.get("headericon"), data.get("Expectedicon"),data.get("headersdata1"));
		mem360.contractTab_Addresses(data.get("ExpectedAddressesheader"), data.get("ExpectedAddresses"));
		// member tab
		mem360.memberTab_Generalinformation(data.get("Memberheader"),data.get("expectedGeneralinformation"));
		mem360.memberTab_Address(data.get("ExpectedMembersaddressheader"), data.get("ExpectedaddressDetails"));
		mem360.memberTab_Memberpreferences(data.get("ExpectedMemberpreferencesheader"), data.get("MemberpreferencesResult"),data.get("preferencesdetail"));
		mem360.memberTab_Associatedcontactslist(data.get("ExpectedAssociatedcontactsheader"), data.get("AssociatedResult"));
		mem360.memberTab_Othermemberidentifiers(data.get("ExpectedOthermemberidentifiersheader"),data.get("OthermemberidentifiersResult"));
		mem360.memberTab_Extendedeligibility(data.get("ExpectedExtendedeligibilityheader"),data.get("ExtendedeligibilityResult"));
		// Group tab
		mem360.groupTab_Generalinformation(data.get("Groupheader"),data.get("ExpectedGroupinformationdetails"));
		mem360.groupTab_Productinformation(data.get("ExpectedProductinformationheader"), data.get("ProductinformationResult"));
		mem360.groupTab_Salesreps(data.get("ExpectedSalesrepsheader"), data.get("SalesrepsResult"));
		mem360.groupTab_Addresses(data.get("ExpectedgroupAddresses"), data.get("ExpectedgroupAddheader"));
		
		// Interactions tab
		
		/*mem360.interactionsTab_Recentinteractions(data.get("Expectedinteractionsheader"));
		mem360.interactionsTab_sortandSelectIntent();
		mem360.interactionsTab_Externalplatform(data.get("Expectedexternalplatformheader"),data.get("Expectedexternalplatformdetails"));
		mem360.interactionsTab_sortandSelectExternalplatform();*/
		InteractionManager.wrapUp("Wrap up interaction");
		log.debug("Navigate to Wrap up screen");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Recentwork.");
		test.log(Status.INFO,"Navigated to the Recentwork.");
		recentWork.sortandSelectIntent( interaction);
		//System.out.println("Sorted and selected interaction " + interaction + " from recent work tab.");
		log.debug("Sorted and selected interaction " + interaction + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected interaction " + interaction + " from recent work tab.");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the intent status.");
		test.log(Status.INFO,"Check the intent status.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  {

		test.log(Status.INFO, "HMHS_AUTC001_Member360_UMI Completed.");
		log.debug("HMHS_AUTC001_Member360_UMI Completed.");
		quit();

	}
}
