package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked"})
public class CreateFollowUpPage extends BasePage {

	String excepionMessage = "";
	String taskNameXpath="//a[contains(text(),'%s')]";
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Add task')]")
	public WebElement addTask;
	@FindBy(how = How.XPATH, using = "//button[@title='Add task']")
	public WebElement add;
	@FindBy(xpath = "//input[@id='5934ac3b']")
	public WebElement Operator;
	@FindBy(how = How.XPATH, using = "//select[@id='13a13f46']")
	public WebElement FollowReason;
	@FindBy(xpath = "//label[contains(text(),'Now')]")
	public WebElement SelectNow;
	@FindBy(xpath = "//label[contains(text(),'Scheduled')]")
	public WebElement SelectScheduled;
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	@FindBy (how = How.XPATH, using = "//textarea[@id='b8561375']")
	public WebElement Followupcomment;
	
	@FindBy(how = How.XPATH, using = "//select[@id='4a4a1e95']")
	public WebElement Reason;
	@FindBy(how = How.XPATH, using="//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[1]/aside[1]/div[1]/div[1]/span[1]/div[1]/span[1]/div[1]/span[2]/div[1]/div[1]/div[3]/div[1]/span[1]/i[1]")
	public WebElement Wrapup;
	@FindBy(name = "$PpyWorkPage$pWrapUpComments")
	public WebElement WrapUpComments;
	@FindBy(xpath = "//div[contains(text(),'Submit')]//ancestor::button")
	public WebElement SubmitWrapUp;
	
	@FindBy(xpath = "//span[contains(text(),'Create Follow-Up')]")
	public WebElement OtherActionsCreateFollowUp;
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]//preceding::b[1]")
	public WebElement message;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(add);
	}
	//TO Add task for Interaction Manager 
	public void addTask(String intentName) {
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3500);
			webElementClick( add, "add Task");
			webElementClick( driver.findElement(By.xpath(String.format(taskNameXpath, intentName))),"task Name");
			webElementClick( addTask, "add Task");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on addTask method " + e);
			test.log(Status.FAIL, "Error on addTask method " + e);
			throw e;
		}
	}
	
public void CreateFollowUpIntent(
			String memberSearchFname,Hashtable<String, String> data){
	String Message= "";
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			selectDropdownValueByVisibleText(FollowReason, data.get("FollowUpReason"), "Reason for follow-up");
			wait(1500);
			webElementClick(SelectScheduled, "Select Scheduled to followup task occur");
			wait(2000);
			webElementSendText(Followupcomment, data.get("comments"), "as Comments");
			waitSleep(1500);
			Message= webElementReadText(message, "Message");
			 //System.out.println(Message);
			webElementClick(Submit, "Submit");
			assertEquals(data.get("ExpectedFollowUpMessage"), Message, "Message");
			wait(2000);
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on CreateFollowUpIntent method " + excepionMessage);
			test.log(Status.FAIL, "Error on CreateFollowUpIntent method " + e);
			throw e;
		}
	}

public void CreateFollowUpIntent(Hashtable<String, String> data){
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		selectDropdownValueByVisibleText(FollowReason, data.get("FollowReason"), "Reason for follow-up");
		wait(1500);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", SelectScheduled);
		webElementClick(SelectScheduled, "Select Scheduled to followup task occur");
		wait(2000);
		webElementSendText(Followupcomment, data.get("comments"), "as Comments");
		waitSleep(1500);
		webElementClick(Submit, "Submit");
		
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on CreateFollowUpIntent method " + excepionMessage);
		test.log(Status.FAIL, "Error on CreateFollowUpIntent method " + e);
		throw e;
	}
}

public void CreateFollowUpPend(
		String memberSearchFname,Hashtable<String, String> data){
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		selectDropdownValueByVisibleText(FollowReason, data.get("FollowUpReason"), "Reason for follow-up");
		wait(1500);
		webElementClick(SelectScheduled, "Select Scheduled to followup task occur");
		wait(2000);
		webElementSendText(Followupcomment, data.get("comments"), "as Comments");
		waitSleep(1500);
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on CreateFollowUpPend method " + excepionMessage);
		test.log(Status.FAIL, "Error on CreateFollowUpPend method " + e);
		throw e;
	}
}


public void CreateFollowUpIntentAssignOpr2(
		String memberSearchFname,Hashtable<String, String> data){
	String Message="";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		webElementSendText(Operator, data.get("Operator"), "to select Reason to Pend");
		wait(1500);
		Operator.sendKeys(Keys.TAB);
		wait(1500);
		selectDropdownValueByVisibleText(FollowReason, data.get("FollowUpReason"), "Reason for follow-up");
		wait(1500);
		webElementClick(SelectScheduled, "Select Scheduled to followup task occur");
		wait(2000);
		webElementSendText(Followupcomment, data.get("comments"), "as Comments");
		waitSleep(1500);
		Message= webElementReadText(message, "Message");
		 //System.out.println(Message);
		
		assertEquals(data.get("ExpectedFollowUpMessage"), Message, "Message");
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on CreateFollowUpIntentAssignOpr2 method " + excepionMessage);
		test.log(Status.FAIL, "Error on CreateFollowUpIntentAssignOpr2 method " + e);
		throw e;
	}
}
	
public void CreateFollowUpIntentNow(
		String memberSearchFname,Hashtable<String, String> data){
	String Message= "";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(5000);
		selectDropdownValueByVisibleText(FollowReason, data.get("FollowUpReason"), "Reason for follow-up");
		wait(1500);
		webElementClick(SelectNow, "Select now to followup task occur");
		wait(2000);
		webElementSendText(Followupcomment, data.get("comments"), "as Comments");
		Message= webElementReadText(message, "Message");
		 //System.out.println(Message);
		
		assertEquals(data.get("ExpectedFollowUpMessage"), Message, "Message");
		waitSleep(1500);
		webElementClick(Submit, "Submit");
		wait(2000);
	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on CreateFollowUpIntent Now method " + excepionMessage);
		test.log(Status.FAIL, "Error on CreateFollowUpIntent Now method " + e);
		throw e;
	}
}


	public CreateFollowUpPage opencreateFollowUpPage()
	{
		return (CreateFollowUpPage)openPage(CreateFollowUpPage.class);
	}
	
}