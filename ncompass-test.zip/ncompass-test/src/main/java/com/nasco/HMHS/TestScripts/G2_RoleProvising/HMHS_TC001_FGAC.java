package com.nasco.HMHS.TestScripts.G2_RoleProvising;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC001_FGAC extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC001_FGAC (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC001_FGAC");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC001_FGAC - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username4"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password4"));
		log.debug("HMHS_TC001_FGAC -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username4") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password4"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username4")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		test.log(Status.INFO, "Member Search Completed");
		searchMember.FGAChovermessage(data.get("ExceptedRestrictedhover"));
		log.debug("FGAChovermessage Completed");
		test.log(Status.INFO, "FGAChovermessage Completed");
		
		searchMember.FGACselectMemberAndNavigatebyRelationship(data.get("Relationship"),data.get("ExceptedError"));
		log.debug(data.get("Relationship") + "Selected from the search results and navigated to verify member page");
		test.log(Status.INFO, data.get("Relationship") + "Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO, "Member Submit Completed.");
		searchMember.ExitInteraction();
		searchMember.WrapUpSubmit("Wrap Up");
		log.debug("Click on the Exit Interaction screen.");
		test.log(Status.INFO, "Click on the Exit Interaction screen.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
       	}
	@AfterMethod
	public void tearDown() throws Exception  
	{	test.log(Status.INFO, "HMHS_TC001_FGAC completed.");
		log.debug("HMHS_TC001_FGAC completed.");
		quit();
	}
}
