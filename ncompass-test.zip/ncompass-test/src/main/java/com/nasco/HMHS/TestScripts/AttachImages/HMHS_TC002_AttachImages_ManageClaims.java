package com.nasco.HMHS.TestScripts.AttachImages;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.ManageClaimsPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.OtherActions;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;

public class HMHS_TC002_AttachImages_ManageClaims extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G1DP")
	public void HMHS_AUTC002_AttachImages_ManageClaims(Hashtable<String, String> data) throws Exception {
		try{
			setUpFramework();
			test = DriverManager.getExtentReport();
			log.info("Inside HMHS_AUTC002_AttachImages_ManageClaims");
			openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
			log.debug("HMHS_AUTC002_AttachImages_ManageClaims - Launched Browser : "
					+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
			test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
			LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
			HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
					getDefaultPassword());
			log.debug("HMHS_AUTC002_AttachImages_ManageClaims -Username entered as "
					+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
					+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
			test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
					);
			MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
			String interaction = searchMember.getLIInteractionID();
			log.debug("Interaction id: " + interaction);
			test.log(Status.INFO,"Interaction id: " + interaction);
			searchMember.HMHSsearchMember(data.get("MemberID"));
			log.debug("Member Search Completed.");
			test.log(Status.INFO,"Member Search Completed.");
			searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
			log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page");
			test.log(Status.INFO,data.get("Fname") + "Selected from the search results and navigated to verify member page");
			log.debug("Member Submit Completed.");
			test.log(Status.INFO,"Member Submit Completed.");
			InteractionManagerPage InteractionManager=searchMember.Verifymember();
			log.debug("Verify member");
			InteractionManager.openTask();
			InteractionManager.addTask(data.get("Intent").toString());
			log.debug("Add Intent "+data.get("Intent"));
			ViewTotalPage TOT=homepage.VeiwTotalPage();
			String intentID = TOT.getIntentID();
			ManageClaimsPage manageClaim=InteractionManager.openManageClaims();
			OtherActions otherActions=homepage.openOtherActions();
			manageClaim.searchClaims(data);
			log.debug("Navigate to Search for claim screen.");
			test.log(Status.INFO,"Navigate to Search for claim screen. ");
			manageClaim.selectClaim(data);
			manageClaim.adjust(data);
			log.debug("User selected the claim screen.");
			TOT.movetoattachImg();
			TOT.attachImg(data);
			intentID = TOT.getIntentID();
			TOT.movetoattachImg();
			TOT.validateAttachImg(data);
			TOT.closeModal();
			otherActions.saveToWorklist(data);
			InteractionManager.openTask();
			InteractionManager.wrapUp(data.get("Comments"));
			RecentWorkPage recentWork = homepage.openrecentWork();
			WorklistPage worklist= homepage.openrecentWorklist();
			worklist.movetoWorklistPage();
			worklist.sortandSelectIntent(data, intentID);
			TOT.movetoattachImg();
			TOT.validateAttachImg(data);
			TOT.closeModal();
			otherActions.cancelWork(data);	
			recentWork.movetoRecentWorkPage();
			recentWork.sortandSelectIntent(intentID);
			TOT.movetoattachImgClick(data);
			recentWork.closeRecentWork();
			
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
		
		
	
	}

	@AfterMethod
	public void tearDown() throws Exception  {
		test.log(Status.INFO, "HMHS_AUTC002_AttachImages_ManageClaims");
		log.debug("HMHS_AUTC002_AttachImages_ManageClaims");
		quit();
	}
}
