package com.nasco.HMHS.TestScripts.G2.Report;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.ReportPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC006_Report_Vaildate_PerformanceGaurentee extends BaseTest{
	
	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC006_Report_Vaildate_PerformanceGaurentee(Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC001_Report_Vaildate_Allreport_links");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC001_Report_Vaildate_Allreport_links - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		log.debug("HMHS_TC001_Report_Vaildate_Allreport_links -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username2") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password2"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username2")
				);
		ReportPage Report = homepage.openReportPage();
		Report.MyReport(data);
		log.debug("Navigated to the Home-My Report Section");
		test.log(Status.INFO, "Navigated to the Home-My Report Section");
		Report.ReportName(data);
		log.debug("Navigated to the Home-My Report SLABreakdownofOpenServiceRequests Section");
		test.log(Status.INFO, "Navigated to the Home-My Report SLABreakdownofOpenServiceRequests Section");
		Report.PerformanceGaurentee(data);
		log.debug("Navigated to the Home-My Report OpenInventory Section");
		test.log(Status.INFO, "Navigated to the Home-My Report OpenInventory Section");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	
	@AfterMethod
	public void tearDown() throws Exception  {

		test.log(Status.INFO, "HMHS_AUTC001_Report_Vaildate_Allreport_links Completed.");
		log.debug("HMHS_AUTC001_Report_Vaildate_Allreport_links Completed.");
		quit();
	}

}
