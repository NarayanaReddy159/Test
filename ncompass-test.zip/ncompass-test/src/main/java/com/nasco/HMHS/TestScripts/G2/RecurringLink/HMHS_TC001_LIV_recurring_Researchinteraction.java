package com.nasco.HMHS.TestScripts.G2.RecurringLink;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.Member360Page;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.ViewTotalPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC001_LIV_recurring_Researchinteraction extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC001_LIV_recurring_Researchinteraction (Hashtable<String, String> data) throws Exception {
		try{
			setUpFramework();
			test = DriverManager.getExtentReport();
			log.info("Inside HMHS_TC001_LIV_recurring_Researchinteraction");
			openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
			log.debug("HMHS_TC001_LIV_recurring_Researchinteraction - Launched Browser : "
					+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
			test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
			LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
			HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
					getDefaultPassword());
			log.debug("HMHS_TC001_LIV_recurring_Researchinteraction -Username entered as "
					+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
					+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
			test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
			);
			MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
			String interaction = searchMember.getLIInteractionID();
			log.debug("Interaction id: " + interaction);
			test.log(Status.INFO,"Interaction id: " + interaction);
			searchMember.HMHSsearchMember(data.get("MemberID"));
			log.debug("Member Search Completed");
			test.log(Status.INFO, "Member Search Completed");
			searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
			log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page");
			test.log(Status.INFO, data.get("Fname") + "Selected from the search results and navigated to verify member page");
			log.debug("Member Submit Completed.");
			test.log(Status.INFO, "Member Submit Completed.");
			InteractionManagerPage InteractionManager=searchMember.Verifymember();
			log.debug("Member Verified successfully.");
			test.log(Status.INFO, "Member Verified successfully.");
			Member360Page mem360=homepage.Member360Page();
			log.debug("Navigate to Member 360 page ");
			InteractionManager.openTask();
			String memberInformation =mem360.interactionHeader_memberInformation(false, "", "PegaGadget1Ifr");
			String contractTab_readMemberDetails=mem360.contractTab_readMemberDetails(false, "",  "PegaGadget1Ifr");
			String contractdetail=mem360.contractTab_contractdetails(false,data.get("contractheader"),data.get("contractheader1"), "", "PegaGadget1Ifr");
			String Spendingaccount=mem360.contractTab_Spendingaccount(false, "", "PegaGadget1Ifr");
			String Addresses=mem360.contractTab_Addresses(false, "", "PegaGadget1Ifr");
			String Members=mem360.contractTab_Members(false, "", "PegaGadget1Ifr");

			String Memberdetails=mem360.memberTab_Generalinformation(false,data.get("Memberheader"), "", "PegaGadget1Ifr");
			String memberTab_Address=mem360.memberTab_Address(false, "", "PegaGadget1Ifr");
			String memberTab_Memberpreferences=mem360.memberTab_Memberpreferences(false, "", "PegaGadget1Ifr");
			String memberTab_Email=mem360.memberTab_Email(false, "", "PegaGadget1Ifr");
			String memberTab_Associatedcontactslist=mem360.memberTab_Associatedcontactslist(false, "", "PegaGadget1Ifr");
			String memberTab_Othermemberidentifiers=mem360.memberTab_Othermemberidentifiers(false, "", "PegaGadget1Ifr");
			String memberTab_Extendedeligibility =mem360.memberTab_Extendedeligibility(false, "", "PegaGadget1Ifr");

			String groupdetails=mem360.groupTab_Generalinformation(false, data.get("Groupheader"), "",  "PegaGadget1Ifr");
			String groupTab_Productinformation=mem360.groupTab_Productinformation(false, "", "PegaGadget1Ifr");
			String groupTab_Salesreps=mem360.groupTab_Salesreps(false, "", "PegaGadget1Ifr");
			String groupTab_Addresses=mem360.groupTab_Addresses(false, "", "PegaGadget1Ifr");
			InteractionManager.addTask(data.get("Intent").toString());
			log.debug("Add Intent "+data.get("Intent"));
			test.log(Status.INFO,"Add Intent "+data.get("Intent"));
			ViewTotalPage TOT=homepage.VeiwTotalPage();

			String intentID = TOT.getIntentID();
			log.debug("Intent id: " + intentID);
			TOT.Createnew(data);
			log.debug("Intent is Created ");		
			InteractionManager.wrapUp(data.get("Comments"));
			log.debug("Navigate to Wrap up screen");

			//String intentID="WEB-1617";
			RecentWorkPage recentWork = homepage.openrecentWork();
			recentWork.movetoRecentWorkPage();
			log.debug("Navigated to the Home-Recentwork Section");
			test.log(Status.INFO, "Navigated to the Home-Recentwork Section");
			recentWork.sortandSelectIntent( intentID);
			//System.out.println("Sorted and selected intent " + intentID + " from recent work tab ");
			log.debug("Sorted and selected intent " + intentID + " from recent work tab ");
			test.log(Status.INFO, "Sorted and selected intent " + intentID + " from recent work tab ");
			//recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
			log.debug("Check the Intent status.");
			recentWork.groupRecurring("PegaGadget1Ifr");
			log.debug("Cilck on group link.");
			
			mem360.ResearchinteractionHeader_memberInformation(true, memberInformation, "PegaGadget2Ifr");
			InteractionManager.openTask("PegaGadget2Ifr");
			mem360.groupTab_Generalinformation(true, data.get("Groupheader"), groupdetails,  "PegaGadget2Ifr");
			mem360.groupTab_Productinformation(true,groupTab_Productinformation, "PegaGadget2Ifr");
			mem360.groupTab_Salesreps(true,groupTab_Salesreps, "PegaGadget2Ifr");
			mem360.groupTab_RIAddresses(true,groupTab_Addresses, "PegaGadget2Ifr");
			
			mem360.memberTab_Generalinformation(true,data.get("Memberheader"), Memberdetails, "PegaGadget2Ifr");
			mem360.memberTab_Address(true,memberTab_Address, "PegaGadget2Ifr");
			mem360.memberTab_Memberpreferences(true, memberTab_Memberpreferences, "PegaGadget2Ifr");
			mem360.memberTab_Email(true, memberTab_Email, "PegaGadget2Ifr");
			mem360.memberTab_Othermemberidentifiers(true, memberTab_Othermemberidentifiers, "PegaGadget2Ifr");
			mem360.memberTab_Extendedeligibility(true, memberTab_Extendedeligibility, "PegaGadget2Ifr");
			mem360.memberTab_Associatedcontactslist(true, memberTab_Associatedcontactslist, "PegaGadget2Ifr");

			//InteractionManager.openTask("PegaGadget2Ifr");
			InteractionManager.EndResearchOpen("PegaGadget2Ifr");
			log.debug("Navigate to End Research screen.");
			test.log(Status.INFO,"Navigate to End Research screen.");
			recentWork.UMIRecurring("PegaGadget1Ifr");
			log.debug("Cilck on group link.");
			
			mem360.ResearchinteractionHeader_memberInformation(true, memberInformation, "PegaGadget2Ifr");
			InteractionManager.openTask("PegaGadget2Ifr");
			mem360.contractTab_readMemberDetails(true, contractTab_readMemberDetails,  "PegaGadget2Ifr");
			mem360.contractTab_contractdetails(true, data.get("contractheader"), data.get("contractheader1"), contractdetail, "PegaGadget2Ifr");
			
			mem360.contractTab_Spendingaccount(true,Spendingaccount, "PegaGadget2Ifr");
			mem360.contractTab_Addresses(true, Addresses, "PegaGadget2Ifr");
			mem360.contractTab_Members(true, Members, "PegaGadget2Ifr");
			//InteractionManager.openTask("PegaGadget2Ifr");
			InteractionManager.EndResearchOpen("PegaGadget2Ifr");
			recentWork.closeRecentwork();
			//System.out.println("----------------LIVE INTERACTION------------");
			recentWork.movetoRecentWorkPage();
			log.debug("Navigated to the Home-Recentwork Section");
			test.log(Status.INFO, "Navigated to the Home-Recentwork Section");
			recentWork.sortandSelectIntent(interaction);
			//System.out.println("Sorted and selected intent " + interaction + " from recent work tab ");
			log.debug("Sorted and selected intent " + interaction + " from recent work tab ");
			test.log(Status.INFO, "Sorted and selected intent " + interaction + " from recent work tab ");

			recentWork.UMIRecurring("PegaGadget1Ifr");
			log.debug("Cilck on group link.");
			mem360.ResearchinteractionHeader_memberInformation(true, memberInformation, "PegaGadget2Ifr");
			mem360.contractTab_contractdetails(true, data.get("contractheader"), data.get("contractheader1"), contractdetail, "PegaGadget2Ifr");
			InteractionManager.openTask("PegaGadget2Ifr");
			InteractionManager.EndResearchOpen("PegaGadget2Ifr");
			recentWork.closeRecentwork();
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  
	{	test.log(Status.INFO, "HMHS_TC001_LIV_recurring_Researchinteraction completed.");
	log.debug("HMHS_TC001_LIV_recurring_Researchinteraction completed.");
	quit();
	}
}
