package com.nasco.HMHS.Run;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.testng.ITestNGListener;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.nasco.HMHS.ExtentListeners.ExtentListeners;

public class RunFailed_NCompass_HMHS {
	public static Properties Config = new Properties();
	private static FileInputStream fis;
	private static Object[][] arrayCounts = new Object[1][4];
	static int includeCount = 0, naCount = 0;
	
	
	public static void reRun(Set<String> failedTC) {
		initConfig();
		dynamicTestNG(failedTC);
	}

	public static void dynamicTestNG(Set<String> failedTC) {
		// Create object of TestNG Class
		TestNG runner = new TestNG();
		// Create an instance of XML Suite and assign a name for it.
		XmlSuite mySuite = new XmlSuite();
		mySuite.setName("HMHSRegressionSuite");
		mySuite.setParallel(XmlSuite.ParallelMode.CLASSES);
		mySuite.setThreadCount(Integer.parseInt(Config.getProperty("PARALLEL_THREAD_COUNT")));
		// Create an instance of XmlTest and assign a name for it.
		XmlTest myTest = new XmlTest(mySuite);
		List<XmlClass> myClasses = new ArrayList<XmlClass>();
		String clsName = "";
		for(Iterator<String> it = failedTC.iterator(); it.hasNext();){
			clsName =it.next();
			myClasses.add(new XmlClass(clsName));
		}
		
		// Assign that to the XmlTest Object created earlier.
		myTest.setXmlClasses(myClasses);

		// Create a list of XmlTests and add the Xmltest you created earlier to
		// it.
		List<XmlTest> myTests = new ArrayList<XmlTest>();
		myTests.add(myTest);

		// add the list of tests to your Suite.
		mySuite.setTests(myTests);

		// Add the suite to the list of suites.
		List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
		mySuites.add(mySuite);
		//System.out.println("myRerunSuite::" + mySuite.toXml());
		// Set the list of Suites to the testNG object you created earlier.
		runner.setXmlSuites(mySuites);
		runner.setUseDefaultListeners(false);
		List<Class<? extends ITestNGListener>> lst = new ArrayList<Class<? extends ITestNGListener>>();
		lst.add(ExtentListeners.class);
		runner.setListenerClasses(lst);
		displayCounts(arrayCounts);
		// invoke run() - this will run your class.
		runner.run();

	}

	public static String getTestDataSheetName(String excelName) {
		String loc = "";

		if (excelName.equalsIgnoreCase("HMHS_Ncompass_TestData_G1")) {
			loc = System.getProperty("user.dir") + Config.getProperty("TestData_G1_XL_PATH");
		}
		if (excelName.equalsIgnoreCase("HMHS_Ncompass_TestData_G2")) {
			loc = System.getProperty("user.dir") + Config.getProperty("TestData_G2_XL_PATH");
		}
		return loc;
	}

	public static void initConfig() {
		try {
			String path = System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\Config.properties";
			fis = new FileInputStream(path);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			Config.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		;
	}

	public static void get_Include_TCs_Count(String dataSheetName, int totRows, int incCnt, int naCnt) {
		totRows = totRows - 1;

		if (dataSheetName.contains("HMHS_Ncompass")) {
			arrayCounts[0][0] = "HMHS";
			arrayCounts[0][1] = totRows;
			arrayCounts[0][2] = incCnt;
			arrayCounts[0][3] = naCnt;
		}

	}

	public static void displayCounts(Object[][] array) {

		for (int i = 0; i < array.length; i++) {

		}
	}

	public static Object[][] getCountsObj() {
		return arrayCounts;
	}

}
