package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;
import com.aventstack.extentreports.Status;

@SuppressWarnings({"rawtypes","unchecked","unused"})
public class RequestIDCardPage extends BasePage {

	String excepionMessage = "";
	//String intentName="//a[contains(text(),'%s')]"; 
	@FindBy(how = How.XPATH, using  = "//*[@id='$PpyFilterCriteria_PriorRequests_pxResults_PriorRequestsForShellIntents_2$ppyColumnFilterCriteria$gWorkID2$ppyUniqueValues$l1']/td[2]//label")
	public WebElement IntentId1;
	@FindBy(how = How.XPATH, using = "//button[@title='Add task']")
	public WebElement add;
	@FindBy(how = How.XPATH, using  = "//tr[contains(@id,'$PPriorRequests$ppxResults$l')]/td[2]")
	public WebElement IntentId2;
	@FindBy (how = How.XPATH, using = "//div[contains(text(),'Verify with the caller and review the remainder of the review for duplicate sections below to determine if a request has been made for ID cards in the last 3 days.')]")
	public WebElement DuplicateMsg;
	@FindBy (how = How.XPATH, using = "//div[contains(text(),'If the member has requested any ID cards within the last three days, any new requests will be routed to Membership for completion.')]")
	public WebElement VerifyDupReq;
	@FindBy (how = How.XPATH, using = "(//strong/following::div/div)[1]")
	public WebElement SendIDCard;

	@FindBy (how = How.XPATH, using = "//label[contains(text(),'Yes')]")
	public WebElement Yes;
	@FindBy (how = How.XPATH, using = "//label[contains(text(),'No')]")
	public WebElement No;
	@FindBy (how = How.XPATH, using = "//input[@id='01e75cdd']")
	public WebElement LostStolen;
	@FindBy (how = How.XPATH, using = "//input[@id='3689431']")
	public WebElement MemberName;
	@FindBy (how = How.XPATH, using = "//input[contains(@name,'$PpyWorkPage$pGetMembers$l1$pNumberOfCards')]")
	public WebElement NoOfCards;
	
	@FindBy (how = How.XPATH, using = "//input[@id='d1933a02']")
	public WebElement TempAddress;
	@FindBy (how = How.XPATH, using = "//input[@id='32a43d58']")
	public WebElement AddressLine1;
	@FindBy (how = How.XPATH, using = "//input[@id='abad6ce2']")
	public WebElement AddressLine2;
	@FindBy (how = How.XPATH, using = "//input[@id='dcaa5c74']")
	public WebElement AddressLine3;
	@FindBy (how = How.XPATH, using = "//input[@id='42cec9d7']")
	public WebElement AddressLine4;
	@FindBy (how = How.XPATH, using = "//input[@id='063af242']")
	public WebElement City;
	@FindBy (how = How.XPATH, using = "//select[@id='1ade6702']")
	public WebElement State;
	@FindBy (how = How.XPATH, using = "//input[@id='794d12a4']")
	public WebElement ZipCode;
	@FindBy (how = How.XPATH, using = "//input[@id='8b59e662']")
	public WebElement ZipCodeNONUSA;
	
	@FindBy (how = How.XPATH, using = "//select[@id='e977af51']")
	public WebElement Country;
	@FindBy (how = How.XPATH, using = "//textarea[@id='7454b91c']")
	public WebElement Comment;
	@FindBy (how = How.XPATH, using = "//span[@id='PegaRULESErrorFlag']")
	public WebElement ZipCodeErr;

	@FindBy (how = How.XPATH, using = "//span[contains(text(),'Value cannot be blank')]")
	public WebElement ZipCodeErr0;

	
	@FindBy (how = How.XPATH, using = "//button[contains(text(),'Next')]")
	public WebElement Next;
	
	
	@FindBy (how = How.XPATH, using = "//input[@id='51bc0d6a']")
	public WebElement WarningCheck1;
	@FindBy (how = How.XPATH, using = "//input[@id='7a915ea9']")
	public WebElement WarningCheck2;
	@FindBy (how = How.XPATH, using = "//input[@id='638a6fe8']")
	public WebElement WarningCheck3;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'There is a limit of one ID card request allowed in')]")
	public WebElement WarningMsg1;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'The requested address does not match the address o')]")
	public WebElement WarningMsg2;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'You are requesting more than limit of 3 cards/sets')]")
	public WebElement WarningMsg3;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'Your request has exceeded the allowable limit of  ')]")
	public WebElement WarningMsg4;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'The contract has a future cancellation date. Pleas')]")
	public WebElement WarningMsg5;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'You have entered a temporary address for country o')]")
	public WebElement WarningMsg6;
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	@FindBy(how = How.XPATH, using = "//button[@id='Back']")
	public WebElement Cancel;
	
	@FindBy (how = How.XPATH, using = "//tbody/tr[@id='$PpyWorkPage$pCommentsSummaryOrderIDCards$l1']/td[3]/div[1]/span[1]")
	public WebElement CommentsCheck;
	@FindBy (how = How.XPATH, using = "//h2[contains(@id,'headerlabel') and contains(text(),'ID card fulfillment')]")
	public WebElement FullReq;
	
	@FindBy (how = How.XPATH, using = "//tbody/tr[@id='$PpyWorkPage$pGetAddresses$l1']/td[1]")
	public WebElement SelectAddr;
	
	@FindBy (how = How.XPATH, using = "//div[contains(text(),'There is no active coverage on this contract. This')]")
	public WebElement ContractInactive;
	
	@FindBy (how = How.XPATH, using = "//span[@id='PegaRULESErrorFlag']")
	public WebElement ErrorImg;

	
	@FindBy (how = How.XPATH, using = "//span[contains(@title,'User must select greater than 0 and below 100 cards')]")
	public WebElement LimitMsg;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget1Ifr");
		return ExpectedConditions.visibilityOf(add);
		
	} 
	
	public void RequestIDCardTask (
			String intentID,String ReviewDupMsg, String VerifyReqMsg,String WarMsg1,String WarMsg2, Hashtable<String, String> data,String FullReqMsg,String SendIDCardTxt, String ReviewComment){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(DuplicateMsg);
			String ExpectedMsg = String.format(ReviewDupMsg);
			 if (ActualMessage.contains(ReviewDupMsg)) {
				test.log(Status.PASS, "Review for Duplicate message matched as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
				Assert.fail();
			 }	
			 wait(5000);
				String ActualMessage1 = webElementReadText(VerifyDupReq);
				String ExpectedMsg1 = String.format(VerifyReqMsg);
				 if (ActualMessage1.contains(VerifyReqMsg)) {
					test.log(Status.PASS, "Verify Duplicate Request as : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
				 } else {
					test.log(Status.FAIL, "Verify Duplicate Request does not matched as :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
					Assert.fail();
				 }	
			wait(3500);
				String ActualMessage2 = webElementReadText(FullReq);
				String ExpectedMsg2 = String.format(FullReqMsg);
				 if (ActualMessage2.contains(FullReqMsg)) {
					test.log(Status.PASS, "Check the ID card fullfillment history : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
				 } else {
					test.log(Status.FAIL, "Fulfillment history message does not matched :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
					Assert.fail();
				 }
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Yes);  
			webElementClick(Yes, "to Select Yes as there has been an ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			//System.out.println("Select 'Yes' as there has been an ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", LostStolen); 
			wait(1500);
			webElementClick(LostStolen, "Select Lost/Stolen with other PHI");
			//System.out.println("Select Lost/Stolen with other PHI");
			wait(3500);
			try{
				String ActualMessage3 = webElementReadText(SendIDCard);
				String ExpectedMsg3 = String.format(SendIDCardTxt);
				 if (ActualMessage3.contains(SendIDCardTxt)) {
					test.log(Status.PASS, "Check Send ID Card message : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg3);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage3);
				 } else {
					test.log(Status.FAIL, "Send ID card message does not there:" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg3);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage3);
					Assert.fail();
				 }	
			}catch(Exception e){
			}
			 wait(1500);
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", MemberName); 
			 wait(1500);
			 if(!MemberName.isSelected())
				{
					webElementClick(MemberName, "Select Member Name from document ID card request list.");	
					//System.out.println("Select Member Name from document ID card request list.");
				}
			wait(1500);		
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", TempAddress); 
			wait(1500);
			webElementClick(TempAddress, "Send to Temp Address");
			wait(2500);
			webElementSendText(AddressLine1, data.get("addressline1"), "Enter Addres Line1");
			wait(1500);
			webElementSendText(AddressLine2, data.get("addressline2"), "Enter Addres Line2");
			wait(1500);
			webElementSendText(AddressLine3, data.get("addressline3"), "Enter Addres Line3");
			wait(1500);
			webElementSendText(AddressLine4, data.get("addressline4"), "Enter Addres Line4");
			wait(1500);
			webElementSendText(City, data.get("city"), "Enter City");
			wait(1500);
			selectDropdownValueByVisibleText(State, data.get("state"), "Select State");
			wait(1500);
			webElementSendText(ZipCode, data.get("zipcode"), "Enter ZipCode");
			wait(1500);
			selectDropdownValueByVisibleText(Country, data.get("country"), "Select Country");
			wait(1500);
			webElementSendText(Comment, ReviewComment, "Enter Comment to go to next Request ID card page.");
			wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			wait(1500);
			//System.out.println("Land on Review ID Card Request page");
			wait(1500);
			webElementClick(WarningCheck1, "to accept-There is a limit of one ID card request allowed in a three day timeframe. Your request will exceed this limit. Please verify that this request is needed, if needed the request will be routed for completion.");
			wait(1500);
			String ActWarningMsg1 = webElementReadText(WarningMsg1);
			String ExpectedWarnMsg1 = String.format(WarMsg1);
			 if (ActWarningMsg1.contains(WarMsg1)) {
				test.log(Status.PASS, "Check the message for one ID card request in three day timeframe :");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
			 } else {
				test.log(Status.FAIL, "Message dopes not matched for one ID card request in three day timeframe :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
				Assert.fail();
			 }	
			webElementClick(WarningCheck2, "Check the message for address match on file.");
			wait(1500);
			String ActWarningMsg2 = webElementReadText(WarningMsg2);
			String ExpectedWarnMsg2 = String.format(WarMsg2);
			 if (ActWarningMsg2.contains(WarMsg2)) {
				test.log(Status.PASS, "Check the address match on file: ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg2);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg2);
			 } else {
				test.log(Status.FAIL, "Check the address does not match on file:" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg2);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg2);
				Assert.fail();
			 }	
			webElementClick(Submit, "Submit");
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", CommentsCheck); 
			wait(1500);
			String ActualComments = webElementReadText(CommentsCheck);
			String ExpectedComments = String.format(ReviewComment);
			 if (ActualComments.contains(ReviewComment)) {
				test.log(Status.PASS, "Review the comments entered on Review ID card request page : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
			 } else {
				test.log(Status.FAIL, "Comments does not matched :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
				Assert.fail();
			 }	
			 wait(1500);
		     webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTask method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTask method " + e);
			throw e;
		}
	}

	public void RequestIDCardTaskNo (
			String intentID,String ReviewDupMsg, String VerifyReqMsg,String WarMsg1,String WarMsg2,String WarMsg3, Hashtable<String, String> data,String FullReqMsg,String ReviewComment,String STVal,String CTVal,String ZipErr0,String ZipErr1,String ZipErr2,String expectedDefault){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(DuplicateMsg);
			String ExpectedMsg = String.format(ReviewDupMsg);
			 if (ActualMessage.contains(ReviewDupMsg)) {
				test.log(Status.PASS, "Review for Duplicate message matched as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
				Assert.fail();
			 }	
			 wait(5000);
				String ActualMessage1 = webElementReadText(VerifyDupReq);
				String ExpectedMsg1 = String.format(VerifyReqMsg);
				 if (ActualMessage1.contains(VerifyReqMsg)) {
					test.log(Status.PASS, "Verify Duplicate Request as : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
				 } else {
					test.log(Status.FAIL, "Verify Duplicate Request does not matched as :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
					Assert.fail();
				 }	
			wait(5000);
				String ActualMessage2 = webElementReadText(FullReq);
				String ExpectedMsg2 = String.format(FullReqMsg);
				 if (ActualMessage2.contains(FullReqMsg)) {
					test.log(Status.PASS, "Check the ID card fullfillment history : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
				 } else {
					test.log(Status.FAIL, "Fullfillment history message does not matched:" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
					Assert.fail();
				 }	
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", No);  
			webElementClick(No, "to select No as there has been no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			//System.out.println("Select 'No' as there been an no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", MemberName); 
			wait(1500);
			if(!MemberName.isSelected())
			{
			    webElementClick(MemberName, "Select Member Name from document ID card request list.");	
                //System.out.println("Select Member Name from document ID card request list.");
			}
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", TempAddress); 
			wait(1500);
			webElementClick(TempAddress, "Send to Temp Address");
			wait(2500);
			webElementSendText(AddressLine1, data.get("addressline1"), "Enter Addres Line1");
			wait(1500);
			webElementSendText(AddressLine2, data.get("addressline2"), "Enter Addres Line2");
			wait(1500);
			webElementSendText(AddressLine3, data.get("addressline3"), "Enter Addres Line3");
			wait(1500);
			webElementSendText(AddressLine4, data.get("addressline4"), "Enter Addres Line4");
			wait(1500);
			webElementSendText(City, data.get("city"), "Enter City");
			wait(1500);
			selectDropdownValueByVisibleText(State, data.get("state"), "Select State");
			wait(1500);
			
			String ST = driver.findElement(By.xpath("//select[@id='1ade6702']")).getText();
			//System.out.println("All State names are: " +ST);
			assertEquals(STVal, ST, "All State values are matched.");
			wait(1500);
			
			Select CountryDefault=new Select(driver.findElement(By.xpath("//select[@id='e977af51']")));
			String Default = CountryDefault.getFirstSelectedOption().getText();
			//System.out.println(Default);
			assertEquals(expectedDefault, Default, "Default value is matched.");
			
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			wait(1500);
			try{
			WarningCheck1.click();
			}catch(Exception e){
			}
			try{
				WarningCheck2.click();
				wait(1500);
				WarningCheck2.click();
				wait(1500);
				WarningCheck2.click();
					}catch(Exception e){	
					}
				wait(3500);
			webElementClick(Submit, "Submit");
			wait(3500);
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", ZipCodeErr0);
			String ActualErrMsg0 = webElementReadText(ZipCodeErr0);
			String ExpectedErrMsg0 = String.format(ZipErr0);
			assertEquals(ActualErrMsg0, ExpectedErrMsg0, "Blank ZIP code for USA should give error and matched.");
			
			wait(2500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", ZipCodeNONUSA); 
			webElementSendText(ZipCode, data.get("wrongUSAzipcode1"), "Enter ZipCode");
			wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			wait(1500);
			try{
			WarningCheck1.click();
			}catch(Exception e){
			}
			try{
			WarningCheck2.click();
			wait(1500);
			WarningCheck2.click();
			wait(1500);
			WarningCheck2.click();
				}catch(Exception e){	
				}
			//((JavascriptExecutor) driver).executeScript("arguments[0].click();", Submit);
			webElementClick(Submit, "Submit");
			wait(3500);
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", ZipCodeErr);
			String ActualErrMsg1 = webElementReadText(ZipCodeErr);
			String ExpectedErrMsg1 = String.format(ZipErr1);
			assertEquals(ActualErrMsg1, ExpectedErrMsg1, "Invalid ZIP code entry for USA should give error and matched.");
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Country); 
			selectDropdownValueByVisibleText(Country, data.get("country"), "Select Country");
			wait(1500);
			
			String CT = driver.findElement(By.xpath("//select[@id='e977af51']")).getText();
			//System.out.println("All Country names are: " +CT);
			assertEquals(CTVal, CT, "All Country values are matched.");
			
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", ZipCodeNONUSA); 
			webElementSendText(ZipCodeNONUSA, data.get("wrongzipcode"), "Enter ZipCode");
			wait(1500);
			webElementSendText(Comment,ReviewComment, "Enter Comment to go to next Request ID card page.");
			wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			wait(1500);
			try{
			wait(1500);
			driver.switchTo().alert().accept();
			}catch(Exception e){
				
			}
			/*((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", ZipCodeErr);
			String ActualErrMsg2= webElementReadText(ZipCodeErr);
			String ExpectedErrMsg2 = String.format(ZipErr2);
			assertEquals(ActualErrMsg2, ExpectedErrMsg2, "Invalid NON USA zip code entry should give suitable error msg and matched.");
			
			ZipCodeNONUSA.clear();
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", ZipCodeNONUSA); 
			webElementSendText(ZipCodeNONUSA, data.get("zipcode"), "Enter correct ZipCode for non USA countries.");
			wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			wait(1500);
			//System.out.println("Land on Review ID Card Request page");
			wait(1500);*/
			webElementClick(WarningCheck1, "to accept-There is a limit of one ID card request allowed in a three day timeframe. Your request will exceed this limit. Please verify that this request is needed, if needed the request will be routed for completion.");
			wait(1500);
			try{
			String ActWarningMsg1 = webElementReadText(WarningMsg1);
			String ExpectedWarnMsg1 = String.format(WarMsg1);
			 if (ActWarningMsg1.contains(WarMsg1)) {
				test.log(Status.PASS, "Check the message for one ID card request in three day timeframe :");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
			 } else {
				test.log(Status.FAIL, "Message does not matched for one ID card request in three day timeframe :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
				Assert.fail();
			 }
			}catch(Exception e){
				}
			webElementClick(WarningCheck2, "The requested address does not match the address on file. Please verify the entered address is correct.");
			wait(5000);
			String ActWarningMsg2 = webElementReadText(WarningMsg2);
			String ExpectedWarnMsg2 = String.format(WarMsg2);
			 if (ActWarningMsg2.contains(WarMsg2)) {
				test.log(Status.PASS, "Check request address message : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg2);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg2);
			 } else {
				test.log(Status.FAIL, "Requested address message does not matched :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg2);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg2);
				Assert.fail();
			 }	
			 webElementClick(WarningCheck3, "Check message after entering temporary address other than the United States");
				wait(5000);
				String ActWarningMsg3 = webElementReadText(WarningMsg6);
				String ExpectedWarnMsg3 = String.format(WarMsg3);
				 if (ActWarningMsg3.contains(WarMsg3)) {
					test.log(Status.PASS, "Check message after entering temporary address other than the United States : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg3);
					test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg3);
				 } else {
					test.log(Status.FAIL, "Requested address message does not matched :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg3);
					test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg3);
					Assert.fail();
				 }	
			webElementClick(Submit, "Submit");
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", CommentsCheck); 
			wait(1500);
			String ActualComments = webElementReadText(CommentsCheck);
			String ExpectedComments = String.format(ReviewComment);
			 if (ActualComments.contains(ReviewComment)) {
				test.log(Status.PASS, "Review for Duplicate message matched as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
				Assert.fail();
			 }	
			 wait(1500);
		     webElementClick(Submit, "Submit");	 
	 
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTask method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTask method " + e);
			throw e;
		}
	}
	
	public void RequestIDCardTaskNoTempAdd (
			String intentID,String ReviewDupMsg, String VerifyReqMsg,String WarMsg1,String WarMsg3, String WarMsg4, Hashtable<String, String> data,String FullReqMsg,String ReviewComment){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(DuplicateMsg);
			String ExpectedMsg = String.format(ReviewDupMsg);
			assertEquals(ActualMessage, ExpectedMsg, "Review for Duplicate message.");
			 wait(1500);
				String ActualMessage1 = webElementReadText(VerifyDupReq);
				String ExpectedMsg1 = String.format(VerifyReqMsg);
				assertEquals(ActualMessage1, ExpectedMsg1, "Verify Duplicate Request.");
			wait(5000);
				String ActualMessage2 = webElementReadText(FullReq);
				String ExpectedMsg2 = String.format(FullReqMsg);
				//System.out.println(ActualMessage2 + " "+ExpectedMsg2);
				assertEquals(ActualMessage1, ExpectedMsg1, "Check the ID card fullfillment history.");
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", No);  
			webElementClick(No, "to select No as there has been no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			//System.out.println("Select 'No' as there been an no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", LostStolen); 
			wait(1500);
			webElementClick(LostStolen, "Select Lost/Stolen with other PHI");
			//System.out.println("Select Lost/Stolen with other PHI");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", MemberName); 
			wait(1500);
			if(!MemberName.isSelected())
			{
				webElementClick(MemberName, "Select Member Name from document ID card request list.");	
                //System.out.println("Select Member Name from document ID card request list.");
			}
			wait(1500);
			
				((JavascriptExecutor) driver).executeScript("arguments[0].value='"+data.get("NoOfCardsSets")+"'", NoOfCards);
				test.log(Status.PASS, data.get("NoOfCardsSets")+" number of cards/sets requestd");
			    //System.out.println("Try to Enter 110 number of cards to be requestd and check respective message.");
			
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", SelectAddr); 
			wait(1500);
			webElementClick(SelectAddr, "Select address from the list.");
			//System.out.println("Select address from the list.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", TempAddress); 
			wait(1500);
			webElementSendText(Comment, ReviewComment, "Enter Comment to go to next Request ID card page.");
			wait(1500);
			webElementClick(Next, "on Next");
		    wait(1500);
		    try{
		    	driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pWarningSelected$l1' and @type='checkbox']")).click();
		    	wait(1500);
		    	driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pWarningSelected$l2' and @type='checkbox']")).click();
		    	driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pWarningSelected$l3' and @type='checkbox']")).click();
		    	Submit.click();
		    }
		    catch(Exception e3)
		    {
		    	Submit.click();
		    }
		    String ActWarningMsg4 = driver.findElement(By.xpath("//*[@id='PegaRULESErrorFlag']")).getAttribute("title");
			String ExpectedWarnMsg4 = "User must select greater than 0 and below 100 cards";
			assertEquals(ExpectedWarnMsg4, ActWarningMsg4, "Warning message for limit exceeding");		
			
			
				((JavascriptExecutor) driver).executeScript("arguments[0].value='"+data.get("NoOfCardsSets1")+"'", NoOfCards);
				//System.out.println("Try to Enter 4 number of cards to be requestd and check respective message.");
			
			wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			//System.out.println("Land on Review ID Card Request page");
			wait(1500);
			try{
		    	driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pWarningSelected$l1' and @type='checkbox']")).click();
		    	wait(1500);
		    	driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pWarningSelected$l2' and @type='checkbox']")).click();
		    	driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pWarningSelected$l3' and @type='checkbox']")).click();
		    	Submit.click();
		    }
		    catch(Exception e3)
		    {
		    	Submit.click();
		    }
			wait(3500);
		    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", CommentsCheck); 
			wait(1500);
			String ActualComments = webElementReadText(CommentsCheck);
			String ExpectedComments = String.format(ReviewComment);
			assertEquals(ExpectedComments, ActualComments, "Comments");	
			wait(1500);
		    webElementClick(Submit, "Submit");   
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTaskNoTempAdd method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTaskNoTempAdd method " + e);
			throw e;
		}
	}
	public void RequestIDCardTaskGroup (
			String intentID,String ReviewDupMsg, String VerifyReqMsg,String WarMsg1,String WarMsg2, Hashtable<String, String> data,String FullReqMsg,String ReviewComment){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(DuplicateMsg);
			String ExpectedMsg = String.format(ReviewDupMsg);
			 if (ActualMessage.contains(ReviewDupMsg)) {
				test.log(Status.PASS, "Review for Duplicate message matched as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
				Assert.fail();
			 }	
			 wait(5000);
				String ActualMessage1 = webElementReadText(VerifyDupReq);
				String ExpectedMsg1 = String.format(VerifyReqMsg);
				 if (ActualMessage1.contains(VerifyReqMsg)) {
					test.log(Status.PASS, "Verify Duplicate Request as : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
				 } else {
					test.log(Status.FAIL, "Verify Duplicate Request does not matched as :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
					Assert.fail();
				 }	
			wait(5000);
				String ActualMessage2 = webElementReadText(FullReq);
				String ExpectedMsg2 = String.format(FullReqMsg);
				 if (ActualMessage2.contains(FullReqMsg)) {
					test.log(Status.PASS, "Check the ID card fullfillment history : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
				 } else {
					test.log(Status.FAIL, "Fullfillment history message does not matched :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
					Assert.fail();
				 }	
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", No);  
			webElementClick(No, "to select No as there has been no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			//System.out.println("Select 'No' as there been an no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", MemberName); 
			wait(1500);
			if(!MemberName.isSelected())
			{
				webElementClick(MemberName, "Select Member Name from document ID card request list.");	
                //System.out.println("Select Member Name from document ID card request list.");
			}
			wait(1500);
			try{
				wait(1500);
				NoOfCards.clear();
				NoOfCards.sendKeys(data.get("NoOfCardsSets"));
				test.log(Status.PASS, data.get("NoOfCardsSets")+" number of cards/sets requestd");
			    //System.out.println("Tty to Enter 2 number of cards to be requestd and check respective message.");
			}catch(StaleElementReferenceException e){
				wait(1500);
				NoOfCards.clear();
				NoOfCards.sendKeys(data.get("NoOfCardsSets"));
				test.log(Status.PASS, data.get("NoOfCardsSets")+" number of cards/sets requestd");
			    //System.out.println("Tty to Enter Enter 2 number of cards to be requestd and check respective message.");
			}
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", SelectAddr); 
			wait(1500);
			webElementClick(SelectAddr, "Select address from the list.");
			//System.out.println("Select address from the list.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", TempAddress); 
			wait(1500);
			webElementSendText(Comment, ReviewComment, "Enter Comment to go to next Request ID card page.");
		    wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			//System.out.println("Land on Review ID Card Request page");
			wait(1500);
			try{
				wait(1500);
				WarningCheck1.click();
				String ActWarningMsg3 = webElementReadText(WarningMsg1);
				String ExpectedWarnMsg3 = String.format(WarMsg1);
				assertEquals(ExpectedWarnMsg3, ActWarningMsg3, "Check the message for one ID card request in three day timeframe ");
				wait(1500);
			}catch(Exception e)
			{
			}
			wait(1500);
			webElementClick(Submit, "Submit");
			wait(3500);
		    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", CommentsCheck); 
			wait(1500);
			String ActualComments = webElementReadText(CommentsCheck);
			String ExpectedComments = String.format(ReviewComment);
			 if (ActualComments.contains(ReviewComment)) {
				test.log(Status.PASS, "Review comment enter on Review ID card request page :");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
			 } else {
				test.log(Status.FAIL, "Review comments does not matched :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
				Assert.fail();
			 }	
			 wait(1500);
		     webElementClick(Submit, "Submit");	
		     
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTask method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTask method " + e);
			throw e;
		}
	}	

	public void RequestIDCardTaskSub (
			String intentID,String ReviewDupMsg, String VerifyReqMsg,String FullReqMsg,String WarMsg1, Hashtable<String, String> data,String ReviewComment){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(DuplicateMsg);
			String ExpectedMsg = String.format(ReviewDupMsg);
			 if (ActualMessage.contains(ReviewDupMsg)) {
				test.log(Status.PASS, "Review for Duplicate message matched as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
				Assert.fail();
			 }	
			 wait(5000);
				String ActualMessage1 = webElementReadText(VerifyDupReq);
				String ExpectedMsg1 = String.format(VerifyReqMsg);
				 if (ActualMessage1.contains(VerifyReqMsg)) {
					test.log(Status.PASS, "Verify Duplicate Request as : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
				 } else {
					test.log(Status.FAIL, "Verify Duplicate Request does not matched as :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
					Assert.fail();
				 }	
			wait(5000);
				String ActualMessage2 = webElementReadText(FullReq);
				String ExpectedMsg2 = String.format(FullReqMsg);
				 if (ActualMessage2.contains(FullReqMsg)) {
					test.log(Status.PASS, "Check the ID card fullfillment history : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
				 } else {
					test.log(Status.FAIL, "Fllfillment history message not matched:" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
					Assert.fail();
				 }	
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", No);  
			webElementClick(No, "to select No as there has been no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			//System.out.println("Select 'No' as there been an no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", MemberName); 
			wait(1500);
			if(!MemberName.isSelected())
			{
				webElementClick(MemberName, "Select Member Name from document ID card request list.");	
                //System.out.println("Select Member Name from document ID card request list.");
			}
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].value='"+data.get("NoOfCardsSets")+"'", NoOfCards);
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", SelectAddr); 
			wait(1500);
			webElementClick(SelectAddr, "Select address from the list.");
			//System.out.println("Select address from the list.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", TempAddress); 
			wait(1500);
			webElementSendText(Comment, ReviewComment, "Enter Comment to go to next Request ID card page.");
		    wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			//System.out.println("Land on Review ID Card Request page");
			wait(3500);
			try{
		    	driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pWarningSelected$l1' and @type='checkbox']")).click();
		    	wait(1500);
		    	driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pWarningSelected$l2' and @type='checkbox']")).click();
		    	driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pWarningSelected$l3' and @type='checkbox']")).click();
		    	Submit.click();
		    }
		    catch(Exception e3)
		    {
		    	Submit.click();
		    }
			 wait(2500);
		     ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", CommentsCheck); 
			 wait(1500);
			 String ActualComments = webElementReadText(CommentsCheck);
			 String ExpectedComments = String.format(ReviewComment);
			 if (ActualComments.contains(ReviewComment)) {
				test.log(Status.PASS, "Review comment enter on Review ID card request page :");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
			 } else {
				test.log(Status.FAIL, "Review comment does not matched :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
				Assert.fail();
			 }	
			 wait(1500);
		     webElementClick(Submit, "Submit");	
		     
		}catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTask method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTask method " + e);
			Assert.fail();
		}
	}	
	
	public void RequestIDCardTaskCancelledContract (String intentID,String ReviewIncMsg){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(ContractInactive);
			String ExpectedMsg = String.format(ReviewIncMsg);
			 if (ActualMessage.contains(ReviewIncMsg)) {
				test.log(Status.PASS, "Review for inactive coverage messaeg as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
				Assert.fail();
			 }
			 wait(1500);
			 webElementClick(Submit, "Submit");  
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTask method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTask method " + e);
			Assert.fail();
		}
	}
	public void RequestIDCardTaskGrpError (String intentID,String ReviewIncMsg){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(ContractInactive);
			String ExpectedMsg = String.format(ReviewIncMsg);
			assertEquals(ActualMessage, ExpectedMsg, "Review for inactive coverage message.");
			wait(1500);
			webElementClick(Submit, "Submit");  
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTask method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTask method " + e);
			Assert.fail();
		}
	}
	public void RequestIDCardTaskFutLost(
			String intentID,String ReviewDupMsg, String VerifyReqMsg,String FullReqMsg,String WarMsg1,String WarMsg5, Hashtable<String, String> data,String ReviewComment){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(DuplicateMsg);
			String ExpectedMsg = String.format(ReviewDupMsg);
			 if (ActualMessage.contains(ReviewDupMsg)) {
				test.log(Status.PASS, "Review for Duplicate message matched as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
				Assert.fail();
			 }	
			 wait(5000);
				String ActualMessage1 = webElementReadText(VerifyDupReq);
				String ExpectedMsg1 = String.format(VerifyReqMsg);
				 if (ActualMessage1.contains(VerifyReqMsg)) {
					test.log(Status.PASS, "Verify Duplicate Request as : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
				 } else {
					test.log(Status.FAIL, "Verify Duplicate Request does not matched as :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
					Assert.fail();
				 }	
			wait(5000);
				String ActualMessage2 = webElementReadText(FullReq);
				String ExpectedMsg2 = String.format(FullReqMsg);
				 if (ActualMessage2.contains(FullReqMsg)) {
					test.log(Status.PASS, "Check the ID card fullfillment history : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
				 } else {
					test.log(Status.FAIL, "Fllfillment history message not matched:" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
					Assert.fail();
				 }	
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", No);  
			webElementClick(No, "to select No as there has been no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			//System.out.println("Select 'No' as there been an no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", LostStolen); 
			wait(1500);
			webElementClick(LostStolen, "Select Lost/Stolen with other PHI");
			//System.out.println("Select Lost/Stolen with other PHI");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", MemberName); 
			wait(1500);
			if(!MemberName.isSelected())
			{
				webElementClick(MemberName, "Select Member Name from document ID card request list.");	
                //System.out.println("Select Member Name from document ID card request list.");
			}
			wait(2500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", SelectAddr); 
			wait(1500);
			webElementClick(SelectAddr, "Select address from the list.");
			//System.out.println("Select address from the list.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", TempAddress); 
			wait(1500);
			webElementSendText(Comment,ReviewComment, "Enter Comment to go to next Request ID card page.");
		    wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			//System.out.println("Land on Review ID Card Request page");
			wait(3500);
			
			/*webElementClick(WarningCheck1, "to accept-The contract has a future cancellation date");
			wait(1500);
			String ActWarningMsg5 = webElementReadText(WarningMsg5);
			String ExpectedWarnMsg5 = String.format(WarMsg5);
			 if (ActWarningMsg5.contains(WarMsg5)) {
				test.log(Status.PASS, "Check the message for contract has a future cancellation date :");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg5);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg5);
			 } else {
				test.log(Status.FAIL, "Message does not matched for contract has a future cancellation date :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg5);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg5);
				Assert.fail();
			 }	*/
			 
			 try{
				 WarningCheck1.click();wait(1500);
				 WarningCheck2.click();wait(1500);
				 /*webElementClick(WarningCheck2, "to accept-There is a limit of one ID card request allowed in a three day timeframe. Your request will exceed this limit. Please verify that this request is needed, if needed the request will be routed for completion.");
				 wait(1500);
				 String ActWarningMsg1 = webElementReadText(WarningMsg1);
				 String ExpectedWarnMsg1 = String.format(WarMsg1);
			     if (ActWarningMsg1.contains(WarMsg1)) {
						test.log(Status.PASS, "Check the message for one ID card request in three day timeframe :");
						test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
						test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
					 } else {
						test.log(Status.FAIL, "Message dopes not matched for one ID card request in three day timeframe :" );
						test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
						test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
						Assert.fail();
					 }	*/
				}
				catch(Exception e){
				}
			 webElementClick(Submit, "Submit");
			 wait(2500);
		     ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", CommentsCheck); 
			 wait(1500);
			 String ActualComments = webElementReadText(CommentsCheck);
			 String ExpectedComments = String.format(ReviewComment);
			 if (ActualComments.contains(ReviewComment)) {
				test.log(Status.PASS, "Review comment enter on Review ID card request page :");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
			 } else {
				test.log(Status.FAIL, "Review comment does not matched :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
				Assert.fail();
			 }	
			 wait(1500);
		     webElementClick(Submit, "Submit");  
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTaskFut method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTaskFut method " + e);
			Assert.fail();
		}
	}
	public void RequestIDCardTaskFut(
			String intentID,String ReviewDupMsg, String VerifyReqMsg,String FullReqMsg,String WarMsg1,String WarMsg5, Hashtable<String, String> data,String ReviewComment){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(DuplicateMsg);
			String ExpectedMsg = String.format(ReviewDupMsg);
			 if (ActualMessage.contains(ReviewDupMsg)) {
				test.log(Status.PASS, "Review for Duplicate message matched as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
				Assert.fail();
			 }	
			 wait(5000);
				String ActualMessage1 = webElementReadText(VerifyDupReq);
				String ExpectedMsg1 = String.format(VerifyReqMsg);
				 if (ActualMessage1.contains(VerifyReqMsg)) {
					test.log(Status.PASS, "Verify Duplicate Request as : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
				 } else {
					test.log(Status.FAIL, "Verify Duplicate Request does not matched as :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
					Assert.fail();
				 }	
			wait(5000);
				String ActualMessage2 = webElementReadText(FullReq);
				String ExpectedMsg2 = String.format(FullReqMsg);
				 if (ActualMessage2.contains(FullReqMsg)) {
					test.log(Status.PASS, "Check the ID card fullfillment history : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
				 } else {
					test.log(Status.FAIL, "Fllfillment history message not matched:" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
					Assert.fail();
				 }	
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", No);  
			webElementClick(No, "to select No as there has been no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			//System.out.println("Select 'No' as there been an no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", MemberName); 
			wait(1500);
			if(!MemberName.isSelected())
			{
				webElementClick(MemberName, "Select Member Name from document ID card request list.");	
                //System.out.println("Select Member Name from document ID card request list.");
			}
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", SelectAddr); 
			wait(1500);
			webElementClick(SelectAddr, "Select address from the list.");
			//System.out.println("Select address from the list.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", TempAddress); 
			wait(1500);
			webElementSendText(Comment,ReviewComment, "Enter Comment to go to next Request ID card page.");
		    wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			//System.out.println("Land on Review ID Card Request page");
			wait(3500);
			/*webElementClick(WarningCheck1, "to accept-The contract has a future cancellation date");
			wait(1500);
			String ActWarningMsg5 = webElementReadText(WarningMsg5);
			String ExpectedWarnMsg5 = String.format(WarMsg5);
			 if (ActWarningMsg5.contains(WarMsg5)) {
				test.log(Status.PASS, "Check the message for contract has a future cancellation date :");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg5);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg5);
			 } else {
				test.log(Status.FAIL, "Message does not matched for contract has a future cancellation date :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg5);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg5);
				Assert.fail();
			 }	*/
			 try{
				 webElementClick(WarningCheck1, "to accept-There is a limit of one ID card request allowed in a three day timeframe. Your request will exceed this limit. Please verify that this request is needed, if needed the request will be routed for completion.");
				 wait(1500);
				 String ActWarningMsg1 = webElementReadText(WarningMsg1);
				 String ExpectedWarnMsg1 = String.format(WarMsg1);
			     if (ActWarningMsg1.contains(WarMsg1)) {
						test.log(Status.PASS, "Check the message for one ID card request in three day timeframe :");
						test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
						test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
					 } else {
						test.log(Status.FAIL, "Message dopes not matched for one ID card request in three day timeframe :" );
						test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
						test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
						Assert.fail();
					 }	
				}
				catch(Exception e){
				}
			 webElementClick(Submit, "Submit");
			 wait(2500);
		     ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", CommentsCheck); 
			 wait(1500);
			 String ActualComments = webElementReadText(CommentsCheck);
			 String ExpectedComments = String.format(ReviewComment);
			 if (ActualComments.contains(ReviewComment)) {
				test.log(Status.PASS, "Review comment enter on Review ID card request page :");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
			 } else {
				test.log(Status.FAIL, "Review comment does not matched :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
				Assert.fail();
			 }	
			 wait(1500);
		     webElementClick(Submit, "Submit");  
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTaskFut method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTaskFut method " + e);
			Assert.fail();
		}
	}
	public void RequestIDCardTaskFutEnrol(
			String intentID,String ReviewDupMsg, String VerifyReqMsg,String FullReqMsg,String WarMsg1,String WarMsg5, Hashtable<String, String> data,String ReviewComment){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(DuplicateMsg);
			String ExpectedMsg = String.format(ReviewDupMsg);
			 if (ActualMessage.contains(ReviewDupMsg)) {
				test.log(Status.PASS, "Review for Duplicate message matched as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
				Assert.fail();
			 }	
			 wait(5000);
				String ActualMessage1 = webElementReadText(VerifyDupReq);
				String ExpectedMsg1 = String.format(VerifyReqMsg);
				 if (ActualMessage1.contains(VerifyReqMsg)) {
					test.log(Status.PASS, "Verify Duplicate Request as : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
				 } else {
					test.log(Status.FAIL, "Verify Duplicate Request does not matched as :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
					Assert.fail();
				 }	
			wait(5000);
				String ActualMessage2 = webElementReadText(FullReq);
				String ExpectedMsg2 = String.format(FullReqMsg);
				 if (ActualMessage2.contains(FullReqMsg)) {
					test.log(Status.PASS, "Check the ID card fullfillment history : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
				 } else {
					test.log(Status.FAIL, "Fllfillment history message not matched:" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
					Assert.fail();
				 }	
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", No);  
			webElementClick(No, "to select No as there has been no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			//System.out.println("Select 'No' as there been an no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", MemberName); 
			wait(1500);
			if(!MemberName.isSelected())
			{
				webElementClick(MemberName, "Select Member Name from document ID card request list.");	
                //System.out.println("Select Member Name from document ID card request list.");
			}
			wait(2500);
			try{
				//NoOfCards.clear();
				((JavascriptExecutor) driver).executeScript("arguments[0].value='0'", NoOfCards);
				//NoOfCards.sendKeys("0");
				test.log(Status.PASS,"0 number of cards/sets requestd");
			    //System.out.println("0 number of cards to be requestd and check respective message.");
			}catch(StaleElementReferenceException e){
				NoOfCards.clear();
				NoOfCards.sendKeys("0");
				test.log(Status.PASS, "0 number of cards to be requestd and check respective message.");
			    //System.out.println("0 number of cards to be requestd and check respective message.");
			}
			wait(1500);
			 try{
				 WarningCheck2.click();
				}catch(Exception e){
				}
			 wait(1500);
				webElementSendText(Comment,ReviewComment, "Enter Comment to go to next Request ID card page.");
			    wait(1500);
				webElementClick(Next, "Go to Next Page -Review ID Card Request");
				//System.out.println("Land on Review ID Card Request page");
				wait(3500);
				 try{
					 webElementClick(WarningCheck1, "to accept-There is a limit of one ID card request allowed in a three day timeframe. Your request will exceed this limit. Please verify that this request is needed, if needed the request will be routed for completion.");
					 wait(1500);
					 String ActWarningMsg1 = webElementReadText(WarningMsg1);
					 String ExpectedWarnMsg1 = String.format(WarMsg1);
				     if (ActWarningMsg1.contains(WarMsg1)) {
							test.log(Status.PASS, "Check the message for one ID card request in three day timeframe :");
							test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
							test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
						 } else {
							test.log(Status.FAIL, "Message dopes not matched for one ID card request in three day timeframe :" );
							test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
							test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
							Assert.fail();
						 }	
					}
					catch(Exception e){
					}
				 webElementClick(Submit, "Submit");
				 wait(2500);
			webElementClick(ErrorImg, "Go to the Error Indicator.");
			Actions act = new Actions(driver);
			waitSleep(4000);
			act.moveToElement(ErrorImg);
			waitSleep(5000);
			String actual = ErrorImg.getAttribute("title").toString();
			//System.out.println("actual :"+actual);
			String expected = "User must select greater than 0 and below 100 cards";
			assertEquals(actual,expected,"Limit Error Message should be matched.");
			wait(2500);
			try{
				((JavascriptExecutor) driver).executeScript("arguments[0].value='"+data.get("NoOfCardsSets")+"'", NoOfCards);
				test.log(Status.PASS, data.get("NoOfCardsSets")+" number of cards/sets requestd");
			    //System.out.println("Try to Enter 4 number of cards to be requestd and check respective message.");
			}catch(StaleElementReferenceException e){
				NoOfCards.clear();
				NoOfCards.sendKeys(data.get("NoOfCardsSets"));
				test.log(Status.PASS, data.get("NoOfCardsSets")+" number of cards/sets requestd");
			    //System.out.println("Try to Enter 4 number of cards to be requestd and check respective message.");
			}
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", SelectAddr);
			webElementClick(SelectAddr, "Select address from the list.");
			//System.out.println("Select address from the list.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", TempAddress); 
			wait(1500);
			webElementSendText(Comment, ReviewComment, "Enter Comment to go to next Request ID card page.");
		    wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			//System.out.println("Land on Review ID Card Request page");
			wait(3500);
			webElementClick(WarningCheck1, "to accept-The contract has a future cancellation date");
			 wait(1500);
			 try{
					WarningCheck2.click();
					wait(1500);
					String ActWarningMsg1 = WarningMsg3.getText();
					String ExpectedWarnMsg1 = "You are requesting more than limit of 3 cards/sets of cards. Please verify that the number requested is correct. If you select the submit button and finish the request, it will be routed for completion.";
					assertEquals(ExpectedWarnMsg1, ActWarningMsg1, "message for requesting more than limit of 3 cards/sets of cards.");
					wait(1500);
				}catch(Exception e){
				}
			 wait(1500);
			 try{
				 WarningCheck3.click();
				 
				}catch(Exception e){
				}
			 webElementClick(Submit, "Submit");
			 wait(2500);
		     ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", CommentsCheck); 
			 wait(1500);
			 String ActualComments = webElementReadText(CommentsCheck);
			 assertEquals(ReviewComment, ActualComments, "Review comment");
			 wait(1500);
		     webElementClick(Submit, "Submit");  
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTaskFut method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTaskFut method " + e);
			Assert.fail();
		}
	}
	
	public void RequestIDCardTaskCreateOPR(
			String intentID,String ReviewDupMsg, String VerifyReqMsg,String FullReqMsg,String WarMsg1, String WarMsg2,String WarMsg3, Hashtable<String, String> data,String ReviewComment){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(DuplicateMsg);
			String ExpectedMsg = String.format(ReviewDupMsg);
			 if (ActualMessage.contains(ReviewDupMsg)) {
				test.log(Status.PASS, "Review for Duplicate message matched as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
				Assert.fail();
			 }	
			 wait(5000);
				String ActualMessage1 = webElementReadText(VerifyDupReq);
				String ExpectedMsg1 = String.format(VerifyReqMsg);
				 if (ActualMessage1.contains(VerifyReqMsg)) {
					test.log(Status.PASS, "Verify Duplicate Request as : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
				 } else {
					test.log(Status.FAIL, "Verify Duplicate Request does not matched as :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
					Assert.fail();
				 }	
			wait(5000);
				String ActualMessage2 = webElementReadText(FullReq);
				String ExpectedMsg2 = String.format(FullReqMsg);
				 if (ActualMessage2.contains(FullReqMsg)) {
					test.log(Status.PASS, "Check the ID card fullfillment history : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
				 } else {
					test.log(Status.FAIL, "Fullfillment history message does not matched:" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
					Assert.fail();
				 }	
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", No);  
			webElementClick(No, "to select No as there has been no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			//System.out.println("Select 'No' as there been an no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", MemberName); 
			wait(1500);
			if(!MemberName.isSelected())
			{
			    webElementClick(MemberName, "Select Member Name from document ID card request list.");	
                //System.out.println("Select Member Name from document ID card request list.");
			}
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", TempAddress); 
			wait(1500);
			webElementClick(TempAddress, "Send to Temp Address");
			wait(2500);
			webElementSendText(AddressLine1, data.get("addressline1"), "Enter Addres Line1");
			wait(1500);
			webElementSendText(AddressLine2, data.get("addressline2"), "Enter Addres Line2");
			wait(1500);
			webElementSendText(AddressLine3, data.get("addressline3"), "Enter Addres Line3");
			wait(1500);
			webElementSendText(AddressLine4, data.get("addressline4"), "Enter Addres Line4");
			wait(1500);
			webElementSendText(City, data.get("city"), "Enter City");
			wait(1500);
			selectDropdownValueByVisibleText(State, data.get("state"), "Select State");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Country); 
			selectDropdownValueByVisibleText(Country, data.get("country"), "Select Country");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", ZipCodeNONUSA); 
			webElementSendText(ZipCodeNONUSA, data.get("zipcode"), "Enter ZipCode");
			wait(1500);
			webElementSendText(Comment,ReviewComment, "Enter Comment to go to next Request ID card page.");
			wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			wait(1500);
			//System.out.println("Land on Review ID Card Request page");
			wait(1500);
			webElementClick(WarningCheck1, "to accept-There is a limit of one ID card request allowed in a three day timeframe. Your request will exceed this limit. Please verify that this request is needed, if needed the request will be routed for completion.");
			wait(1500);
			try{
			String ActWarningMsg1 = webElementReadText(WarningMsg1);
			String ExpectedWarnMsg1 = String.format(WarMsg1);
			 if (ActWarningMsg1.contains(WarMsg1)) {
				test.log(Status.PASS, "Check the message for one ID card request in three day timeframe :");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
			 } else {
				test.log(Status.FAIL, "Message does not matched for one ID card request in three day timeframe :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
				Assert.fail();
			 }
			}catch(Exception e){
				}
			webElementClick(WarningCheck2, "The requested address does not match the address on file. Please verify the entered address is correct.");
			wait(5000);
			String ActWarningMsg2 = webElementReadText(WarningMsg2);
			String ExpectedWarnMsg2 = String.format(WarMsg2);
			 if (ActWarningMsg2.contains(WarMsg2)) {
				test.log(Status.PASS, "Check request address message : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg2);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg2);
			 } else {
				test.log(Status.FAIL, "Requested address message does not matched :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg2);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg2);
				Assert.fail();
			 }	
			 webElementClick(WarningCheck3, "Check message after entering temporary address other than the United States");
				wait(5000);
				String ActWarningMsg3 = webElementReadText(WarningMsg6);
				String ExpectedWarnMsg3 = String.format(WarMsg3);
				 if (ActWarningMsg3.contains(WarMsg3)) {
					test.log(Status.PASS, "Check message after entering temporary address other than the United States : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg3);
					test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg3);
				 } else {
					test.log(Status.FAIL, "Requested address message does not matched :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg3);
					test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg3);
					Assert.fail();
				 }	
			webElementClick(Submit, "Submit");
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", CommentsCheck); 
			wait(1500);
			String ActualComments = webElementReadText(CommentsCheck);
			String ExpectedComments = String.format(ReviewComment);
			 if (ActualComments.contains(ReviewComment)) {
				test.log(Status.PASS, "Review for Duplicate message matched as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
				Assert.fail();
			 }	
			 wait(1500);
		     webElementClick(Submit, "Submit");		 
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTaskCreateOPR method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTaskCreateOPR method " + e);
			Assert.fail();
		}
	}
	
	public void RequestIDCardTaskFutCancel(
			String intentID,String ReviewDupMsg, String VerifyReqMsg,String FullReqMsg,String WarMsg1,String WarMsg5, Hashtable<String, String> data,String ReviewComment){
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(5000);
			String ActualMessage = webElementReadText(DuplicateMsg);
			String ExpectedMsg = String.format(ReviewDupMsg);
			 if (ActualMessage.contains(ReviewDupMsg)) {
				test.log(Status.PASS, "Review for Duplicate message matched as : ");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			 } else {
				test.log(Status.FAIL, "Review for Duplicate message does not matched as :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg);
				test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
				Assert.fail();
			 }	
			 wait(5000);
				String ActualMessage1 = webElementReadText(VerifyDupReq);
				String ExpectedMsg1 = String.format(VerifyReqMsg);
				 if (ActualMessage1.contains(VerifyReqMsg)) {
					test.log(Status.PASS, "Verify Duplicate Request as : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
				 } else {
					test.log(Status.FAIL, "Verify Duplicate Request does not matched as :" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg1);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage1);
					Assert.fail();
				 }	
			wait(5000);
				String ActualMessage2 = webElementReadText(FullReq);
				String ExpectedMsg2 = String.format(FullReqMsg);
				 if (ActualMessage2.contains(FullReqMsg)) {
					test.log(Status.PASS, "Check the ID card fullfillment history : ");
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
				 } else {
					test.log(Status.FAIL, "Fllfillment history message not matched:" );
					test.log(Status.PASS,"Expected Message: "+' '+ExpectedMsg2);
					test.log(Status.PASS,"Actual Message: "+' '+ActualMessage2);
					Assert.fail();
				 }	
			wait(3500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", No);  
			webElementClick(No, "to select No as there has been no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			//System.out.println("Select 'No' as there been an no ID card request placed through the IVR, portal or by speaking to an advocate in the last 3 days.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", MemberName); 
			wait(1500);
			if(!MemberName.isSelected())
			{
				webElementClick(MemberName, "Select Member Name from document ID card request list.");	
                //System.out.println("Select Member Name from document ID card request list.");
			}
			wait(2500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", SelectAddr); 
			wait(1500);
			webElementClick(SelectAddr, "Select address from the list.");
			//System.out.println("Select address from the list.");
			wait(1500);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", TempAddress); 
			wait(1500);
			webElementSendText(Comment, ReviewComment, "Enter Comment to go to next Request ID card page.");
		    wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			//System.out.println("Land on Review ID Card Request page");
			wait(3500);
			webElementClick(WarningCheck1, "to accept-The contract has a future cancellation date");
			wait(1500);
			String ActWarningMsg5 = webElementReadText(WarningMsg5);
			String ExpectedWarnMsg5 = String.format(WarMsg5);
			 if (ActWarningMsg5.contains(WarMsg5)) {
				test.log(Status.PASS, "Check the message for contract has a future cancellation date :");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg5);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg5);
			 } else {
				test.log(Status.FAIL, "Message does not matched for contract has a future cancellation date :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg5);
				test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg5);
				Assert.fail();
			 }	
			 wait(1500);
			 try{
				 webElementClick(WarningCheck2, "to accept-There is a limit of one ID card request allowed in a three day timeframe. Your request will exceed this limit. Please verify that this request is needed, if needed the request will be routed for completion.");
				 wait(1500);
				 String ActWarningMsg1 = webElementReadText(WarningMsg1);
				 String ExpectedWarnMsg1 = String.format(WarMsg1);
			     if (ActWarningMsg1.contains(WarMsg1)) {
						test.log(Status.PASS, "Check the message for one ID card request in three day timeframe :");
						test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
						test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
					 } else {
						test.log(Status.FAIL, "Message dopes not matched for one ID card request in three day timeframe :" );
						test.log(Status.PASS,"Expected Message: "+' '+ExpectedWarnMsg1);
						test.log(Status.PASS,"Actual Message: "+' '+ActWarningMsg1);
						Assert.fail();
					 }	
				}catch(Exception e){
				}
			 webElementClick(Submit, "Submit");
			 wait(2500);
		     ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", CommentsCheck); 
			 wait(1500);
			 String ActualComments = webElementReadText(CommentsCheck);
			 String ExpectedComments = String.format(ReviewComment);
			 if (ActualComments.contains(ReviewComment)) {
				test.log(Status.PASS, "Review comment enter on Review ID card request page :");
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
			 } else {
				test.log(Status.FAIL, "Review comment does not matched :" );
				test.log(Status.PASS,"Expected Message: "+' '+ExpectedComments);
				test.log(Status.PASS,"Actual Message: "+' '+ActualComments);
				Assert.fail();
			 }
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on RequestIDCardTaskFut method " + excepionMessage);
			test.log(Status.FAIL, "Error on RequestIDCardTaskFut method " + e);
			throw e;
		}
	}

}
