
package com.nasco.HMHS.TestScripts.G2.RespondToCustomer;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.OtherActions;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.RespondToCustomerPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC004_RespondToCustomer_Callback extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC004_RespondToCustomer_Callback (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC004_RespondToCustomer_AddTaskCallback");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC004_RespondToCustomer_AddTaskCallback - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug("HMHS_TC004_RespondToCustomer_AddTaskCallback -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		test.log(Status.INFO, "Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page.");
		test.log(Status.INFO, data.get("Fname") + "Selected from the search results and navigated to verify member page.");
		log.debug("Member Submit Completed");
		test.log(Status.INFO, "Member Submit Completed.");
		
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Member Verified successfully.");
        test.log(Status.INFO, "Member Verified successfully.");
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(Status.INFO,"Add Intent "+data.get("Intent"));
        
        String intentID = searchMember.getIntentID();
		log.debug("Intent id: " + intentID);
		test.log(Status.INFO, "Intent id: " + intentID);
		OtherActions otheraction= homepage.openOtherActions();
        RespondToCustomerPage RTC = homepage.RespondToCustomerIntentCallback();
        RTC.RespondToCustomerIntentCallback( intentID,data);
		log.debug("Navigate to Respond to Customer intent screen to add task against Callback.");
		test.log(Status.INFO,"Navigate to Respond to Customer intent screen to add task against Callback.");
		otheraction.saveToWorklist212(data);
		log.debug("Navigate to save To Worklist screen");
		test.log(Status.INFO,"Navigate to save To Worklist screen.");
		InteractionManagerPage wrap = searchMember.wrapIntent();
	    wrap.wrapUp(data.get("Comments"));
		log.debug("Wrapping up the intent.");
		test.log(Status.INFO, "Wrapping up the intent.");
		
		WorklistPage worklist = homepage.openrecentWorklist();
		worklist.movetoWorklistPage();
		log.debug("Navigate to the User's Worklist page");
		worklist.sortandSelectIntent(data, intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from Worklist tab ");
		log.debug("Sorted and selected intent " + intentID + " from Worklist tab ");
		worklist.CallbackAttemptDiff( intentID, data);
		log.debug("Perform the callback attempt  in worklist.");
		test.log(Status.INFO,"Perform the callback attempt in worklist.");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetoRecentWorkPage();
		log.debug("Navigated to the Home-Recentwork Section.");
		test.log(Status.INFO, "Navigated to the Home-Recentwork Section.");
		recentWork.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from recent work tab.");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab ");
		test.log(Status.INFO, "Sorted and selected intent " + intentID + " from recent work tab.");
		recentWork.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the intent status.");
		test.log(Status.INFO, "Check the intent status.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  {
		test.log(Status.INFO, "HMHS_TC004_RespondToCustomer_AddTaskCallback completed.");
		log.debug("HMHS_TC004_RespondToCustomer_AddTaskCallback completed.");
		quit();

	}
}
