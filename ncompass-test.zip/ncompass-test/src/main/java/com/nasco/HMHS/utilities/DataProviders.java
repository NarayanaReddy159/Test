package com.nasco.HMHS.utilities;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;

import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;

public class DataProviders {

	@DataProvider(name = "HMHS_Ncompass_G1DP", parallel = false)
	public static Object[][] getDataG1(Method m) {

		if(RunTestNG_NCompass_HMHS.runCount>0)
		{
			int rowsSize=RunTestNG_NCompass_HMHS.failedData.get(m.getName()).size();
			Object[][] datautil= new Object[rowsSize][1];
			for(int i=0;i<rowsSize;i++)
			{
				datautil[i][0]=RunTestNG_NCompass_HMHS.failedData.get(m.getName()).get(i);
			}
			return datautil;
		}else{
			ExcelReader excel = new ExcelReader(
					System.getProperty("user.dir") + RunTestNG_NCompass_HMHS.Config.getProperty("TestData_G1_XL_PATH"));
			String testcase = m.getName();
			 return DataUtil.getData(testcase, excel);
		}
		

	}
	
	@DataProvider(name = "HMHS_Ncompass_G2DP", parallel = false)
	public static Object[][] getDataG2(Method m) {

		if(RunTestNG_NCompass_HMHS.runCount>0)
		{
			int rowsSize=RunTestNG_NCompass_HMHS.failedData.get(m.getName()).size();
			Object[][] datautil= new Object[rowsSize][1];
			for(int i=0;i<rowsSize;i++)
			{
				datautil[i][0]=RunTestNG_NCompass_HMHS.failedData.get(m.getName()).get(i);
			}
			return datautil;
		}else{
			ExcelReader excel = new ExcelReader(
					System.getProperty("user.dir") + RunTestNG_NCompass_HMHS.Config.getProperty("TestData_G2_XL_PATH"));
			String testcase = m.getName();
			return DataUtil.getData(testcase, excel);
		}
		
		

	}

}
