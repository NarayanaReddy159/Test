package com.nasco.HMHS.Pages;

import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;

import net.bytebuddy.implementation.bytecode.Throw;

@SuppressWarnings({"rawtypes","unchecked","unused"})
public class ReportPage extends BasePage {
	String workbasketXpath="(//span[contains(text(),'%s')])[1]";
	String header="//label[contains(text(),'%s')]";
	
	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	@FindBy(xpath = "//div[1]/div/div/div/ul/li[2]/a/span[1]/span")
	public WebElement myWorkIcon;
	@FindBy(xpath = "//li[@title='My Reports']")
	public WebElement MyReport;
	
 @Override
  protected ExpectedCondition getPageLoadCondition() {
  switchToFrame("PegaGadget0Ifr");
  return ExpectedConditions.visibilityOf(myWorkIcon);
  }
 @FindBy(xpath = "//label[contains(text(),'Route intent to last assigned operator')]")
	public WebElement  Routeintenttolastassignedoperator;
 @FindBy(xpath = "//h2[contains(text(),'Open inventory')] ")
	public WebElement openInventory;
 @FindBy(xpath = "//a[contains(text(),'SLA Breakdown of Open Tasks')]")
	public WebElement Slabreakdown;
 @FindBy(xpath = "//a[contains(text(),'Research Invalid Work Objects')]")
	public WebElement Researchinvalid;
 @FindBy(xpath = "//h2[contains(text(),'Throughput')]")
	public WebElement ThroughPut;
 @FindBy(xpath = "//a[contains(text(),'Throughput Timeliness')]")
	public WebElement Timeliness;
	@FindBy(xpath = "//a[contains(text(),'Throughput Summary')]")
	public WebElement Summary;
	@FindBy(xpath = "//h1[contains(text(),'SLA Breakdown of Open Tasks')]")
	public WebElement Slabreakdowntitle;
	@FindBy(xpath = "//div[contains(@class,'content   layout-content-stacked content-stacked  clearfix')]")
	public WebElement SlaNote;
	@FindBy(xpath = "//tbody/tr[2]/td[6]/nobr[1]/span[1]/i[1]/img[1]")
	public WebElement workbasket;
	@FindBy(xpath = "//tbody/tr[3]/td[9]/nobr[1]/span[1]/i[1]/img[1]")
	public WebElement Performanceguarantee;
	@FindBy(xpath = "//input[@name='$PCustomFilter$pPerformanceGuaranteeIndicator']//following::i[1]")
	public WebElement PerformanceguaranteIcon;
	@FindBy(id = "ModalButtonCancel")
	public WebElement Cancel;
	@FindBy(xpath = "//tbody/tr[@id='GrandTotal']/td[8]")
	public WebElement DrillDown;
	@FindBy(xpath = "//h1[contains(text(),'Research Invalid Work Objects')]")
	public WebElement Researchtitle;
	@FindBy(xpath = "//h1[contains(text(),'Throughput Timeliness')]")
	public WebElement ThroughputtimelinessTitle;
	@FindBy(xpath = "//h1[contains(text(),'Throughput Summary')]")
	public WebElement ThroughputSummaryTitle;
	@FindBy(xpath = "//a[contains(text(),'Export to PDF')]")
	public WebElement ExportToPDF;
	@FindBy(xpath = "//a[contains(text(),'Export to Excel')]")
	public WebElement ExportToExcel;
	@FindBy(xpath = "//span[contains(text(),'Generated on')]")
	public WebElement generatedon;
	@FindBy(how = How.XPATH, using = "//button[text()='  Submit ']")
	public WebElement submitBtn;
	@FindBy(how = How.XPATH, using = "//div[text()='Generate report']")
	public WebElement Generatereport;
	@FindBy(xpath = "//tbody/tr[@id='GrandTotal']/td[8]//span[1]")
	public WebElement Grandtotals;
	@FindBy(xpath = "//tbody/tr[@id='$PpyReportContentPage$ppxResults$l1']/td[9]/div[1]")
	public WebElement Totalassigned;
	@FindBy(xpath = "//*[@id='$PpyReportContentPage$ppzDrillDownReport$ppxResults$l1']/td[5]/div")
	public WebElement Pg;
	@FindBy(xpath = "//*[@id='$PpyReportContentPage$ppzDrillDownReport$ppxResults$l10']/td[5]/div")
	public WebElement Pg1;
	
	@FindBy(xpath = "(//div[contains(text(),'Clear')])[1]")
	public WebElement Clear;
 public void MyReport(Hashtable<String, String> data) throws Exception
	{
		try{
			waitSleep(3000);
			switchToFrame("PegaGadget0Ifr");
			webElementClick(MyReport, "My Report");
			waitSleep(1500);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on MyReport method " + e);
			test.log(Status.FAIL, "Error on MyReport method " + e);
			throw e;
		}
	}
 public void OpenInventory(Hashtable<String, String> data) throws Exception
	{
		try{
			waitSleep(3000);
			switchToFrame("PegaGadget0Ifr");
			String OpenInventory=webElementReadText(openInventory);
			String SlaBreakdown=webElementReadText(Slabreakdown)+"::"+Slabreakdown.getAttribute("title").toString();
			assertEquals(SlaBreakdown, data.get("ExpectedSlaBreakdown"), "Sla Breakdown");
			String ResearchInvalid=webElementReadText(Researchinvalid)+"::"+Researchinvalid.getAttribute("title").toString();
			assertEquals(ResearchInvalid, data.get("ExpectedResearchInvalid"), "Sla Breakdown");
			//System.out.println(OpenInventory+"::"+SlaBreakdown+"::"+ResearchInvalid);
			waitSleep(1500);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on OpenInventory method " + e);
			test.log(Status.FAIL, "Error on OpenInventory method " + e);
			throw e;
		}
		}
		public void Throughput(Hashtable<String, String> data) throws Exception
		{
			try{
				waitSleep(3000);
				switchToFrame("PegaGadget0Ifr");
				String Throughput=webElementReadText(ThroughPut);
				String ThroughputTimeliness=webElementReadText(Timeliness)+"::"+Timeliness.getAttribute("title").toString();
				assertEquals(ThroughputTimeliness, data.get("ExpectedThroughputTimeliness"), "Throughput Timeliness");
				String ThroughputSummary=webElementReadText(Summary)+"::"+Summary.getAttribute("title").toString();
				assertEquals(ThroughputSummary, data.get("ExpectedThroughputSummary"), "Throughput Summary");
				//System.out.println(Throughput+"::"+ThroughputTimeliness+"::"+ThroughputSummary);
				waitSleep(1500);
			
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on Throughput method " + e);
				test.log(Status.FAIL, "Error on Throughput method " + e);
				throw e;
			}
	}
		public void ReportName(Hashtable<String, String> data) throws Exception
		{
			
			try{
				waitSleep(3000);
				switchToFrame("PegaGadget0Ifr");
				driver.findElement(By.xpath("//span[@class='heading_2']")).click();
				waitSleep(1000);
				if(data.get("ReportName").equals("SLA Breakdown of Open Tasks"))
				{
					webElementClick(Slabreakdown, "SLA Breakdown of Open Tasks");
				}else if(data.get("ReportName").equals("Research Invalid Work Objects"))
				{
					webElementClick(Researchinvalid, "Research Invalid Work Objects");
				}else if(data.get("ReportName").equals("Throughput Timeliness"))
				{
					driver.findElement(By.xpath("//*[@id='EXPAND-INNERDIV']/div/div[2]")).click();
					webElementClick(Timeliness, "Throughput Timeliness");
				}else if(data.get("ReportName").equals("Throughput Summary"))
				{
					webElementClick(Summary, "Throughput Summary");
				}
				
				waitSleep(1500);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on ReportName method " + e);
				test.log(Status.FAIL, "Error on ReportName method " + e);
				throw e;
			}
		}
				
		
		public void VaildationSLABreakdownofOpenServiceRequests(Hashtable<String, String> data) throws Exception
		{
			
			try{
				waitSleep(3000);
				switchToFrame("PegaGadget0Ifr");
				waitSleep(1500);
				
				String parentWindow=driver.getWindowHandle();
				for (String windowHandle : driver.getWindowHandles())
				{
					if(!parentWindow.equals(windowHandle)){
						 driver.switchTo().window(windowHandle);
						 //System.out.println("Switched to"+windowHandle);
					}
					//System.out.println(windowHandle);
					
				}
				
				switchToDefault();
				Slanote(data);
				if(data.get("ReportName").equals("SLA Breakdown of Open Tasks"))
				{
					String SlaBreakdownTitle=webElementReadText(Slabreakdowntitle);
	                assertEquals(SlaBreakdownTitle, data.get("ReportName"), "SlaBreakdownTitle");
	                Tableheader(data);
	             
	                
				}else if(data.get("ReportName").equals("Research Invalid Work Objects"))
				{
					String ResearchTitle=webElementReadText(Researchtitle);
					assertEquals(ResearchTitle, data.get("ReportName"), "ResearchTitle");
					Tableheader(data);
					
				}else if(data.get("ReportName").equals("Throughput Timeliness"))
				{
					String ThroughputTimelinesstitle=webElementReadText(ThroughputtimelinessTitle);
					assertEquals(ThroughputTimelinesstitle, data.get("ReportName"), "ThroughputTimelinesstitle");
					Tableheader(data);
					
				}else if(data.get("ReportName").equals("Throughput Summary"))
				{
					String ThroughputSummarytitle=webElementReadText(ThroughputSummaryTitle);
					assertEquals(ThroughputSummarytitle, data.get("ReportName"), "ThroughputSummarytitle");
					TableheaderThroughputSummary(data);
				}
				VaildateFieldName(data);
				if(data.get("DrillDown").equals("Yes"))
				{   
					if(data.get("ReportName").equals("Research Invalid Work Objects"))
					{
					
					workbasket(data);
					}else{
						Performanceguarantee(data);	
						SLA_workbasket();
					}
				    DrillDown(data);
				    
				}
				driver.close();
				driver.switchTo().window(parentWindow);

			
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on VaildationSLABreakdownofOpenServiceRequests method " + e);
				test.log(Status.FAIL, "Error on VaildationSLABreakdownofOpenServiceRequests method " + e);
				throw e;
			}
		}
		public void workbasket(Hashtable<String, String> data) throws Exception
		{
			String workbaskets="";
			try{
				waitSleep(3000);
				
				webElementClick(workbasket, "work basket");
				waitSleep(1500);
				 List<WebElement> hr = driver.findElements(By.xpath("//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]")); 
	    			//System.out.println(hr.size());
	    			if(hr.size()==0)
	    			{
	    				waitSleep(15000);
	    				hr = driver
	    						.findElements(By.xpath("//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]"));
	    				//System.out.println(hr.size());
	    			}
	    			
	    			String h = "(//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]//td[2])[%d]";				
	    				for(int i=1;i<=hr.size();i++)
	    				{	
	    					workbaskets = workbaskets + "|" + driver.findElement(By.xpath(String.format(h, i))).getText();
	    						
	    						
	    				}	
	    				
	    			////System.out.println(workbaskets);
	    			assertEquals(data.get("Expectedworkbaskets"), workbaskets, "workbaskets");
	    			 webElementClick(Cancel,"Cancel");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on SLABreakdownofOpenServiceRequests method " + e);
				test.log(Status.FAIL, "Error on SLABreakdownofOpenServiceRequests method " + e);
				throw e;
			}
		}
		public void Slanote(Hashtable<String, String> data) throws Exception
		{
			
			try{
				waitSleep(1500);
				
                String Slanote=webElementReadText(SlaNote);
                assertEquals(Slanote, data.get("ExpectedSlanote"), "Slanote");
				waitSleep(1500);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on Slanote method " + e);
				test.log(Status.FAIL, "Error on Slanote method " + e);
				throw e;
			}
		}
		public void VaildateFieldName(Hashtable<String, String> data) throws Exception
		{
			
			try{
				waitSleep(3000);
				 String HeaderofallFields=getrowdata(data.get("HeadersField"), header);
				 String ExporttoPDF=webElementReadText(ExportToPDF);
				 String ExporttoExcel=webElementReadText(ExportToExcel);
				 String Generatedon=webElementReadText(generatedon);
				 String field=ExporttoPDF+"::"+ExporttoExcel+"::"+Generatedon;
				
				 assertEquals(field, data.get("ExpectedHeaderField"), "Header Field Name");
	             assertEquals(HeaderofallFields, data.get("ExpectedFieldtab"), "Header Field Name");
	              
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on VaildateFieldName method " + e);
				test.log(Status.FAIL, "Error on VaildateFieldName method " + e);
				throw e;
			}
		}
		public void Tableheader(Hashtable<String, String> data) throws Exception
		{
			String SLaheader="";
			try{
				waitSleep(3000);
				List<WebElement> hr = driver.findElements(By.xpath("//th[contains(@class,'dataLabelRead cellCont gridCell ellipsis')]")); 
    			//System.out.println(hr.size());
    			if(hr.size()==0)
    			{
    				waitSleep(15000);
    				hr = driver
    						.findElements(By.xpath("(//th[contains(@class,'dataLabelRead cellCont gridCell ellipsis')]"));
    				//System.out.println(hr.size());
    			}
    			
    			String h = "//th[contains(@class,'dataLabelRead cellCont gridCell ellipsis')]";				
    				List<WebElement> colums = driver.findElements(By.xpath(h));
    				for (int j = 0; j < colums.size(); j++) {
    					if (j ==0) {
    						SLaheader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    					} else {
    						SLaheader = SLaheader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    						
    					}
    				}
    			////System.out.println(SLaheader);
    			assertEquals(data.get("ExpectedSLaheader"), SLaheader, "SLaheader");
              
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on Tableheader method " + e);
				test.log(Status.FAIL, "Error on Tableheader method " + e);
				throw e;
			}
		}
		public void DrillDown(Hashtable<String, String> data) throws Exception
		{
			
			try{
				waitSleep(3000);
				

				webElementClick(DrillDown, "Open SR Drill Down");
				waitSleep(1500);
				Slanote(data);
				VaildateFieldName(data);
				DrillDownTableheader(data);
				if(data.get("ReportName").equals("Research Invalid Work Objects"))
				{
				 workbasket(data);
				}else{
					Performanceguarantee(data);	
					SLA_workbasket();
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on DrillDown method " + e);
				test.log(Status.FAIL, "Error on DrillDown method " + e);
				throw e;
			}
		}
				
		public void DrillDownTableheader(Hashtable<String, String> data) throws Exception
		{
			String SLaheader="";
			try{
				waitSleep(3000);
				List<WebElement> hr = driver.findElements(By.xpath("//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle   ')]")); 
    			//System.out.println(hr.size());
    			if(hr.size()==0)
    			{
    				waitSleep(15000);
    				hr = driver
    						.findElements(By.xpath("//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle   ')]"));
    				//System.out.println(hr.size());
    			}
    			
    			String h = "//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle   ')]";				
    				List<WebElement> colums = driver.findElements(By.xpath(h));
    				for (int j = 0; j < colums.size(); j++) {
    					if (j ==0) {
    						SLaheader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    					} else {
    						SLaheader = SLaheader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    						
    					}
    				}
    			////System.out.println(SLaheader);
    			assertEquals(data.get("ExpectedDrillDown"), SLaheader, "SLaheader");
              
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on DrillDownTableheader method " + e);
				test.log(Status.FAIL, "Error on DrillDownTableheader method " + e);
				throw e;
			}
		}
		public void TableheaderThroughputSummary(Hashtable<String, String> data) throws Exception
		{
			String SLaheader="";
			try{
				waitSleep(3000);
				List<WebElement> hr = driver.findElements(By.xpath("//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle')]")); 
    			//System.out.println(hr.size());
    			if(hr.size()==0)
    			{
    				waitSleep(15000);
    				hr = driver
    						.findElements(By.xpath("//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle')]"));
    				//System.out.println(hr.size());
    			}
    			
    			String h = "//th[contains(@class,'dataLabelRead cellCont gridCell highlight-ele  colResize pointerStyle')]";				
    				List<WebElement> colums = driver.findElements(By.xpath(h));
    				for (int j = 0; j < colums.size(); j++) {
    					if (j ==0) {
    						SLaheader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    					} else {
    						SLaheader = SLaheader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
    						
    						
    					}
    				}
    			////System.out.println(SLaheader);
    			assertEquals(data.get("ExpectedSLaheader"), SLaheader, "SLaheader");
              
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on TableheaderThroughputSummary method " + e);
				test.log(Status.FAIL, "Error on TableheaderThroughputSummary method " + e);
				throw e;
			}
		}
		public void SLA_workbasket() throws Exception
		{
			String workbaskets = " ";
			try{
				waitSleep(3000);

				webElementClick(workbasket, "work basket");
				waitSleep(1500);
				
				waitSleep(1500);
				 List<WebElement> hr = driver.findElements(By.xpath("//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]")); 
	    			//System.out.println(hr.size());
	    			if(hr.size()==0)
	    			{
	    				waitSleep(15000);
	    				hr = driver
	    						.findElements(By.xpath("//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]"));
	    				//System.out.println(hr.size());
	    			}
	    			
	    			String h = "(//tr[contains(@id,'$PWorkbasketList$ppxResults$l')]//td[2])[%d]";
	    			boolean workbasketvalue =true;
	    				for(int i=1;i<=hr.size();i++)
	    				{	
	    					//workbaskets = workbaskets + "|" + driver.findElement(By.xpath(String.format(h, i))).getText();
	    						if(driver.findElement(By.xpath(String.format(h, i))).getText().equals(""))
	    						{
	    							workbasketvalue=false;
	    							break;
	    						}
	    					
	    							
	    						
	    				}	
	    	
				if(workbasketvalue)
				{
					BaseTest.log.debug("Workbasket values are displaying");
					test.log(Status.PASS, "Workbasket values are displaying ");
				}else{
				     Assert.fail();
				     
				}

				
				webElementClick(Cancel,"Cancel");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on SLABreakdownofOpenServiceRequests method " + e);
				test.log(Status.FAIL, "Error on SLABreakdownofOpenServiceRequests method " + e);
				throw e;
			}
		}
		public void Performanceguarantee(Hashtable<String, String> data) throws Exception
		{
			String Performanceguarante="";
			try{
				waitSleep(3000);
				
				webElementClick(Performanceguarantee, "Performance guarantee");
				waitSleep(1500);
				 List<WebElement> hr = driver.findElements(By.xpath("//tr[contains(@id,'$PPGIndicatorValues$ppxResults$l')]")); 
	    			//System.out.println(hr.size());
	    			if(hr.size()==0)
	    			{
	    				waitSleep(15000);
	    				hr = driver
	    						.findElements(By.xpath("//tr[contains(@id,'$PPGIndicatorValues$ppxResults$l')]"));
	    				//System.out.println(hr.size());
	    			}
	    			
	    			String h = "(//tr[contains(@id,'$PPGIndicatorValues$ppxResults$l')]//td[2])[%d]";				
	    				for(int i=1;i<=hr.size();i++)
	    				{	
	    					Performanceguarante = Performanceguarante+ "|" + driver.findElement(By.xpath(String.format(h, i))).getText();
	    						
	    						
	    				}	
	    				
	    			////System.out.println(workbaskets);
	    			assertEquals(data.get("ExpectedPerformanceguarantee"), Performanceguarante, "Performanceguarantee");
	    			 webElementClick(Cancel,"Cancel");
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on SLABreakdownofOpenServiceRequests method " + e);
				test.log(Status.FAIL, "Error on SLABreakdownofOpenServiceRequests method " + e);
				throw e;
			}
		}
		public void Performanceguaranteeselect(WebElement performicon,String Performanceguarante){
			try{
				waitSleep(2500);
				webElementClick(performicon, "Performance guarantee");
				waitSleep(1500);
				webElementClick(Clear, "clear");
				waitSleep(1500);
				List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PPGIndicatorValues$ppxResults$l')]"));
				if(tableRows.size()>0)
				{
					for(int i=1;i<=tableRows.size();i++)
					{
						
						if(driver.findElement(By.xpath("//tr[contains(@id,'$PPGIndicatorValues$ppxResults$l"+i+"')]/td[2]")).getText().equals(Performanceguarante))
						{
							WebElement reviewed=driver.findElement(By.xpath("//tr[contains(@id,'$PPGIndicatorValues$ppxResults$l"+i+"')]/td[1]//input[@type='checkbox']"));
							((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", reviewed);
							jsClick(reviewed,"Reviewed");
							waitSleep(3500);
							webElementClick(submitBtn, "Submit");
							waitSleep(1500);
							break;
						}
					}
				}
				waitSleep(2000);
				webElementClick(Generatereport, "Generate report");
				waitSleep(5500);
			}catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on Performanceguaranteeselect method " + e);
				test.log(Status.FAIL, "Error on Performanceguaranteeselect method " + e);
				throw e;
			}
		}
		public void PerformanceGaurentee(Hashtable<String, String> data) throws Exception
		{
			
			try{
				waitSleep(3000);
				switchToFrame("PegaGadget0Ifr");
				
				String parentWindow=driver.getWindowHandle();
				for (String windowHandle : driver.getWindowHandles())
				{
					if(!parentWindow.equals(windowHandle)){
						 driver.switchTo().window(windowHandle);
						 //System.out.println("Switched to"+windowHandle);
						 driver.manage().window().maximize();
					}
					//System.out.println(windowHandle);
					
				}
				
			
				switchToDefault();
				int grandtotal= 0,Yestotal= 0,Nototal=0;
				
				if(data.get("ReportName").equals("SLA Breakdown of Open Tasks"))
				{   grandtotal= Grandtotal(data,Grandtotals);
				    Performanceguaranteeselect(Performanceguarantee,data.get("Performanceguarantee"));
				    Nototal=Grandtotal(data,Grandtotals);
					PG(data.get("Performanceguarantee"));
					webElementClick(Slabreakdown, "Back to report sub page");
					waitSleep(3500);
					Performanceguaranteeselect(Performanceguarantee,data.get("Performanceguarantee1"));
					Yestotal=Grandtotal(data,Grandtotals);
					PG(data.get("Performanceguarantee1"));
					/*
					 * if(grandtotal==Nototal+Yestotal) { test.log(Status.PASS,
					 * "Performanceguarantee filter is working as excepted ");
					 * 
					 * }else{ test.log(Status.FAIL,
					 * "Performanceguarantee filter is not working as excepted "); throw new
					 * ArithmeticException("Performanceguarantee filter is not working as excepted "
					 * ); }
					 */
				}else if(data.get("ReportName").equals("Throughput Timeliness"))
				{ 
					grandtotal=Grandtotal(data,Grandtotals);
			        Performanceguaranteeselect(PerformanceguaranteIcon,data.get("Performanceguarantee"));
			        Nototal=Grandtotal(data,Grandtotals);
				    Performanceguaranteeselect(PerformanceguaranteIcon,data.get("Performanceguarantee1"));
				    Yestotal=Grandtotal(data,Grandtotals);
					/*
					 * if(grandtotal==Nototal+Yestotal) { test.log(Status.PASS,
					 * "Performanceguarantee filter is working as excepted ");
					 * 
					 * }else{ test.log(Status.FAIL,
					 * "Performanceguarantee filter is not working as excepted "); throw new
					 * ArithmeticException("Performanceguarantee filter is not working as excepted "
					 * ); }
					 */
				}else if(data.get("ReportName").equals("Throughput Summary"))
				{
					grandtotal=Grandtotal(data,Totalassigned);
					    Performanceguaranteeselect(PerformanceguaranteIcon,data.get("Performanceguarantee"));
					    Nototal=Grandtotal(data,Totalassigned);
						
						Performanceguaranteeselect(PerformanceguaranteIcon,data.get("Performanceguarantee1"));
						Yestotal=Grandtotal(data,Totalassigned);
						if(grandtotal==Nototal+Yestotal)
						{
							test.log(Status.PASS, "Performanceguarantee filter is working as excepted ");
							
						}else{
							test.log(Status.FAIL, "Performanceguarantee filter is not working as excepted ");
							throw new ArithmeticException("Performanceguarantee filter is not working as excepted ");
						}
						
				}
				
				waitSleep(1500);
			
			driver.close();
			driver.switchTo().window(parentWindow);

		
		
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on PerformanceGaurentee method " + e);
				test.log(Status.FAIL, "Error on PerformanceGaurentee method " + e);
				throw e;
			}
		}
		public int Grandtotal(Hashtable<String, String> data , WebElement total) throws Exception
		{
			String Grandtotal="";
			try{
				waitSleep(3000);
				 
				// return Integer.valueOf(Grandtotal.trim());
				 try{
					 Grandtotal=total.getText();
					 System.out.println("Grandtotal::"+Grandtotal);
					 return Integer.valueOf(Grandtotal.trim());
						}catch(Exception ex1){
							
							return 0;
							
						}

	              
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on VaildateFieldName method " + e);
				test.log(Status.FAIL, "Error on VaildateFieldName method " + e);
				throw e;
			}
		}
		public void PG(String Performanceguarantee ) throws Exception
		{
			String PG="";
			try{
				 waitSleep(3000);
				 webElementClick(DrillDown, "Open SR Drill Down");
				 waitSleep(3000);
				 PG=webElementReadText(Pg, "Pg value ");
				 assertEquals(Performanceguarantee, PG, "Pg Value from table ");
				 PG=webElementReadText(Pg1, "Pg value ");
				 assertEquals(Performanceguarantee, PG, "Pg Value from table ");
				
	              
			}
			catch(Exception e)
			{
				e.printStackTrace();
				BaseTest.log.error("Error on VaildateFieldName method " + e);
				test.log(Status.FAIL, "Error on VaildateFieldName method " + e);
				throw e;
			}
		}
			
}
