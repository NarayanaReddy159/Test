package com.nasco.HMHS.Pages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;
import com.aventstack.extentreports.Status;

@SuppressWarnings({"rawtypes","unchecked","unused"})
public class WorklistPage extends BasePage {

	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	
	@FindBy(xpath = "//span[contains(text(),'Home')]")
	public WebElement Home;

	@FindBy(xpath = "//div[1]/div/div/div/ul/li[2]/a/span[1]/span")
	public WebElement myWorkIcon;

	@FindBy(xpath = "//h3[contains(text(),'Recent work')]")
	public WebElement recentWork;

	@FindBy(xpath = "(//*[@id='pui_filter'])[2]")
	public WebElement idSort;
	
	@FindBy(xpath = "(//*[@id='pui_filter'])[4]")
	public WebElement statusSort;
	
	@FindBy(xpath = "//span/div/div/div/div/div/div/div/span/input")
	public WebElement searchID;
	
	@FindBy(xpath = "//label[text()='Contact is authorized']")
	public WebElement authorizedYes;
	
	@FindBy(xpath = "//input[@name='$PpyWorkPage$ppyWorkParty$gMember$pDateOfBirthCheck' and @type='checkbox']")
	public WebElement VerifyDOB;
	
	@FindBy(xpath = "//button[contains(text(),'Apply')]")
	public WebElement applyBtn;
	@FindBy(xpath = "//*[@id='$PpgRepPgSubSectionpyUserWorkListBB$ppxResults$l1']/td[2]/div/span/a")
	public WebElement intentclick;
	@FindBy(xpath = "//span[contains(text(),'Status')]//following::div[1]")
	public WebElement IntentStatus;
	@FindBy(xpath = "(//a[@class='Header_nav'])[3]")
	public WebElement MenuDropdown;
	@FindBy(xpath = "//span[contains(text(),'Logout')]")
	public WebElement LogOut;
	//@FindBy(xpath = "//h3[contains(text(),'Worklist')]")
	//@FindBy(xpath = "//div[5]/div[1]/h3/text()")
    //@FindBy(xpath= "//div[@class='header']//h3[contains(text(),'Worklist')]")
    //public WebElement worklist;
	
	@FindBy(xpath= "//h3[contains(text(),'Worklist')]")
	public WebElement worklist; 
	
	@FindBy(xpath = "//button[contains(text(),'+ Create new work')]")
	public WebElement CreateNewWork;
	@FindBy(xpath = "//div[contains(text(),'If you reached an invalid callback number, prior t')]")
	public WebElement InvalidCallNoText;

	@FindBy(xpath = "//select[@id='0b372c42']")
	public WebElement attempt;
	@FindBy(xpath = "//div[2]/div[1]/div[1]/div[1]/span[1]/img[1]")
	public WebElement SelectDate;
	@FindBy(xpath = "//a[contains(text(),'24')]")
	public WebElement SelectDay;
	@FindBy (how = How.XPATH, using = "//textarea[@id='ebea7f57']")
	public WebElement AttemptComments;
	@FindBy (how = How.XPATH, using = "//select[@id='StartTime']")
	public WebElement StartTime;
	@FindBy (how = How.XPATH, using = "//div[contains(text(),'Recommended number of callback attempts reached. Prior to selecting submit, navigate to the create new work button and select respond to customer to send correspondence.')]")
	public WebElement LimitMsgCheck;
	
	@FindBy(xpath = "//button[@title='Other actions']")
	public WebElement OtherActions;
	@FindBy(xpath = "//span[text()='Save to Worklist']")
	public WebElement SaveToWorklist;
	@FindBy(xpath = "//span[contains(text(),'Verify Contact and Document Callback Res...')]")
	public WebElement VerifyCallback;
	
	@FindBy(xpath = "//select[@id='8b0fe3a6']")
	public WebElement ReasonToPend;
	@FindBy (how = How.XPATH, using = "//textarea[@id='5e1978c7']")
	public WebElement Comments;
	@FindBy (how = How.XPATH, using = "//textarea[@name='$PpyWorkPage$pWrapUpComments']")
	public WebElement WorkComments;
	@FindBy (how = How.XPATH, using = "//label[text()='Comments']//following::textarea[1]")
	public WebElement MsgComments;
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Submit')]")
	public WebElement Submit;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Route to Team')]")
	public WebElement RouteToTeam;
	@FindBy(xpath = "//div[1]/div[1]/div[1]/span[1]/label[1]")
	public WebElement TeamMemWork;
	
	@FindBy(xpath = "//label[contains(text(),'Workbasket')]")
	public WebElement WorkBasket;
	@FindBy(xpath = "//input[@id='9c5eeb90']")
	public WebElement TransferTo;
	
	@FindBy(xpath = "//input[@id='d621496c']")
	public WebElement Operator;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Document Follow-Up Task Resolution')]")
	public WebElement GoBackFollowUp;
	
	@FindBy(how = How.XPATH, using = "//button[contains(text(),'+ Create new work')]")
	public WebElement CeateNewWork;
	@FindBy(how = How.XPATH, using = "//a//span[contains(text(),'Create Follow Up')]")
	public WebElement CreateFollowUp;
	@FindBy(how = How.XPATH, using = "//a//span[contains(text(),'Respond to Customer')]")
	public WebElement CreateRTC;
	@FindBy(how = How.XPATH, using = "//a//span[contains(text(),'Request ID Card')]")
	public WebElement CreateReqIDCard;
	@FindBy (how = How.XPATH, using = "//button[contains(text(),'Next')]")
	public WebElement Next;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'There is a limit of one ID card request allowed in')]")
	public WebElement WarningMsg1;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'You are requesting more than limit of 3 cards/sets')]")
	public WebElement WarningMsg3;
	@FindBy (how = How.XPATH, using = "//span[contains(text(),'The contract has a future cancellation date. Pleas')]")
	public WebElement WarningMsg5;
	@FindBy (how = How.XPATH, using = "//input[@id='80a4df31']")
	public WebElement WarningCheck1;
	@FindBy (how = How.XPATH, using = "//input[@id='ab898cf2']")
	public WebElement WarningCheck2;
	@FindBy (how = How.XPATH, using = "//input[@id='b292bdb3']")
	public WebElement WarningCheck3;
	@FindBy(xpath = "//span[contains(text(),'Type of inquiry')]//following::span[1]")
	public WebElement typeofinquiry;
	@FindBy(xpath = "//span[contains(text(),'Reason')]//following::span[1]")
	public WebElement reason;
	@FindBy(xpath = "//span[contains(text(),'Resolution')]//following::span[1]")
	public WebElement resolution;
	@FindBy(xpath = "//label[contains(text(),'Resolve')]")
	public WebElement Resolve;
	@FindBy(xpath = "//select[@name='$PpyWorkPage$pInquiriesList$l1$pInquiryType']")
	public WebElement TypeofInq;
	@FindBy(xpath = "//select[@name='$PpyWorkPage$pInquiriesList$l1$pInquiryReason']")
	public WebElement Reason;
	@FindBy(xpath = "//select[@name='$PpyWorkPage$pInquiriesList$l1$pInquiryResolution']")
	public WebElement Resolution;
	
	@FindBy(xpath = "//input[contains(@name,'$PpyWorkPage$ppyNotes$l') and contains(@name,'$pInfoReceivedDate')]")
	public WebElement Inforeceivedate;
	@FindBy(xpath = "//*[@id='PegaRULESErrorFlag']")
	public WebElement messageDisclosure;
	@FindBy(how = How.XPATH, using  = "//button[contains(text(),'Submit')]//preceding::b[1]")
	public WebElement message;
	
	@FindBy(how = How.XPATH, using  = "//label[contains(text(),'Correspondence')]")
	public WebElement Correspondence;
	@FindBy(how = How.XPATH, using  = "//b[contains(text(),'Submit will resolve')]")
	public WebElement NewMsg9;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
	switchToFrame("PegaGadget0Ifr");
	return ExpectedConditions.visibilityOf(myWorkIcon);
	}
	
	public void movetoWorklistPage() throws Exception
	{
		try{
			waitSleep(3000);
			switchToFrame("PegaGadget0Ifr");
			webElementClick(myWorkIcon, "My Work");
			waitSleep(3500);
			webElementClick(recentWork, "RecentWork tab");
			waitSleep(2500);
			webElementClick(worklist, "Worklist tab"); 
		}
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on Worklist method " + e);
			test.log(Status.FAIL, "Error on Worklist method " + e);
			throw e;
		}
	}	
	
	public void movetoHome() {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget0Ifr");
			waitSleep(1500);
			webElementClick(Home, "Home");
			waitSleep(3000);
			webElementClick(myWorkIcon, "My Work");
			waitSleep(2000);
			webElementClick(recentWork, "RecentWork tab");
		} catch (Exception e) {
			BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
			test.log(Status.FAIL, "Error on movetoRecentWorkPage method " + e);
			throw e;
		}
	}

	public void sortStatus(String status ) {
		try {
			switchToFrame("PegaGadget0Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(statusSort));
			webElementClick(statusSort, "Status Sort");
			try{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
				webElementSendText(searchID, status, "Search Status");
				}catch(StaleElementReferenceException e){
					waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
					webElementSendText(searchID, status, "Search Status");
				}
			waitSleep(1500);
			try{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(applyBtn));
				webElementClick(applyBtn, "Apply");
				}catch(StaleElementReferenceException e){
					webElementClick(applyBtn, "Apply");
				}
			waitSleep(1500);
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(Status.FAIL, "Error on sortandSelectIntent method " + e);
			throw e;
		}
	}
	
	// HMHS Sort and Select Intent
	public void sortandSelectIntent(Hashtable<String, String> data,String intentID) {
		try {
			switchToFrame("PegaGadget0Ifr");
			waitSleep(3500);
			driver.findElement(By.xpath("(//*[@id='pui_filter'])[3]")).click();
			driver.findElement(By.xpath("//input[contains(@name,'$PpyFilterCriteria_pgRepPgSubSectionpyUserWorkListBB_pxResults_pyUserWorkList') and contains(@name,'$ppySearchText')]")).sendKeys(data.get("Intent"));;
			driver.findElement(By.xpath("//button[text()='Apply']")).click();
			//waitForPageToLoad(ExpectedConditions.elementToBeClickable(idSort));
			waitSleep(1500);
			webElementClick(idSort, "ID Sort");
			try{
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
			webElementSendText(searchID, intentID, "Search Intent");
			}catch(StaleElementReferenceException e)
			{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
				webElementSendText(searchID, intentID, "Search Intent");
			}
			try{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(applyBtn));
				webElementClick(applyBtn, "Apply");
				waitSleep(3500);
				}
				catch(StaleElementReferenceException e){
					waitForPageToLoad(ExpectedConditions.elementToBeClickable(applyBtn));
					webElementClick(applyBtn, "Apply");
				}
			//waitForPageToLoad(ExpectedConditions.elementToBeClickable(intentclick));
			try{
				intentclick.click();
			//	webElementClick(intentclick, "Intent " + intentID);
				}
				catch(StaleElementReferenceException e){
					intentclick.click();
				//	webElementClick(intentclick, "Intent " + intentID);
				}
			waitSleep(2500);
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(Status.FAIL, "Error on sortandSelectIntent method " + e);
			throw e;
		}
	}
	
//Below method written for TC005_CreateFollowup_SaveToWorklist after opening intent on Worklist click on Other action.
	public void OtherActionsSaveToWorklist( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
			webElementClick(OtherActions, "to click on Other Actions");
			wait(3000);
			webElementClick(SaveToWorklist, "Save To Worklist");
			wait(3000);
			selectDropdownValueByVisibleText(ReasonToPend, data.get("ReasonToPend"), "to select Reason to Pend");
			wait(1500);
			webElementSendText(Comments, data.get("comments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActionsSaveToWorklist method " + e);
			test.log(Status.FAIL, "Error on OtherActionsSaveToWorklist method " + e);
			throw e;
		}
	}
	
	public void WorklistComments( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(2500);
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(Comments));
			webElementSendText(Comments, data.get("Worklistcomments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on WorklistComments & then Submit it." + e);
			test.log(Status.FAIL, "Error on WorklistComments & then Submit it." + e);
			throw e;
		}
	}

	public void fprReason()
	{
		try {
			switchToFrame("PegaGadget1Ifr");
			wait(2500);
			
			selectDropdownValueByValue(driver.findElement(By.name("$PpyWorkPage$pReason")), "Provider file issue", "Reason");
			wait(1500);
		
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on fprReason." + e);
			test.log(Status.FAIL, "Error on fprReason." + e);
			throw e;
		}
	}
	public void WorklistCommentsReqID( String intentID, Hashtable<String, String> data, String WarMsg1,String WarMsg5) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(Comments));
			webElementSendText(Comments, data.get("Worklistcomments"), "as Comments");
			wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			//System.out.println("Land on Review ID Card Request page");
			wait(3500);
			try{
				WarningCheck1.click();
			}
			catch(Exception e1)
			{
				
			}
			 wait(1500);
			 try{
				 WarningCheck2.click();
				 wait(3000);
				}
				catch(Exception e){
				}
			 wait(1500);
			 try{
				 WarningCheck3.click();
				 wait(3000);
				}
				catch(Exception e){
				}
			  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Submit); 
			  webElementClick(Submit, "Submit");
			  wait(3000);
			  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Submit); 
			  webElementClick(Submit, "Submit");
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on WorklistComments & then Submit it." + e);
			test.log(Status.FAIL, "Error on WorklistComments & then Submit it." + e);
			throw e;
		}
	}
	
	public void WorklistCommentsReqIDNoFut( String intentID, Hashtable<String, String> data, String WarMsg1,String WarMsg5) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(Comments));
			webElementSendText(Comments, data.get("Worklistcomments"), "as Comments");
			wait(1500);
			webElementClick(Next, "Go to Next Page -Review ID Card Request");
			//System.out.println("Land on Review ID Card Request page");
			wait(2500);
			try{
				WarningCheck1.click();
				wait(1500);
				
			}catch(Exception e)
			{
				
			}
			 wait(1500);
			 try{
				 WarningCheck2.click();
				 wait(1500);
				}
				catch(Exception e){
				}
			  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Submit); 
			  webElementClick(Submit, "Submit");
			  wait(3000);
			  ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Submit); 
			  webElementClick(Submit, "Submit");
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on WorklistComments & then Submit it." + e);
			test.log(Status.FAIL, "Error on WorklistComments & then Submit it." + e);
			throw e;
		}
	}
	
	public void MSGWorklistComments( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(MsgComments));
			webElementSendText(MsgComments, data.get("Worklistcomments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on WorklistComments & then Submit it." + e);
			test.log(Status.FAIL, "Error on WorklistComments & then Submit it." + e);
			throw e;
		}
	}
	
	public void OtherActionsRouteToTeam( String intentID, Hashtable<String, String> data) {
		String Message="";
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
			webElementClick(OtherActions, "to click on Other Actions");
			wait(3000);
			webElementClick(RouteToTeam, "Save To Worklist");
			wait(1500);
			webElementClick(TeamMemWork, "to select the Team Member's Worklist");
			wait(2000);
			webElementSendText(Operator, data.get("Operator"), "to select another Operator");
			wait(1500);
			Operator.sendKeys(Keys.TAB);
			wait(2000);
			webElementSendText(Comments, data.get("Routecomments"), "as Comments");
			wait(1500);
			Message= webElementReadText(message, "Message");
			 //System.out.println(Message);
			 assertEquals(data.get("ExpectedWorklistMessage"), Message, "WorklistMessage");
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActionsSaveToWorklist method " + e);
			test.log(Status.FAIL, "Error on OtherActionsSaveToWorklist method " + e);
			throw e;
		}
	}

	public void OtherActionsRouteToTeamWB( String intentID, Hashtable<String, String> data) {
		try {
			wait(4000);
			switchToFrame("PegaGadget1Ifr");
			wait(2000);
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
			webElementClick(OtherActions, "to click on Other Actions");
			wait(3000);
			webElementClick(RouteToTeam, "to Route To team");
			wait(1500);
			webElementClick(WorkBasket, "to select the Workbasket option to transfet the intent");
			wait(2000);
			webElementSendText(TransferTo, data.get("TransferWB"), "to select another Operator");
			wait(2000);
			webElementSendText(Comments, data.get("Routecomments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on OtherActionsSaveToWorklist method " + e);
			test.log(Status.FAIL, "Error on OtherActionsSaveToWorklist method " + e);
			throw e;
		}
	}

//From Worklist click on SaveToWorklist and again from SaveToWorklist go back to CreateFollowUp
		public void OtherActionsSaveToWorklistBack( String intentID, Hashtable<String, String> data) {
			try {
				switchToFrame("PegaGadget1Ifr");
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
				webElementClick(OtherActions, "to click on Other Actions");
				wait(1500);
				webElementClick(SaveToWorklist, "Save To Worklist");
				wait(1500);
				test.log(Status.INFO, "User land on SaveToWorklist page");
				wait(1500);
				webElementClick(OtherActions, "to click on Other Actions");
				wait(1500);
				webElementClick(GoBackFollowUp, "to click on Document Follow-Up Task Resolution from Other actions to go back to Followup page");
				test.log(Status.INFO, "Go Back to Create FollowUp page");
			} catch (Exception e) {
				e.printStackTrace();
				BaseTest.log.error("Error on OtherActionsSaveToWorklistBack method " + e);
				test.log(Status.FAIL, "Error on OtherActionsSaveToWorklistBack method " + e);
				throw e;
			}
		}
	
//From Worklist click on SaveToWorklist and again from SaveToWorklist go back to CreateFollowUp
public void OtherActionsSaveToWorklistBack1( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		waitForPageToLoad(ExpectedConditions.elementToBeClickable(OtherActions));
		webElementClick(OtherActions, "to click on Other Actions");
		wait(1500);
		webElementClick(VerifyCallback, "to land on Verify Contact and Document Callback Resolution page.");
		wait(1500);
		test.log(Status.INFO, "User land on Verify Contact and Document Callback Resolution page.");
		wait(1500);
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on OtherActionsSaveToWorklistBack method " + e);
		test.log(Status.FAIL, "Error on OtherActionsSaveToWorklistBack method " + e);
		throw e;
	}
}		
				
//After opening intent on Worklist click on CreateNewWork
 public void CreateNewWork( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		webElementClick(CreateNewWork, "to Create New Work");
		wait(1500);
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on CreateNewWork method " + e);
		test.log(Status.FAIL, "Error on CreateNewWork method " + e);
		throw e;
	}
 }			
		
		
//To select the CreateFollowup Intent from +CreateNew Work list
 public void CreateNewWorkFollowup( String intentID, Hashtable<String, String> data) {
	try {
			switchToFrame("PegaGadget1Ifr");
			webElementClick(CreateFollowUp, "to select Create FollowUp");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on CreateNewWorkFollowup method " + e);
			test.log(Status.FAIL, "Error on CreateNewWorkFollowup method " + e);
			throw e;
		}
	 }		
				
//To select the CreateFollowup Intent from +CreateNew Work list
public void CreateNewWorkRTC( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		webElementClick(CreateRTC, "to select Respond To Customer");
		//System.out.println("New Intent id: " +intentID);
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on CreateNewWorkRTC method " + e);
		test.log(Status.FAIL, "Error on CreateNewWorkRTC method " + e);
		throw e;
	}
}


//To select the CreateNewWorkReqID card Intent from +CreateNew Work list
public void CreateNewWorkReqIDCard( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(1500);
		webElementClick(CreateReqIDCard, "to select Request ID Card");
		wait(1500);
		//webElementClick(BackTab, "Go Back to previous intent");
		//wait(1500);
		//webElementSendText(WorkComments,data.get("Workcomments"), "Go Back to previous intent");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on CreateNewWorkReqIDCard method " + e);
		test.log(Status.FAIL, "Error on CreateNewWorkReqIDCard method " + e);
		throw e;
	}
}

//Go to Home page
public void GoToHome( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		webElementClick(Home, "to Go to Home page");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on CreateNewWorkRTC method " + e);
		test.log(Status.FAIL, "Error on CreateNewWorkRTC method " + e);
		throw e;
	}
}
	
		
		
//Below method written for TC005_CreateFollowup_SaveToWorklist after opening intent on Worklist click on Other action.
	public void FollowUpUnsuccessAttempt( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			selectDropdownValueByVisibleText(attempt, data.get("followupUnsuccess"), "to select reason of followup");
			wait(2000);
			Calendar calendar = Calendar.getInstance();
		    calendar.add(Calendar.DAY_OF_YEAR, 1);
		    Date tomorrowDate = calendar.getTime();
		    SimpleDateFormat formatter= new SimpleDateFormat("MM/dd/yyyy");
		    String tomorrowFormatted=formatter.format(tomorrowDate);
		    driver.findElement(By.xpath("//input[@name='$PNewSchedule$pStartDate']")).sendKeys(tomorrowFormatted);
			wait(1500);
			webElementSendText(AttemptComments, data.get("followupcomments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on FollowUpUnsuccessAttempt method " + e);
			test.log(Status.FAIL, "Error on FollowUpUnsuccessAttempt method " + e);
			throw e;
		}
	}	

public void FollowUpAttemptSuccess( String intentID, Hashtable<String, String> data) {
	String Message="";	
	try {
			switchToFrame("PegaGadget1Ifr");
			selectDropdownValueByVisibleText(attempt, data.get("followupSuccess"), "to select reason of followup");
			wait(2000);
			webElementSendText(AttemptComments, data.get("followupsuccesscomments"), "as Comments");
			wait(1500);
			
			Message= webElementReadText(message, "Message");
			//System.out.println(Message);
			assertEquals(data.get("ExpectedFollowUpAttemptMessage"), Message, "WorklistMessage");
			wait(1500);

			try{
				Calendar calendar = Calendar.getInstance();
			    calendar.add(Calendar.DAY_OF_YEAR, 1);
			    Date tomorrowDate = calendar.getTime();
			    SimpleDateFormat formatter= new SimpleDateFormat("MM/dd/yyyy");
			    String tomorrowFormatted=formatter.format(tomorrowDate);
			    driver.findElement(By.xpath("//input[@name='$PpyWorkPage$ppyNotes$l2$pInfoReceivedDate']")).sendKeys(tomorrowFormatted);
				}catch(Exception e){
				
				}
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on FollowUpAttemptSuccess method " + e);
			test.log(Status.FAIL, "Error on FollowUpAttemptSuccess method " + e);
			throw e;
		}
	}

		
//Below method written for TC005_CreateFollowup_SaveToWorklist after opening intent on Worklist click on Other action.
public void CallbackAttempt( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
			try{
				VerifyDOB.click();
			}
			catch(Exception e1)
			{
				
			}
			//webElementClick(VerifyDOB, "Verify DOB");
		wait(1000);
		selectDropdownValueByVisibleText(attempt, data.get("Resolution"), "to select reason of callback");
		try{
			wait(1000);
			webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
			catch(StaleElementReferenceException e){
				wait(1000);
				webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
		wait(1500);
		selectDropdownValueByValue(StartTime, data.get("startTime"), "to select start time for callback");
		wait(1500);
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on CallbackAttempt method " + e);
		test.log(Status.FAIL, "Error on CallbackAttempt method " + e);
		throw e;
	}
}

public void CallbackAttemptSub(String intentID,Hashtable<String, String> data,String expectedMessage1) {
	try {
		switchToFrame("PegaGadget1Ifr");
		//webElementClick(authorizedYes, "Authorized");
		webElementClick(VerifyDOB, "Verify DOB");
		wait(1000);
		selectDropdownValueByVisibleText(attempt, data.get("Resolution"), "to select reason of callback");
		try{
			String actualmsg1 = webElementReadText(InvalidCallNoText);
			String expectedmsg1 = String.format(expectedMessage1);
			assertEquals(actualmsg1,expectedmsg1,"Info massage matched If you reached an invalid callback number.");
		}
		catch(Exception e){
			
		}
		try{
			wait(1000);
			webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
			catch(StaleElementReferenceException e){
				wait(1000);
				webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
		wait(1500);
		selectDropdownValueByValue(StartTime, data.get("startTime"), "to select start time for callback");
		//selectDropdownValueByVisibleText(StartTime, data.get("startTime"), "to select start time for callback");
		wait(1500);
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on OtherActions method " + e);
		test.log(Status.FAIL, "Error on OtherActions method " + e);
		throw e;
	}
}

public void CallbackAttemptDiff( String intentID, Hashtable<String, String> data) {
	String Message9 = "";
	try {
		switchToFrame("PegaGadget1Ifr");
		//webElementClick(authorizedYes, "Authorized ");
		webElementClick(VerifyDOB, "Verify DOB");
		wait(1000);
		selectDropdownValueByVisibleText(attempt,data.get("Resolution"), "to select reason of callback");
		wait(1500);
		Calendar calendar = Calendar.getInstance();
	    calendar.add(Calendar.DAY_OF_YEAR, 1);
	    Date tomorrowDate = calendar.getTime();
	    SimpleDateFormat formatter= new SimpleDateFormat("MM/dd/yyyy");
	    String tomorrowFormatted=formatter.format(tomorrowDate);
	    driver.findElement(By.xpath("//input[@name='$PpyWorkPage$ppyNotes$l1$pInfoReceivedDate']")).sendKeys(tomorrowFormatted);
	    wait(1500);
		try{
			wait(1000);
			webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
			catch(StaleElementReferenceException e){
				wait(1000);
				webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
		wait(1500);
		
		Message9 = webElementReadText(NewMsg9);
	    //System.out.println(Message9);
		assertEquals(Message9,data.get("Message9"),"Info massage matched as Submit will resolve.");
		
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on CallbackAttemptDiff method " + e);
		test.log(Status.FAIL, "Error on CallbackAttemptDiff method " + e);
		throw e;
	}
}

public void CallbackAttemptResolve( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		try{
			VerifyDOB.click();
		}
		
		catch(Exception e1)
		{
		
		}
		//webElementClick(VerifyDOB, "Verify DOB");
		wait(1000);
		selectDropdownValueByVisibleText(attempt,data.get("Resolution"), "to select reason of callback");
		try{
			wait(1000);
			webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
			catch(StaleElementReferenceException e){
				wait(1000);
				webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
		wait(1500);
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on OtherActions method " + e);
		test.log(Status.FAIL, "Error on OtherActions method " + e);
		throw e;
	}
}

public void CallbackAttemptDiff1( String intentID, Hashtable<String, String> data) {
	try {
		switchToFrame("PegaGadget1Ifr");
		//webElementClick(authorizedYes, "Contact is Authorized");
		webElementClick(VerifyDOB, "Verify DOB");
		wait(1000);
		selectDropdownValueByVisibleText(attempt, data.get("Resolution"), "to select reason of callback");
		wait(3500);
		Calendar calendar = Calendar.getInstance();
	    calendar.add(Calendar.DAY_OF_YEAR, 1);
	    Date tomorrowDate = calendar.getTime();
	    SimpleDateFormat formatter= new SimpleDateFormat("MM/dd/yyyy");
	    String tomorrowFormatted=formatter.format(tomorrowDate);
	    driver.findElement(By.xpath("//input[@name='$PpyWorkPage$ppyNotes$l1$pInfoReceivedDate']")).sendKeys(tomorrowFormatted);
		wait(1500);
		try{
			wait(1000);
			webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
			catch(StaleElementReferenceException e){
				wait(1000);
				webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
			}
		wait(1500);
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on OtherActions method " + e);
		test.log(Status.FAIL, "Error on OtherActions method " + e);
		throw e;
	}
}


public void LimitMsg( String intentID, Hashtable<String, String> data,String LimitMsg) {
	try {
		switchToFrame("PegaGadget1Ifr");
		selectDropdownValueByVisibleText(attempt, data.get("Resolution"), "to select reason of callback");
		String ActualMessage = webElementReadText(LimitMsgCheck);
		//String ExpectedNotRegMsg = String.format(LimitMsg);
		 if (ActualMessage.contains(LimitMsg)) {
			test.log(Status.PASS, "Recommended number of callback attempt message matched.");
			test.log(Status.PASS,"Expected Message: "+' '+LimitMsg);
			test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
		 } else {
			test.log(Status.FAIL, "Recommended number of callback attempt message not matched.");
			test.log(Status.PASS,"Expected Message: "+' '+LimitMsg);
			test.log(Status.PASS,"Actual Message: "+' '+ActualMessage);
			Assert.fail();
		 }
		
		
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on Recommended number of callback attempts reached  method " + e);
		test.log(Status.FAIL, "Error on Recommended number of callback attempts reached method " + e);
		throw e;
	}
}


// HMHS IntentStatus

public void IntentStatusWorklist( String IntStatus, String frame) {
try {
	wait(2500);
	switchToFrame(frame);
	String actualMessage = webElementReadText(IntentStatus);
	String expected = String.format(IntStatus);
	if (actualMessage.contains(expected)) {
		test.log(Status.PASS, "Intent status is matched");
		test.log(Status.PASS,"Actual Intent status is: "+' '+actualMessage);
		test.log(Status.PASS,"Expected Intent status is: "+' '+expected);
	} else {
		test.log(Status.FAIL, "Intent status is not matched");
		test.log(Status.PASS,"Actual Intent status is: "+' '+actualMessage);
		test.log(Status.PASS,"Expected Intent status is: "+' '+expected);
		Assert.fail();
	}
} catch (Exception e) {
	e.printStackTrace();
	String excepionMessage = Arrays.toString(e.getStackTrace());
	BaseTest.log.error("Error on IntentStatus method " + excepionMessage);
	test.log(Status.FAIL, "Error on IntentStatus method " + e);
	throw e;
}
}

// HMHS User will move to My Work and Recent Work page

public void movetomyWorkLogout() {
try {
	waitSleep(3000);
	switchToFrame("PegaGadget0Ifr");
	webElementClick(myWorkIcon, "My Work");
	waitSleep(2000);
	switchToDefault();
	webElementClick(MenuDropdown, "Menu Dropdown");
	waitSleep(3500);
	webElementClick(LogOut, "Log Out");
	driver.switchTo().alert().accept();

} catch (Exception e) {
	e.printStackTrace();
	BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
	test.log(Status.FAIL, "Error on movetoRecentWorkPage method " + e);
	throw e;
}
}

public void CreateNewWork(Hashtable<String, String> data) {
try {
	waitSleep(3000);
	switchToFrame("PegaGadget1Ifr");
	webElementClick(CreateNewWork, "Create New Work");
	waitSleep(2000);
	selectDropdownValueByVisibleText(CreateNewWork,data.get("CreateNewWork"), "Method of Response as Mail");
	wait(1500);
} catch (Exception e) {
	e.printStackTrace();
	BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
	test.log(Status.FAIL, "Error on movetoRecentWorkPage method " + e);
	throw e;
}
}



@FindBy(xpath = "//button[@title='Other actions']")
public WebElement otherActions;

@FindBy(xpath = "//span[contains(text(),'Cancel Work')]")
public WebElement cancelWork;

@FindBy(name = "$PpyWorkPage$pWrapUpComments")
public WebElement comments;

public void cancelWorkFortesting(int row)
{
	String intentid=webElementReadText(driver.findElement(By.xpath("//*[@id='$PpgRepPgSubSectionpyUserWorkListBB$ppxResults$l"+row+"']/td[2]/div/span/a")), "Intent ");
	String member=webElementReadText(driver.findElement(By.xpath("//*[@id='$PpgRepPgSubSectionpyUserWorkListBB$ppxResults$l1']/td[8]")), "Member ");
	//System.out.println("Member: "+member);
	webElementClick(driver.findElement(By.xpath("//*[@id='$PpgRepPgSubSectionpyUserWorkListBB$ppxResults$l"+row+"']/td[2]/div/span/a")), "Intent ");
	switchToFrame("PegaGadget1Ifr");
	if(intentid.contains("FOL"))
	{
	selectDropdownValueByVisibleText(driver.findElement(By.name("$PpyWorkPage$pCallbackResolution")), 
			"Successful", "Attempt");
	waitSleep(2500);
	webElementSendText(driver.findElement(By.xpath("//label[text()='Comments']//following::textarea[1]")), "Test", "Comments");
	webElementClick(Submit, "Submit");
	}if(intentid.contains("LVI"))
	{
		if(!member.equals(""))
		{
			waitSleep(3500);
			webElementClick(driver.findElement(By.xpath("//i[contains(@name,'CPMInteractionDriver_D_Interaction') and @title='Wrap up']")), "Wrap Up");
			waitSleep(1500);
			webElementClick(driver.findElement(By.xpath("//div[contains(text(),'Submit')]//ancestor::button")), "Submit");
			waitSleep(1500);
		}else{
			webElementClick(otherActions, "Other Actions");
			waitSleep(1500);
			try{
				driver.findElement(By.xpath("//span[contains(text(),'Wrap Up, Member Not Found')]")).click();
				waitSleep(1500);
				selectDropdownValueByVisibleText(driver.findElement(By.name("$PpyWorkPage$pReasonForInteraction")), 
						"General Inquiry", "Attempt");
				waitSleep(1500);
			}
			catch(Exception e1)
			{
				driver.findElement(By.xpath("//span[contains(text(),'Wrap Up, Contact Not Verified')]")).click();
				waitSleep(1500);
			}
			
			webElementClick(Submit, "Submit");
		}
		
	}
	
	else{
		webElementClick(otherActions, "Other Actions");
		waitSleep(1500);
		webElementClick(cancelWork, "cancelWork");
		waitSleep(1000);
		webElementClick(Submit, "Submit");	
		waitSleep(3500);	
	}
}
public void contractInformation(Hashtable<String,String> data) 
{
	String Contractinformation ="";
	try{
		
		switchToFrame("PegaGadget1Ifr");
		List<String> headerRow= new ArrayList<String>();
        headerRow.add("Subscriber name");
        headerRow.add("Group number");
        headerRow.add("UMI");
        headerRow.add("Group name");
        


        ArrayList<String> rowData= new ArrayList<String>();
                                for(int j=0;j<headerRow.size();j++)
                                {if(headerRow.get(j).equals("UMI"))
                            	{
                            		rowData.add(driver.findElement(By.xpath("(//span[text()='"+headerRow.get(j)+"']//following::span/a)[1]")).getText());
                            	}else {
                            		rowData.add(driver.findElement(By.xpath("//span[contains(text(),'"+headerRow.get(j)+"')]/following::div[1]")).getText());	
                            	}
                                      if(j==0){
                                    	  Contractinformation=rowData.get(j);
                                      }else{
                                    	  Contractinformation=Contractinformation + "|" + rowData.get(j);
                                      }
                                }
                    
                          
                    
                    waitSleep(4000);
                    //rowData=AuthRows;
                    //AuthRows=AuthRows.substring(1,AuthRows.length());
                    //System.out.println(Contractinformation);
                    //System.out.println(data.get("Expected_details"));
                    assertEquals(data.get("Expected_details"), Contractinformation, "Contract information");
                  
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getIntentID method " + e);
		test.log(Status.FAIL, "Error on getIntentID method " + e);
		throw e;
	}
}
public void Servicerequestreview(String frame,Hashtable<String,String> data) {
	try {
		wait(2500);
		switchToFrame(frame);
		String Typeofinquiry = webElementReadText(typeofinquiry);
		assertEquals(data.get("TypeOfInq"), Typeofinquiry, "Type of inquiry");
        String Reason = webElementReadText(reason);
        assertEquals(data.get("Reason"), Reason, "Reason");
        String Resolution = webElementReadText(resolution);
        assertEquals(data.get("Resolution"), Resolution, "Resolution");
        


	} catch (Exception e) {
		e.printStackTrace();
		String excepionMessage = Arrays.toString(e.getStackTrace());
		BaseTest.log.error("Error on Servicerequestreview method " + excepionMessage);
		test.log(Status.FAIL, "Error on Servicerequestreview method " + e);
		throw e;
	}
}

public void WorklistWeb() {
	try{
		switchToFrame("PegaGadget1Ifr");
		waitSleep(3500);
		try{
			Select type= new Select(TypeofInq);
			type.selectByIndex(1);
			wait(1500);
			Select reason= new Select(Reason);
			reason.selectByValue("Issue with registration");
			wait(1500);
			Select resolution= new Select(Resolution);
			resolution.selectByValue("Completed registration");
			wait(1500);
		}catch(StaleElementReferenceException e1)
		{
			Select type= new Select(TypeofInq);
			type.selectByIndex(1);
			wait(1500);
			Select reason= new Select(Reason);
			reason.selectByValue("Issue with registration");
			wait(1500);
			Select resolution= new Select(Resolution);
			resolution.selectByValue("Completed registration");
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on WorklistWeb method " + e);
		test.log(Status.FAIL, "Error on WorklistWeb method " + e);
		throw e;
	}
}


public void Resolve(Hashtable<String, String> data) {
	String Message="";
	try {
		switchToFrame("PegaGadget1Ifr");
		wait(2500);
		webElementClick(Resolve, "Resolve the intant");
		wait(1500);
		webElementSendText(Comments, data.get("Comments"), "as Comments");
		wait(1500);
		Message= webElementReadText(message, "Message");
		 //System.out.println(Message);
		
		//assertEquals(data.get("ExpectedResolvedworkMessage"), Message, "Message");
		webElementClick(Submit, "Submit");
	} catch (Exception e) {
		e.printStackTrace();
		BaseTest.log.error("Error on Resolve." + e);
		test.log(Status.FAIL, "Error on Resolve." + e);
		throw e;
	}
}

public void interactionID(String intentID,String interactionID){
	try{
		String interactionIDxpath="//span[text()='%s']//following::a[(text()='%s') and contains(@name,'CPMGeneral')]";
		String interactionIDValue=String.format(interactionIDxpath, intentID,interactionID);
		//System.out.println(interactionIDValue);
		switchToFrame("PegaGadget1Ifr");
		String interaction=driver.findElement(By.xpath(interactionIDValue)).getText();
		//System.out.println(interaction);
		assertEquals(interactionID, interaction, "Interaction ID");
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on interactionID method " + e);
		test.log(Status.FAIL, "Error on interactionID method " + e);
		throw e;
	}
	
}


public void createNewFollowup(String intent)
{
	try{
		webElementClick(CeateNewWork, "CreateNewWork");
		if(intent.equals("Create Follow Up"))
		{
			driver.findElement(By.xpath("//a//span[contains(text(),'Create Follow-Up')]")).click();
		}else{
			webElementClick(CreateFollowUp, "Create Follow Up");	
		}
		
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on createNewFollowup method " + e);
		test.log(Status.FAIL, "Error on createNewFollowup method " + e);
		throw e;
	}
	
}

public void validateFollowuptask(String interactionID,String intentID)
{
	try{
		switchToFrame("PegaGadget2Ifr");
		String interactionIDxpath="//a[(text()='%s') and contains(@name,'CPMGeneral')]";
		String interactionValue=String.format(interactionIDxpath, interactionID);
		String interaction=driver.findElement(By.xpath(interactionValue)).getText();
		assertEquals(interactionID,interaction, "Interaction ID");
		String intent=intentID;
		driver.findElement(By.xpath("//h2[text()='Related tasks']//following::th[2]//following::a[1]")).click();
		driver.findElement(By.xpath("//label[text()='Search text']//following::input[1]")).sendKeys(intentID);
		driver.findElement(By.xpath("//button[contains(text(),'Apply')]")).click();
		waitSleep(2500);
		
		if(driver.findElement(By.xpath("//input[contains(@name,'$PpyWorkPage$pSelectRelatedIntent$l') and @type='checkbox']")).isSelected())
		{
			 intent=driver.findElement(By.xpath("//tr[contains(@id,'$PpyWorkPage$pSelectRelatedIntent$l')]/td[2]")).getText();
		}
		assertEquals(intentID, intent, intentID+" is selected automation in folowup intent");
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on validateFollowuptask method " + e);
		test.log(Status.FAIL, "Error on validateFollowuptask method " + e);
		throw e;
	}
	
}

public void createNewWork(String intent)
{
	try{
		webElementClick(CeateNewWork, "CreateNewWork");
		if(intent.equals("Create Follow Up"))
		{
			intent="Create Follow-Up";
		}
		webElementClick(driver.findElement(By.xpath(String.format("//a//span[contains(text(),'%s')]",intent))),
				"New intent");
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on closeChildIntent method " + e);
		test.log(Status.FAIL, "Error on closeChildIntent method " + e);
		throw e;
	}
	
}


public void validateInteractionID(String interactionID)
{
	try{
		switchToFrame("PegaGadget2Ifr");
		String interactionIDxpath="//a[(text()='%s') and contains(@name,'CPMGeneral')]";
		String interactionValue=String.format(interactionIDxpath, interactionID);
		String interaction=driver.findElement(By.xpath(interactionValue)).getText();
		assertEquals(interactionID,interaction, "Interaction ID");
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on validateInteractionID method " + e);
		test.log(Status.FAIL, "Error on validateInteractionID method " + e);
		throw e;
	}
	
}

public String getChildintentid()
{
	String intentid="";
	try{
		switchToFrame("PegaGadget2Ifr");
		intentid= driver.findElement(By.xpath("//span[@class='heading_3']")).getText();
		test.log(Status.INFO,"intentid");
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getChildintentid method " + e);
		test.log(Status.FAIL, "Error on closeChildIntent method " + e);
		throw e;
	}
	
	return intentid;
}

public void getChildHistory()
{
	try{
		driver.findElement(By.xpath("//label[@class='actionTitleBarLabelStyle']//following::i[3]")).click();
		String mainWindowHandle=driver.getWindowHandle();
		driver.findElement(By.xpath("//a//span[text()='View History']")).click();
		Set<String> allWindowHandles = driver.getWindowHandles();
	    Iterator<String> iterator = allWindowHandles.iterator();
	    String childHistory="";
	    // Here we will check if child window has other child windows and will fetch the heading of the child window
	    while (iterator.hasNext()) {
	        String ChildWindow = iterator.next();
	            if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
	            driver.switchTo().window(ChildWindow);
	            driver.switchTo().activeElement();
	            childHistory= driver.findElement(By.xpath("//span[contains(text(),'Created from')]")).getText();
	            driver.close();
	        }
	    }
		driver.switchTo().window(mainWindowHandle);
		//System.out.println("Audit History:"+childHistory);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getChildHistory method " + e);
		test.log(Status.FAIL, "Error on getChildHistory method " + e);
		throw e;
	}
	
}

public void getParentHistory()
{
	try{
		switchToFrame("PegaGadget1Ifr");
		driver.findElement(By.xpath("//label[@class='actionTitleBarLabelStyle']//following::i[3]")).click();
		String mainWindowHandle=driver.getWindowHandle();
		driver.findElement(By.xpath("//a//span[text()='View History']")).click();
		Set<String> allWindowHandles = driver.getWindowHandles();
	    Iterator<String> iterator = allWindowHandles.iterator();
	    String childHistory="";
	    // Here we will check if child window has other child windows and will fetch the heading of the child window
	    while (iterator.hasNext()) {
	        String ChildWindow = iterator.next();
	            if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
	            driver.switchTo().window(ChildWindow);
	            driver.switchTo().activeElement();
	            childHistory= driver.findElement(By.xpath("//span[contains(text(),'New Intent')]")).getText();
	            driver.close();
	        }
	    }
		driver.switchTo().window(mainWindowHandle);
		//System.out.println("Audit History:"+childHistory);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getParentHistory method " + e);
		test.log(Status.FAIL, "Error on getParentHistory method " + e);
		throw e;
	}
	switchToFrame("PegaGadget1Ifr");
	
}

public void closeChildIntent(String childIntent)
{
	try{
		driver.switchTo().defaultContent();
		//System.out.println(String.format("//a[contains(text(),'%s')]//following::span[contains(@title,'Close Tab')]", childIntent));
		try{
			driver.findElement(By.xpath(String.format("//a[contains(text(),'%s')]//following::span[contains(@title,'Close Tab')]", childIntent))).click();
		}catch(Exception e1)
		{
			driver.findElement(By.xpath(String.format("//span[contains(text(),'%s')]//following::span[contains(@title,'Close Tab')]", childIntent))).click();
		}	
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on closeChildIntent method " + e);
		test.log(Status.FAIL, "Error on closeChildIntent method " + e);
		throw e;
	}
	
}

public void contractInformation(Hashtable<String,String> data, String frame) 
{
	String Contractinformation ="";
	try{
		
		switchToFrame(frame);
		List<String> headerRow= new ArrayList<String>();
        headerRow.add("Subscriber name");
        headerRow.add("Group number");
        headerRow.add("UMI");
        headerRow.add("Group name");
        


        ArrayList<String> rowData= new ArrayList<String>();
                                for(int j=0;j<headerRow.size();j++)
                                {											
                                	if(headerRow.get(j).equals("UMI"))
                                	{
                                		rowData.add(driver.findElement(By.xpath("(//span[text()='"+headerRow.get(j)+"']//following::span/a)[1]")).getText());
                                	}else {
                                		rowData.add(driver.findElement(By.xpath("//span[contains(text(),'"+headerRow.get(j)+"')]/following::div[1]")).getText());	
                                	}
                                
                                      if(j==0){
                                    	  Contractinformation=rowData.get(j);
                                      }else{
                                    	  Contractinformation=Contractinformation + "|" + rowData.get(j);
                                      }
                                }
                    
                          
                    
                    waitSleep(4000);
                   assertEquals(data.get("Expected_details"), Contractinformation, "Contract information");
                  
	}
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getIntentID method " + e);
		test.log(Status.FAIL, "Error on getIntentID method " + e);
		throw e;
	}
}
public void saveToWorklist212(Hashtable<String, String> data)
	{
		try{
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			//System.out.println("Save to worklist");
			selectDropdownValueByVisibleText(ReasonToPend, data.get("ReasonToPend"), "to select Reason to Pend");
			wait(1500);
			webElementSendText(Comments, data.get("comments"), "as Comments");
			wait(1500);
			webElementClick(Submit, "Submit");
			wait(1500);
		}	
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on getIntentID method " + e);
			test.log(Status.FAIL, "Error on getIntentID method " + e);
			throw e;
		}
	}
public void Inforeceivedate(Hashtable<String, String> data)
{
	try{
		switchToFrame("PegaGadget1Ifr");
		waitSleep(3000);
		String MessageDisclosure=messageDisclosure.getAttribute("title").toString();
		//System.out.println(MessageDisclosure);
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		//System.out.println(dateFormat.format(date));
		webElementSendText(Inforeceivedate, dateFormat.format(date), "Inforeceivedate");
		wait(2500);
		webElementClick(Submit, "Submit");
		wait(1500);
	}	
	catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on getIntentID method " + e);
		test.log(Status.FAIL, "Error on getIntentID method " + e);
		throw e;
	}
}
public void Inforeceivedatedisable()
{
	try{
		waitSleep(6500);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Inforeceivedate);
		waitSleep(2500);
		if(Inforeceivedate.isSelected())
		{
			test.log(Status.INFO, "Adjustment needed is selected ");
		}
		else
		{
			test.log(Status.INFO, "Adjustment needed is not selected ");	
		}
		waitSleep(3500);
	}catch(Exception e)
	{
		e.printStackTrace();
		BaseTest.log.error("Error on Inforeceivedatedisable method " + e);
		test.log(Status.FAIL, "Error on Inforeceivedatedisable method " + e);
		throw e;
	}
}
	public void RespondToCustomerIntentFax1 (String memberSearchFname, Hashtable<String, String> data){
		try {
			switchToFrame("PegaGadget1Ifr");
			waitSleep(3000);
			//waitForElementsToVisible("//label[contains(text(),'Correspondence')]");
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Correspondence); ;
			webElementClick(Correspondence, "Select Correspondence");
			wait(1500);
			webElementClick(Submit, "Submit");
			wait(1500);
			/*selectDropdownValueByVisibleText(Method, data.get("MethodFax"), "Method of Response as Fax");
			wait(1500);
			
			webElementClick(LetterLink, "Able to click on Client Letter Link");
			wait(1500);
			
			String actualTitle = driver.getTitle();
			String expectedTitle = "CPMHC Interaction Portal";
			assertEquals(expectedTitle,actualTitle,memberSearchFname);
			
			webElementClick(BISCOM, "Able to click on BISCOM Link");
			wait(1500);
			
			String actualTitle1 = driver.getTitle();
			String expectedTitle1 = "CPMHC Interaction Portal";
			assertEquals(expectedTitle1,actualTitle1,memberSearchFname);
			
			webElementSendText(ClientIDFax, data.get("ClientID"), "Client Letter ID");
			wait(1500);
			webElementSendText(FaxMsg, data.get("FaxMsg"), "Client Letter ID");
			wait(1500);
			webElementSendText(Faxcomment, data.get("Comment"), "Enter Comment");
			wait(1500);
			webElementClick(Submit, "to submit the comments");*/
		} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on Respond To Customer Intent Fax method " + excepionMessage);
			test.log(Status.FAIL, "Error on Respond To Customer Intent Fax method " + e);
			throw e;
		}
}
	public void CallbackAttempt1( String intentID, Hashtable<String, String> data) {
		try {
			switchToFrame("PegaGadget1Ifr");
			try{
				VerifyDOB.click();
			}
			
			catch(Exception e1)
			{
			
			}
			//webElementClick(VerifyDOB, "Verify DOB");
		
			wait(1000);
			selectDropdownValueByVisibleText(attempt, data.get("Resolution"), "to select reason of callback");
			wait(1500);
			Calendar calendar = Calendar.getInstance();
		    calendar.add(Calendar.DAY_OF_YEAR, 1);
		    Date tomorrowDate = calendar.getTime();
		    SimpleDateFormat formatter= new SimpleDateFormat("MM/dd/yyyy");
		    String tomorrowFormatted=formatter.format(tomorrowDate);
		    driver.findElement(By.xpath("//input[@name='$PpyWorkPage$ppyNotes$l1$pInfoReceivedDate']")).sendKeys(tomorrowFormatted);
			wait(1500);
			try{
				wait(1000);
				webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
				}
				catch(StaleElementReferenceException e){
					wait(1000);
					webElementSendText(AttemptComments, data.get("callbackcomments"), "as Comments");
				}
			wait(1500);
			webElementClick(Submit, "Submit");
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on CallbackAttempt method " + e);
			test.log(Status.FAIL, "Error on CallbackAttempt method " + e);
			throw e;
		}
	}
}
