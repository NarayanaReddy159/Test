package com.nasco.HMHS.Pages;

import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Setup.BasePage;

@SuppressWarnings({"rawtypes","unchecked"})
public class ManagerToolsPage extends BasePage {
	
	@FindBy(id = "PegaGadget0Ifr")
	public WebElement frame;
	@FindBy(xpath = "//div[1]/div/div/div/ul/li[2]/a/span[1]/span")
	public WebElement myWorkIcon;
//	@FindBy(xpath = "//span[contains(text(),'Home')]")
//	public WebElement Home;

	@FindBy(how = How.NAME, using  = "$PCleanupPage$ppyUserName")
	public WebElement Operator;
	@FindBy(how = How.XPATH, using  = "//span[contains(text(),'vid9272')]")
	public WebElement OperatorName;
	
	@FindBy(how = How.NAME, using  = "$PCleanupPage$pWorkType")
	public WebElement WorkType;
	@FindBy(how = How.XPATH, using  = "	//span[contains(text(),'Home')]")
	public WebElement Home;
	
	@FindBy(xpath = "//span[contains(text(),'Manager Tools')]")
	public WebElement managerTools;
    
	@FindBy(xpath = "//li[4]/a[1]/span[1]/span[1]")
	public WebElement managerToolsIcon;
	
	@FindBy(xpath="//button[contains(text(),'Cleanup utility')]")
	public WebElement cleanUp;
	
	@FindBy(xpath="//button[contains(text(),'Search')]")
	public WebElement Search;
	@FindBy(xpath="//div[contains(text(),'Created')]")
	public WebElement Created;
	
	@FindBy(xpath="//button[contains(text(),'Submit')]")
	public WebElement submitBtn;
	@FindBy(xpath="//tbody/tr[@id='$PFinalResults$ppxResults$l1']/td[6]")
	public WebElement Statusofresult;
	@FindBy(xpath="//button[contains(text(),'Close')]")
	public WebElement Close;
	@FindBy(how = How.NAME, using  = "$PCleanupPage$pSearchby")
	public WebElement SearchBy;
	@FindBy(how = How.NAME, using  = "$PCleanupPage$pInteractionID")
	public WebElement Id;
	@FindBy(xpath = "(//*[@id='pui_filter'])[1]")
	public WebElement idSort;
	@FindBy(xpath = "//span/div/div/div/div/div/div/div/span/input")
	public WebElement searchID;
	@FindBy(xpath = "//button[contains(text(),'Apply')]")
	public WebElement applyBtn;
	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		switchToFrame("PegaGadget0Ifr");
		return ExpectedConditions.visibilityOf(myWorkIcon);
	}
	
	public void movetoManageTools() {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget0Ifr");
			waitSleep(1500);
		//	webElementClick(Home, "Home");
		//	waitSleep(500);
			
			webElementClick(managerToolsIcon, "managerTools tab");
			webElementClick(Search, "managerTools tab");
		} catch (Exception e) {
			BaseTest.log.error("Error on movetoManageTools method " + e);
			test.log(Status.FAIL, "Error on movetoManageTools method " + e);
			throw e;
		}
	}
	public void cleanUpUtility() {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget0Ifr");
			waitSleep(1500);
			webElementClick(cleanUp, "Click on CleanUp Utility");
		
		} catch (Exception e) {
			BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
			test.log(Status.FAIL, "Error on movetoRecentWorkPage method " + e);
			throw e;
		}
	}
	public void Search_Worktype(String Worktype,String Operatorid ) {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
	        selectDropdownValueByVisibleText(WorkType,Worktype, "Work Type");
			waitSleep(1500);
			webElementSendText(Operator,Operatorid , "enter the Operator ID");
			wait(1500);
			Operator.sendKeys(Keys.TAB);
			wait(1500);
			webElementClick(Search, "Click on Search button");
		} catch (Exception e) {
			BaseTest.log.error("Error on Search_Worktype method " + e);
			test.log(Status.FAIL, "Error on Search_Worktype method " + e);
			throw e;
		}
	}
	
	public void Search_Worktype1(String Operatorid ) {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
			webElementSendText(Operator,Operatorid , "enter the Operator ID");
			wait(1500);
			webElementClick(OperatorName, "Select the Operator");
			wait(1500);
			Operator.sendKeys(Keys.TAB);
			wait(1500);
			
			webElementClick(Search, "Click on Search button");
			wait(1500);
			webElementClick(Created, "Search Button");
			wait(1500);
			webElementClick(Created, "Search Button");
			/*Actions actions = new Actions(driver);
			WebElement elementLocator = driver.findElement(By.xpath("//div[contains(text(),'Created')]"));
			actions.doubleClick(elementLocator).perform();*/
			
		} catch (Exception e) {
			BaseTest.log.error("Error on Search_Worktype1 method " + e);
			test.log(Status.FAIL, "Error on Search_Worktype1 method " + e);
			throw e;
		}
	}
	public void sortandSelectIntent( String intentID) {
		try {
			switchToFrame("PegaGadget1Ifr");
			waitForPageToLoad(ExpectedConditions.elementToBeClickable(idSort));
			webElementClick(idSort, "ID Sort");
			try{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
				webElementSendText(searchID, intentID, "Search Intent");
				}catch(StaleElementReferenceException e){
					waitForPageToLoad(ExpectedConditions.elementToBeClickable(searchID));
					webElementSendText(searchID, intentID, "Search Intent");
				}
			waitSleep(1500);
			try{
				waitForPageToLoad(ExpectedConditions.elementToBeClickable(applyBtn));
				webElementClick(applyBtn, "Apply");
				}catch(StaleElementReferenceException e){
					webElementClick(applyBtn, "Apply");
				}
			waitSleep(1500);
//			try{
//				waitForPageToLoad(ExpectedConditions.elementToBeClickable(intentclick));
//				webElementClick(intentclick, "Intent " + intentID);
//				}catch(StaleElementReferenceException e){
//					webElementClick(intentclick, "Intent " + intentID);
//				}
			waitSleep(2500);
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on sortandSelectIntent method " + e);
			test.log(Status.FAIL, "Error on sortandSelectIntent method " + e);
			throw e;
		}
	}
	
	public void selectTask(String Workid){
		try{
			List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PSelectedResults$ppxResults$l')]"));
			if(tableRows.size()>0)
			{
				for(int i=1;i<=tableRows.size();i++)
				{
					if(driver.findElement(By.xpath("//tr[contains(@id,'$PSelectedResults$ppxResults$l')]/td[2]")).getText().equals(Workid))
					{
						WebElement Select=driver.findElement(By.xpath("//tr[contains(@id,'$PSelectedResults$ppxResults$l')]/td[1]//input[@type='checkbox']"));
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", Select);
						jsClick(Select,"Select");
						waitSleep(3500);
						webElementClick(submitBtn, "Submit");
						waitSleep(3500);
						break;
					}
				}
			}
			waitSleep(7500);
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectTask method " + e);
			test.log(Status.FAIL, "Error on selectTask method " + e);
			throw e;
		}
	}
	public void statusOfResult( String IntStatus, String frame) {
		try {
			wait(2500);
			switchToFrame(frame);
			String Status = webElementReadText(Statusofresult);
			//System.out.println(Status);
			assertEquals(Status, Status, "Page Title");	
			webElementClick(Close, "Close");
			} catch (Exception e) {
			e.printStackTrace();
			String excepionMessage = Arrays.toString(e.getStackTrace());
			BaseTest.log.error("Error on IntentStatus method " + excepionMessage);
			test.log(Status.FAIL, "Error on IntentStatus method " + e);
			throw e;
		}
	}
	public void SearchresultsHeader(Hashtable<String, String> data)
	{
		String SearchresultsHeader="";
		
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);

			List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Search results') and contains(@id,'headerlabel')]//following::table[2]//th")); 
			//System.out.println(hr.size());
			
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[contains(text(),'Search results') and contains(@id,'headerlabel')]//following::table[2]//th"));
				//System.out.println(hr.size());
			}
			
			String h = "//h2[contains(text(),'Search results') and contains(@id,'headerlabel')]//following::table[2]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						SearchresultsHeader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						SearchresultsHeader = SearchresultsHeader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			//System.out.println(SearchresultsHeader);
			

            assertEquals(data.get("ExpectedSearchresultsHeader"), SearchresultsHeader, "SearchresultsHeader");
            
			
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on SearchresultsHeader method " + e);
			test.log(Status.FAIL, "Error on SearchresultsHeader method " + e);
			throw e;
		}
	}
	public void Statusforopen(String Workid,String Expectedstatus){
		String status="";
		try{
			List<WebElement> tableRows=driver.findElements(By.xpath("//tr[contains(@id,'$PSelectedResults$ppxResults$l')]"));
			if(tableRows.size()>0)
			{
				for(int i=1;i<=tableRows.size();i++)
				{
					if(driver.findElement(By.xpath("//tr[contains(@id,'$PSelectedResults$ppxResults$l')]/td[2]")).getText().equals(Workid))
					{
						WebElement StatusEle=driver.findElement(By.xpath("//tr[contains(@id,'$PSelectedResults$ppxResults$l')]/td[6]"));
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", StatusEle);
						 status=webElementReadText(StatusEle, "Status");
						waitSleep(3500);
						WebElement checkbox=driver.findElement(By.xpath("//tr[contains(@id,'$PSelectedResults$ppxResults$l')]/td[2]"));
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", checkbox);
						waitSleep(2500);
						try{
							waitSleep(2000);
						if(checkbox.isEnabled())
						{
							test.log(Status.INFO, "checkbox  isEnabled ");
						}
						}
						   catch(Exception e1)
							{

								test.log(Status.INFO, "checkbox is  not isEnabled ");	
							
							waitSleep(3500);
							}
						waitSleep(3500);

						webElementClick(Close, "Close");
						waitSleep(3500);
						break;
					}
				}
			}
			 assertEquals(Expectedstatus, status, "status");
		}catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on selectClaim method " + e);
			test.log(Status.FAIL, "Error on selectClaim method " + e);
			throw e;
		}
	}
	public void resultsHeader(Hashtable<String, String> data)
	{
		String resultsHeader="";
		
		
		try{
			
			waitSleep(2000);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1000);

			List<WebElement> hr = driver.findElements(By.xpath("//h2[contains(text(),'Results') and contains(@id,'headerlabel')]//following::table[2]//th")); 
			//System.out.println(hr.size());
			
			if(hr.size()==0)
			{
				waitSleep(15000);
				hr = driver
						.findElements(By.xpath("//h2[contains(text(),'Results') and contains(@id,'headerlabel')]//following::table[2]//th"));
				//System.out.println(hr.size());
			}
			
			String h = "//h2[contains(text(),'Results') and contains(@id,'headerlabel')]//following::table[2]//th";				
				List<WebElement> colums = driver.findElements(By.xpath(h));
				for (int j = 0; j < colums.size(); j++) {
					if (j ==0) {
						resultsHeader = driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
					} else {
						resultsHeader = resultsHeader + "|" + driver.findElement(By.xpath(h + "[" + (j + 1) + "]")).getText();
						
						
					}
				}
			//System.out.println(resultsHeader);
			

            assertEquals(data.get("ExpectedresultsHeader"), resultsHeader, "SearchresultsHeader");
            
			
           }
 
		
		catch(Exception e)
		{
			e.printStackTrace();
			BaseTest.log.error("Error on SearchresultsHeader method " + e);
			test.log(Status.FAIL, "Error on SearchresultsHeader method " + e);
			throw e;
		}
	}
	public void SearchBy(String searchBy,String ID ) {
		try {
			waitSleep(1500);
			switchToFrame("PegaGadget1Ifr");
			waitSleep(1500);
	        selectDropdownValueByVisibleText(SearchBy,searchBy, "Work Item");
			waitSleep(1500);
			webElementSendText(Id,ID, "enter the  ID");
			wait(1500);
			webElementClick(Search, "Click on Search button");
		} catch (Exception e) {
			BaseTest.log.error("Error on movetoRecentWorkPage method " + e);
			test.log(Status.FAIL, "Error on movetoRecentWorkPage method " + e);
			throw e;
		}
	}

}	


