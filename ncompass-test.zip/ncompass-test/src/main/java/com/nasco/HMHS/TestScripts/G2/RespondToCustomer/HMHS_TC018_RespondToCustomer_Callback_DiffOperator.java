package com.nasco.HMHS.TestScripts.G2.RespondToCustomer;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.OtherActions;
import com.nasco.HMHS.Pages.RecentWorkPage;
import com.nasco.HMHS.Pages.RespondToCustomerPage;
import com.nasco.HMHS.Pages.WorklistPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC018_RespondToCustomer_Callback_DiffOperator extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC018_RespondToCustomer_Callback_DiffOperator (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC018_RespondToCustomer_Callback_DiffOperator");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC018_RespondToCustomer_Callback_DiffOperator - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		
		log.debug("HMHS_TC018_RespondToCustomer_Callback_DiffOperator -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed.");
		test.log(Status.INFO,"Member Search Completed.");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		test.log(Status.INFO,data.get("Fname") + " Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO,"Member Submit Completed.");
		
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Member Verified successfully.");
        test.log(Status.INFO,"Member Verified successfully.");
        InteractionManager.openTask();
        InteractionManager.addTask(data.get("Intent").toString());
        log.debug("Add Intent "+data.get("Intent"));
        test.log(Status.INFO,"Add Intent "+data.get("Intent"));

        String intentID = searchMember.getIntentID();
		log.debug("Intent id: " + intentID);
		test.log(Status.INFO,"Intent id: " + intentID);
		RespondToCustomerPage RTC = homepage.RespondToCustomerIntentCallback();
        RTC.RespondToCustomerIntentCallbackDiffOpr( intentID,data, data.get("NextMsg"));
		log.debug("Navigate to Respond to Customer intent screen to add task against Message Center method.");
		test.log(Status.INFO,"Navigate to Respond to Customer intent screen to add task against Message Center method.");
		
		OtherActions otheraction= homepage.openOtherActions();
		otheraction.saveToWorklist212(data);
		log.debug("Navigate to save To Worklist screen");
		test.log(Status.INFO,"Navigate to save To Worklist screen.");
		
		InteractionManagerPage wrap = searchMember.wrapIntent();
	    wrap.wrapUp(data.get("Comments"));
		log.debug("Wrapping up the intent");
		test.log(Status.INFO, "Wrapping up the intent.");
		
		RecentWorkPage recentWork = homepage.openrecentWork();
		recentWork.movetomyWorkLogout();
		log.debug("Logout from the screen.");
		test.log(Status.INFO,"Logout from the screen.");
		DriverManager.getDriver().close();
		DriverManager.getDriver();
		setUpFramework();
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		LoginPage login2 = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage1 = login2.doLoginAsValidUser(RunTestNG_NCompass_HMHS.Config.getProperty("username2"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password2")); 
		log.debug("Login again by using 2nd operator.");
		test.log(Status.INFO,"Login again by using 2nd operator.");
		
		WorklistPage worklist = homepage1.openrecentWorklist();
		worklist.movetoWorklistPage();
		log.debug("Navigated to the Worklist page.");
		test.log(Status.INFO,"Navigated to the Worklist page.");
		
		worklist.sortandSelectIntent(data, intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from Worklist tab.");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected intent " + intentID + " from recent work tab.");
		
		worklist.IntentStatusWorklist(data.get("IntentStatusWork"), "PegaGadget1Ifr");
		log.debug("Check the intent status.");
		test.log(Status.INFO,"Check the intent status.");
		worklist.CallbackAttemptDiff1( intentID, data);
		log.debug("Successfully able to perform Callback attempt.");
		test.log(Status.INFO,"Successfully able to perform Callback attempt.");
		
		RecentWorkPage recentWork1 = homepage.openrecentWork();
		recentWork1.movetomyWorkLogout();
		log.debug("Logout from the screen.");
		test.log(Status.INFO,"Logout from the screen.");
		DriverManager.getDriver().close();
		DriverManager.getDriver();
		setUpFramework();
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		LoginPage login3 = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		login3.doLoginAsValidUser( getDefaultUserName(),getDefaultPassword());
		log.debug("Login again by using 1st operator.");
		test.log(Status.INFO,"Login again by using 1st operator.");
		
		RecentWorkPage recentWork2 = homepage.openrecentWork();
		recentWork2.movetoRecentWorkPage();
		log.debug("Navigated to the Home-Recentwork Section.");
		test.log(Status.INFO,"Navigated to the Home-Recentwork Section.");
		recentWork2.sortandSelectIntent( intentID);
		//System.out.println("Sorted and selected intent " + intentID + " from recent work tab ");
		log.debug("Sorted and selected intent " + intentID + " from recent work tab.");
		test.log(Status.INFO,"Sorted and selected intent " + intentID + " from recent work tab.");
		recentWork2.IntentStatus( data.get("IntentStatus"), "PegaGadget1Ifr");
		log.debug("Check the intent status.");
		test.log(Status.INFO,"Check the intent status.");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}

	@AfterMethod
	public void tearDown() throws Exception  {
		test.log(Status.INFO, "HMHS_TC018_RespondToCustomer_Callback_DiffOperator completed.");
		log.debug("HMHS_TC018_RespondToCustomer_Callback_DiffOperator completed.");
		quit();

	}
}
