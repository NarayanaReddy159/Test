package com.nasco.HMHS.ExtentListeners;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Run.RunFailed_NCompass_HMHS;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DriverManager;
import com.nasco.HMHS.utilities.EmailHTMLBuilder;
import com.nasco.HMHS.utilities.EmailHTMLBuilder_Body;
import com.nasco.HMHS.utilities.EmailUtil;
import com.nasco.HMHS.utilities.ExcelReader;
import com.nasco.HMHS.utilities.FileUtil;

public class ExtentListeners implements ITestListener {

	static Date d = new Date();
	static String fileName = "Extent_" + d.toString().replace(":", "_").replace(" ", "_") + ".html";
	Set<String> failedTc = new LinkedHashSet<String>();
	Map<String, List<String>> results = new HashMap<String, List<String>>();
	String status = "";
	String reportFileName = "HMHS_NCompass_Automation_Execution_Report.xlsx";
	String reportFilePath = System.getProperty("user.dir") + RunTestNG_NCompass_HMHS.Config.getProperty("ReportFile")
			+ reportFileName;
	String extentFilepath = System.getProperty("user.dir")
			+ RunTestNG_NCompass_HMHS.Config.getProperty("EXTREPORT_LOC");
	public String timeStamp = new SimpleDateFormat("MM-dd-yyyy").format(Calendar.getInstance().getTime());
	public String timeStamp_email = timeStamp;
	EmailHTMLBuilder htmlbuilder_Summary = new EmailHTMLBuilder();
	EmailHTMLBuilder_Body htmlbuilder = new EmailHTMLBuilder_Body();
	DecimalFormat df = new DecimalFormat("###.##");
	static ExcelReader excel = null;
	String path1 = reportFileName.replace(".xlsx", "") + d.toString().replace(":", "_").replace(" ", "_") + ".xlsx";
	String reportFilePath1 = System.getProperty("user.dir") + RunTestNG_NCompass_HMHS.Config.getProperty("ReportFile")
			+ path1;
	String defectsListFile = System.getProperty("user.dir")
			+ RunTestNG_NCompass_HMHS.Config.getProperty("DEFECTSLISTFILE_LOC");

	public static ExtentReports extent = ExtentManager.getInstance();
	public static ExtentReports extent1 = ExtentManager.getFailureInstance();
	public static ThreadLocal<ExtentTest> testReport = new ThreadLocal<ExtentTest>();
	public static ThreadLocal<ExtentTest> testReport1 = new ThreadLocal<ExtentTest>();

	long diff = 0;
	long diffMinutes = 0;
	long diffSeconds = 0;
	long diffHours = 0;

	String starttime = "";
	String endTime = "";
	List<ExtentTest> testList = new ArrayList<>();

	public void onTestStart(ITestResult result) {
		ExtentTest test;
		if (RunTestNG_NCompass_HMHS.runCount > 0) {
			test = extent1.createTest("TestCase : " + result.getMethod().getMethodName());
			DriverManager.setExtentReport(test);
			testReport1.set(DriverManager.getExtentReport());
		} else {
			try {
				File f = new File(defectsListFile);
				f.delete();

			} catch (Exception e) {

			}
			test = extent.createTest("TestCase : " + result.getMethod().getMethodName());
			DriverManager.setExtentReport(test);
			testReport.set(DriverManager.getExtentReport());
			testList.add(test);
		}
	}

	public void onTestSuccess(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		if (RunTestNG_NCompass_HMHS.runCount > 0) {
			testReport1.get().log(Status.PASS, methodName + " Test Case Passed");
			passedTCsCounts(result);
			resultStatus(result, methodName, "Pass");

		} else {
			testReport.get().log(Status.PASS, methodName + " Test Case Passed");
			passedTCsCounts(result);
			resultStatus(result, methodName, "Pass");
		}

		RunTestNG_NCompass_HMHS.pass++;
		System.out.println("Pass: " + RunTestNG_NCompass_HMHS.pass + " Fail: " + RunTestNG_NCompass_HMHS.fail);
	}

	public void onTestFailure(ITestResult result) {
		RunTestNG_NCompass_HMHS.fail++;
		System.out.println("Pass: "+RunTestNG_NCompass_HMHS.pass+" Fail: "+RunTestNG_NCompass_HMHS.fail);
		String excepionMessage = Arrays.toString(result.getThrowable().getStackTrace());
		String methodName = result.getMethod().getMethodName();
		System.out.println(methodName);
		if(RunTestNG_NCompass_HMHS.runCount>0)
		{
			if (!excepionMessage.isEmpty())
				testReport1.get().log(Status.FAIL, excepionMessage);
			
			try {
				ExtentManager.captureScreenshot(methodName);
				testReport1.get().addScreenCaptureFromPath(ExtentManager.screenshotName).fail("<b><font color=red> Screen shot of failure</font></b>",MediaEntityBuilder.createScreenCaptureFromPath(ExtentManager.screenshotName).build());
				} catch (Exception e) {
				e.printStackTrace();
			}
			testReport1.get().log(Status.FAIL, methodName + " Test Case Failed");
			failedTCsCounts(result);
			resultStatus(result, methodName, "Fail");
			RunTestNG_NCompass_HMHS.failedMethods.add(methodName);
		}
		else{
			if (!excepionMessage.isEmpty())
				testReport.get().log(Status.FAIL, excepionMessage);
			if(!ExceptionUtils.getStackTrace(result.getThrowable()).contains("AssertionError")
					&&RunTestNG_NCompass_HMHS.Config.getProperty("Rerun").toString().equalsIgnoreCase("Y"))
				{
				System.out.println(ExceptionUtils.getStackTrace(result.getThrowable()));
				for(int i=0;i<testList.size();i++)
				{
					if(testList.get(i).getModel().getName().contains(methodName) &&testList.get(i).getStatus().toString().equalsIgnoreCase("Fail"))
					{
						extent.removeTest(testList.get(i));
						failedTc.add(result.getTestClass().getName());
					}
				}
			}
			else{
				try {
					ExtentManager.captureScreenshot(methodName);
					testReport.get().addScreenCaptureFromPath(
							ExtentManager.screenshotName).fail("<b><font color=red> Screen shot of failure</font></b>",
							MediaEntityBuilder.createScreenCaptureFromPath(ExtentManager.screenshotName).build());
					/*
					 * String base64Screenshot =
					 * "data:image/png;base64,"+((TakesScreenshot)DriverManager.
					 * getDriver()). getScreenshotAs(OutputType.BASE64);
					 * 
					 * //Extentreports log and screenshot operations for failed tests.
					 * testReport.get().log(Status.FAIL,"Test Failed Screenshot",
					 * testReport.get().addBase64ScreenShot(base64Screenshot));
					 */
					/*for(int i=0;i<testList.size();i++)
					{
						if(testList.get(i).getModel().getName().contains(methodName) &&testList.get(i).getStatus().toString().equalsIgnoreCase("Fail"))
						{
							testList.get(i).fail("<b><font color=red> Screen shot of failure</font></b>",MediaEntityBuilder.createScreenCaptureFromPath(ExtentManager.screenshotName).build());
						}
					}
					testReport.get().log(Status.FAIL,
							ExtentManager.screenshotName + testReport.get().addScreenCaptureFromPath(ExtentManager.screenshotName));
				*/} catch (Exception e) {
					e.printStackTrace();
				}
				
				testReport.get().log(Status.FAIL, methodName + " Test Case Failed");
				failedTCsCounts(result);
				resultStatus(result, methodName, "Fail");
				RunTestNG_NCompass_HMHS.failedMethods.add(methodName);
			}
			
			
			
	}
		
		
		
	}

	public void onTestSkipped(ITestResult result) {
		String methodName = result.getMethod().getMethodName();
		if (RunTestNG_NCompass_HMHS.runCount > 0) {
			testReport1.get().log(Status.SKIP, methodName + " Test Case Skipped");

		} else {
			testReport.get().log(Status.SKIP, methodName + " Test Case Skipped");

		}

	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	public void onStart(ITestContext context) {
		if (RunTestNG_NCompass_HMHS.runCount > 0) {
			// extent1.setSystemInfo("Environment",
			// RunTestNG_NCompass_HMHS.Config.getProperty("Environment"));

		} else {
			extent.setSystemInfo("User Name", System.getProperty("user.name").toUpperCase());
			extent.setSystemInfo("OS", System.getProperty("java.version"));
			extent.setSystemInfo("Java Version", System.getProperty("os.name"));
			try {
				extent.setSystemInfo("Host Name", InetAddress.getLocalHost().getHostName());
			} catch (UnknownHostException e) {
			}
			extent.setSystemInfo("Environment", RunTestNG_NCompass_HMHS.Config.getProperty("Environment"));
			extent.setSystemInfo("Browser", RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toUpperCase());
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date date = new Date();
			starttime = formatter.format(date);
		}
	}

	@SuppressWarnings("unused")
	public void onFinish(ITestContext context) {

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("MMM");
		SimpleDateFormat dateFormat2 = new SimpleDateFormat("YYYY");
		SimpleDateFormat dateFormat3 = new SimpleDateFormat("MM");
		Date date = new Date();
		String reportsPath = RunTestNG_NCompass_HMHS.Config.getProperty("Reports_Loc") + dateFormat2.format(date) + "/"
				+ dateFormat3.format(date) + "-" + dateFormat1.format(date).toUpperCase() + "/"
				+ dateFormat.format(date);
		endTime = formatter.format(date);
		Date startDate = null;
		Date endDate = null;
		try {
			startDate = formatter.parse(starttime);
			endDate = formatter.parse(endTime);

		} catch (ParseException e) {

		}
		try {
			diff = endDate.getTime() - startDate.getTime();
			diffSeconds = diff / 1000 % 60;
			diffMinutes = diff / (60 * 1000) % 60;
			diffHours = diff / (60 * 60 * 1000);
		} catch (Exception e) {

		}

		if (RunTestNG_NCompass_HMHS.runCount > 0) {

			Object[][] arrayCounts = RunFailed_NCompass_HMHS.getCountsObj();
			if (extent1 != null) {
				RunTestNG_NCompass_HMHS.passedCount = RunTestNG_NCompass_HMHS.passedCount
						+ context.getPassedTests().size();
				RunTestNG_NCompass_HMHS.failedCount = RunTestNG_NCompass_HMHS.failedCount
						- context.getPassedTests().size();
				// RunTestNG_NCompass_HMHS.excTcCount =
				// RunTestNG_NCompass_HMHS.passedCount+RunTestNG_NCompass_HMHS.failedCount;
				System.out.println(" Pass Count: " + RunTestNG_NCompass_HMHS.passedCount + " Fail Count: "
						+ RunTestNG_NCompass_HMHS.failedCount);
				extent1.flush();
			}
		} else {
			Object[][] arrayCounts = RunTestNG_NCompass_HMHS.getCountsObj();
			if (extent != null) {

				// int totalTcsCnt = 296;//Integer.parseInt(arrayCounts[0][1].toString());
				RunTestNG_NCompass_HMHS.passedCount = context.getPassedTests().size();
				RunTestNG_NCompass_HMHS.failedCount = context.getFailedTests().size();
				RunTestNG_NCompass_HMHS.excTcCount = RunTestNG_NCompass_HMHS.passedCount
						+ RunTestNG_NCompass_HMHS.failedCount;
				System.out.println(" Pass Count: " + RunTestNG_NCompass_HMHS.passedCount + " Fail Count: "
						+ RunTestNG_NCompass_HMHS.failedCount);

				extent.flush();
				if (failedTc.size() > 0 && RunTestNG_NCompass_HMHS.runCount == 0
						&& RunTestNG_NCompass_HMHS.Config.getProperty("Rerun").toString().equalsIgnoreCase("Y")) {
					RunTestNG_NCompass_HMHS.runCount++;
					formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
					date = new Date();
					starttime = formatter.format(date);
					for (int i = 0; i < failedTc.size(); i++) {
						RunTestNG_NCompass_HMHS.fail--;
					}
					RunFailed_NCompass_HMHS.reRun(failedTc);
					generatereport(reportsPath);
				} else {
					generatereport(reportsPath);
				}
			}

		}
	}

	public void generatereport(String reportsPath) {
		FileUtil.createandwriteFile(defectsListFile, RunTestNG_NCompass_HMHS.failedMethods);
		String path = System.getProperty("user.dir") + RunTestNG_NCompass_HMHS.Config.getProperty("ReportFile");
		String filename_Attachment = ExtentManager.fileName;
		String suiteStatus_Subject;
		String Env_Subject = null;
		Env_Subject = RunTestNG_NCompass_HMHS.Config.getProperty("Environment");

		if (status.equalsIgnoreCase("")) {
			suiteStatus_Subject = "PASS";
		} else
			suiteStatus_Subject = "FAIL";
		printMap(results);
		RunTestNG_NCompass_HMHS.excTcCount = RunTestNG_NCompass_HMHS.passedCount + RunTestNG_NCompass_HMHS.failedCount;
		double passpercentage = (double) (RunTestNG_NCompass_HMHS.passedCount * 100)
				/ RunTestNG_NCompass_HMHS.excTcCount;
		String passPercent = df.format(passpercentage);
		double failpercentage = (double) (RunTestNG_NCompass_HMHS.failedCount * 100)
				/ RunTestNG_NCompass_HMHS.excTcCount;
		String failPercent = df.format(failpercentage);
		String header_content = RunTestNG_NCompass_HMHS.Config.getProperty("Body_Text") + timeStamp_email;
		htmlbuilder_Summary.appendSummary_Header(header_content,
				"Total time taken:" + diffHours + "h " + diffMinutes + "m " + diffSeconds + "s");
		htmlbuilder_Summary.appendSummary("HMHS NCompass", RunTestNG_NCompass_HMHS.excTcCount,
				RunTestNG_NCompass_HMHS.passedCount, RunTestNG_NCompass_HMHS.failedCount, passPercent, failPercent);
		htmlbuilder_Summary.append_closeTable();
		htmlbuilder_Summary.append_ReportsLoc(reportsPath);
		htmlbuilder_Summary.appendSummary_HeaderIntentWise("Intent Wise Summary Report:");
		htmlbuilder_Summary.appendSummary_IntentWise("Member Search", RunTestNG_NCompass_HMHS.passMemSecnt,
				RunTestNG_NCompass_HMHS.failMemSecnt);
		htmlbuilder_Summary.appendSummary_IntentWise("Prospective Member", RunTestNG_NCompass_HMHS.passProsMemcnt,
				RunTestNG_NCompass_HMHS.failProsMemcnt);
		htmlbuilder_Summary.appendSummary_IntentWise("Verify Member", RunTestNG_NCompass_HMHS.passVeriMemcnt,
				RunTestNG_NCompass_HMHS.failVeriMemcnt);
		htmlbuilder_Summary.appendSummary_IntentWise("Member 360", RunTestNG_NCompass_HMHS.passMem360cnt,
				RunTestNG_NCompass_HMHS.failMem360cnt);
		htmlbuilder_Summary.appendSummary_IntentWise("Attach Images", RunTestNG_NCompass_HMHS.passAttach,
				RunTestNG_NCompass_HMHS.failAttach);
		htmlbuilder_Summary.appendSummary_IntentWise("Data Masking", RunTestNG_NCompass_HMHS.passDatamask,
				RunTestNG_NCompass_HMHS.failDatamask);
		htmlbuilder_Summary.appendSummary_IntentWise("Role Provisioning", RunTestNG_NCompass_HMHS.passRole,
				RunTestNG_NCompass_HMHS.failRole);
		htmlbuilder_Summary.appendSummary_IntentWise("Reports", RunTestNG_NCompass_HMHS.passReports,
				RunTestNG_NCompass_HMHS.failReports);
		htmlbuilder_Summary.appendSummary_IntentWise("Manage Claims", RunTestNG_NCompass_HMHS.passCLM,
				RunTestNG_NCompass_HMHS.failCLM);
		htmlbuilder_Summary.appendSummary_IntentWise("Create GSI", RunTestNG_NCompass_HMHS.passGSI,
				RunTestNG_NCompass_HMHS.failGSI);
		htmlbuilder_Summary.appendSummary_IntentWise("Find A Provider", RunTestNG_NCompass_HMHS.passFPR,
				RunTestNG_NCompass_HMHS.failFPR);
		htmlbuilder_Summary.appendSummary_IntentWise("View Totals", RunTestNG_NCompass_HMHS.passTOT,
				RunTestNG_NCompass_HMHS.failTOT);
		htmlbuilder_Summary.appendSummary_IntentWise("View Benefits", RunTestNG_NCompass_HMHS.passBEN,
				RunTestNG_NCompass_HMHS.failBEN);
		htmlbuilder_Summary.appendSummary_IntentWise("Manage Other Coverage", RunTestNG_NCompass_HMHS.passMOC,
				RunTestNG_NCompass_HMHS.failMOC);
		htmlbuilder_Summary.appendSummary_IntentWise("Manage Checks", RunTestNG_NCompass_HMHS.passManageChecks,
				RunTestNG_NCompass_HMHS.failManageChecks);
		htmlbuilder_Summary.appendSummary_IntentWise("Manage PCP or POR", RunTestNG_NCompass_HMHS.passPCP,
				RunTestNG_NCompass_HMHS.failPCP);
		htmlbuilder_Summary.appendSummary_IntentWise("View Authorizations", RunTestNG_NCompass_HMHS.passAUT,
				RunTestNG_NCompass_HMHS.failAUT);
		htmlbuilder_Summary.appendSummary_IntentWise("Scheduled Appointment", RunTestNG_NCompass_HMHS.passSCH,
				RunTestNG_NCompass_HMHS.failSCH);
		htmlbuilder_Summary.appendSummary_IntentWise("Website Support", RunTestNG_NCompass_HMHS.passWS,
				RunTestNG_NCompass_HMHS.failWS);
		htmlbuilder_Summary.appendSummary_IntentWise("Respond to Customer", RunTestNG_NCompass_HMHS.passRTC,
				RunTestNG_NCompass_HMHS.failRTC);
		htmlbuilder_Summary.appendSummary_IntentWise("Research Interaction", RunTestNG_NCompass_HMHS.passRI,
				RunTestNG_NCompass_HMHS.failRI);
		htmlbuilder_Summary.appendSummary_IntentWise("Create Follow Up", RunTestNG_NCompass_HMHS.passFOL,
				RunTestNG_NCompass_HMHS.failFOL);
		htmlbuilder_Summary.appendSummary_IntentWise("Request IDCard", RunTestNG_NCompass_HMHS.passIDC,
				RunTestNG_NCompass_HMHS.failIDC);
		htmlbuilder_Summary.appendSummary_total(RunTestNG_NCompass_HMHS.passedCount,
				RunTestNG_NCompass_HMHS.failedCount);
		htmlbuilder_Summary.append_closeTable();
		htmlbuilder_Summary.append_closebody();

		String htmlcontent = htmlbuilder_Summary.sb.toString();
		System.out.println(htmlcontent);
	
		refereshExcel();
		createApplicationLog();
		// System.out.println("htmlcontent: "+htmlcontent);
		
		  EmailUtil.sendEmailWithAttachment(path, Env_Subject, suiteStatus_Subject,
		  timeStamp_email, path1, htmlcontent, extentFilepath, filename_Attachment);
		 
	}

	public void passedTCsCounts(ITestResult result) {
		if (result.getTestClass().getName().contains("MemberSearch"))
			RunTestNG_NCompass_HMHS.passMemSecnt++;
		else if (result.getTestClass().getName().contains("AttachImages"))
			RunTestNG_NCompass_HMHS.passAttach++;
		else if (result.getTestClass().getName().contains("Prospective"))
			RunTestNG_NCompass_HMHS.passProsMemcnt++;
		else if (result.getTestClass().getName().contains("VerifyMember"))
			RunTestNG_NCompass_HMHS.passVeriMemcnt++;
		else if (result.getTestClass().getName().contains("Member360"))
			RunTestNG_NCompass_HMHS.passMem360cnt++;
		else if (result.getTestClass().getName().contains("DataMasking"))
			RunTestNG_NCompass_HMHS.passDatamask++;
		else if (result.getTestClass().getName().contains("RoleProvising"))
			RunTestNG_NCompass_HMHS.passRole++;
		else if (result.getTestClass().getName().contains("GSI"))
			RunTestNG_NCompass_HMHS.passGSI++;
		else if (result.getTestClass().getName().contains("ManageOtherCoverage")
				|| result.getTestClass().getName().contains("MOC"))
			RunTestNG_NCompass_HMHS.passMOC++;
		else if (result.getTestClass().getName().contains("CreateFollowUp"))
			RunTestNG_NCompass_HMHS.passFOL++;
		else if (result.getTestClass().getName().contains("FindAProvider"))
			RunTestNG_NCompass_HMHS.passFPR++;
		else if (result.getTestClass().getName().contains("ManageChecks"))
			RunTestNG_NCompass_HMHS.passManageChecks++;
		else if (result.getTestClass().getName().contains("ManageClaims"))
			RunTestNG_NCompass_HMHS.passCLM++;
		else if (result.getTestClass().getName().contains("ManagePCPPOR"))
			RunTestNG_NCompass_HMHS.passPCP++;
		else if (result.getTestClass().getName().contains("Report"))
			RunTestNG_NCompass_HMHS.passReports++;
		else if (result.getTestClass().getName().contains("RequestIDCard"))
			RunTestNG_NCompass_HMHS.passIDC++;
		else if (result.getTestClass().getName().contains("ResearchInteraction"))
			RunTestNG_NCompass_HMHS.passRI++;
		else if (result.getTestClass().getName().contains("RespondToCustomer"))
			RunTestNG_NCompass_HMHS.passRTC++;
		else if (result.getTestClass().getName().contains("ScheduleAppointment"))
			RunTestNG_NCompass_HMHS.passSCH++;
		else if (result.getTestClass().getName().contains("ViewAuth"))
			RunTestNG_NCompass_HMHS.passAUT++;
		else if (result.getTestClass().getName().contains("ViewBenefits"))
			RunTestNG_NCompass_HMHS.passBEN++;
		else if (result.getTestClass().getName().contains("TOT"))
			RunTestNG_NCompass_HMHS.passTOT++;
		else if (result.getTestClass().getName().contains("WebsiteSupport"))
			RunTestNG_NCompass_HMHS.passWS++;
		else
			RunTestNG_NCompass_HMHS.passMemSecnt++;
	}

	public void failedTCsCounts(ITestResult result) {
		if (result.getTestClass().getName().contains("MemberSearch"))
			RunTestNG_NCompass_HMHS.failMemSecnt++;
		else if (result.getTestClass().getName().contains("AttachImages"))
			RunTestNG_NCompass_HMHS.failAttach++;
		else if (result.getTestClass().getName().contains("Prospective"))
			RunTestNG_NCompass_HMHS.failProsMemcnt++;
		else if (result.getTestClass().getName().contains("VerifyMember"))
			RunTestNG_NCompass_HMHS.failVeriMemcnt++;
		else if (result.getTestClass().getName().contains("Member360"))
			RunTestNG_NCompass_HMHS.failMem360cnt++;
		else if (result.getTestClass().getName().contains("DataMasking"))
			RunTestNG_NCompass_HMHS.failDatamask++;
		else if (result.getTestClass().getName().contains("RoleProvising"))
			RunTestNG_NCompass_HMHS.failRole++;
		else if (result.getTestClass().getName().contains("GSI"))
			RunTestNG_NCompass_HMHS.failGSI++;
		else if (result.getTestClass().getName().contains("ManageOtherCoverage")
				|| result.getTestClass().getName().contains("MOC"))
			RunTestNG_NCompass_HMHS.failMOC++;
		else if (result.getTestClass().getName().contains("CreateFollowUp"))
			RunTestNG_NCompass_HMHS.failFOL++;
		else if (result.getTestClass().getName().contains("FindAProvider"))
			RunTestNG_NCompass_HMHS.failFPR++;
		else if (result.getTestClass().getName().contains("ManageChecks"))
			RunTestNG_NCompass_HMHS.failManageChecks++;
		else if (result.getTestClass().getName().contains("ManageClaims"))
			RunTestNG_NCompass_HMHS.failCLM++;
		else if (result.getTestClass().getName().contains("ManagePCPPOR"))
			RunTestNG_NCompass_HMHS.failPCP++;
		else if (result.getTestClass().getName().contains("Report"))
			RunTestNG_NCompass_HMHS.failReports++;
		else if (result.getTestClass().getName().contains("RequestIDCard"))
			RunTestNG_NCompass_HMHS.failIDC++;
		else if (result.getTestClass().getName().contains("ResearchInteraction"))
			RunTestNG_NCompass_HMHS.failRI++;
		else if (result.getTestClass().getName().contains("RespondToCustomer"))
			RunTestNG_NCompass_HMHS.failRTC++;
		else if (result.getTestClass().getName().contains("ScheduleAppointment"))
			RunTestNG_NCompass_HMHS.failSCH++;
		else if (result.getTestClass().getName().contains("ViewAuth"))
			RunTestNG_NCompass_HMHS.failAUT++;
		else if (result.getTestClass().getName().contains("ViewBenefits"))
			RunTestNG_NCompass_HMHS.failBEN++;
		else if (result.getTestClass().getName().contains("TOT"))
			RunTestNG_NCompass_HMHS.failTOT++;
		else if (result.getTestClass().getName().contains("WebsiteSupport"))
			RunTestNG_NCompass_HMHS.failWS++;
		else
			RunTestNG_NCompass_HMHS.failMemSecnt++;
	}

	public void resultStatus(ITestResult result, String tcname, String tcstatus) {
		List<String> values = new ArrayList<String>();
		values.add(0, result.getTestClass().getName());
		values.add(1, tcname);
		values.add(2, tcstatus);
		results.put(tcname, values);
	}

	public void printMap(Map<String, List<String>> results) {
		for (String name : results.keySet()) {
			List<String> value = results.get(name);
			String result = value.get(0);
			String tcname = value.get(1);
			String tcstatus = value.get(2);
			updatedetailreport(result, tcname, tcstatus);
		}
	}

	public void updatedetailreport(String result, String tcname, String tcstatus) {
		int rowNum = 0;
		String pathLoc = System.getProperty("user.dir") + RunTestNG_NCompass_HMHS.Config.getProperty("EXTREPORT_LOC");
		String reportLoc = pathLoc + ExtentManager.fileName;
		excel = new ExcelReader(reportFilePath);
		rowNum = excel.getCellRowNum("HMHS", "TestCases", tcname);
		excel.setCellData("HMHS", "Status", rowNum, tcstatus);
		excel.setCellData("HMHS", "Report File Name", rowNum, reportLoc);
	}

	public void getdetailreport(ITestResult result, String tcname, String tcstatus) {
		int rowNum = 0;
		String pathLoc = RunTestNG_NCompass_HMHS.Config.getProperty("EXTREPORT_LOC");
		String reportLoc = System.getProperty("user.dir") + pathLoc + ExtentManager.fileName;
		excel = new ExcelReader(reportFilePath);
		rowNum = excel.getCellRowNum("HMHS", "TestCases", tcname);
		excel.setCellData("HMHS", "Status", rowNum, tcstatus);
		excel.setCellData("HMHS", "Report File Name", rowNum, reportLoc);
	}

	@SuppressWarnings("unused")
	public void refereshExcel() {
		FileInputStream excelFile;

		try {
			excelFile = new FileInputStream(new File(reportFilePath));
			XSSFWorkbook excelWorkbook = new XSSFWorkbook(excelFile);
			XSSFSheet excelSheet = excelWorkbook.getSheet("Execution Summary Report");
			XSSFFormulaEvaluator.evaluateAllFormulaCells(excelWorkbook);
			excelFile.close();
			FileOutputStream outExcelFile = new FileOutputStream(new File(reportFilePath));
			excelWorkbook.write(outExcelFile);
			outExcelFile.close();
			FileOutputStream outExcelFile1 = new FileOutputStream(new File(reportFilePath1));
			excelWorkbook.write(outExcelFile1);
			outExcelFile.close();

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void createApplicationLog() {
		FileInputStream instream = null;
		FileOutputStream outstream = null;
		try {
			Date d = new Date();
			File infile = new File(System.getProperty("user.dir") + "/src/test/resources/logs/Application.log");
			File outfile = new File(System.getProperty("user.dir") + "/src/test/resources/logs/Application-"
					+ d.toString().replace(":", "_").replace(" ", "_") + ".log");
			instream = new FileInputStream(infile);
			outstream = new FileOutputStream(outfile);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = instream.read(buffer)) > 0) {
				outstream.write(buffer, 0, length);
			}
			instream.close();
			outstream.close();
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
	}
}
