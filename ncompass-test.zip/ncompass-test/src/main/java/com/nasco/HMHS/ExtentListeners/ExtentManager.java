package com.nasco.HMHS.ExtentListeners;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DriverManager;

public class ExtentManager {
	private static ExtentReports extent;
	public static String fileName;
	public static String logFileName;
	
	public static ExtentHtmlReporter htmlReporter;

	public static ExtentReports getInstance() {

		if (extent == null) {
			Date d = new Date();
			fileName = "NCompass_HMHS_ExtentReport" + d.toString().replace(":", "_").replace(" ", "_") + ".html";
			logFileName = System.getProperty("user.dir") + "src/test/resources/logs/Application"
					+ d.toString().replace(":", "_").replace(" ", "_") + ".log";
			 htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir")
						+ RunTestNG_NCompass_HMHS.Config.getProperty("EXTREPORT_LOC") + fileName);
			 htmlReporter.config().setDocumentTitle("HMHS Regression Automation"); 
             // Name of the report
			 htmlReporter.config().setReportName("HMHS NCompass Regression Automation"); 
             // Dark Theme
			 htmlReporter.config().setTheme(Theme.STANDARD);	
			 extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			}

		return extent;

	}
	
	public static ExtentReports getFailureInstance() {
		if (extent == null) {
			Date d = new Date();
			fileName = "NCompass_HMHS_ExtentReport_Rerun" + d.toString().replace(":", "_").replace(" ", "_") + ".html";
			logFileName = System.getProperty("user.dir") + "src/test/resources/logs/Application"
					+ d.toString().replace(":", "_").replace(" ", "_") + ".log";
			// htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir")
				//		+ RunTestNG_NCompass_HMHS.Config.getProperty("EXTREPORT_LOC") + fileName);
			 // Dark Theme
			 htmlReporter.config().setTheme(Theme.STANDARD);	
			 extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			}
			return extent;

	}
	public static String screenshotPath;
	public static String screenshotName;

	public static void captureScreenshot(String testCaseName) {

		File scrFile = ((TakesScreenshot) DriverManager.getDriver()).getScreenshotAs(OutputType.FILE);
		Date d = new Date();
		screenshotName = testCaseName + "_" + d.toString().replace(":", "_").replace(" ", "_") + ".jpg";
		try {
			FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")
					+ RunTestNG_NCompass_HMHS.Config.getProperty("EXTREPORT_LOC") + screenshotName));
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
}
