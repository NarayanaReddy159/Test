package com.nasco.HMHS.TestScripts.G2.VerifyMember;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.Member360Page;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Pages.VerifyMemberPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC006_VerifyMember_AssociateContactNotaMember extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC006_VerifyMember_AssociateContactNotaMember(Hashtable<String, String> data) throws Exception {
		try{
		String methodName="HMHS_AUTC006_VerifyMember_AssociateContactNotaMember";
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside "+methodName);
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug(methodName+" - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser( getDefaultUserName(),
				getDefaultPassword());
		log.debug(methodName+" -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		String interaction = searchMember.getLIInteractionID();
		log.debug("Interaction id: " + interaction);
		test.log(Status.INFO,"Interaction id: " + interaction);
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		test.log(Status.INFO,"Interaction id: " + interaction);
		searchMember.contactisNotmember();
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + " Selected from the search results and navigated to verify member page");
		test.log(Status.INFO,data.get("Fname") + " Selected from the search results and navigated to verify member page");
		VerifyMemberPage verifyMember=searchMember.OpenVerifyMember();
		verifyMember.getAssociateMemberList(data);
		verifyMember.selectAssociateMember(data);
		verifyMember.verifyAssociate(data);
		Member360Page member360= verifyMember.OpenMember360Page();
		member360.disclosureLevel(data);
		log.debug("Member disclosure level in Member360 is: "+data.get("ExpectedDisclosure"));
		test.log(Status.INFO,"Member disclosure level in Member360 is: "+data.get("ExpectedDisclosure"));
		InteractionManagerPage interactionManger =searchMember.openInteractionPage();
		interactionManger.openTask();
		interactionManger.wrapUp("wrapping up intent");
		log.debug("Interaction wrapped up successfully");
		test.log(Status.INFO,"Interaction wrapped up successfully");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}	
		
	}
	@AfterMethod
	public void tearDown() throws Exception  {

		test.log(Status.INFO, "HMHS_AUTC006_VerifyMember_AssociateContactNotaMember Completed.");
		log.debug("HMHS_AUTC006_VerifyMember_AssociateContactNotaMember Completed.");
		quit();

	}
}
