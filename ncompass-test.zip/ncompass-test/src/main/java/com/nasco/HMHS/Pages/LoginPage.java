package com.nasco.HMHS.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.Status;
import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.Setup.BasePage;
import com.nasco.HMHS.utilities.DriverManager;

@SuppressWarnings("rawtypes")
public class LoginPage extends BasePage {

	// Log in page Fields
	// user Name text box
	@FindBy(id = "username")
	public WebElement txtUserName;
	// Password text box
	@FindBy(id = "password")
	public WebElement txtPassword;
	
	// submit-button
	//@FindBy(xpath = "//form/div[4]/span/input")
		@FindBy(id = "submit-button")
	public WebElement btnLoginMO;

	@FindBy(id = "submit-button")
	public WebElement btnLoginDev;
	
	@FindBy(xpath = "//div[1]/div/div/div/ul/li[2]/a/span[1]/span")
	public WebElement myWorkIcon;
	@FindBy(xpath = "(//a[@class='Header_nav'])[3]")
	public WebElement MenuDropdown;
	@FindBy(xpath = "//span[contains(text(),'Logout')]")
	public WebElement LogOut;
	@FindBy(xpath = "//span[contains(text(),'Switch Application')]")
	public WebElement switchApp;
	@FindBy(xpath = "//span[contains(text(),'HHPCSD_May Rel (HMCSD Level2 Manager_R1)')]")
	public WebElement mayRel;
	
	

	// open login page
	@SuppressWarnings("unchecked")
	public LoginPage open(String url) {

		//System.out.println("Page Opened" + url);
		BaseTest.log.info("Driver Initialized !!!");
		DriverManager.getDriver().navigate().to(url);
		BaseTest.log.info("Navigated to URL:" + url);
		test.log(Status.INFO, "Navigated to URL:" + url);
		return (LoginPage) openPage(LoginPage.class);
	}

	
	public void Redirect(String url) {

		//System.out.println("Page Opened" + url);
		BaseTest.log.info("Driver Initialized !!!");
		DriverManager.getDriver().navigate().to(url);
		BaseTest.log.info("Navigated to URL:" + url);
		test.log(Status.INFO, "Navigated to URL:" + url);
	}
	
	// Login to application as valid user

	@SuppressWarnings("unchecked")
	public HomePage doLoginAsValidUser(String username,String password) {

		try {

			//webElementSendText(txtUserName, username, "User Name");
			//webElementSendText(txtPassword, password, "Password");
			txtUserName.sendKeys(username);
			txtPassword.sendKeys(password);
			if (RunTestNG_NCompass_HMHS.Config.getProperty("Environment").toString().equalsIgnoreCase("MO")
					||RunTestNG_NCompass_HMHS.Config.getProperty("Environment").toString().equalsIgnoreCase("INTG")) {
				webElementClick(btnLoginMO, "Login");
			} else if (RunTestNG_NCompass_HMHS.Config.getProperty("Environment").toString().equalsIgnoreCase("DEV")) {
				webElementClick(btnLoginDev, "Login");
			}
			
			waitSleep(3000);
			/*
			 * switchToDefault(); webElementClick(MenuDropdown, "Menu Dropdown");
			 * waitSleep(3500); HoverOnElement(switchApp,"Switch Application");
			 * //HoverOnElement(marRel,"MarchRelease");
			 * 
			 * Actions builder = new Actions(driver);
			 * builder.moveToElement(mayRel).click().build().perform();
			 * 
			 * waitSleep(3000);
			 */
			
		} catch (Exception e) {
			e.printStackTrace();
			BaseTest.log.error("Error on doLoginAsValidUser method " + e);
			test.log(Status.FAIL, "Error on doLoginAsValidUser method " + e);
			throw e;
		}

		return (HomePage) openPage(HomePage.class);
	}

	
	@Override
	protected ExpectedCondition getPageLoadCondition() {
		try{
			return ExpectedConditions.visibilityOf(txtPassword);
		}catch(Exception e)
		{
			throw e;
		}
		
	}

}
