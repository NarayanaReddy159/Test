package com.nasco.HMHS.TestScripts.G1;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC019_Add_Prospective_Member extends BaseTest{

	
	@Test(dataProviderClass=DataProviders.class,dataProvider="HMHS_Ncompass_G1DP")
    public void HMHS_AUTC019_Add_Prospective_Member(Hashtable<String,String> data) throws Exception {
		try{
		setUpFramework();
		test=DriverManager.getExtentReport();
		log.info("Inside TC019_Add_Prospective_Member");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("TC019_Add_Prospective_Member - Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : "+RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage=login.doLoginAsValidUser(getDefaultUserName(), getDefaultPassword());
		log.debug("TC019_Add_Prospective_Member -Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		test.log(Status.INFO, "Username entered as "+RunTestNG_NCompass_HMHS.Config.getProperty("username"));
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.movetoProsMem();
		log.debug("Moved to Prospective Member page.");
		test.log(Status.INFO,"Moved to Prospective Member page.");
		searchMember.AddProsMem( data);
		log.debug("Prospective Member Added.");
		test.log(Status.INFO,"Prospective Member Added.");
		searchMember.WrapUp_MemberNotFound();
		searchMember.WrapUpMemNotFoundSubmit( "Wrap up interaction", "Wrong Number");
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  {
		
		test.log(Status.INFO, "TC019_Add_Prospective_Member Completed");
		log.debug("TC019_Add_Prospective_Member Completed");
		quit();
		
	}
}
