package com.nasco.HMHS.TestScripts.G2_DataMasking;

import java.util.ArrayList;
import java.util.Hashtable;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.nasco.HMHS.Base.BaseTest;
import com.nasco.HMHS.Pages.HomePage;
import com.nasco.HMHS.Pages.InteractionManagerPage;
import com.nasco.HMHS.Pages.LoginPage;
import com.nasco.HMHS.Pages.Member360Page;
import com.nasco.HMHS.Pages.MemberSearchPage;
import com.nasco.HMHS.Run.RunTestNG_NCompass_HMHS;
import com.nasco.HMHS.utilities.DataProviders;
import com.nasco.HMHS.utilities.DriverManager;
import com.aventstack.extentreports.Status;

public class HMHS_TC001_DataMasking_Contractid_masked_ContractTab extends BaseTest {

	@Test(dataProviderClass = DataProviders.class, dataProvider = "HMHS_Ncompass_G2DP")
	public void HMHS_AUTC001_DataMasking_Contractid_masked_ContractTab (Hashtable<String, String> data) throws Exception {
		try{
		setUpFramework();
		test = DriverManager.getExtentReport();
		log.info("Inside HMHS_TC001_DataMasking_Contractid_masked_ContractTab");
		openBrowser(RunTestNG_NCompass_HMHS.Config.getProperty("Browser").toString());
		log.debug("HMHS_TC001_DataMasking_Contractid_masked_ContractTab - Launched Browser : "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		test.log(Status.INFO, "Launched Browser : " + RunTestNG_NCompass_HMHS.Config.getProperty("Browser"));
		LoginPage login = new LoginPage().open(RunTestNG_NCompass_HMHS.Config.getProperty("URL").toString());
		HomePage homepage = login.doLoginAsValidUser(RunTestNG_NCompass_HMHS.Config.getProperty("username4"),
				RunTestNG_NCompass_HMHS.Config.getProperty("password4"));
		log.debug("HMHS_TC001_DataMasking_Contractid_masked_ContractTab -Username entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("username4") + " and Password entered as "
				+ RunTestNG_NCompass_HMHS.Config.getProperty("password4"));
		test.log(Status.INFO, "Username entered as " + RunTestNG_NCompass_HMHS.Config.getProperty("username4")
				);
		MemberSearchPage searchMember = homepage.clickOnHMHSLiveInteractionMember();
		searchMember.HMHSsearchMember(data.get("MemberID"));
		log.debug("Member Search Completed");
		test.log(Status.INFO, "Member Search Completed");
		searchMember.HMHSselectMemberAndNavigatebyfname(data.get("Fname"));
		log.debug(data.get("Fname") + "Selected from the search results and navigated to verify member page");
		test.log(Status.INFO, data.get("Fname") + "Selected from the search results and navigated to verify member page");
		log.debug("Member Submit Completed.");
		test.log(Status.INFO, "Member Submit Completed.");
		InteractionManagerPage InteractionManager=searchMember.Verifymember();
        log.debug("Member Verified successfully.");
        test.log(Status.INFO, "Member Verified successfully.");
    	Member360Page mem360=homepage.Member360Page();
		log.debug("Navigate to Member 360 page ");
		test.log(Status.INFO, "Navigate to Member 360 page .");
		
        InteractionManager.openTask();
		mem360.contractTab_DataMasking(data.get("Contractheader"),data.get("Expectedcontractdetails"));
		log.debug("Navigate to contract Tab ");
		test.log(Status.INFO, "Navigate to contract Tab .");
		
		InteractionManager.wrapUp(data.get("Comments"));
		log.debug("Navigate to Wrap up screen");
		test.log(Status.INFO, "Navigate to Wrap up screen.");
		
		}
		catch(Exception e)
		{
			if(RunTestNG_NCompass_HMHS.runCount==0)
			{
				String method=new Throwable().getStackTrace()[0].getMethodName();
				try{
					if(RunTestNG_NCompass_HMHS.failedData.get(method).equals(null))
					{
						RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
					else{
						RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
					}
				}catch(Exception e1)
				{
					RunTestNG_NCompass_HMHS.failedData.put(method, new ArrayList<Hashtable<String, String>>());
					RunTestNG_NCompass_HMHS.failedData.get(method).add(data);
				}
			}
			throw e;
		}
	}
	@AfterMethod
	public void tearDown() throws Exception  
	{	test.log(Status.INFO, "HMHS_TC001_DataMasking_Contractid_masked_ContractTab completed.");
		log.debug("HMHS_TC001_DataMasking_Contractid_masked_ContractTab completed.");
		quit();
	}
}
